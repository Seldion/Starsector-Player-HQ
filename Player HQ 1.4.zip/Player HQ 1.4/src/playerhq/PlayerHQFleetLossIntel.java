package playerhq;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.util.Set;

public class PlayerHQFleetLossIntel extends BaseIntelPlugin {

	public static final String ICON_PATH = PlayerHQMonthlyReportIntel.ICON_PATH;

	private String fleetLabel;
	private String cause;
	private long timestamp;

	public static void report(SectorEntityToken station, String fleetLabel, String cause) {
		if (station == null) return;

		PlayerHQFleetLossIntel intel = new PlayerHQFleetLossIntel();
		intel.fleetLabel = fleetLabel;
		intel.cause = cause;
		intel.timestamp = Global.getSector().getClock().getTimestamp();

		Global.getSector().getIntelManager().addIntel(intel);
		Global.getSector().getCampaignUI().addMessage("The " + fleetLabel + " has been destroyed by " + cause + ".",
				Misc.getNegativeHighlightColor());
	}

	@Override
	protected String getName() {
		return fleetLabel + " Destroyed";
	}

	@Override
	public String getIcon() {
		return ICON_PATH;
	}

	@Override
	public boolean isPlayerVisible() {
		return !isHidden() && !isEnded();
	}

	@Override
	public Set<String> getIntelTags(SectorMapAPI map) {
		Set<String> tags = super.getIntelTags(map);
		tags.add("Personal");
		return tags;
	}

	@Override
	public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		float opad = 10f;
		info.addPara(getName(), opad);
		info.addPara("The " + fleetLabel + " was destroyed by " + cause + " on "
				+ Global.getSector().getClock().createClock(timestamp).getDateString() + ".", opad, Misc.getNegativeHighlightColor());
		info.addPara("Its committed ships and crew aren't lost for good -- replacements will be ready in about "
				+ "a month.", opad);
	}
}
