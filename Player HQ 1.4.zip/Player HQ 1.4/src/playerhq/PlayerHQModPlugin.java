package playerhq;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;

import java.util.List;

public class PlayerHQModPlugin extends BaseModPlugin {

	@Override
	public void onApplicationLoad() throws Exception {
		Global.getSettings().loadTexture(PlayerHQMonthlyReportIntel.ICON_PATH);
	}

	@Override
	public void onGameLoad(boolean newGame) {
		if (!Global.getSector().getListenerManager().hasListenerOfClass(PlayerHQIncomeReportListener.class)) {
			Global.getSector().getListenerManager().addListener(new PlayerHQIncomeReportListener(), true);
		}
		if (!Global.getSector().getListenerManager().hasListenerOfClass(PlayerHQFleetLossListener.class)) {
			Global.getSector().getListenerManager().addListener(new PlayerHQFleetLossListener(), true);
		}

		grantAbilityIfMissing(Ids.ABILITY_CONSTRUCT);
		grantAbilityIfMissing(Ids.ABILITY_CALL_RESUPPLY);
		PlayerHQItemDescriptions.apply();
	}

	private void grantAbilityIfMissing(String abilityId) {
		MutableCharacterStatsAPI stats = Global.getSector().getPlayerStats();
		if (stats == null) return;

		List<String> granted = stats.getGrantedAbilityIds();
		if (!granted.contains(abilityId)) {
			granted.add(abilityId);
		}
	}
}
