package playerhq;

public class Ids {

	public static final String STATION_ENTITY_LOWTECH = "playerhq_station_lowtech";
	public static final String STATION_ENTITY_HIGHTECH = "playerhq_station_hightech";

	public static final String STATION_DESCRIPTION_ID = "playerhq_station";

	public static final String INDUSTRY_DOCKYARD = "playerhq_dockyard";

	public static final String TAG_STATION = "playerhq";

	public static final String ABILITY_CONSTRUCT = "playerhq_construct";
	public static final String ABILITY_CALL_RESUPPLY = "playerhq_call_resupply";
}
