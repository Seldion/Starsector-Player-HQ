package playerhq;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.loading.Description;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.RecreationalHubModule;

public class PlayerHQItemDescriptions {

	private static final String MARKER = "== Player HQ effects ==";

	public static void apply() {
		appendBlock(Items.DEALMAKER_HOLOSUITE,
				"Resort (as VR Suites): +" + Math.round(RecreationalHubModule.HOLOSUITE_BONUS * 100f) + "% income.\n"
						+ "Military Paradigm: contributes to Marine training speed.");

		appendBlock(Items.ORBITAL_FUSION_LAMP,
				"Resort (as Build Beach Resort): +" + Math.round(RecreationalHubModule.FUSION_LAMP_BONUS * 100f) + "% income.\n"
						+ "Bio-Dome: required to build.");

		appendBlock(Items.CATALYTIC_CORE,
				"Manufactorium: reduces the ore cost of refining metals per batch (-"
						+ (int) IndustrialHubModule.CATALYTIC_CORE_ORE_REDUCTION + ") and increases metals "
						+ "output per batch (+" + (int) IndustrialHubModule.CATALYTIC_CORE_METAL_OUTPUT_BONUS + "); "
						+ "reduces the rare ore cost of refining transplutonics per batch (-"
						+ (int) IndustrialHubModule.CATALYTIC_CORE_RARE_ORE_REDUCTION + ") and increases "
						+ "transplutonics output per batch (+"
						+ (int) IndustrialHubModule.CATALYTIC_CORE_TRANSPLUTONICS_OUTPUT_BONUS + ").");

		appendBlock(Items.SYNCHROTRON,
				"Manufactorium: unlocks production of Fuel from Volatiles. ("
						+ (int) IndustrialHubModule.FUEL_PER_BATCH + " fuel per "
						+ (int) IndustrialHubModule.VOLATILES_PER_FUEL_BATCH + " volatile)");

		String nanoforgeShared = "Manufactorium: unlocks production of Domestic Goods, Luxury Goods, and Heavy Armaments.\n"
				+ "Strategic Assembly: reduces ship and weapon construction costs.";
		appendBlock(Items.CORRUPTED_NANOFORGE, nanoforgeShared
				+ "\nStrategic Assembly discount (Corrupted): "
				+ Math.round(AssemblyBayModule.CORRUPTED_NANOFORGE_DISCOUNT * 100f) + "%.");
		appendBlock(Items.PRISTINE_NANOFORGE, nanoforgeShared
				+ "\nStrategic Assembly discount (Pristine): "
				+ Math.round(AssemblyBayModule.PRISTINE_NANOFORGE_DISCOUNT * 100f) + "%.");
	}

	private static void appendBlock(String itemId, String body) {
		Description desc = Global.getSettings().getDescription(itemId, Description.Type.RESOURCE);
		if (desc == null) return;

		String text = desc.getText1();
		if (text != null && text.contains(MARKER)) return;

		String addition = "\n\n" + MARKER + "\n" + body;
		desc.setText1((text == null ? "" : text) + addition);
	}
}
