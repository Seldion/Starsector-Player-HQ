package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import playerhq.Ids;
import playerhq.modules.MilitaryWardModule;
import playerhq.util.PlayerHQUtils;

import java.awt.Color;

public class CallResupplyFleetAbility extends BaseDurationAbility {

	private static SectorEntityToken findStation() {
		return PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
	}

	@Override
	public boolean isUsable() {
		SectorEntityToken station = findStation();
		if (station == null || !MilitaryWardModule.hasResupplyBayBuilt(station)) return false;
		if (MilitaryWardModule.isResupplyFleetActive(station)) return false;
		return super.isUsable();
	}

	@Override
	protected void activateImpl() {
		SectorEntityToken station = findStation();
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (station == null || playerFleet == null || !MilitaryWardModule.hasResupplyBayBuilt(station)) return;

		if (MilitaryWardModule.dispatchResupplyFleet(station, playerFleet)) {
			Global.getSector().getCampaignUI().addMessage("The Resupply Fleet departs the Player HQ and starts "
					+ "heading your way.");
		}
	}

	@Override
	protected void applyEffect(float amount, float level) { }

	@Override
	protected void deactivateImpl() { }

	@Override
	protected void cleanupImpl() { }

	@Override
	public boolean hasTooltip() {
		return true;
	}

	@Override
	public boolean isTooltipExpandable() {
		return false;
	}

	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
		Color bad = Misc.getNegativeHighlightColor();
		float pad = 10f;

		tooltip.addTitle("Call Resupply Fleet");
		tooltip.addPara("Summons the Player HQ's Resupply Fleet -- a real fleet that spawns at the Player HQ and "
				+ "travels to intercept you, wherever you are, crossing systems on its own if it has to. It can't "
				+ "be attacked, and doesn't need fuel, supplies, or crew of its own to make the trip.", pad);
		tooltip.addPara("Once it reaches you, a transfer window opens letting you take Supplies, Fuel, and Crew "
				+ "from it -- limited to whatever the Player HQ's own storage currently has on hand. While it's "
				+ "escorting you, flying far enough away and back up to it opens the window again, so you can grab "
				+ "more before it heads home.", pad);
		tooltip.addPara("It escorts your fleet for %s days, then heads back to the Player HQ on its own "
				+ "-- heading for a jump point and out through hyperspace if it has to. The ability can't be used "
				+ "again until it completes the whole round trip and docks, plus a further %s-day cooldown.", pad,
				Misc.getHighlightColor(), MilitaryWardModule.RESUPPLY_FLEET_FOLLOW_DAYS + "",
				MilitaryWardModule.RESUPPLY_FLEET_POST_RETURN_COOLDOWN_DAYS + "");

		SectorEntityToken station = findStation();
		if (station == null) {
			tooltip.addPara("Requires a Player HQ station to exist.", bad, pad);
		} else if (!MilitaryWardModule.hasResupplyBayBuilt(station)) {
			tooltip.addPara("Requires a Resupply Bay to be crewed in the Player HQ's Fleet HQ.", bad, pad);
		} else if (MilitaryWardModule.isResupplyFleetActive(station)) {
			tooltip.addPara("The Resupply Fleet is currently " + MilitaryWardModule.getResupplyFleetStatusText(station)
					+ ".", bad, pad);
		}
	}
}
