package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoPickerListener;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import playerhq.util.PlayerHQUtils;

import java.util.Map;

public class ResupplyTransferDialogPlugin implements InteractionDialogPlugin {

	private final SectorEntityToken station;
	private final CargoAPI offer;
	private final Runnable onDismiss;

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;

	public ResupplyTransferDialogPlugin(SectorEntityToken station, CargoAPI offer, Runnable onDismiss) {
		this.station = station;
		this.offer = offer;
		this.onDismiss = onDismiss;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		this.text = dialog.getTextPanel();

		text.addPara("Take Supplies, Fuel, and Crew from the Resupply Fleet's stores.");

		dialog.showCargoPickerDialog("Resupply Fleet", "Take", "Done", false, 400f, offer,
				new CargoPickerListener() {
					@Override
					public void pickedCargo(CargoAPI picked) {
						CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
						float suppliesTaken = picked.getSupplies();
						float fuelTaken = picked.getFuel();
						int crewTaken = picked.getCrew();

						if (storage != null) {
							storage.removeSupplies(Math.min(suppliesTaken, storage.getSupplies()));
							storage.removeFuel(Math.min(fuelTaken, storage.getFuel()));
							storage.removeCrew(Math.min(crewTaken, storage.getCrew()));
						}

						CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
						if (playerFleet != null) {
							playerFleet.getCargo().addSupplies(suppliesTaken);
							playerFleet.getCargo().addFuel(fuelTaken);
							playerFleet.getCargo().addCrew(crewTaken);
						}

						text.addPara("Transfer complete.");
						dialog.dismiss();
						if (onDismiss != null) onDismiss.run();
					}

					@Override
					public void cancelledCargoSelection() {
						dialog.dismiss();
						if (onDismiss != null) onDismiss.run();
					}

					@Override
					public void recreateTextPanel(TooltipMakerAPI panel, CargoAPI cargo, CargoStackAPI pickedUp,
							boolean pickedUpFromSource, CargoAPI combined) {
						panel.addPara("Take Supplies, Fuel, and Crew from the Resupply Fleet's stores -- limited to "
								+ "whatever the Player HQ's own storage currently has on hand.", 0f);
					}
				});
	}

	@Override
	public void optionSelected(String optionText, Object optionData) { }

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
