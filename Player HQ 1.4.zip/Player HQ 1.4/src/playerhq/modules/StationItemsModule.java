package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class StationItemsModule {

	public static final String SPACE_ELEVATOR_MEMORY_KEY = "$playerhq_stationitem_spaceelevator";
	public static final String PUBLIC_SHUTTLES_MEMORY_KEY = "$playerhq_stationitem_publicshuttles";

	public static final float BASE_ACCESSIBILITY = 25f;
	public static final float SPACE_ELEVATOR_ACCESSIBILITY_BONUS = 50f;
	public static final float PUBLIC_SHUTTLES_ACCESSIBILITY_BONUS = 25f;

	public static final float INDUSTRIAL_PLANNING_ACCESSIBILITY_BONUS = 15f;

	public static final float SPACE_ELEVATOR_METALS_COST = 2000f;
	public static final float SPACE_ELEVATOR_TRANSPLUTONICS_COST = 500f;
	public static final float SPACE_ELEVATOR_HEAVY_MACHINERY_COST = 100f;

	public static final float PUBLIC_SHUTTLES_METALS_COST = 1000f;
	public static final float PUBLIC_SHUTTLES_TRANSPLUTONICS_COST = 250f;
	public static final float PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST = 50f;

	public static float getAccessibility(SectorEntityToken station) {
		float accessibility = BASE_ACCESSIBILITY;
		if (hasSpaceElevatorInstalled(station)) accessibility += SPACE_ELEVATOR_ACCESSIBILITY_BONUS;
		if (hasPublicShuttlesInstalled(station)) accessibility += PUBLIC_SHUTTLES_ACCESSIBILITY_BONUS;
		if (hasIndustrialPlanningSkill()) accessibility += INDUSTRIAL_PLANNING_ACCESSIBILITY_BONUS;
		return accessibility;
	}

	public static float getAccessibilityMultiplier(SectorEntityToken station) {
		return getAccessibility(station) / 100f;
	}

	public static boolean hasIndustrialPlanningSkill() {
		return Global.getSector().getPlayerStats() != null
				&& Global.getSector().getPlayerStats().getSkillLevel(Skills.INDUSTRIAL_PLANNING) > 0;
	}

	public static boolean hasSpaceElevatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(SPACE_ELEVATOR_MEMORY_KEY);
	}

	public static boolean hasSpaceElevatorInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.FULLERENE_SPOOL, null)) >= 1;
	}

	public static boolean hasSpaceElevatorCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.FULLERENE_SPOOL)
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= SPACE_ELEVATOR_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= SPACE_ELEVATOR_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= SPACE_ELEVATOR_HEAVY_MACHINERY_COST;
	}

	public static void installSpaceElevator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSpaceElevatorCost(station, playerFleet)) return;
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.FULLERENE_SPOOL, 1);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, SPACE_ELEVATOR_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, SPACE_ELEVATOR_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, SPACE_ELEVATOR_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, true);
	}

	public static void refundSpaceElevator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSpaceElevatorInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FULLERENE_SPOOL, null), 1);
		cargo.addCommodity(Commodities.METALS, SPACE_ELEVATOR_METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, SPACE_ELEVATOR_TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, SPACE_ELEVATOR_HEAVY_MACHINERY_COST * fraction);
		station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, false);
	}

	public static void uninstallSpaceElevator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSpaceElevatorInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FULLERENE_SPOOL, null), 1);
			storage.addCommodity(Commodities.METALS, SPACE_ELEVATOR_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, SPACE_ELEVATOR_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.HEAVY_MACHINERY, SPACE_ELEVATOR_HEAVY_MACHINERY_COST * fraction);
		}
		station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, false);
	}

	public static boolean hasPublicShuttlesInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(PUBLIC_SHUTTLES_MEMORY_KEY);
	}

	public static boolean hasPublicShuttlesCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= PUBLIC_SHUTTLES_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= PUBLIC_SHUTTLES_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST;
	}

	public static void installPublicShuttles(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasPublicShuttlesCost(station, playerFleet)) return;
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, PUBLIC_SHUTTLES_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, PUBLIC_SHUTTLES_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, true);
	}

	public static void refundPublicShuttles(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasPublicShuttlesInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.addCommodity(Commodities.METALS, PUBLIC_SHUTTLES_METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, PUBLIC_SHUTTLES_TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST * fraction);
		station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, false);
	}

	public static void uninstallPublicShuttles(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasPublicShuttlesInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(Commodities.METALS, PUBLIC_SHUTTLES_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, PUBLIC_SHUTTLES_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.HEAVY_MACHINERY, PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST * fraction);
		}
		station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, false);
	}

}
