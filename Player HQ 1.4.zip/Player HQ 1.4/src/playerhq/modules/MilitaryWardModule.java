package playerhq.modules;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainPlugin;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelAtEntity;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelData;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelRank;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidBeltTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import playerhq.PlayerHQFleetLossIntel;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.abilities.ResupplyTransferDialogPlugin;
import playerhq.util.PlayerHQUtils;

public class MilitaryWardModule {

	public static final String MEMORY_KEY = "$playerhq_module_militaryward";
	public static final String HOLOSUITE_MEMORY_KEY = "$playerhq_module_militaryward_holosuite";
	public static final String DRONE_REPLICATOR_MEMORY_KEY = "$playerhq_module_militaryward_dronereplicator";
	public static final String AICORE_MEMORY_KEY = "$playerhq_module_militaryward_aicore";

	public static final float CREDIT_COST = 75000f;
	public static final float METALS_COST = 4000f;
	public static final float TRANSPLUTONICS_COST = 2000f;
	public static final float HEAVY_MACHINERY_COST = 200f;

	public static final float MAX_PERSONNEL = 5000f;

	public static final float CREW_PRODUCTION_PER_MONTH = 250f;
	public static final float MARINE_PRODUCTION_PER_MONTH = 100f;

	public static final float CREW_STIPEND_PER_UNIT = 0.10f;
	public static final float MARINE_STIPEND_PER_UNIT = 5f;

	public static final float TRAINING_RATE_HOLODECK_ONLY = 0.03f;
	public static final float TRAINING_RATE_DRONE_REPLICATOR_ONLY = 0.03f;
	public static final float TRAINING_RATE_BOTH = 0.08f;

	public static final float AI_CORE_COST = 1f;

	public static final float MILITARY_WARD_DEFENSE_BONUS = 0.50f;
	public static final float MILITARY_WARD_STABILITY_BONUS = 1f;
	public static final String MILITARY_WARD_BONUS_MARKET_MEMORY_KEY = "$playerhq_module_militaryward_bonus_market";
	private static final String MILITARY_WARD_DEFENSE_MOD_ID = "playerhq_militaryward_defense";
	private static final String MILITARY_WARD_STABILITY_MOD_ID = "playerhq_militaryward_stability";

	public static final int MAX_TRAINING_EXPEDITION_BAYS = 4;

	public static final int EXPEDITION_BAY_TRANSPORTS_REQUIRED = 2;
	public static final int EXPEDITION_BAY_FREIGHTERS_REQUIRED = 2;

	public static final float TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST = 10f;
	public static final float TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST = 10f;

	public static final String FLEET_HQ_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_hq";
	public static final float FLEET_HQ_METALS_COST = 500f;
	public static final float FLEET_HQ_TRANSPLUTONICS_COST = 50f;
	public static final float FLEET_HQ_VOLATILES_COST = 20f;

	public static final String TRAINING_EXPEDITIONS_BAY_COUNT_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_baycount";
	public static final String TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_ships";
	public static final String TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_crewcost";
	public static final String TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_touring";
	public static final String TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_fleet";
	public static final String TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_planet";
	public static final String TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_dayoffset";
	public static final String TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_lootlog";

	public static final int TRAINING_EXPEDITIONS_VISITS_PER_MONTH = 3;

	public static final int TRAINING_EXPEDITIONS_ORBIT_DAYS = 8;

	public static final int TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS = 1;

	public static final int TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS = TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS * 2
			+ TRAINING_EXPEDITIONS_ORBIT_DAYS * TRAINING_EXPEDITIONS_VISITS_PER_MONTH;

	public static final int TRAINING_EXPEDITIONS_LOOT_ROLL_DAY = 6;

	public static final float RUINS_CHANCE_SCATTERED = 0.01f;
	public static final float RUINS_CHANCE_WIDESPREAD = 0.02f;
	public static final float RUINS_CHANCE_EXTENSIVE = 0.03f;
	public static final float RUINS_CHANCE_VAST = 0.04f;

	public static final float SALVAGING_SKILL_BONUS = 0.01f;

	public static final float MAX_LOOT_SHIP_VALUE = 200000f;

	public static final float LOOT_SHIP_CHANCE_3_DMODS = 0.01f;
	public static final float LOOT_SHIP_CHANCE_2_DMODS = 0.10f;
	public static final float LOOT_SHIP_CHANCE_1_DMOD = 0.30f;
	public static final int MAX_LOOT_SHIP_DMODS = 3;

	private static final float LOOT_WEIGHT_WEAPON = 40f;
	private static final float LOOT_WEIGHT_FIGHTER = 28f;
	private static final float LOOT_WEIGHT_HULLMOD = 14f;
	private static final float LOOT_WEIGHT_BLUEPRINT = 12f;
	private static final float LOOT_WEIGHT_SHIP = 4f;
	private static final float LOOT_WEIGHT_SPECIAL_ITEM = 2f;

	private static final String[] SPECIAL_ITEM_LOOT_POOL = {
			Items.CORRUPTED_NANOFORGE, Items.PRISTINE_NANOFORGE, Items.SYNCHROTRON,
			Items.ORBITAL_FUSION_LAMP, Items.MANTLE_BORE, Items.CATALYTIC_CORE,
			Items.SOIL_NANITES, Items.BIOFACTORY_EMBRYO, Items.FULLERENE_SPOOL,
			Items.PLASMA_DYNAMO, Items.CRYOARITHMETIC_ENGINE, Items.DRONE_REPLICATOR,
			Items.DEALMAKER_HOLOSUITE,
	};

	public static final String[] IMAGE_PATHS = {
			"graphics/modules/military_ward.jpg",
			"graphics/modules/military_ward_2.jpg",
			"graphics/modules/military_ward_3.jpg",
			"graphics/modules/military_ward_4.jpg",
			"graphics/modules/military_ward_5.jpg",
			"graphics/modules/military_ward_6.jpg",
			"graphics/modules/military_ward_7.jpg",
			"graphics/modules/military_ward_8.jpg",
			"graphics/modules/military_ward_9.jpg",
			"graphics/modules/military_ward_10.jpg",
			"graphics/modules/military_ward_11.jpg",
			"graphics/modules/military_ward_12.jpg",
			"graphics/modules/military_ward_13.jpg",
	};

	public static String getRandomImagePath() {
		int index = (int) (Math.random() * IMAGE_PATHS.length);
		if (index >= IMAGE_PATHS.length) index = IMAGE_PATHS.length - 1;
		return IMAGE_PATHS[index];
	}

	public static final String[] TRAINING_EXPEDITION_IMAGE_PATHS = {
			"graphics/modules/training_expedition.jpg",
			"graphics/modules/training_expedition_2.jpg",
			"graphics/modules/training_expedition_3.jpg",
			"graphics/modules/training_expedition_4.jpg",
			"graphics/modules/training_expedition_5.jpg",
	};

	public static final String[] LOGISTIC_FLEET_IMAGE_PATHS = {
			"graphics/modules/logistic_fleet.jpg",
			"graphics/modules/logistic_fleet_2.jpg",
	};

	public static String getRandomLogisticFleetImagePath() {
		int index = (int) (Math.random() * LOGISTIC_FLEET_IMAGE_PATHS.length);
		if (index >= LOGISTIC_FLEET_IMAGE_PATHS.length) index = LOGISTIC_FLEET_IMAGE_PATHS.length - 1;
		return LOGISTIC_FLEET_IMAGE_PATHS[index];
	}

	public static final String[] PATROL_FLEET_IMAGE_PATHS = {
			"graphics/modules/patrol_fleet.jpg",
			"graphics/modules/patrol_fleet_2.jpg",
			"graphics/modules/patrol_fleet_3.jpg",
	};

	public static String getRandomPatrolFleetImagePath() {
		int index = (int) (Math.random() * PATROL_FLEET_IMAGE_PATHS.length);
		if (index >= PATROL_FLEET_IMAGE_PATHS.length) index = PATROL_FLEET_IMAGE_PATHS.length - 1;
		return PATROL_FLEET_IMAGE_PATHS[index];
	}

	public static final String[] MINING_FLEET_IMAGE_PATHS = {
			"graphics/modules/mining_fleet.jpg",
			"graphics/modules/mining_fleet_2.jpg",
			"graphics/modules/mining_fleet_3.jpg",
			"graphics/modules/mining_fleet_4.jpg",
			"graphics/modules/mining_fleet_5.jpg",
			"graphics/modules/mining_fleet_6.jpg",
	};

	public static String getRandomMiningFleetImagePath() {
		int index = (int) (Math.random() * MINING_FLEET_IMAGE_PATHS.length);
		if (index >= MINING_FLEET_IMAGE_PATHS.length) index = MINING_FLEET_IMAGE_PATHS.length - 1;
		return MINING_FLEET_IMAGE_PATHS[index];
	}

	public static String getRandomTrainingExpeditionImagePath() {
		int index = (int) (Math.random() * TRAINING_EXPEDITION_IMAGE_PATHS.length);
		if (index >= TRAINING_EXPEDITION_IMAGE_PATHS.length) index = TRAINING_EXPEDITION_IMAGE_PATHS.length - 1;
		return TRAINING_EXPEDITION_IMAGE_PATHS[index];
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
		updateDefenseAndStabilityBonus(station);
	}

	private static void clearDefenseAndStabilityBonus(SectorEntityToken station) {
		String marketId = station.getMemoryWithoutUpdate().getString(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY);
		if (marketId == null) return;

		MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);
		if (market != null) {
			market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(MILITARY_WARD_DEFENSE_MOD_ID);
			market.getStability().unmodifyFlat(MILITARY_WARD_STABILITY_MOD_ID);
		}
		station.getMemoryWithoutUpdate().unset(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY);
	}

	public static void updateDefenseAndStabilityBonus(SectorEntityToken station) {
		clearDefenseAndStabilityBonus(station);

		if (!isBuilt(station)) return;

		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return;

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(
				MILITARY_WARD_DEFENSE_MOD_ID, 1f + MILITARY_WARD_DEFENSE_BONUS, "Military Paradigm (Player HQ)");
		market.getStability().modifyFlat(MILITARY_WARD_STABILITY_MOD_ID, MILITARY_WARD_STABILITY_BONUS, "Military Paradigm (Player HQ)");
		station.getMemoryWithoutUpdate().set(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY, market.getId());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;

		clearDefenseAndStabilityBonus(station);

		CargoAPI cargo = playerFleet.getCargo();
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);

		if (hasHolosuiteInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
		}
		if (hasDroneReplicatorInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		}
		String aiCoreTier = getInstalledAICoreTier(station);
		if (aiCoreTier != null) {
			cargo.addCommodity(aiCoreTier, AI_CORE_COST);
		}

		if (hasFleetHQBuilt(station)) {
			disbandAllBaysInto(station, cargo, playerFleet.getFaction().getId());
			disbandAllPatrolFleetBaysInto(station, cargo, playerFleet.getFaction().getId());
			cargo.addCommodity(Commodities.METALS, FLEET_HQ_METALS_COST * fraction);
			cargo.addCommodity(Commodities.RARE_METALS, FLEET_HQ_TRANSPLUTONICS_COST * fraction);
			cargo.addCommodity(Commodities.VOLATILES, FLEET_HQ_VOLATILES_COST * fraction);
			station.getMemoryWithoutUpdate().unset(FLEET_HQ_MEMORY_KEY);
		}
	}

	public static boolean hasHolosuiteInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasHolosuiteAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE);
	}

	public static void installHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().set(HOLOSUITE_MEMORY_KEY, true);
	}

	public static void uninstallHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasHolosuiteInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().unset(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR);
	}

	public static void installDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, true);
	}

	public static void uninstallDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasDroneReplicatorInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().unset(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static String getInstalledAICoreTier(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getString(AICORE_MEMORY_KEY);
	}

	public static boolean hasAICoreInstalled(SectorEntityToken station) {
		return getInstalledAICoreTier(station) != null;
	}

	public static boolean hasGammaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.GAMMA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasBetaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.BETA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasAlphaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ALPHA_CORE) >= AI_CORE_COST;
	}

	public static void installAICore(SectorEntityToken station, CampaignFleetAPI playerFleet, String coreCommodityId) {
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, coreCommodityId) < AI_CORE_COST) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, coreCommodityId, AI_CORE_COST);
		station.getMemoryWithoutUpdate().set(AICORE_MEMORY_KEY, coreCommodityId);
	}

	public static void uninstallAICore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return;

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(tier, AI_CORE_COST);
		}
		station.getMemoryWithoutUpdate().unset(AICORE_MEMORY_KEY);
	}

	public static float getAICoreTrainingMultiplier(SectorEntityToken station) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return 1f;
		if (Commodities.BETA_CORE.equals(tier)) return 2f;
		if (Commodities.GAMMA_CORE.equals(tier)) return 3f;
		if (Commodities.ALPHA_CORE.equals(tier)) return 4f;
		return 1f;
	}

	private static float getBaseTrainingRatio(SectorEntityToken station) {
		boolean holosuite = hasHolosuiteInstalled(station);
		boolean drone = hasDroneReplicatorInstalled(station);
		if (holosuite && drone) return TRAINING_RATE_BOTH;
		if (holosuite) return TRAINING_RATE_HOLODECK_ONLY;
		if (drone) return TRAINING_RATE_DRONE_REPLICATOR_ONLY;
		return 0f;
	}

	public static float getTrainingRatioPerMonth(SectorEntityToken station) {
		return getBaseTrainingRatio(station) * getAICoreTrainingMultiplier(station);
	}

	public static float getExpectedMonthlyTrainingXP(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return 0f;
		float marines = storageSubmarket.getCargo().getMarines();
		if (marines <= 0f) return 0f;
		return getTrainingRatioPerMonth(station) * marines;
	}

	private static SubmarketAPI getStorageSubmarket(SectorEntityToken station) {
		if (station.getMarket() == null) return null;
		return station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE);
	}

	private static void addCrewCapped(CargoAPI storage, float amount) {
		int current = storage.getCrew();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addCrew(toAdd);
	}

	private static void addMarinesCapped(CargoAPI storage, float amount) {
		int current = storage.getMarines();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addMarines(toAdd);
	}

	public static void enforceCap(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;
		CargoAPI storage = storageSubmarket.getCargo();

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();

		int crew = storage.getCrew();
		if (crew > (int) MAX_PERSONNEL) {
			int excess = crew - (int) MAX_PERSONNEL;
			storage.removeCrew(excess);
			if (playerFleet != null) playerFleet.getCargo().addCrew(excess);
		}

		int marines = storage.getMarines();
		if (marines > (int) MAX_PERSONNEL) {
			int excess = marines - (int) MAX_PERSONNEL;
			storage.removeMarines(excess);
			if (playerFleet != null) playerFleet.getCargo().addMarines(excess);
		}
	}

	private static void applyTraining(SectorEntityToken station, SubmarketAPI storageSubmarket) {
		float ratio = getTrainingRatioPerMonth(station);
		if (ratio <= 0f) return;

		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return;

		at.data.numMayHaveChanged(marines, true);
		at.data.addXP(ratio * marines);
	}

	public static void accumulateMonthly(SectorEntityToken station) {
		if (!isBuilt(station)) return;

		updateDefenseAndStabilityBonus(station);

		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;
		CargoAPI storage = storageSubmarket.getCargo();

		addCrewCapped(storage, CREW_PRODUCTION_PER_MONTH);
		addMarinesCapped(storage, MARINE_PRODUCTION_PER_MONTH);

		float stipend = storage.getCrew() * CREW_STIPEND_PER_UNIT + storage.getMarines() * MARINE_STIPEND_PER_UNIT;
		if (stipend > 0f) {
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (playerFleet != null) playerFleet.getCargo().getCredits().subtract(stipend);
		}

		applyTraining(station, storageSubmarket);
	}

	public static PersonnelRank getStoredMarineRank(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return null;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return null;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return null;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getRank();
	}

	public static float getStoredMarineTrainingPercent(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return 0f;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return 0f;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return 0f;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getXPLevel() * 100f;
	}

	public static class MarineTransferSnapshot {
		float stationNum;
		float stationXP;
		float fleetNum;
		float fleetXP;
	}

	public static MarineTransferSnapshot snapshotMarineXP(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		MarineTransferSnapshot snap = new MarineTransferSnapshot();

		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return snap;

		snap.stationNum = storageSubmarket.getCargo().getMarines();
		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		at.data.numMayHaveChanged(snap.stationNum, true);
		snap.stationXP = at.data.xp;

		PersonnelData fleetData = PlayerFleetPersonnelTracker.getInstance().getMarineData();
		snap.fleetNum = playerFleet.getCargo().getMarines();
		fleetData.numMayHaveChanged(snap.fleetNum, true);
		snap.fleetXP = fleetData.xp;

		return snap;
	}

	public static void reconcileMarineTransfer(SectorEntityToken station, CampaignFleetAPI playerFleet, MarineTransferSnapshot before) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;

		float stationNumAfter = storageSubmarket.getCargo().getMarines();
		float fleetNumAfter = playerFleet.getCargo().getMarines();

		int withdrawn = Math.round(before.stationNum - stationNumAfter);
		if (withdrawn == 0) return;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		PersonnelData fleetData = PlayerFleetPersonnelTracker.getInstance().getMarineData();

		if (withdrawn > 0) {
			float xpPerMarine = before.stationNum > 0 ? before.stationXP / before.stationNum : 0f;
			float xpMoved = xpPerMarine * withdrawn;

			at.data.num = stationNumAfter;
			at.data.xp = Math.max(0f, before.stationXP - xpMoved);

			fleetData.num = fleetNumAfter;
			fleetData.xp = Math.min(before.fleetXP + xpMoved, Math.max(0f, fleetNumAfter));
		} else {
			int deposited = -withdrawn;
			float xpPerMarine = before.fleetNum > 0 ? before.fleetXP / before.fleetNum : 0f;
			float xpMoved = xpPerMarine * deposited;

			fleetData.num = fleetNumAfter;
			fleetData.xp = Math.max(0f, before.fleetXP - xpMoved);

			at.data.num = stationNumAfter;
			at.data.xp = Math.min(before.stationXP + xpMoved, Math.max(0f, stationNumAfter));
		}

		PlayerFleetPersonnelTracker.getInstance().update();
	}

	private static String bayKey(String base, int bayIndex) {
		return base + "_" + bayIndex;
	}

	public static boolean hasFleetHQBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(FLEET_HQ_MEMORY_KEY);
	}

	public static boolean hasFleetHQCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= FLEET_HQ_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= FLEET_HQ_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= FLEET_HQ_VOLATILES_COST;
	}

	public static void buildFleetHQ(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (hasFleetHQBuilt(station)) return;
		if (!hasFleetHQCost(station, playerFleet)) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, FLEET_HQ_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, FLEET_HQ_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, FLEET_HQ_VOLATILES_COST);

		station.getMemoryWithoutUpdate().set(FLEET_HQ_MEMORY_KEY, true);
	}

	public static boolean isExpeditionBayBuilt(SectorEntityToken station, int bayIndex) {
		return getCommittedShips(station, bayIndex) != null;
	}

	public static int getTrainingExpeditionBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (isExpeditionBayBuilt(station, i)) count++;
		}
		return count;
	}

	public static boolean canBuildAnotherExpeditionBay(SectorEntityToken station) {
		return hasFleetHQBuilt(station) && systemHasRuins(station)
				&& getTrainingExpeditionBayCount(station) < MAX_TRAINING_EXPEDITION_BAYS;
	}

	public static boolean isBayTouring(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY, bayIndex));
	}

	public static boolean isTouring(SectorEntityToken station) {
		return getTouringBayCount(station) > 0;
	}

	public static int getTouringBayCount(SectorEntityToken station) {
		int touring = 0;
		for (int i = 0; i < MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (isBayTouring(station, i)) touring++;
		}
		return touring;
	}

	public static List<FleetMemberAPI> getExpeditionFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return getLogisticCandidatesFromEverywhere(station, playerFleet, true);
	}

	public static boolean isValidExpeditionComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.size() != EXPEDITION_BAY_TRANSPORTS_REQUIRED + EXPEDITION_BAY_FREIGHTERS_REQUIRED) return false;
		int transports = 0, freighters = 0;
		for (FleetMemberAPI m : chosen) {
			LogisticShipRole role = classifyLogisticShip(m, true);
			if (role == LogisticShipRole.TRANSPORT) transports++;
			else if (role == LogisticShipRole.FREIGHTER) freighters++;
		}
		return transports == EXPEDITION_BAY_TRANSPORTS_REQUIRED && freighters == EXPEDITION_BAY_FREIGHTERS_REQUIRED;
	}

	public static boolean systemHasRuins(SectorEntityToken station) {
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return false;
		for (PlanetAPI p : system.getPlanets()) {
			if (p.isStar() || p.getMarket() == null) continue;
			if (getRuinsTier(p.getMarket()) > 0) return true;
		}
		return false;
	}

	public static int getRequiredCrewForShips(List<FleetMemberAPI> ships) {
		int total = 0;
		for (FleetMemberAPI m : ships) {
			total += Math.round(m.getMinCrew());
		}
		return total;
	}

	private static void stripAutoAssignedOfficer(FleetMemberAPI m) {
		if (m == null) return;
		PersonAPI captain = m.getCaptain();
		if (captain != null && !captain.isDefault()) {
			m.setCaptain(null);
		}
		m.getStats().getSuppliesPerMonth().unmodifyMult(NO_SUPPLY_UPKEEP_SOURCE);
	}

	private static void removeShipFromWhereverItIs(SectorEntityToken station, CampaignFleetAPI playerFleet, FleetMemberAPI m) {
		if (playerFleet.getFleetData() != null && playerFleet.getFleetData().getMembersListCopy().contains(m)) {
			playerFleet.getFleetData().removeFleetMember(m);
			playerFleet.getFleetData().ensureHasFlagship();
			return;
		}

		CargoAPI fleetCargo = playerFleet.getCargo();
		fleetCargo.initMothballedShips(playerFleet.getFaction().getId());
		if (fleetCargo.getMothballedShips() != null && fleetCargo.getMothballedShips().getMembersListCopy().contains(m)) {
			fleetCargo.getMothballedShips().removeFleetMember(m);
			return;
		}

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.initMothballedShips(playerFleet.getFaction().getId());
			if (storage.getMothballedShips() != null) {
				storage.getMothballedShips().removeFleetMember(m);
			}
		}
	}

	public static void buildExpeditionBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet,
			int bayIndex, List<FleetMemberAPI> chosen) {
		if (bayIndex < 0 || bayIndex >= MAX_TRAINING_EXPEDITION_BAYS) return;
		if (!hasFleetHQBuilt(station) || isExpeditionBayBuilt(station, bayIndex) || !systemHasRuins(station)) return;
		if (!isValidExpeditionComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HAND_WEAPONS)
				< TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST) return;
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY)
				< TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HAND_WEAPONS, TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex), new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, bayIndex), crewNeeded);
	}

	public static boolean hasHeavyArmamentsForBay(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HAND_WEAPONS)
				>= TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST;
	}

	public static boolean hasHeavyMachineryForBay(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY)
				>= TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST;
	}

	private static void disbandAllBaysInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		if (getTrainingExpeditionBayCount(station) < 1) return;

		if (destination != null) {
			destination.initMothballedShips(factionId);
		}

		for (int i = 0; i < MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (!isExpeditionBayBuilt(station, i)) continue;

			if (isBayTouring(station, i)) {
				recallTouringFleet(station, i);
			}
			List<FleetMemberAPI> ships = getCommittedShips(station, i);
			if (ships != null && !ships.isEmpty() && destination != null && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			if (destination != null) {
				int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, i));
				if (crewCost > 0) {
					destination.addCrew(crewCost);
				}
				destination.addCommodity(Commodities.HAND_WEAPONS,
						TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
				destination.addCommodity(Commodities.HEAVY_MACHINERY,
						TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
			}
			clearBayMemory(station, i);
		}
	}

	public static void uninstallExpeditionBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MAX_TRAINING_EXPEDITION_BAYS) return;
		if (!isExpeditionBayBuilt(station, bayIndex)) return;

		if (isBayTouring(station, bayIndex)) {
			recallTouringFleet(station, bayIndex);
		}

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.initMothballedShips(playerFleet.getFaction().getId());
			List<FleetMemberAPI> ships = getCommittedShips(station, bayIndex);
			if (ships != null && !ships.isEmpty() && storage.getMothballedShips() != null) {
				FleetDataAPI mothballed = storage.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) {
				storage.addCrew(crewCost);
			}
			storage.addCommodity(Commodities.HAND_WEAPONS,
					TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
			storage.addCommodity(Commodities.HEAVY_MACHINERY,
					TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
		}

		clearBayMemory(station, bayIndex);
	}

	public static void uninstallFleetHQ(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasFleetHQBuilt(station)) return;

		disbandAllBaysInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
		disbandResupplyBayInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
		disbandAllCourierBaysInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
		disbandAllPatrolFleetBaysInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
			storage.addCommodity(Commodities.METALS, FLEET_HQ_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, FLEET_HQ_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.VOLATILES, FLEET_HQ_VOLATILES_COST * fraction);
		}

		station.getMemoryWithoutUpdate().unset(FLEET_HQ_MEMORY_KEY);
	}

	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasHolosuiteInstalled(station) && !hasDroneReplicatorInstalled(station)
				&& !hasAICoreInstalled(station) && !hasFleetHQBuilt(station);
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet);
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getCommittedShips(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	private static CampaignFleetAPI getTouringFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY, bayIndex));
	}

	@SuppressWarnings("unchecked")
	private static List<String> getExpeditionPlanetIds(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<String>) o : new ArrayList<String>();
	}

	private static int getVisitIndexForDayOffset(SectorEntityToken station, int bayIndex, int dayOffset) {
		int intoOrbitPhase = dayOffset - TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS;
		if (intoOrbitPhase < 0) intoOrbitPhase = 0;
		int visitIndex = intoOrbitPhase / TRAINING_EXPEDITIONS_ORBIT_DAYS;

		int available = getExpeditionPlanetIds(station, bayIndex).size();
		int maxIndex = Math.max(0, Math.min(TRAINING_EXPEDITIONS_VISITS_PER_MONTH, available) - 1);
		if (visitIndex > maxIndex) visitIndex = maxIndex;
		return visitIndex;
	}

	public static String getExpeditionPlanetId(SectorEntityToken station, int bayIndex) {
		List<String> ids = getExpeditionPlanetIds(station, bayIndex);
		if (ids.isEmpty()) return null;
		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex));
		return ids.get(getVisitIndexForDayOffset(station, bayIndex, dayOffset));
	}

	public static String getExpeditionPlanetName(SectorEntityToken station, int bayIndex) {
		PlanetAPI planet = findPlanet(station.getStarSystem(), getExpeditionPlanetId(station, bayIndex));
		return planet != null ? planet.getName() : null;
	}

	public static String getBayStatusText(SectorEntityToken station, int bayIndex) {
		if (!isBayTouring(station, bayIndex)) {
			return "docked at the station, awaiting its next departure on the 1st of the month";
		}

		String planetName = getExpeditionPlanetName(station, bayIndex);
		String planet = planetName != null ? planetName : "a planet";
		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex));
		int orbitPhaseEnd = TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS
				+ TRAINING_EXPEDITIONS_ORBIT_DAYS * TRAINING_EXPEDITIONS_VISITS_PER_MONTH;

		if (dayOffset < TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS) {
			return "moving to " + planet;
		}
		if (dayOffset >= orbitPhaseEnd) {
			return "returning to the station";
		}
		return "conducting a training exercise in orbit of " + planet;
	}

	private static PlanetAPI pickExpeditionPlanet(StarSystemAPI system, Set<String> alreadyChosen) {
		if (system == null) return null;

		List<PlanetAPI> planets = new ArrayList<PlanetAPI>();
		for (PlanetAPI p : system.getPlanets()) {
			if (!p.isStar() && (alreadyChosen == null || !alreadyChosen.contains(p.getId()))) planets.add(p);
		}
		if (planets.isEmpty()) {
			for (PlanetAPI p : system.getPlanets()) {
				if (!p.isStar()) planets.add(p);
			}
		}
		if (planets.isEmpty()) return null;

		float bestChance = -1f;
		List<PlanetAPI> best = new ArrayList<PlanetAPI>();
		for (PlanetAPI p : planets) {
			float chance = getRuinsChance(p.getMarket());
			if (chance > bestChance) {
				bestChance = chance;
				best.clear();
				best.add(p);
			} else if (chance == bestChance) {
				best.add(p);
			}
		}
		if (bestChance <= 0f) return pickRandom(planets);
		return pickRandom(best);
	}

	public static void launchTrainingExpeditionIfDue(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		for (int bayIndex = 0; bayIndex < MAX_TRAINING_EXPEDITION_BAYS; bayIndex++) {
			launchBay(station, bayIndex);
		}
	}

	private static void markAsNonInteractiveTraffic(CampaignFleetAPI fleet, float noEngagingDays) {
		MemoryAPI mem = fleet.getMemoryWithoutUpdate();
		mem.set(MemFlags.MEMORY_KEY_MAKE_NON_HOSTILE, true);
		mem.set(MemFlags.FLEET_IGNORED_BY_OTHER_FLEETS, true);
		mem.set(MemFlags.FLEET_IGNORES_OTHER_FLEETS, true);
		fleet.setNoEngaging(noEngagingDays);
	}

	private static final String NO_SUPPLY_UPKEEP_SOURCE = "playerhq_fleet_no_supply_upkeep";
	public static final float SPAWNED_FLEET_STARTING_SUPPLIES = 10f;

	private static void injectFleetLogistics(CampaignFleetAPI fleet, List<FleetMemberAPI> ships) {
		fleet.getCargo().addSupplies(SPAWNED_FLEET_STARTING_SUPPLIES);
		fleet.getCargo().addCrew(getRequiredCrewForShips(ships));
		for (FleetMemberAPI m : ships) {
			if (m == null) continue;
			m.getStats().getSuppliesPerMonth().modifyMult(NO_SUPPLY_UPKEEP_SOURCE, 0f, "Player HQ fleet");
		}
	}

	private static void positionFleetAtPlanet(CampaignFleetAPI fleet, PlanetAPI planet) {
		fleet.setCircularOrbitPointingDown(planet, (float) (Math.random() * 360f),
				planet.getRadius() + 250f, TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS * 2f);
	}

	private static void launchBay(SectorEntityToken station, int bayIndex) {
		if (isBayTouring(station, bayIndex)) return;

		List<FleetMemberAPI> ships = getCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return;

		StarSystemAPI system = station.getStarSystem();
		List<String> planetIds = new ArrayList<String>();
		Set<String> chosen = new HashSet<String>();
		for (int i = 0; i < TRAINING_EXPEDITIONS_VISITS_PER_MONTH; i++) {
			PlanetAPI planet = pickExpeditionPlanet(system, chosen);
			if (planet == null) break;
			planetIds.add(planet.getId());
			chosen.add(planet.getId());
		}
		if (planetIds.isEmpty()) return;

		PlanetAPI firstPlanet = findPlanet(system, planetIds.get(0));
		if (firstPlanet == null) return;

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Training Expedition - Bay " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS * 2f);
		injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY, bayIndex), new ArrayList<String>(planetIds));
		mem.set(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex), 0);
		mem.set(bayKey(TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY, bayIndex), true);
	}

	public static void advanceTrainingExpeditionDaily(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_TRAINING_EXPEDITION_BAYS; bayIndex++) {
			advanceBayDaily(station, bayIndex);
		}
	}

	private static void advanceBayDaily(SectorEntityToken station, int bayIndex) {
		if (!isBayTouring(station, bayIndex)) return;

		CampaignFleetAPI fleet = getTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) {
			clearTouringState(station, bayIndex);
			return;
		}

		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex)) + 1;
		if (dayOffset >= TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS) {
			recallTouringFleet(station, bayIndex);
			return;
		}

		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex), dayOffset);

		int orbitPhaseEnd = TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS
				+ TRAINING_EXPEDITIONS_ORBIT_DAYS * TRAINING_EXPEDITIONS_VISITS_PER_MONTH;

		if (dayOffset == orbitPhaseEnd) {
			fleet.setLocation(station.getLocation().x, station.getLocation().y);
			return;
		}
		if (dayOffset < TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS || dayOffset >= orbitPhaseEnd) return;

		int intoOrbitPhase = dayOffset - TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS;
		int dayOfThisOrbit = intoOrbitPhase % TRAINING_EXPEDITIONS_ORBIT_DAYS + 1;

		PlanetAPI planet = findPlanet(station.getStarSystem(), getExpeditionPlanetId(station, bayIndex));
		if (planet == null) return;

		if (dayOfThisOrbit == 1) {
			positionFleetAtPlanet(fleet, planet);
		}

		if (dayOfThisOrbit == TRAINING_EXPEDITIONS_LOOT_ROLL_DAY) {
			rollForLoot(station, planet);
		}
	}

	private static void recallTouringFleet(SectorEntityToken station, int bayIndex) {
		CampaignFleetAPI fleet = getTouringFleet(station, bayIndex);
		if (fleet != null) {
			List<FleetMemberAPI> ships = getCommittedShips(station, bayIndex);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearTouringState(station, bayIndex);
	}

	private static void clearTouringState(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex));
	}

	private static void clearBayMemory(SectorEntityToken station, int bayIndex) {
		clearTouringState(station, bayIndex);
		station.getMemoryWithoutUpdate().unset(bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, bayIndex));
	}

	private static PlanetAPI findPlanet(StarSystemAPI system, String planetId) {
		if (system == null || planetId == null) return null;
		for (PlanetAPI p : system.getPlanets()) {
			if (planetId.equals(p.getId())) return p;
		}
		return null;
	}

	private static int getRuinsTier(MarketAPI market) {
		if (market == null) return 0;
		if (market.hasCondition(Conditions.RUINS_VAST)) return 4;
		if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) return 3;
		if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) return 2;
		if (market.hasCondition(Conditions.RUINS_SCATTERED)) return 1;
		return 0;
	}

	private static float getBaseRuinsChanceForTier(int tier) {
		switch (tier) {
			case 4: return RUINS_CHANCE_VAST;
			case 3: return RUINS_CHANCE_EXTENSIVE;
			case 2: return RUINS_CHANCE_WIDESPREAD;
			case 1: return RUINS_CHANCE_SCATTERED;
			default: return 0f;
		}
	}

	private static boolean hasSalvagingSkill() {
		return Global.getSector().getPlayerStats() != null
				&& Global.getSector().getPlayerStats().getSkillLevel(Skills.SALVAGING) > 0;
	}

	private static float getRuinsChance(MarketAPI market) {
		int tier = getRuinsTier(market);
		if (tier <= 0) return 0f;

		float chance = getBaseRuinsChanceForTier(tier);
		if (hasSalvagingSkill()) {
			chance += SALVAGING_SKILL_BONUS;
		}
		return chance;
	}

	private static void rollForLoot(SectorEntityToken station, PlanetAPI planet) {
		MarketAPI market = planet.getMarket();
		if (market == null) return;

		float chance = getRuinsChance(market);
		if (chance <= 0f) return;
		if (Math.random() >= chance) return;

		String lootLine = generateLoot(station);
		if (lootLine == null) return;

		logLoot(station, planet.getName(), lootLine);
	}

	@SuppressWarnings("unchecked")
	private static void logLoot(SectorEntityToken station, String planetName, String lootLine) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		Object o = mem.get(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY);
		List<String> log = (o instanceof List) ? (List<String>) o : new ArrayList<String>();
		log.add(lootLine + " -- found at " + planetName);
		mem.set(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY, log);
	}

	@SuppressWarnings("unchecked")
	public static List<String> getTrainingExpeditionLootThisMonth(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY);
		return (o instanceof List) ? new ArrayList<String>((List<String>) o) : new ArrayList<String>();
	}

	public static void clearTrainingExpeditionLootThisMonth(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY);
	}

	private static <T> T pickRandom(List<T> list) {
		if (list == null || list.isEmpty()) return null;
		return list.get((int) (Math.random() * list.size()));
	}

	private static FighterWingSpecAPI pickRandomRegularFighter() {
		List<FighterWingSpecAPI> pool = new ArrayList<FighterWingSpecAPI>();
		for (FighterWingSpecAPI spec : Global.getSettings().getAllFighterWingSpecs()) {
			if (spec.isRegularFighter()) pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static HullModSpecAPI pickRandomHullMod() {
		List<HullModSpecAPI> pool = new ArrayList<HullModSpecAPI>();
		for (HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
			if (spec.isHidden() || spec.isHiddenEverywhere() || spec.isAlwaysUnlocked()) continue;
			pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static boolean isLootableHullSize(HullSize size) {
		return size == HullSize.FRIGATE || size == HullSize.DESTROYER
				|| size == HullSize.CRUISER || size == HullSize.CAPITAL_SHIP;
	}

	private static List<String> getLootableShipVariantIds() {
		List<String> result = new ArrayList<String>();
		for (String variantId : Global.getSettings().getAllVariantIds()) {
			ShipVariantAPI variant = Global.getSettings().getVariant(variantId);
			if (variant == null) continue;
			ShipHullSpecAPI hull = variant.getHullSpec();
			if (hull == null || hull.isDHull()) continue;
			if (hull.getBaseValue() > MAX_LOOT_SHIP_VALUE) continue;
			if (!isLootableHullSize(hull.getHullSize())) continue;
			result.add(variantId);
		}
		return result;
	}

	private static List<ShipHullSpecAPI> getLootableHullSpecs() {
		List<ShipHullSpecAPI> result = new ArrayList<ShipHullSpecAPI>();
		Set<String> seen = new HashSet<String>();
		for (ShipHullSpecAPI hull : Global.getSettings().getAllShipHullSpecs()) {
			if (hull.isDHull()) continue;
			if (hull.getBaseValue() > MAX_LOOT_SHIP_VALUE) continue;
			if (!isLootableHullSize(hull.getHullSize())) continue;
			if (seen.add(hull.getHullId())) result.add(hull);
		}
		return result;
	}

	private static int rollLootShipDMods() {
		float roll = (float) Math.random();
		if (roll < LOOT_SHIP_CHANCE_3_DMODS) return 3;
		if (roll < LOOT_SHIP_CHANCE_3_DMODS + LOOT_SHIP_CHANCE_2_DMODS) return 2;
		if (roll < LOOT_SHIP_CHANCE_3_DMODS + LOOT_SHIP_CHANCE_2_DMODS + LOOT_SHIP_CHANCE_1_DMOD) return 1;
		return 0;
	}

	private static String generateShip(String factionId, CargoAPI storage) {
		String variantId = pickRandom(getLootableShipVariantIds());
		if (variantId == null) return null;

		FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, variantId);

		int dmodsWanted = rollLootShipDMods();
		if (dmodsWanted > 0) {
			DModManager.addDMods(member.getVariant(), false, dmodsWanted, null);
		}
		int dmodsActual = Math.min(DModManager.getNumDMods(member.getVariant()), MAX_LOOT_SHIP_DMODS);

		storage.initMothballedShips(factionId);
		storage.getMothballedShips().addFleetMember(member);

		String dmodNote = dmodsActual > 0 ? ", " + dmodsActual + " D-mod" + (dmodsActual > 1 ? "s" : "") : "";
		return "1 " + member.getHullSpec().getHullName() + " (ship" + dmodNote + ", stored at the station)";
	}

	private static String generateBlueprint(CargoAPI storage) {
		int roll = (int) (Math.random() * 3);
		if (roll == 0) {
			WeaponSpecAPI spec = pickRandom(Global.getSettings().getAllWeaponSpecs());
			if (spec == null) return null;
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.WEAPON_BP, spec.getWeaponId()), 1);
			return "1 blueprint: " + spec.getWeaponName() + " (weapon)";
		} else if (roll == 1) {
			FighterWingSpecAPI spec = pickRandomRegularFighter();
			if (spec == null) return null;
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FIGHTER_BP, spec.getId()), 1);
			return "1 blueprint: " + spec.getWingName() + " (fighter wing)";
		} else {
			ShipHullSpecAPI spec = pickRandom(getLootableHullSpecs());
			if (spec == null) return null;
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SHIP_BP, spec.getHullId()), 1);
			return "1 blueprint: " + spec.getHullName() + " (ship)";
		}
	}

	private static String generateLoot(SectorEntityToken station) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return null;

		WeightedRandomPicker<String> categoryPicker = new WeightedRandomPicker<String>();
		categoryPicker.add("weapon", LOOT_WEIGHT_WEAPON);
		categoryPicker.add("fighter", LOOT_WEIGHT_FIGHTER);
		categoryPicker.add("hullmod", LOOT_WEIGHT_HULLMOD);
		categoryPicker.add("blueprint", LOOT_WEIGHT_BLUEPRINT);
		categoryPicker.add("ship", LOOT_WEIGHT_SHIP);
		categoryPicker.add("special", LOOT_WEIGHT_SPECIAL_ITEM);
		String category = categoryPicker.pick();
		if (category == null) return null;

		if (category.equals("weapon")) {
			WeaponSpecAPI spec = pickRandom(Global.getSettings().getAllWeaponSpecs());
			if (spec == null) return null;
			storage.addWeapons(spec.getWeaponId(), 1);
			return "1 " + spec.getWeaponName() + " (weapon)";
		}
		if (category.equals("fighter")) {
			FighterWingSpecAPI spec = pickRandomRegularFighter();
			if (spec == null) return null;
			storage.addFighters(spec.getId(), 1);
			return "1 " + spec.getWingName() + " (fighter wing)";
		}
		if (category.equals("hullmod")) {
			HullModSpecAPI spec = pickRandomHullMod();
			if (spec == null) return null;
			storage.addHullmods(spec.getId(), 1);
			return "1 " + spec.getDisplayName() + " (hull mod)";
		}
		if (category.equals("blueprint")) {
			return generateBlueprint(storage);
		}
		if (category.equals("ship")) {
			return generateShip(Factions.PLAYER, storage);
		}
		if (category.equals("special")) {
			String itemId = SPECIAL_ITEM_LOOT_POOL[(int) (Math.random() * SPECIAL_ITEM_LOOT_POOL.length)];
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
			SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec(itemId);
			return "1 " + (spec != null ? spec.getName() : itemId) + " (special item)";
		}
		return null;
	}

	public static final int MAX_MINING_FLEET_BAYS = 4;
	public static final int MAX_MINING_FLEET_SHIPS_PER_BAY = 6;

	public static final int MINING_POWER_FRIGATE = 5;
	public static final int MINING_POWER_DESTROYER = 10;
	public static final int MINING_POWER_CRUISER = 20;
	public static final int MINING_POWER_CAPITAL = 30;
	private static final int SPECIALIZED_MINING_POWER_MULTIPLIER = 2;

	public static final float MINING_FLEET_RESOURCES_PER_POWER = 3f;

	public static final int MINING_FLEET_TRANSIT_DAYS = 1;
	public static final int MINING_FLEET_WORK_DAYS = 25;
	public static final int MINING_FLEET_TOUR_LENGTH_DAYS = MINING_FLEET_TRANSIT_DAYS * 2 + MINING_FLEET_WORK_DAYS;

	private static final String MINING_FLEET_BELT_TARGET_ID = "playerhq_miningfleet_belt";

	public static final String MINING_FLEET_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_ships";
	public static final String MINING_FLEET_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_crewcost";
	public static final String MINING_FLEET_TARGET_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_target";
	public static final String MINING_FLEET_TOURING_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_touring";
	public static final String MINING_FLEET_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_fleet";
	public static final String MINING_FLEET_DAY_OFFSET_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_dayoffset";
	public static final String MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_respawnmanifest";
	public static final String MINING_FLEET_DESTROYED_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_destroyed";
	public static final String MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_respawndaysleft";
	public static final String MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_destroyedcause";

	private static boolean systemHasAsteroidBeltOrField(StarSystemAPI system) {
		if (system == null) return false;
		for (Object object : system.getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) object;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if (plugin instanceof AsteroidBeltTerrainPlugin || plugin instanceof AsteroidFieldTerrainPlugin) return true;
		}
		return false;
	}

	private static String getStationOwnTargetId(SectorEntityToken station) {
		SectorEntityToken focus = station.getOrbitFocus();
		if (focus instanceof PlanetAPI) return focus.getId();
		if (focus != null) return MINING_FLEET_BELT_TARGET_ID;
		return null;
	}

	public static List<String> getMiningFleetTargetIds(SectorEntityToken station) {
		List<String> ids = new ArrayList<String>();
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return ids;

		String ownTargetId = getStationOwnTargetId(station);

		for (PlanetAPI p : system.getPlanets()) {
			if (p.isStar()) continue;
			if (p.getId().equals(ownTargetId)) continue;
			ids.add(p.getId());
		}

		if (systemHasAsteroidBeltOrField(system)) {
			ids.add(MINING_FLEET_BELT_TARGET_ID);
		}

		return ids;
	}

	public static int getMaxMiningFleetBays(SectorEntityToken station) {
		return MAX_MINING_FLEET_BAYS;
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getMiningFleetCommittedShips(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	public static boolean isMiningFleetBayBuilt(SectorEntityToken station, int bayIndex) {
		return getMiningFleetCommittedShips(station, bayIndex) != null || isMiningFleetBayDestroyed(station, bayIndex);
	}

	public static boolean isMiningFleetBayDestroyed(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex));
	}

	private static String getMiningFleetDestroyedCause(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : "unknown causes";
	}

	public static int getMiningFleetBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_MINING_FLEET_BAYS; i++) {
			if (isMiningFleetBayBuilt(station, i)) count++;
		}
		return count;
	}

	public static boolean canBuildAnotherMiningFleetBay(SectorEntityToken station) {
		return MiningHangarModule.isBuilt(station) && getMiningFleetBayCount(station) < getMaxMiningFleetBays(station);
	}

	private static boolean isEligibleMiningShip(FleetMemberAPI m) {
		if (m.getHullSpec() == null) return false;
		Set<ShipHullSpecAPI.ShipTypeHints> hints = m.getHullSpec().getHints();
		boolean eligibleRole = hints.contains(ShipHullSpecAPI.ShipTypeHints.FREIGHTER)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.TRANSPORT)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.CIVILIAN)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.PHASE)
				|| hasMiningOrCarrierDesignation(m);
		if (!eligibleRole) return false;
		if (m.getVariant() != null && DModManager.getNumDMods(m.getVariant()) > 0) return false;
		return true;
	}

	public static int getMiningPower(FleetMemberAPI m) {
		if (m.getHullSpec() == null) return 0;
		HullSize size = m.getHullSpec().getHullSize();
		int base;
		if (size == HullSize.FRIGATE) base = MINING_POWER_FRIGATE;
		else if (size == HullSize.DESTROYER) base = MINING_POWER_DESTROYER;
		else if (size == HullSize.CRUISER) base = MINING_POWER_CRUISER;
		else if (size == HullSize.CAPITAL_SHIP) base = MINING_POWER_CAPITAL;
		else return 0;
		return hasMiningOrCarrierDesignation(m) ? base * SPECIALIZED_MINING_POWER_MULTIPLIER : base;
	}

	private static boolean hasMiningOrCarrierDesignation(FleetMemberAPI m) {
		if (m.getHullSpec() == null || !m.getHullSpec().hasDesignation()) return false;
		String designation = m.getHullSpec().getDesignation().toLowerCase(Locale.ROOT);
		return designation.contains("mining") || designation.contains("miner") || designation.contains("carrier")
				|| designation.contains("drone tender");
	}

	public static int getTotalMiningPower(List<FleetMemberAPI> ships) {
		int total = 0;
		for (FleetMemberAPI m : ships) total += getMiningPower(m);
		return total;
	}

	public static List<FleetMemberAPI> getMiningFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		List<FleetMemberAPI> result = new ArrayList<FleetMemberAPI>();
		if (playerFleet.getFleetData() != null) {
			for (FleetMemberAPI m : playerFleet.getFleetData().getMembersListCopy()) {
				if (m.isFlagship()) continue;
				if (isEligibleMiningShip(m)) result.add(m);
			}
		}
		addMiningCandidatesFrom(playerFleet.getCargo(), playerFleet.getFaction().getId(), result);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) addMiningCandidatesFrom(storage, playerFleet.getFaction().getId(), result);
		return result;
	}

	private static void addMiningCandidatesFrom(CargoAPI cargo, String factionId, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : mothballed.getMembersListCopy()) {
			if (isEligibleMiningShip(m)) out.add(m);
		}
	}

	public static void buildMiningFleetBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex, List<FleetMemberAPI> chosen) {
		if (!MiningHangarModule.isBuilt(station)) return;
		if (bayIndex < 0 || bayIndex >= getMaxMiningFleetBays(station) || isMiningFleetBayBuilt(station, bayIndex)) return;
		if (chosen == null || chosen.isEmpty() || chosen.size() > MAX_MINING_FLEET_SHIPS_PER_BAY) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		station.getMemoryWithoutUpdate().set(bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex), new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(bayKey(MINING_FLEET_CREW_COST_MEMORY_KEY, bayIndex), crewNeeded);
	}

	public static boolean isMiningFleetBayTouring(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(MINING_FLEET_TOURING_MEMORY_KEY, bayIndex));
	}

	private static CampaignFleetAPI getMiningTouringFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(MINING_FLEET_FLEET_MEMORY_KEY, bayIndex));
	}

	public static String getMiningFleetTargetId(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getString(bayKey(MINING_FLEET_TARGET_MEMORY_KEY, bayIndex));
	}

	public static String getMiningFleetTargetName(SectorEntityToken station, int bayIndex) {
		String targetId = getMiningFleetTargetId(station, bayIndex);
		if (targetId == null) return null;
		if (MINING_FLEET_BELT_TARGET_ID.equals(targetId)) return "the system's asteroid belt/field";
		PlanetAPI planet = findPlanet(station.getStarSystem(), targetId);
		return planet != null ? planet.getName() : null;
	}

	public static String getMiningFleetBayStatusText(SectorEntityToken station, int bayIndex) {
		if (isMiningFleetBayDestroyed(station, bayIndex)) {
			int daysLeft = Math.max(station.getMemoryWithoutUpdate().getInt(bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex)), 0);
			return "destroyed by " + getMiningFleetDestroyedCause(station, bayIndex) + " -- rebuilding, ready again in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		if (!isMiningFleetBayTouring(station, bayIndex)) {
			return "docked at the station, awaiting its next departure on the 1st of the month";
		}
		String target = getMiningFleetTargetName(station, bayIndex);
		if (target == null) target = "its target";
		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(MINING_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex));
		if (dayOffset < MINING_FLEET_TRANSIT_DAYS) return "moving to " + target;
		if (dayOffset >= MINING_FLEET_TRANSIT_DAYS + MINING_FLEET_WORK_DAYS) return "returning to the station";
		return "mining " + target;
	}

	private static void positionMiningFleet(CampaignFleetAPI fleet, StarSystemAPI system, String targetId) {
		if (MINING_FLEET_BELT_TARGET_ID.equals(targetId)) {
			fleet.setLocation(0f, 0f);
			return;
		}
		PlanetAPI planet = findPlanet(system, targetId);
		if (planet == null) return;
		fleet.setCircularOrbitPointingDown(planet, (float) (Math.random() * 360f),
				planet.getRadius() + 250f, MINING_FLEET_TOUR_LENGTH_DAYS * 2f);
	}

	public static void launchMiningFleetsIfDue(SectorEntityToken station) {
		if (!MiningHangarModule.isBuilt(station)) return;
		for (int bayIndex = 0; bayIndex < MAX_MINING_FLEET_BAYS; bayIndex++) {
			launchMiningBay(station, bayIndex);
		}
	}

	private static void launchMiningBay(SectorEntityToken station, int bayIndex) {
		if (isMiningFleetBayTouring(station, bayIndex)) return;
		List<FleetMemberAPI> ships = getMiningFleetCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return;

		List<String> available = new ArrayList<String>(getMiningFleetTargetIds(station));
		if (available.isEmpty()) return;
		String targetId = pickRandom(available);

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Mining Fleet - Bay " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, MINING_FLEET_TOUR_LENGTH_DAYS * 2f);
		injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(MINING_FLEET_TARGET_MEMORY_KEY, bayIndex), targetId);
		mem.set(bayKey(MINING_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex), 0);
		mem.set(bayKey(MINING_FLEET_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(MINING_FLEET_TOURING_MEMORY_KEY, bayIndex), true);
	}

	public static void advanceMiningFleetsDaily(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_MINING_FLEET_BAYS; bayIndex++) {
			advanceMiningBayDaily(station, bayIndex);
		}
	}

	private static void advanceMiningBayDaily(SectorEntityToken station, int bayIndex) {
		if (isMiningFleetBayDestroyed(station, bayIndex)) {
			advanceLogisticFleetRespawn(station,
					bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			return;
		}
		if (!isMiningFleetBayTouring(station, bayIndex)) return;

		CampaignFleetAPI fleet = getMiningTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) {
			markLogisticFleetDestroyed(station, "Mining Fleet - Bay " + (bayIndex + 1), getMiningFleetCommittedShips(station, bayIndex),
					"unknown causes",
					bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			clearMiningTouringState(station, bayIndex);
			return;
		}

		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(MINING_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex)) + 1;
		if (dayOffset >= MINING_FLEET_TOUR_LENGTH_DAYS) {
			recallMiningFleet(station, bayIndex);
			return;
		}
		station.getMemoryWithoutUpdate().set(bayKey(MINING_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex), dayOffset);

		String targetId = getMiningFleetTargetId(station, bayIndex);
		StarSystemAPI system = station.getStarSystem();
		if (targetId == null || system == null) return;

		if (dayOffset == MINING_FLEET_TRANSIT_DAYS) {
			positionMiningFleet(fleet, system, targetId);
		} else if (dayOffset == MINING_FLEET_TRANSIT_DAYS + MINING_FLEET_WORK_DAYS) {
			fleet.setLocation(station.getLocation().x, station.getLocation().y);
		}
	}

	private static void depositMiningHaul(SectorEntityToken station, int bayIndex) {
		String targetId = getMiningFleetTargetId(station, bayIndex);
		if (targetId == null) return;
		List<FleetMemberAPI> ships = getMiningFleetCommittedShips(station, bayIndex);
		if (ships == null) return;

		int power = getTotalMiningPower(ships);
		if (power <= 0) return;
		float haul = power * MINING_FLEET_RESOURCES_PER_POWER;

		boolean ore, rareOre, volatiles, organics;
		if (MINING_FLEET_BELT_TARGET_ID.equals(targetId)) {
			ore = true; rareOre = true; volatiles = true; organics = false;
		} else {
			PlanetAPI planet = findPlanet(station.getStarSystem(), targetId);
			ore = MiningHangarModule.hasOreDeposit(planet);
			rareOre = MiningHangarModule.hasRareOreDeposit(planet);
			volatiles = MiningHangarModule.hasVolatilesDeposit(planet);
			organics = MiningHangarModule.hasOrganicsDeposit(planet);
		}

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		if (ore) addCappedResource(storage, Commodities.ORE, haul);
		if (rareOre) addCappedResource(storage, Commodities.RARE_ORE, haul);
		if (volatiles) addCappedResource(storage, Commodities.VOLATILES, haul);
		if (organics) addCappedResource(storage, Commodities.ORGANICS, haul);
	}

	private static void addCappedResource(CargoAPI storage, String commodityId, float amount) {
		if (amount <= 0f) return;
		float space = MiningHangarModule.MAX_STORED_RESOURCES - storage.getCommodityQuantity(commodityId);
		if (space <= 0f) return;
		storage.addCommodity(commodityId, Math.min(amount, space));
	}

	private static void despawnMiningFleet(SectorEntityToken station, int bayIndex) {
		CampaignFleetAPI fleet = getMiningTouringFleet(station, bayIndex);
		if (fleet != null) {
			List<FleetMemberAPI> ships = getMiningFleetCommittedShips(station, bayIndex);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearMiningTouringState(station, bayIndex);
	}

	private static void recallMiningFleet(SectorEntityToken station, int bayIndex) {
		depositMiningHaul(station, bayIndex);
		despawnMiningFleet(station, bayIndex);
	}

	private static void clearMiningTouringState(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(MINING_FLEET_TOURING_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_TARGET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex));
	}

	private static void clearMiningBayMemory(SectorEntityToken station, int bayIndex) {
		clearMiningTouringState(station, bayIndex);
		station.getMemoryWithoutUpdate().unset(bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(MINING_FLEET_CREW_COST_MEMORY_KEY, bayIndex));
		clearLogisticFleetDestroyedState(station,
				bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex),
				bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
	}

	public static void uninstallMiningFleetBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MAX_MINING_FLEET_BAYS || !isMiningFleetBayBuilt(station, bayIndex)) return;

		if (isMiningFleetBayTouring(station, bayIndex)) {
			despawnMiningFleet(station, bayIndex);
		}

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.initMothballedShips(playerFleet.getFaction().getId());
			List<FleetMemberAPI> ships = getReturnableShips(station, getMiningFleetCommittedShips(station, bayIndex),
					bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex));
			if (ships != null && !ships.isEmpty() && storage.getMothballedShips() != null) {
				FleetDataAPI mothballed = storage.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(MINING_FLEET_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) {
				storage.addCrew(crewCost);
			}
		}

		clearMiningBayMemory(station, bayIndex);
	}

	public static void disbandAllMiningFleetBaysInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		if (destination != null) destination.initMothballedShips(factionId);
		for (int i = 0; i < MAX_MINING_FLEET_BAYS; i++) {
			if (!isMiningFleetBayBuilt(station, i)) continue;
			if (isMiningFleetBayTouring(station, i)) {
				despawnMiningFleet(station, i);
			}
			List<FleetMemberAPI> ships = getReturnableShips(station, getMiningFleetCommittedShips(station, i),
					bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, i));
			if (ships != null && !ships.isEmpty() && destination != null && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			if (destination != null) {
				int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(MINING_FLEET_CREW_COST_MEMORY_KEY, i));
				if (crewCost > 0) {
					destination.addCrew(crewCost);
				}
			}
			clearMiningBayMemory(station, i);
		}
	}

	private enum LogisticShipRole { TANKER, TRANSPORT, FREIGHTER }

	private static LogisticShipRole classifyLogisticShip(FleetMemberAPI m, boolean allowTransport) {
		if (m.getHullSpec() == null) return null;
		if (m.getHullSpec().getHullSize() == HullSize.FRIGATE) return null;
		Set<ShipHullSpecAPI.ShipTypeHints> hints = m.getHullSpec().getHints();
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.TANKER) || hasDesignationContaining(m, "tanker")) {
			return LogisticShipRole.TANKER;
		}
		if (allowTransport && (hints.contains(ShipHullSpecAPI.ShipTypeHints.TRANSPORT) || hasDesignationContaining(m, "transport"))) {
			return LogisticShipRole.TRANSPORT;
		}
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.FREIGHTER) || hasDesignationContaining(m, "freighter")) {
			return LogisticShipRole.FREIGHTER;
		}
		return null;
	}

	private static boolean hasDesignationContaining(FleetMemberAPI m, String substring) {
		if (!m.getHullSpec().hasDesignation()) return false;
		String designation = m.getHullSpec().getDesignation();
		return designation != null && designation.toLowerCase(Locale.ROOT).contains(substring);
	}

	private static boolean isPristine(FleetMemberAPI m) {
		return m.getVariant() == null || DModManager.getNumDMods(m.getVariant()) <= 0;
	}

	private static List<FleetMemberAPI> getLogisticCandidatesFromEverywhere(SectorEntityToken station, CampaignFleetAPI playerFleet, boolean allowTransport) {
		List<FleetMemberAPI> result = new ArrayList<FleetMemberAPI>();
		if (playerFleet.getFleetData() != null) {
			for (FleetMemberAPI m : playerFleet.getFleetData().getMembersListCopy()) {
				if (m.isFlagship()) continue;
				if (classifyLogisticShip(m, allowTransport) != null && isPristine(m)) result.add(m);
			}
		}
		addLogisticCandidatesFrom(playerFleet.getCargo(), playerFleet.getFaction().getId(), allowTransport, result);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) addLogisticCandidatesFrom(storage, playerFleet.getFaction().getId(), allowTransport, result);
		return result;
	}

	private static void addLogisticCandidatesFrom(CargoAPI cargo, String factionId, boolean allowTransport, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : mothballed.getMembersListCopy()) {
			if (classifyLogisticShip(m, allowTransport) != null && isPristine(m)) out.add(m);
		}
	}

	private static void returnShipsToStorage(SectorEntityToken station, CampaignFleetAPI playerFleet, List<FleetMemberAPI> ships) {
		if (ships == null || ships.isEmpty()) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		storage.initMothballedShips(playerFleet.getFaction().getId());
		FleetDataAPI mothballed = storage.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : ships) {
			stripAutoAssignedOfficer(m);
			mothballed.addFleetMember(m);
		}
	}

	public static final int LOGISTIC_FLEET_RESPAWN_DAYS = 30;

	private static List<ShipVariantAPI> snapshotVariants(List<FleetMemberAPI> ships) {
		List<ShipVariantAPI> manifest = new ArrayList<ShipVariantAPI>();
		if (ships != null) {
			for (FleetMemberAPI m : ships) {
				if (m != null && m.getVariant() != null) manifest.add(m.getVariant().clone());
			}
		}
		return manifest;
	}

	private static List<FleetMemberAPI> buildFreshShipsFromManifest(List<ShipVariantAPI> manifest) {
		List<FleetMemberAPI> rebuilt = new ArrayList<FleetMemberAPI>();
		if (manifest != null) {
			for (ShipVariantAPI variant : manifest) {
				rebuilt.add(Global.getFactory().createFleetMember(FleetMemberType.SHIP, variant.clone()));
			}
		}
		return rebuilt;
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getReturnableShips(SectorEntityToken station, List<FleetMemberAPI> committedShips, String manifestKey) {
		if (committedShips != null) return committedShips;
		Object o = station.getMemoryWithoutUpdate().get(manifestKey);
		return (o instanceof List) ? buildFreshShipsFromManifest((List<ShipVariantAPI>) o) : null;
	}

	private static void markLogisticFleetDestroyed(SectorEntityToken station, String reportLabel, List<FleetMemberAPI> lostShips, String cause,
			String shipsKey, String manifestKey, String destroyedKey, String daysLeftKey, String causeKey) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(manifestKey, snapshotVariants(lostShips));
		mem.unset(shipsKey);
		mem.set(destroyedKey, true);
		mem.set(daysLeftKey, LOGISTIC_FLEET_RESPAWN_DAYS);
		mem.set(causeKey, cause);
		PlayerHQFleetLossIntel.report(station, reportLabel, cause);
	}

	@SuppressWarnings("unchecked")
	private static void advanceLogisticFleetRespawn(SectorEntityToken station,
			String shipsKey, String manifestKey, String destroyedKey, String daysLeftKey, String causeKey) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		int daysLeft = mem.getInt(daysLeftKey) - 1;
		if (daysLeft > 0) {
			mem.set(daysLeftKey, daysLeft);
			return;
		}

		Object o = mem.get(manifestKey);
		mem.set(shipsKey, buildFreshShipsFromManifest((o instanceof List) ? (List<ShipVariantAPI>) o : null));
		mem.unset(manifestKey);
		mem.unset(destroyedKey);
		mem.unset(daysLeftKey);
		mem.unset(causeKey);
	}

	private static void clearLogisticFleetDestroyedState(SectorEntityToken station,
			String manifestKey, String destroyedKey, String daysLeftKey, String causeKey) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(manifestKey);
		mem.unset(destroyedKey);
		mem.unset(daysLeftKey);
		mem.unset(causeKey);
	}

	public static final int RESUPPLY_BAY_MAX_SHIPS = 4;
	public static final int RESUPPLY_BAY_TANKERS_REQUIRED = 1;
	public static final int RESUPPLY_BAY_TRANSPORTS_REQUIRED = 1;
	public static final int RESUPPLY_BAY_FREIGHTERS_REQUIRED = 2;

	public static final String RESUPPLY_BAY_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_ships";
	public static final String RESUPPLY_BAY_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_crewcost";
	public static final String RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_respawnmanifest";
	public static final String RESUPPLY_BAY_DESTROYED_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_destroyed";
	public static final String RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_respawndaysleft";
	public static final String RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_destroyedcause";

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getResupplyBayCommittedShips(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(RESUPPLY_BAY_SHIPS_MEMORY_KEY);
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	public static boolean hasResupplyBayBuilt(SectorEntityToken station) {
		return getResupplyBayCommittedShips(station) != null || isResupplyBayDestroyed(station);
	}

	public static boolean isResupplyBayDestroyed(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(RESUPPLY_BAY_DESTROYED_MEMORY_KEY);
	}

	private static String getResupplyBayDestroyedCause(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
		return (o instanceof String) ? (String) o : "unknown causes";
	}

	private static void handleResupplyFleetFoundDestroyed(SectorEntityToken station, String cause) {
		markLogisticFleetDestroyed(station, "Resupply Fleet", getResupplyBayCommittedShips(station), cause,
				RESUPPLY_BAY_SHIPS_MEMORY_KEY, RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY,
				RESUPPLY_BAY_DESTROYED_MEMORY_KEY, RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
		clearResupplyFleetState(station);
	}

	public static List<FleetMemberAPI> getResupplyFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return getLogisticCandidatesFromEverywhere(station, playerFleet, true);
	}

	public static boolean isValidResupplyComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.size() != RESUPPLY_BAY_MAX_SHIPS) return false;
		int tankers = 0, transports = 0, freighters = 0;
		for (FleetMemberAPI m : chosen) {
			LogisticShipRole role = classifyLogisticShip(m, true);
			if (role == LogisticShipRole.TANKER) tankers++;
			else if (role == LogisticShipRole.TRANSPORT) transports++;
			else if (role == LogisticShipRole.FREIGHTER) freighters++;
			else return false;
		}
		return tankers == RESUPPLY_BAY_TANKERS_REQUIRED && transports == RESUPPLY_BAY_TRANSPORTS_REQUIRED
				&& freighters == RESUPPLY_BAY_FREIGHTERS_REQUIRED;
	}

	public static void buildResupplyBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, List<FleetMemberAPI> chosen) {
		if (!hasFleetHQBuilt(station) || hasResupplyBayBuilt(station)) return;
		if (!isValidResupplyComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		station.getMemoryWithoutUpdate().set(RESUPPLY_BAY_SHIPS_MEMORY_KEY, new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(RESUPPLY_BAY_CREW_COST_MEMORY_KEY, crewNeeded);
	}

	public static void uninstallResupplyBay(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasResupplyBayBuilt(station)) return;
		recallResupplyFleetImmediately(station);
		returnShipsToStorage(station, playerFleet,
				getReturnableShips(station, getResupplyBayCommittedShips(station), RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY));
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			int crewCost = station.getMemoryWithoutUpdate().getInt(RESUPPLY_BAY_CREW_COST_MEMORY_KEY);
			if (crewCost > 0) storage.addCrew(crewCost);
		}
		station.getMemoryWithoutUpdate().unset(RESUPPLY_BAY_SHIPS_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(RESUPPLY_BAY_CREW_COST_MEMORY_KEY);
		clearLogisticFleetDestroyedState(station,
				RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_MEMORY_KEY,
				RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
	}

	private static void disbandResupplyBayInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		if (!hasResupplyBayBuilt(station)) return;
		recallResupplyFleetImmediately(station);
		if (destination != null) {
			destination.initMothballedShips(factionId);
			List<FleetMemberAPI> ships = getReturnableShips(station, getResupplyBayCommittedShips(station), RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY);
			if (ships != null && !ships.isEmpty() && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(RESUPPLY_BAY_CREW_COST_MEMORY_KEY);
			if (crewCost > 0) destination.addCrew(crewCost);
		}
		station.getMemoryWithoutUpdate().unset(RESUPPLY_BAY_SHIPS_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(RESUPPLY_BAY_CREW_COST_MEMORY_KEY);
		clearLogisticFleetDestroyedState(station,
				RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_MEMORY_KEY,
				RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
	}

	public static final int RESUPPLY_FLEET_FOLLOW_DAYS = 6;
	public static final int RESUPPLY_FLEET_POST_RETURN_COOLDOWN_DAYS = 6;
	private static final float RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS = 999f;
	private static final float RESUPPLY_FLEET_ARRIVAL_RANGE = 300f;
	private static final float RESUPPLY_FLEET_REARM_RANGE = 800f;

	private static final String RESUPPLY_FLEET_STATE_OUTBOUND = "outbound";
	private static final String RESUPPLY_FLEET_STATE_FOLLOWING = "following";
	private static final String RESUPPLY_FLEET_STATE_RETURNING = "returning";
	private static final String RESUPPLY_FLEET_STATE_COOLDOWN = "cooldown";

	public static final String RESUPPLY_FLEET_STATE_MEMORY_KEY = "$playerhq_module_militaryward_resupplyfleet_state";
	public static final String RESUPPLY_FLEET_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_resupplyfleet_fleet";
	public static final String RESUPPLY_FLEET_TIMER_MEMORY_KEY = "$playerhq_module_militaryward_resupplyfleet_timer";
	private static final String RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY = "$playerhq_module_militaryward_resupplyfleet_interactlocked";

	private static String getResupplyFleetState(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(RESUPPLY_FLEET_STATE_MEMORY_KEY);
		return (o instanceof String) ? (String) o : null;
	}

	public static boolean isResupplyFleetActive(SectorEntityToken station) {
		return getResupplyFleetState(station) != null;
	}

	private static CampaignFleetAPI getResupplyTouringFleet(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getFleet(RESUPPLY_FLEET_FLEET_MEMORY_KEY);
	}

	public static String getResupplyFleetStatusText(SectorEntityToken station) {
		if (isResupplyBayDestroyed(station)) {
			int daysLeft = Math.max(station.getMemoryWithoutUpdate().getInt(RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY), 0);
			return "destroyed by " + getResupplyBayDestroyedCause(station) + " -- rebuilding, ready again in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		String state = getResupplyFleetState(station);
		if (state == null) return "docked at the station, ready to be called";
		if (RESUPPLY_FLEET_STATE_OUTBOUND.equals(state)) return "en route to intercept your fleet";
		if (RESUPPLY_FLEET_STATE_FOLLOWING.equals(state)) return "escorting your fleet";
		if (RESUPPLY_FLEET_STATE_RETURNING.equals(state)) return "returning to the station";
		if (RESUPPLY_FLEET_STATE_COOLDOWN.equals(state)) return "back at the station, resting its crew before its next run";
		return "unavailable";
	}

	public static boolean dispatchResupplyFleet(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasResupplyBayBuilt(station) || isResupplyFleetActive(station) || playerFleet == null) return false;
		List<FleetMemberAPI> ships = getResupplyBayCommittedShips(station);
		if (ships == null || ships.isEmpty()) return false;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return false;

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER, "Resupply Fleet", false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);

		fleet.addAssignment(FleetAssignment.INTERCEPT, playerFleet, RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_OUTBOUND);
		mem.set(RESUPPLY_FLEET_FLEET_MEMORY_KEY, fleet);
		return true;
	}

	public static void advanceResupplyFleetRealtime(SectorEntityToken station) {
		String state = getResupplyFleetState(station);
		if (state == null) return;

		boolean expectingLiveFleet = RESUPPLY_FLEET_STATE_OUTBOUND.equals(state) || RESUPPLY_FLEET_STATE_FOLLOWING.equals(state)
				|| RESUPPLY_FLEET_STATE_RETURNING.equals(state);

		CampaignFleetAPI fleet = getResupplyTouringFleet(station);
		if (fleet == null || !fleet.isAlive()) {
			if (expectingLiveFleet) {
				handleResupplyFleetFoundDestroyed(station, "unknown causes");
			} else {
				clearResupplyFleetState(station);
			}
			return;
		}

		if (RESUPPLY_FLEET_STATE_OUTBOUND.equals(state) || RESUPPLY_FLEET_STATE_FOLLOWING.equals(state)) {
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (playerFleet == null) return;
			if (fleet.getContainingLocation() != playerFleet.getContainingLocation()) return;

			float dist = Misc.getDistance(fleet, playerFleet);
			MemoryAPI mem = station.getMemoryWithoutUpdate();
			boolean locked = mem.getBoolean(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY);

			if (!locked && dist <= RESUPPLY_FLEET_ARRIVAL_RANGE) {
				boolean firstMeeting = RESUPPLY_FLEET_STATE_OUTBOUND.equals(state);
				if (firstMeeting) {
					fleet.clearAssignments();
					mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_FOLLOWING);
				}
				mem.set(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY, true);
				openResupplyTransferDialog(station, fleet, playerFleet, firstMeeting);
			} else if (locked && dist > RESUPPLY_FLEET_REARM_RANGE) {
				mem.unset(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY);
			}
			return;
		}

		if (RESUPPLY_FLEET_STATE_RETURNING.equals(state)) {
			if (fleet.getContainingLocation() != station.getContainingLocation()) return;
			if (Misc.getDistance(fleet, station) > RESUPPLY_FLEET_ARRIVAL_RANGE) return;
			finishResupplyFleetReturn(station, fleet);
		}
	}

	private static void openResupplyTransferDialog(final SectorEntityToken station, final CampaignFleetAPI fleet,
			CampaignFleetAPI playerFleet, final boolean firstMeeting) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		CargoAPI offer = Global.getFactory().createCargo(true);
		if (storage != null) {
			offer.addSupplies(storage.getSupplies());
			offer.addFuel(storage.getFuel());
			offer.addCrew(storage.getCrew());
		}

		Runnable onDismiss = new Runnable() {
			@Override
			public void run() {
				if (firstMeeting) beginResupplyFleetFollow(station, fleet);
			}
		};

		if (offer.getSupplies() <= 0f && offer.getFuel() <= 0f && offer.getCrew() <= 0) {
			Global.getSector().getCampaignUI().addMessage(firstMeeting
					? "The Resupply Fleet meets up with you, but the Player HQ's storage has no Supplies, Fuel, "
							+ "or Crew on hand to transfer."
					: "You rendezvous with the Resupply Fleet again, but the Player HQ's storage has nothing new "
							+ "to transfer.");
			onDismiss.run();
			return;
		}

		Global.getSector().getCampaignUI().addMessage(firstMeeting
				? "The Resupply Fleet meets up with your fleet."
				: "You rendezvous with the Resupply Fleet again.");
		Global.getSector().getCampaignUI().showInteractionDialog(
				new ResupplyTransferDialogPlugin(station, offer, onDismiss), playerFleet);
	}

	private static void beginResupplyFleetFollow(SectorEntityToken station, CampaignFleetAPI fleet) {
		if (fleet == null || !fleet.isAlive()) {
			handleResupplyFleetFoundDestroyed(station, "unknown causes");
			return;
		}
		fleet.clearAssignments();
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet != null) {
			fleet.addAssignment(FleetAssignment.FOLLOW, playerFleet, RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS);
		}
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_FOLLOWING);
		mem.set(RESUPPLY_FLEET_TIMER_MEMORY_KEY, RESUPPLY_FLEET_FOLLOW_DAYS);
	}

	private static void beginResupplyFleetReturn(SectorEntityToken station, CampaignFleetAPI fleet) {
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS);
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_RETURNING);
		mem.unset(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY);
	}

	private static void finishResupplyFleetReturn(SectorEntityToken station, CampaignFleetAPI fleet) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addAll(fleet.getCargo());
		}
		List<FleetMemberAPI> ships = getResupplyBayCommittedShips(station);
		if (ships != null) {
			for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
				fleet.getFleetData().removeFleetMember(m);
			}
		}
		fleet.despawn();

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(RESUPPLY_FLEET_FLEET_MEMORY_KEY);
		mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_COOLDOWN);
		mem.set(RESUPPLY_FLEET_TIMER_MEMORY_KEY, RESUPPLY_FLEET_POST_RETURN_COOLDOWN_DAYS);
	}

	private static void clearResupplyFleetState(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(RESUPPLY_FLEET_STATE_MEMORY_KEY);
		mem.unset(RESUPPLY_FLEET_FLEET_MEMORY_KEY);
		mem.unset(RESUPPLY_FLEET_TIMER_MEMORY_KEY);
		mem.unset(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY);
	}

	public static void advanceResupplyFleetDaily(SectorEntityToken station) {
		if (isResupplyBayDestroyed(station)) {
			advanceLogisticFleetRespawn(station,
					RESUPPLY_BAY_SHIPS_MEMORY_KEY, RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY,
					RESUPPLY_BAY_DESTROYED_MEMORY_KEY, RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
			return;
		}

		String state = getResupplyFleetState(station);
		if (state == null) return;

		if (RESUPPLY_FLEET_STATE_FOLLOWING.equals(state)) {
			CampaignFleetAPI fleet = getResupplyTouringFleet(station);
			if (fleet == null || !fleet.isAlive()) {
				handleResupplyFleetFoundDestroyed(station, "unknown causes");
				return;
			}
			int daysLeft = station.getMemoryWithoutUpdate().getInt(RESUPPLY_FLEET_TIMER_MEMORY_KEY) - 1;
			if (daysLeft <= 0) {
				beginResupplyFleetReturn(station, fleet);
			} else {
				station.getMemoryWithoutUpdate().set(RESUPPLY_FLEET_TIMER_MEMORY_KEY, daysLeft);
			}
			return;
		}

		if (RESUPPLY_FLEET_STATE_COOLDOWN.equals(state)) {
			int daysLeft = station.getMemoryWithoutUpdate().getInt(RESUPPLY_FLEET_TIMER_MEMORY_KEY) - 1;
			if (daysLeft <= 0) {
				clearResupplyFleetState(station);
			} else {
				station.getMemoryWithoutUpdate().set(RESUPPLY_FLEET_TIMER_MEMORY_KEY, daysLeft);
			}
		}
	}

	private static void recallResupplyFleetImmediately(SectorEntityToken station) {
		if (!isResupplyFleetActive(station)) return;
		CampaignFleetAPI fleet = getResupplyTouringFleet(station);
		if (fleet != null && fleet.isAlive()) {
			CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
			if (storage != null) storage.addAll(fleet.getCargo());
			List<FleetMemberAPI> ships = getResupplyBayCommittedShips(station);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearResupplyFleetState(station);
	}

	public static final int MAX_COURIER_BAYS = 4;
	public static final int COURIER_BAY_MAX_SHIPS = 4;
	public static final int COURIER_BAY_TANKERS_REQUIRED = 1;
	public static final int COURIER_BAY_FREIGHTERS_REQUIRED = 3;

	public static final String COURIER_BAY_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_ships";
	public static final String COURIER_BAY_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_crewcost";
	public static final String COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_respawnmanifest";
	public static final String COURIER_BAY_DESTROYED_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_destroyed";
	public static final String COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_respawndaysleft";
	public static final String COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_destroyedcause";

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getCourierBayCommittedShips(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	public static boolean isCourierBayBuilt(SectorEntityToken station, int bayIndex) {
		return getCourierBayCommittedShips(station, bayIndex) != null || isCourierBayDestroyed(station, bayIndex);
	}

	public static boolean isCourierBayDestroyed(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex));
	}

	private static String getCourierBayDestroyedCause(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : "unknown causes";
	}

	public static int getCourierBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_COURIER_BAYS; i++) {
			if (isCourierBayBuilt(station, i)) count++;
		}
		return count;
	}

	public static boolean canBuildAnotherCourierBay(SectorEntityToken station) {
		return hasFleetHQBuilt(station) && getCourierBayCount(station) < MAX_COURIER_BAYS;
	}

	public static List<FleetMemberAPI> getCourierFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return getLogisticCandidatesFromEverywhere(station, playerFleet, false);
	}

	public static boolean isValidCourierComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.size() != COURIER_BAY_MAX_SHIPS) return false;
		int tankers = 0, freighters = 0;
		for (FleetMemberAPI m : chosen) {
			LogisticShipRole role = classifyLogisticShip(m, false);
			if (role == LogisticShipRole.TANKER) tankers++;
			else if (role == LogisticShipRole.FREIGHTER) freighters++;
			else return false;
		}
		return tankers == COURIER_BAY_TANKERS_REQUIRED && freighters == COURIER_BAY_FREIGHTERS_REQUIRED;
	}

	public static void buildCourierBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex, List<FleetMemberAPI> chosen) {
		if (!hasFleetHQBuilt(station)) return;
		if (bayIndex < 0 || bayIndex >= MAX_COURIER_BAYS || isCourierBayBuilt(station, bayIndex)) return;
		if (!isValidCourierComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		station.getMemoryWithoutUpdate().set(bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex), new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, bayIndex), crewNeeded);
	}

	public static void uninstallCourierBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MAX_COURIER_BAYS || !isCourierBayBuilt(station, bayIndex)) return;

		if (isCourierBayTouring(station, bayIndex)) {
			despawnCourierFleet(station, bayIndex);
		}

		returnShipsToStorage(station, playerFleet, getReturnableShips(station, getCourierBayCommittedShips(station, bayIndex),
				bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex)));
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) storage.addCrew(crewCost);
		}
		station.getMemoryWithoutUpdate().unset(bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, bayIndex));
		clearLogisticFleetDestroyedState(station,
				bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex),
				bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
	}

	private static void disbandAllCourierBaysInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		if (destination != null) destination.initMothballedShips(factionId);
		for (int i = 0; i < MAX_COURIER_BAYS; i++) {
			if (!isCourierBayBuilt(station, i)) continue;
			if (isCourierBayTouring(station, i)) {
				despawnCourierFleet(station, i);
			}
			List<FleetMemberAPI> ships = getReturnableShips(station, getCourierBayCommittedShips(station, i),
					bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, i));
			if (ships != null && !ships.isEmpty() && destination != null && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			if (destination != null) {
				int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, i));
				if (crewCost > 0) destination.addCrew(crewCost);
			}
			station.getMemoryWithoutUpdate().unset(bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, i));
			station.getMemoryWithoutUpdate().unset(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, i));
			clearLogisticFleetDestroyedState(station,
					bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, i), bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, i),
					bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, i), bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, i));
		}
	}

	public static final int COURIER_FLEET_TRAVEL_DAYS = 5;
	public static final int COURIER_FLEET_TOUR_LENGTH_DAYS = COURIER_FLEET_TRAVEL_DAYS * 2;

	public static final String COURIER_FLEET_TOURING_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_touring";
	public static final String COURIER_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_fleet";
	public static final String COURIER_FLEET_DAY_OFFSET_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_dayoffset";
	public static final String COURIER_FLEET_TARGET_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_target";

	public static boolean isCourierBayTouring(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(COURIER_FLEET_TOURING_MEMORY_KEY, bayIndex));
	}

	private static CampaignFleetAPI getCourierTouringFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(COURIER_FLEET_MEMORY_KEY, bayIndex));
	}

	private static SectorEntityToken getCourierTargetEntity(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex));
		return (o instanceof SectorEntityToken) ? (SectorEntityToken) o : null;
	}

	public static String getCourierBayStatusText(SectorEntityToken station, int bayIndex) {
		if (isCourierBayDestroyed(station, bayIndex)) {
			int daysLeft = Math.max(station.getMemoryWithoutUpdate().getInt(bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex)), 0);
			return "destroyed by " + getCourierBayDestroyedCause(station, bayIndex) + " -- rebuilding, ready again in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		if (!isCourierBayTouring(station, bayIndex)) {
			return "docked at the station, ready to dispatch";
		}
		SectorEntityToken target = getCourierTargetEntity(station, bayIndex);
		String targetName = target != null ? target.getName() : "its destination";
		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(COURIER_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex));
		return dayOffset < COURIER_FLEET_TRAVEL_DAYS ? ("en route to " + targetName) : "returning to the station";
	}

	public static void dispatchCourierBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex,
			SectorEntityToken target, CargoAPI outboundCargo) {
		if (!isCourierBayBuilt(station, bayIndex) || isCourierBayTouring(station, bayIndex) || target == null) return;

		List<FleetMemberAPI> ships = getCourierBayCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return;

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Courier Fleet - Bay " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, COURIER_FLEET_TOUR_LENGTH_DAYS * 2f);
		injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);
		if (outboundCargo != null) fleet.getCargo().addAll(outboundCargo);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex), target);
		mem.set(bayKey(COURIER_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex), 0);
		mem.set(bayKey(COURIER_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(COURIER_FLEET_TOURING_MEMORY_KEY, bayIndex), true);
	}

	public static void advanceCourierFleetsDaily(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_COURIER_BAYS; bayIndex++) {
			advanceCourierBayDaily(station, bayIndex);
		}
	}

	private static void advanceCourierBayDaily(SectorEntityToken station, int bayIndex) {
		if (isCourierBayDestroyed(station, bayIndex)) {
			advanceLogisticFleetRespawn(station,
					bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			return;
		}
		if (!isCourierBayTouring(station, bayIndex)) return;

		CampaignFleetAPI fleet = getCourierTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) {
			markLogisticFleetDestroyed(station, "Courier Fleet - Bay " + (bayIndex + 1), getCourierBayCommittedShips(station, bayIndex),
					"unknown causes",
					bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			clearCourierTouringState(station, bayIndex);
			return;
		}

		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(COURIER_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex)) + 1;
		if (dayOffset >= COURIER_FLEET_TOUR_LENGTH_DAYS) {
			recallCourierFleet(station, bayIndex);
			return;
		}
		station.getMemoryWithoutUpdate().set(bayKey(COURIER_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex), dayOffset);

		if (dayOffset == COURIER_FLEET_TRAVEL_DAYS) {
			arriveAndTurnAroundCourierFleet(station, bayIndex, fleet);
		}
	}

	private static void arriveAndTurnAroundCourierFleet(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		SectorEntityToken target = getCourierTargetEntity(station, bayIndex);

		if (target != null && target.getStarSystem() != null && target.getStarSystem() == station.getStarSystem()) {
			fleet.setLocation(target.getLocation().x + 50f, target.getLocation().y + 50f);
		}

		if (target != null && target.getMarket() != null) {
			SubmarketAPI targetStorage = target.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE);
			if (targetStorage != null) {
				CargoAPI colonyCargo = targetStorage.getCargo();
				CargoAPI pickedUp = Global.getFactory().createCargo(true);
				pickedUp.addAll(colonyCargo);
				colonyCargo.removeAll(pickedUp);
				colonyCargo.addAll(fleet.getCargo());
				fleet.getCargo().clear();
				fleet.getCargo().addAll(pickedUp);
			}
		}

		fleet.setLocation(station.getLocation().x, station.getLocation().y);
	}

	private static void recallCourierFleet(SectorEntityToken station, int bayIndex) {
		despawnCourierFleet(station, bayIndex);
	}

	private static void depositCourierCargoCapped(CargoAPI storage, CargoAPI fleetCargo) {
		if (storage == null || fleetCargo == null) return;

		addCrewCapped(storage, fleetCargo.getCrew());
		addMarinesCapped(storage, fleetCargo.getMarines());
		fleetCargo.removeCrew(fleetCargo.getCrew());
		fleetCargo.removeMarines(fleetCargo.getMarines());

		for (CargoStackAPI stack : new ArrayList<CargoStackAPI>(fleetCargo.getStacksCopy())) {
			if (stack.isNull() || !stack.isCommodityStack()) continue;
			String commodityId = stack.getCommodityId();
			if (commodityId == null) continue;
			float space = MiningHangarModule.MAX_STORED_RESOURCES - storage.getCommodityQuantity(commodityId);
			float toAdd = Math.max(0f, Math.min(stack.getSize(), space));
			float toDrop = stack.getSize() - toAdd;
			if (toDrop > 0f) fleetCargo.removeCommodity(commodityId, toDrop);
		}

		storage.addAll(fleetCargo);
	}

	private static void despawnCourierFleet(SectorEntityToken station, int bayIndex) {
		CampaignFleetAPI fleet = getCourierTouringFleet(station, bayIndex);
		if (fleet != null) {
			CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
			if (storage != null) {
				depositCourierCargoCapped(storage, fleet.getCargo());
			}
			List<FleetMemberAPI> ships = getCourierBayCommittedShips(station, bayIndex);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearCourierTouringState(station, bayIndex);
	}

	private static void clearCourierTouringState(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(COURIER_FLEET_TOURING_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(COURIER_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(COURIER_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex));
	}

	public static final int MAX_PATROL_FLEET_BAYS = 4;

	public static final int PATROL_FLEET_CAPITALS_REQUIRED = 1;
	public static final int PATROL_FLEET_CRUISERS_REQUIRED = 4;
	public static final int PATROL_FLEET_BOTTOM_TIER_HALF_POINTS_REQUIRED = 10;
	public static final int PATROL_FLEET_DESTROYER_HALF_POINTS = 2;
	public static final int PATROL_FLEET_FRIGATE_HALF_POINTS = 1;

	public static final int PATROL_FLEET_FRIGATE_REBUILD_DAYS = 3;
	public static final int PATROL_FLEET_DESTROYER_REBUILD_DAYS = 6;
	public static final int PATROL_FLEET_CRUISER_REBUILD_DAYS = 10;
	public static final int PATROL_FLEET_CAPITAL_REBUILD_DAYS = 16;

	public static final int PATROL_FLEET_WIPED_REBUILD_DAYS = 30;

	public static final String PATROL_FLEET_LOADOUT_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_loadout";
	public static final String PATROL_FLEET_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_fleet";
	public static final String PATROL_FLEET_DEPLOYED_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_deployed";
	public static final String PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_cooldowndaysleft";
	public static final String PATROL_FLEET_WIPED_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_wiped";

	private static final int PATROL_FLEET_OFFICER_LEVEL = 17;
	private static final String[] PATROL_FLEET_OFFICER_ELITE_SKILLS = {
			Skills.HELMSMANSHIP,
			Skills.TARGET_ANALYSIS,
			Skills.COMBAT_ENDURANCE,
			Skills.POINT_DEFENSE,
			Skills.IMPACT_MITIGATION,
			Skills.BALLISTIC_MASTERY,
			Skills.FIELD_MODULATION,
			Skills.DAMAGE_CONTROL,
			Skills.SYSTEMS_EXPERTISE,
			Skills.MISSILE_SPECIALIZATION,
			Skills.GUNNERY_IMPLANTS,
			Skills.ENERGY_WEAPON_MASTERY,
			Skills.ELECTRONIC_WARFARE,
			Skills.FLUX_REGULATION,
			Skills.FIELD_REPAIRS,
			Skills.ORDNANCE_EXPERTISE,
			Skills.POLARIZED_ARMOR,
	};

	private static boolean isWarshipOrCarrier(FleetMemberAPI m) {
		if (m.getHullSpec() == null) return false;
		ShipHullSpecAPI spec = m.getHullSpec();
		if (spec.isCarrier()) return true;
		if (spec.isCivilianNonCarrier()) return false;
		if (spec.isPhase() || spec.getHints().contains(ShipHullSpecAPI.ShipTypeHints.PHASE)) return false;
		return !m.isStation();
	}

	public static List<FleetMemberAPI> getPatrolFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		List<FleetMemberAPI> result = new ArrayList<FleetMemberAPI>();
		if (playerFleet.getFleetData() != null) {
			for (FleetMemberAPI m : playerFleet.getFleetData().getMembersListCopy()) {
				if (m.isFlagship()) continue;
				if (isWarshipOrCarrier(m)) result.add(m);
			}
		}
		addPatrolCandidatesFrom(playerFleet.getCargo(), playerFleet.getFaction().getId(), result);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) addPatrolCandidatesFrom(storage, playerFleet.getFaction().getId(), result);
		return result;
	}

	private static void addPatrolCandidatesFrom(CargoAPI cargo, String factionId, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : mothballed.getMembersListCopy()) {
			if (isWarshipOrCarrier(m)) out.add(m);
		}
	}

	public static boolean isValidPatrolFleetComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.isEmpty()) return false;
		int capitals = 0, cruisers = 0, bottomHalfPoints = 0;
		for (FleetMemberAPI m : chosen) {
			if (m.getHullSpec() == null) return false;
			HullSize size = m.getHullSpec().getHullSize();
			if (size == HullSize.CAPITAL_SHIP) capitals++;
			else if (size == HullSize.CRUISER) cruisers++;
			else if (size == HullSize.DESTROYER) bottomHalfPoints += PATROL_FLEET_DESTROYER_HALF_POINTS;
			else if (size == HullSize.FRIGATE) bottomHalfPoints += PATROL_FLEET_FRIGATE_HALF_POINTS;
			else return false;
		}
		return capitals == PATROL_FLEET_CAPITALS_REQUIRED && cruisers == PATROL_FLEET_CRUISERS_REQUIRED
				&& bottomHalfPoints == PATROL_FLEET_BOTTOM_TIER_HALF_POINTS_REQUIRED;
	}

	@SuppressWarnings("unchecked")
	private static List<ShipVariantAPI> getPatrolFleetLoadout(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(PATROL_FLEET_LOADOUT_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<ShipVariantAPI>) o : null;
	}

	public static boolean isPatrolFleetBayBuilt(SectorEntityToken station, int bayIndex) {
		return getPatrolFleetLoadout(station, bayIndex) != null;
	}

	public static int getPatrolFleetBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_PATROL_FLEET_BAYS; i++) {
			if (isPatrolFleetBayBuilt(station, i)) count++;
		}
		return count;
	}

	public static boolean canBuildAnotherPatrolFleetBay(SectorEntityToken station) {
		return hasFleetHQBuilt(station) && getPatrolFleetBayCount(station) < MAX_PATROL_FLEET_BAYS;
	}

	public static int getPatrolFleetSize(SectorEntityToken station, int bayIndex) {
		List<ShipVariantAPI> loadout = getPatrolFleetLoadout(station, bayIndex);
		return loadout != null ? loadout.size() : 0;
	}

	private static FleetMemberAPI buildFreshPatrolShip(ShipVariantAPI variant) {
		FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, variant.clone());
		member.setCaptain(createPatrolFleetOfficer());
		return member;
	}

	private static PersonAPI createPatrolFleetOfficer() {
		PersonAPI officer = Global.getSector().getFaction(Factions.PLAYER).createRandomPerson();
		MutableCharacterStatsAPI stats = officer.getStats();
		stats.setSkipRefresh(true);

		stats.setLevel(PATROL_FLEET_OFFICER_LEVEL);
		for (String skillId : PATROL_FLEET_OFFICER_ELITE_SKILLS) {
			stats.setSkillLevel(skillId, 2f);
		}

		stats.setSkipRefresh(false);
		stats.refreshCharacterStatsEffects();

		officer.setPersonality(Personalities.STEADY);
		officer.setRankId(Ranks.SPACE_COMMANDER);
		officer.setPostId(Ranks.POST_OFFICER);
		return officer;
	}

	public static void buildPatrolFleetWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex, List<FleetMemberAPI> chosen) {
		if (bayIndex < 0 || bayIndex >= MAX_PATROL_FLEET_BAYS) return;
		if (!hasFleetHQBuilt(station) || isPatrolFleetBayBuilt(station, bayIndex)) return;
		if (!isValidPatrolFleetComposition(chosen)) return;

		List<ShipVariantAPI> loadout = new ArrayList<ShipVariantAPI>();
		for (FleetMemberAPI m : chosen) {
			ShipVariantAPI variant = m.getVariant() != null ? m.getVariant().clone() : null;
			if (variant == null) continue;
			loadout.add(variant);
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		if (loadout.isEmpty()) return;

		station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_LOADOUT_MEMORY_KEY, bayIndex), loadout);
		deployPatrolFleet(station, bayIndex);
	}

	public static boolean isPatrolFleetDeployed(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(PATROL_FLEET_DEPLOYED_MEMORY_KEY, bayIndex));
	}

	public static boolean isPatrolFleetWiped(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(PATROL_FLEET_WIPED_MEMORY_KEY, bayIndex));
	}

	public static int getPatrolFleetCooldownDaysLeft(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getInt(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex));
	}

	private static CampaignFleetAPI getPatrolFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(PATROL_FLEET_FLEET_MEMORY_KEY, bayIndex));
	}

	public static String getPatrolFleetBayStatusText(SectorEntityToken station, int bayIndex) {
		if (!isPatrolFleetBayBuilt(station, bayIndex)) return null;
		if (isPatrolFleetDeployed(station, bayIndex)) {
			return "patrolling the system";
		}
		int daysLeft = Math.max(getPatrolFleetCooldownDaysLeft(station, bayIndex), 0);
		if (isPatrolFleetWiped(station, bayIndex)) {
			return "wiped out in battle -- rebuilding, redeploys in " + daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		return "recovering at the station, redeploys in " + daysLeft + " day" + (daysLeft == 1 ? "" : "s");
	}

	private static int computeRebuildDaysForLosses(List<ShipVariantAPI> loadout, List<FleetMemberAPI> survivors) {
		int frigates = 0, destroyers = 0, cruisers = 0, capitals = 0;
		for (ShipVariantAPI variant : loadout) {
			if (variant.getHullSpec() == null) continue;
			HullSize size = variant.getHullSpec().getHullSize();
			if (size == HullSize.FRIGATE) frigates++;
			else if (size == HullSize.DESTROYER) destroyers++;
			else if (size == HullSize.CRUISER) cruisers++;
			else if (size == HullSize.CAPITAL_SHIP) capitals++;
		}
		for (FleetMemberAPI m : survivors) {
			if (m.getHullSpec() == null) continue;
			HullSize size = m.getHullSpec().getHullSize();
			if (size == HullSize.FRIGATE && frigates > 0) frigates--;
			else if (size == HullSize.DESTROYER && destroyers > 0) destroyers--;
			else if (size == HullSize.CRUISER && cruisers > 0) cruisers--;
			else if (size == HullSize.CAPITAL_SHIP && capitals > 0) capitals--;
		}
		return frigates * PATROL_FLEET_FRIGATE_REBUILD_DAYS
				+ destroyers * PATROL_FLEET_DESTROYER_REBUILD_DAYS
				+ cruisers * PATROL_FLEET_CRUISER_REBUILD_DAYS
				+ capitals * PATROL_FLEET_CAPITAL_REBUILD_DAYS;
	}

	private static void deployPatrolFleet(SectorEntityToken station, int bayIndex) {
		List<ShipVariantAPI> loadout = getPatrolFleetLoadout(station, bayIndex);
		if (loadout == null || loadout.isEmpty()) return;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return;

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Patrol Fleet - Bay " + (bayIndex + 1), false);
		FleetMemberAPI flagship = null;
		for (ShipVariantAPI variant : loadout) {
			FleetMemberAPI member = buildFreshPatrolShip(variant);
			fleet.getFleetData().addFleetMember(member);
			if (flagship == null || member.getHullSpec().getHullSize() == HullSize.CAPITAL_SHIP) flagship = member;
		}
		if (flagship != null) fleet.getFleetData().setFlagship(flagship);
		injectFleetLogistics(fleet, fleet.getFleetData().getMembersListCopy());

		system.addEntity(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);
		fleet.addAssignment(FleetAssignment.PATROL_SYSTEM, station, 36500f, "Patrolling the system");

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(PATROL_FLEET_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(PATROL_FLEET_DEPLOYED_MEMORY_KEY, bayIndex), true);
		mem.unset(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_WIPED_MEMORY_KEY, bayIndex));
	}

	private static void clearPatrolFleetDeployment(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(PATROL_FLEET_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_DEPLOYED_MEMORY_KEY, bayIndex));
	}

	public static void advancePatrolFleetDaily(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_PATROL_FLEET_BAYS; bayIndex++) {
			advancePatrolFleetBayDaily(station, bayIndex);
		}
	}

	private static void advancePatrolFleetBayDaily(SectorEntityToken station, int bayIndex) {
		if (!isPatrolFleetBayBuilt(station, bayIndex)) return;

		if (isPatrolFleetDeployed(station, bayIndex)) {
			CampaignFleetAPI fleet = getPatrolFleet(station, bayIndex);
			List<ShipVariantAPI> loadout = getPatrolFleetLoadout(station, bayIndex);
			int fullSize = loadout != null ? loadout.size() : 0;

			if (fleet == null || !fleet.isAlive() || fleet.getFleetData() == null
					|| fleet.getFleetData().getMembersListCopy().isEmpty()) {
				if (fleet != null && fleet.isAlive()) fleet.despawn();
				clearPatrolFleetDeployment(station, bayIndex);
				station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_WIPED_MEMORY_KEY, bayIndex), true);
				station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex), PATROL_FLEET_WIPED_REBUILD_DAYS);
				return;
			}

			List<FleetMemberAPI> survivors = fleet.getFleetData().getMembersListCopy();
			int currentSize = survivors.size();
			if (currentSize < fullSize) {
				int rebuildDays = loadout != null ? computeRebuildDaysForLosses(loadout, survivors) : 0;
				fleet.despawn();
				clearPatrolFleetDeployment(station, bayIndex);
				station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex), rebuildDays);
			}
			return;
		}

		int daysLeft = getPatrolFleetCooldownDaysLeft(station, bayIndex) - 1;
		if (daysLeft <= 0) {
			deployPatrolFleet(station, bayIndex);
		} else {
			station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex), daysLeft);
		}
	}

	private static void clearPatrolFleetMemory(SectorEntityToken station, int bayIndex) {
		clearPatrolFleetDeployment(station, bayIndex);
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(PATROL_FLEET_LOADOUT_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_WIPED_MEMORY_KEY, bayIndex));
	}

	private static void disbandPatrolFleetBayInto(SectorEntityToken station, int bayIndex, CargoAPI destination, String factionId) {
		if (!isPatrolFleetBayBuilt(station, bayIndex)) return;

		List<ShipVariantAPI> loadout = getPatrolFleetLoadout(station, bayIndex);

		CampaignFleetAPI fleet = getPatrolFleet(station, bayIndex);
		if (fleet != null) fleet.despawn();

		if (destination != null && loadout != null) {
			destination.initMothballedShips(factionId);
			FleetDataAPI mothballed = destination.getMothballedShips();
			if (mothballed != null) {
				for (ShipVariantAPI variant : loadout) {
					mothballed.addFleetMember(buildFreshPatrolShip(variant));
				}
			}
		}

		clearPatrolFleetMemory(station, bayIndex);
	}

	private static void disbandAllPatrolFleetBaysInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		for (int bayIndex = 0; bayIndex < MAX_PATROL_FLEET_BAYS; bayIndex++) {
			disbandPatrolFleetBayInto(station, bayIndex, destination, factionId);
		}
	}

	public static void uninstallPatrolFleetBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MAX_PATROL_FLEET_BAYS) return;
		disbandPatrolFleetBayInto(station, bayIndex, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
	}

	public static boolean canDisbandFleetHQ(SectorEntityToken station) {
		return hasFleetHQBuilt(station)
				&& getTrainingExpeditionBayCount(station) == 0
				&& !hasResupplyBayBuilt(station)
				&& getCourierBayCount(station) == 0
				&& getPatrolFleetBayCount(station) == 0;
	}

	public static void handleLogisticFleetLostInBattle(SectorEntityToken station, CampaignFleetAPI fleet, String cause) {
		if (station == null || fleet == null) return;

		for (int bayIndex = 0; bayIndex < MAX_MINING_FLEET_BAYS; bayIndex++) {
			if (fleet == getMiningTouringFleet(station, bayIndex)) {
				markLogisticFleetDestroyed(station, "Mining Fleet - Bay " + (bayIndex + 1), getMiningFleetCommittedShips(station, bayIndex), cause,
						bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
						bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
						bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
				clearMiningTouringState(station, bayIndex);
				return;
			}
		}

		for (int bayIndex = 0; bayIndex < MAX_COURIER_BAYS; bayIndex++) {
			if (fleet == getCourierTouringFleet(station, bayIndex)) {
				markLogisticFleetDestroyed(station, "Courier Fleet - Bay " + (bayIndex + 1), getCourierBayCommittedShips(station, bayIndex), cause,
						bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
						bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
						bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
				clearCourierTouringState(station, bayIndex);
				return;
			}
		}

		if (fleet == getResupplyTouringFleet(station)) {
			handleResupplyFleetFoundDestroyed(station, cause);
		}
	}
}
