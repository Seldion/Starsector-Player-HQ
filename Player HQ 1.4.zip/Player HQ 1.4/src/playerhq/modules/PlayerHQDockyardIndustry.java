package playerhq.modules;

import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;

public class PlayerHQDockyardIndustry extends BaseIndustry {

	@Override
	public void apply() {
		super.apply(true);
	}

	@Override
	public boolean isAvailableToBuild() {
		return false;
	}

	@Override
	public boolean showWhenUnavailable() {
		return false;
	}

	@Override
	public boolean isHidden() {
		return true;
	}
}
