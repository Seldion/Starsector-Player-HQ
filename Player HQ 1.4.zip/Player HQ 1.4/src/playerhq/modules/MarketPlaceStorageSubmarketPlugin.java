package playerhq.modules;

import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CoreUIAPI;
import com.fs.starfarer.api.campaign.SubmarketPlugin.TransferAction;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;

public class MarketPlaceStorageSubmarketPlugin extends BaseSubmarketPlugin {

	@Override
	public void init(SubmarketAPI submarket) {
		super.init(submarket);
	}

	@Override
	public String getName() {
		return "Agora";
	}

	@Override
	public void updateCargoPrePlayerInteraction() {
	}

	@Override
	public boolean isParticipatesInEconomy() {
		return false;
	}

	@Override
	public float getTariff() {
		return 0f;
	}

	@Override
	public boolean isFreeTransfer() {
		return true;
	}

	@Override
	public boolean isBlackMarket() {
		return false;
	}

	@Override
	public boolean isOpenMarket() {
		return false;
	}

	@Override
	public boolean isEnabled(CoreUIAPI ui) {
		return true;
	}

	@Override
	public String getTooltipAppendix(CoreUIAPI ui) {
		int total = (int) MarketPlaceModule.getTotalValue(getCargo());
		return "Total value of items stored: " + total + " credits.";
	}

	@Override
	public String getBuyVerb() {
		return "Take";
	}

	@Override
	public String getSellVerb() {
		return "Store";
	}

	@Override
	public boolean isIllegalOnSubmarket(CargoStackAPI stack, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return !MarketPlaceModule.isDepositable(stack);
		}
		return false;
	}

	@Override
	public boolean isIllegalOnSubmarket(String commodityId, TransferAction action) {
		return false;
	}

	@Override
	public String getIllegalTransferText(CargoStackAPI stack, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "Only weapons, fighter wings, blueprints, and hull mods can be stored here";
		}
		return super.getIllegalTransferText(stack, action);
	}

	@Override
	public boolean isIllegalOnSubmarket(FleetMemberAPI member, TransferAction action) {
		return action == TransferAction.PLAYER_SELL;
	}

	@Override
	public String getIllegalTransferText(FleetMemberAPI member, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "Ships can't be stored in the Agora";
		}
		return super.getIllegalTransferText(member, action);
	}
}
