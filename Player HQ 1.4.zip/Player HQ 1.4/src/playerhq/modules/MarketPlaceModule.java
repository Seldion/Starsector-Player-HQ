package playerhq.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class MarketPlaceModule {

	public static final String MEMORY_KEY = "$playerhq_module_marketplace";
	public static final String INVENTORY_MEMORY_KEY = "$playerhq_module_marketplace_inventory";

	public static final String MARKETPLACE_SUBMARKET_ID = "playerhq_marketplace";
	public static final String BLACKMARKET_SUBMARKET_ID = "playerhq_blackmarket";

	public static final float CREDIT_COST = 5000f;
	public static final float METALS_COST = 500f;
	public static final float TRANSPLUTONICS_COST = 50f;
	public static final float HEAVY_MACHINERY_COST = 10f;

	public static final float MIN_MERCHANT_BUDGET = 0f;
	public static final float MAX_MERCHANT_BUDGET = 1000000f;

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void install(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (isBuilt(station) || !hasCost(station, playerFleet)) return;

		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		MarketAPI market = station.getMarket();
		if (market != null) {
			if (!market.hasSubmarket(MARKETPLACE_SUBMARKET_ID)) {
				market.addSubmarket(MARKETPLACE_SUBMARKET_ID);
			}
			if (!market.hasSubmarket(BLACKMARKET_SUBMARKET_ID)) {
				market.addSubmarket(BLACKMARKET_SUBMARKET_ID);
			}
		}

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void uninstall(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(Commodities.METALS, METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);
			storage.addAll(getInventory(station));
		}
		removeMarketSubmarkets(station);
		clearState(station);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);
		cargo.addAll(getInventory(station));
		removeMarketSubmarkets(station);
		clearState(station);
	}

	private static void removeMarketSubmarkets(SectorEntityToken station) {
		MarketAPI market = station.getMarket();
		if (market == null) return;
		if (market.hasSubmarket(MARKETPLACE_SUBMARKET_ID)) {
			market.removeSubmarket(MARKETPLACE_SUBMARKET_ID);
		}
		if (market.hasSubmarket(BLACKMARKET_SUBMARKET_ID)) {
			market.removeSubmarket(BLACKMARKET_SUBMARKET_ID);
		}
	}

	private static void clearState(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(INVENTORY_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(EXTRA_MERCHANT_BUDGET_MEMORY_KEY);
	}

	public static CargoAPI getInventory(SectorEntityToken station) {
		MarketAPI market = station.getMarket();
		if (market != null && market.hasSubmarket(MARKETPLACE_SUBMARKET_ID)) {
			CargoAPI cargo = market.getSubmarket(MARKETPLACE_SUBMARKET_ID).getCargo();
			migrateLegacyInventory(station, cargo);
			return cargo;
		}
		return Global.getFactory().createCargo(true);
	}

	@SuppressWarnings("unchecked")
	private static void migrateLegacyInventory(SectorEntityToken station, CargoAPI submarketCargo) {
		Object o = station.getMemoryWithoutUpdate().get(INVENTORY_MEMORY_KEY);
		if (o instanceof CargoAPI) {
			submarketCargo.addAll((CargoAPI) o);
			station.getMemoryWithoutUpdate().unset(INVENTORY_MEMORY_KEY);
		}
	}

	public static CargoAPI getDepositCandidates(CampaignFleetAPI playerFleet) {
		CargoAPI copy = Global.getFactory().createCargo(true);
		for (CargoStackAPI stack : playerFleet.getCargo().getStacksCopy()) {
			if (isDepositable(stack)) {
				copy.addFromStack(stack);
			}
		}
		return copy;
	}

	public static boolean isDepositable(CargoStackAPI stack) {
		if (stack.isWeaponStack()) return true;
		if (stack.isFighterWingStack()) return true;
		if (stack.isSpecialStack()) {
			SpecialItemData data = stack.getSpecialDataIfSpecial();
			if (data == null) return false;
			String id = data.getId();
			return Items.TAG_MODSPEC.equals(id) || Items.SHIP_BP.equals(id)
					|| Items.WEAPON_BP.equals(id) || Items.FIGHTER_BP.equals(id);
		}
		return false;
	}

	public static void depositPicked(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI picked) {
		if (picked == null || picked.isEmpty()) return;
		for (CargoStackAPI stack : picked.getStacksCopy()) {
			playerFleet.getCargo().removeItems(stack.getType(), stack.getData(), stack.getSize());
		}
		getInventory(station).addAll(picked);
	}

	public static void withdrawPicked(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI picked) {
		if (picked == null || picked.isEmpty()) return;
		CargoAPI inventory = getInventory(station);
		for (CargoStackAPI stack : picked.getStacksCopy()) {
			inventory.removeItems(stack.getType(), stack.getData(), stack.getSize());
		}
		playerFleet.getCargo().addAll(picked);
	}

	public static float getTotalValue(CargoAPI cargo) {
		float total = 0f;
		for (CargoStackAPI stack : cargo.getStacksCopy()) {
			total += stack.getBaseValuePerUnit() * stack.getSize();
		}
		return total;
	}

	public static final String EXTRA_MERCHANT_BUDGET_MEMORY_KEY = "$playerhq_module_extra_merchant_budget";

	public static void addExchangeSpend(SectorEntityToken station, float amountSpent) {
		if (amountSpent <= 0f) return;
		float current = station.getMemoryWithoutUpdate().getFloat(EXTRA_MERCHANT_BUDGET_MEMORY_KEY);
		station.getMemoryWithoutUpdate().set(EXTRA_MERCHANT_BUDGET_MEMORY_KEY, current + amountSpent);
	}

	public static float collectMerchantIncome(SectorEntityToken station) {
		if (!isBuilt(station)) return 0f;

		float extra = station.getMemoryWithoutUpdate().getFloat(EXTRA_MERCHANT_BUDGET_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(EXTRA_MERCHANT_BUDGET_MEMORY_KEY);

		CargoAPI inventory = getInventory(station);
		if (inventory.isEmpty()) return 0f;

		float budget = MIN_MERCHANT_BUDGET + (float) Math.random() * (MAX_MERCHANT_BUDGET - MIN_MERCHANT_BUDGET) + extra;
		float spent = 0f;

		List<CargoStackAPI> stacks = new ArrayList<CargoStackAPI>(inventory.getStacksCopy());
		Collections.sort(stacks, new Comparator<CargoStackAPI>() {
			@Override
			public int compare(CargoStackAPI a, CargoStackAPI b) {
				return Float.compare(b.getBaseValuePerUnit(), a.getBaseValuePerUnit());
			}
		});

		for (CargoStackAPI stack : stacks) {
			float unitValue = stack.getBaseValuePerUnit();
			if (unitValue <= 0f) continue;
			float remainingBudget = budget - spent;
			if (remainingBudget <= 0f) break;

			float unitsAffordable = (float) Math.floor(remainingBudget / unitValue);
			float unitsToSell = Math.min(stack.getSize(), unitsAffordable);
			if (unitsToSell <= 0f) continue;

			inventory.removeItems(stack.getType(), stack.getData(), unitsToSell);
			spent += unitsToSell * unitValue;
		}

		if (spent <= 0f) return 0f;
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet != null) playerFleet.getCargo().getCredits().add(spent);
		return spent;
	}
}
