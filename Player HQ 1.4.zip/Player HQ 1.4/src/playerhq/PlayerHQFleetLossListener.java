package playerhq;

import java.util.List;

import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import playerhq.modules.MilitaryWardModule;
import playerhq.util.PlayerHQUtils;

public class PlayerHQFleetLossListener extends BaseCampaignEventListener {

	public PlayerHQFleetLossListener() {
		super(false);
	}

	@Override
	public void reportFleetDespawned(CampaignFleetAPI fleet, FleetDespawnReason reason, Object param) {
		if (reason != FleetDespawnReason.DESTROYED_BY_BATTLE) return;

		SectorEntityToken station = PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
		if (station == null) return;

		MilitaryWardModule.handleLogisticFleetLostInBattle(station, fleet, describeCause(fleet, param));
	}

	private String describeCause(CampaignFleetAPI fleet, Object param) {
		if (param instanceof BattleAPI) {
			BattleAPI battle = (BattleAPI) param;
			String cause = firstFactionName(battle.getOtherSideSnapshotFor(fleet));
			if (cause == null) cause = firstFactionName(battle.getNonPlayerSideSnapshot());
			if (cause != null) return cause;
		}
		return "unknown attackers";
	}

	private String firstFactionName(List<CampaignFleetAPI> fleets) {
		if (fleets == null) return null;
		for (CampaignFleetAPI f : fleets) {
			if (f != null && f.getFaction() != null) {
				return f.getFaction().getDisplayNameWithArticle() + " fleet";
			}
		}
		return null;
	}
}
