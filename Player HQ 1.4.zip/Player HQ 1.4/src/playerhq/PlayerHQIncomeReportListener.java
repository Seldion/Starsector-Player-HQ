package playerhq;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MonthlyReport;
import com.fs.starfarer.api.campaign.econ.MonthlyReport.FDNode;
import com.fs.starfarer.api.campaign.listeners.EconomyTickListener;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.modules.RecreationalHubModule;
import playerhq.util.PlayerHQUtils;

public class PlayerHQIncomeReportListener implements EconomyTickListener {

	public static final String NODE_ID = "playerhq_node";

	@Override
	public void reportEconomyTick(int iterIndex) {
		int lastIterInMonth = (int) Global.getSettings().getFloat("economyIterPerMonth") - 1;
		if (iterIndex != lastIterInMonth) return;

		SectorEntityToken station = PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
		if (station == null) return;

		float income = 0f;
		if (RecreationalHubModule.isBuilt(station)) {
			income = RecreationalHubModule.getFinalIncome(station);
		}
		boolean upkeepApplies = ConstructPlayerHQAbility.isUpkeepApplicable(station);

		if (income <= 0f && !upkeepApplies) return;

		MonthlyReport report = SharedData.getData().getCurrentReport();
		FDNode node = report.getNode(NODE_ID);
		if (node.name == null) {
			node.name = "Player HQ";
			node.icon = Global.getSettings().getSpriteName("income_report", "generic_income");
		}

		if (income > 0f) {
			FDNode incomeNode = report.getNode(node, "playerhq_recreation_income");
			incomeNode.name = "Resort income";
			incomeNode.income = income;
			incomeNode.icon = Global.getSettings().getSpriteName("income_report", "generic_income");
		}

		if (upkeepApplies) {
			FDNode upkeepNode = report.getNode(node, "playerhq_upkeep");
			upkeepNode.name = "Player HQ orbital upkeep";
			upkeepNode.upkeep = ConstructPlayerHQAbility.POPULATED_ORBIT_UPKEEP;
			upkeepNode.icon = Global.getSettings().getSpriteName("income_report", "generic_expense");
		}
	}

	@Override
	public void reportEconomyMonthEnd() {
	}
}
