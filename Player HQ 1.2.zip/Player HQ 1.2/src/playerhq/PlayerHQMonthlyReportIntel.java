package playerhq;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.HydroponicsHubModule.HydroponicsResult;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.IndustrialHubModule.IndustrialHubResult;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.MiningHangarModule.MiningResult;
import playerhq.modules.RecreationalHubModule;
import playerhq.util.PlayerHQUtils;

/**
 * A single, persistent status report -- styled after the settlement report from Random
 * Assortment of Things -- covering where the station is built, what's built on it, and what it
 * produced last month. Unlike the old one-shot version, this same instance is reused and updated
 * in place every month rather than being deleted and recreated, so it doesn't disappear from the
 * Intel screen between checks.
 */
public class PlayerHQMonthlyReportIntel extends BaseIntelPlugin {

	public static final String ICON_PATH = "graphics/icons/intel/playerhq_report.png";

	private SectorEntityToken station;

	private MiningResult mining;
	private IndustrialHubResult industrial;
	private HydroponicsResult hydroponics;
	private float recreationIncome;
	private float marketPlaceIncome;
	private float upkeepCharged;
	private List<String> deliveredShips = new ArrayList<String>();
	private List<String> deliveredWeapons = new ArrayList<String>();
	private List<String> trainingExpeditionLoot = new ArrayList<String>();

	public static void report(SectorEntityToken station, MiningResult mining, IndustrialHubResult industrial,
			HydroponicsResult hydroponics, float recreationIncome, float marketPlaceIncome, float upkeepCharged,
			List<String> deliveredShips, List<String> deliveredWeapons, List<String> trainingExpeditionLoot) {
		if (station == null) return;

		PlayerHQMonthlyReportIntel intel = (PlayerHQMonthlyReportIntel)
				Global.getSector().getIntelManager().getFirstIntel(PlayerHQMonthlyReportIntel.class);
		boolean isNew = intel == null;
		if (isNew) {
			intel = new PlayerHQMonthlyReportIntel();
		}

		intel.station = station;
		intel.mining = mining;
		intel.industrial = industrial;
		intel.hydroponics = hydroponics;
		intel.recreationIncome = recreationIncome;
		intel.marketPlaceIncome = marketPlaceIncome;
		intel.upkeepCharged = upkeepCharged;
		intel.deliveredShips = deliveredShips != null ? deliveredShips : new ArrayList<String>();
		intel.deliveredWeapons = deliveredWeapons != null ? deliveredWeapons : new ArrayList<String>();
		intel.trainingExpeditionLoot = trainingExpeditionLoot != null ? trainingExpeditionLoot : new ArrayList<String>();

		if (isNew) {
			Global.getSector().getIntelManager().addIntel(intel);
		} else {
			intel.sendUpdateIfPlayerHasIntel(null, false);
		}
	}

	/**
	 * Creates the persistent report as soon as the station itself is built, so the Facilities
	 * section is visible on the Intel screen right away instead of only appearing after the first
	 * monthly tick fires. Does nothing if the report already exists.
	 */
	public static void ensureCreated(SectorEntityToken station) {
		if (station == null) return;

		IntelInfoPlugin existing = Global.getSector().getIntelManager().getFirstIntel(PlayerHQMonthlyReportIntel.class);
		if (existing != null) return;

		PlayerHQMonthlyReportIntel intel = new PlayerHQMonthlyReportIntel();
		intel.station = station;
		Global.getSector().getIntelManager().addIntel(intel);
	}

	/** Removes the persistent report entirely -- called when the station itself is dismantled. */
	public static void removeIfPresent() {
		IntelInfoPlugin intel = Global.getSector().getIntelManager().getFirstIntel(PlayerHQMonthlyReportIntel.class);
		if (intel != null) {
			Global.getSector().getIntelManager().removeIntel(intel);
		}
	}

	@Override
	protected String getName() {
		return "Player HQ Status Report";
	}

	@Override
	public String getIcon() {
		return ICON_PATH;
	}

	/**
	 * This is the player's own station -- always show it in the Intel screen, regardless of comm
	 * relay range. The base class's default visibility only turns on once the player happens to be
	 * within relay range of a comm relay, which could otherwise leave this entry never appearing at
	 * all.
	 */
	@Override
	public boolean isPlayerVisible() {
		return !isHidden() && !isEnded();
	}

	/**
	 * Puts this report under the Intel screen's "Personal" filter tab. That tab isn't a hardcoded
	 * engine category -- it's just the set of intel entries tagged with the literal string
	 * "Personal", same as how other mods (e.g. Nexerelin's own personal-report intel) do it.
	 */
	@Override
	public Set<String> getIntelTags(SectorMapAPI map) {
		Set<String> tags = super.getIntelTags(map);
		tags.add("Personal");
		return tags;
	}

	// No getMapLocation() override -- leaving it null (the base class default) keeps this report out
	// of the "Local" tag, so it doesn't also show up under the Local tab.

	// No addBulletPoints() override -- the base class's default is a no-op, so the intel list row on
	// the left just shows the icon and title, the same minimal footprint as Random Assortment of
	// Things' settlement report. The full production report still lives in createSmallDescription()
	// below, shown when the entry itself is opened.

	@Override
	public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		float opad = 10f;
		info.addPara(getName(), opad);
		addLines(info, opad);
	}

	private void addLines(TooltipMakerAPI info, float pad) {
		Color h = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();
		Color headingText = Misc.getBasePlayerColor();
		Color headingBg = Misc.getDarkPlayerColor();

		if (station == null || !station.isAlive()) {
			info.addPara("The station no longer exists.", pad, bad);
			return;
		}

		info.addPara(PlayerHQUtils.getStationLocationSummary(station), pad, h);

		info.addSectionHeading("Facilities", headingText, headingBg, Alignment.MID, pad);
		addFacilitiesSection(info, pad);

		info.addSectionHeading("Last Month's Production", headingText, headingBg, Alignment.MID, pad);
		addProductionSection(info, pad);
	}

	private static class Facility {
		final String name;
		final String iconCommodityId;
		Facility(String name, String iconCommodityId) {
			this.name = name;
			this.iconCommodityId = iconCommodityId;
		}
	}

	private void addFacilitiesSection(TooltipMakerAPI info, float pad) {
		List<Facility> facilities = getBuiltFacilities(station);

		if (facilities.isEmpty()) {
			info.addPara("No modules have been built yet.", pad);
			return;
		}

		for (Facility facility : facilities) {
			TooltipMakerAPI row = info.beginImageWithText(commodityIcon(facility.iconCommodityId), 32f);
			row.addPara(facility.name, Misc.getHighlightColor(), 0f);
			info.addImageWithText(pad * 0.5f);
		}

		if (MilitaryWardModule.hasTrainingExpeditionHQBuilt(station)) {
			info.addPara("Training Expedition HQ: %s/%s bays built.", pad, Misc.getHighlightColor(),
					"" + MilitaryWardModule.getTrainingExpeditionBayCount(station),
					"" + MilitaryWardModule.MAX_TRAINING_EXPEDITION_BAYS);
		}
	}

	private static List<Facility> getBuiltFacilities(SectorEntityToken station) {
		List<Facility> facilities = new ArrayList<Facility>();

		if (MiningHangarModule.isBuilt(station)) facilities.add(new Facility("Materials Acquisition Hub", Commodities.ORE));
		if (RecreationalHubModule.isBuilt(station)) facilities.add(new Facility("Resort", Commodities.LUXURY_GOODS));
		if (IndustrialHubModule.isBuilt(station)) facilities.add(new Facility("Manufactorium", Commodities.HEAVY_MACHINERY));
		if (HydroponicsHubModule.isBuilt(station)) facilities.add(new Facility("Bio-Dome", Commodities.FOOD));
		if (AssemblyBayModule.isBuilt(station)) facilities.add(new Facility("Strategic Assembly", Commodities.HAND_WEAPONS));
		if (MilitaryWardModule.isBuilt(station)) facilities.add(new Facility("Military Paradigm", Commodities.MARINES));
		if (MilitaryWardModule.hasTrainingExpeditionHQBuilt(station)) facilities.add(new Facility("Training Expedition HQ", Commodities.SUPPLIES));

		return facilities;
	}

	private void addProductionSection(TooltipMakerAPI info, float pad) {
		Color h = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();

		boolean anyProduction = false;

		if (mining != null) {
			if (!mining.contributingPlanets.isEmpty()) {
				info.addPara("Materials Acquisition Hub drew from: %s.", pad, h, String.join(", ", mining.contributingPlanets));
			}
			anyProduction |= addQuantityRow(info, pad, Commodities.ORE, mining.ore);
			anyProduction |= addQuantityRow(info, pad, Commodities.RARE_ORE, mining.rareOre);
			anyProduction |= addQuantityRow(info, pad, Commodities.VOLATILES, mining.volatiles);
			anyProduction |= addQuantityRow(info, pad, Commodities.ORGANICS, mining.organics);
			if (mining.oreLostToCap > 0f) {
				info.addPara("The station's ore storage is full (10,000 cap) - %s ore could not be collected.",
						pad, bad, fmt(mining.oreLostToCap));
			}
			if (mining.rareOreLostToCap > 0f) {
				info.addPara("The station's transplutonic ore storage is full (10,000 cap) - %s transplutonic ore could not be collected.",
						pad, bad, fmt(mining.rareOreLostToCap));
			}
			if (mining.volatilesLostToCap > 0f) {
				info.addPara("The station's volatiles storage is full (10,000 cap) - %s volatiles could not be collected.",
						pad, bad, fmt(mining.volatilesLostToCap));
			}
			if (mining.organicsLostToCap > 0f) {
				info.addPara("The station's organics storage is full (10,000 cap) - %s organics could not be collected.",
						pad, bad, fmt(mining.organicsLostToCap));
			}
		}

		if (industrial != null) {
			anyProduction |= addQuantityRow(info, pad, Commodities.METALS, industrial.metals);
			anyProduction |= addQuantityRow(info, pad, Commodities.RARE_METALS, industrial.transplutonics);
			anyProduction |= addQuantityRow(info, pad, Commodities.HEAVY_MACHINERY, industrial.heavyMachinery);
			anyProduction |= addQuantityRow(info, pad, Commodities.SUPPLIES, industrial.supplies);
			anyProduction |= addQuantityRow(info, pad, Commodities.DRUGS, industrial.drugs);
			anyProduction |= addQuantityRow(info, pad, Commodities.ORGANS, industrial.organs);
			anyProduction |= addQuantityRow(info, pad, Commodities.DOMESTIC_GOODS, industrial.domesticGoods);
			anyProduction |= addQuantityRow(info, pad, Commodities.LUXURY_GOODS, industrial.luxuryGoods);
			anyProduction |= addQuantityRow(info, pad, Commodities.HAND_WEAPONS, industrial.heavyArmaments);
			anyProduction |= addQuantityRow(info, pad, Commodities.FUEL, industrial.fuel);
		}

		if (hydroponics != null) {
			anyProduction |= addQuantityRow(info, pad, Commodities.FOOD, hydroponics.food);
			anyProduction |= addQuantityRow(info, pad, Commodities.ORGANICS, hydroponics.organics);
			if (hydroponics.foodLostToCap > 0f) {
				info.addPara("The station's food storage is full (10,000 cap) - %s food could not be produced.",
						pad, bad, fmt(hydroponics.foodLostToCap));
			}
			if (hydroponics.organicsLostToCap > 0f) {
				info.addPara("The station's organics storage is full (10,000 cap) - %s organics could not be produced.",
						pad, bad, fmt(hydroponics.organicsLostToCap));
			}
		}

		if (recreationIncome > 0f) {
			info.addPara("Resort generated %s credits in income.", pad, h, fmt(recreationIncome));
			anyProduction = true;
		}

		if (marketPlaceIncome > 0f) {
			info.addPara("Agora merchants paid %s credits for stock.", pad, h, fmt(marketPlaceIncome));
			anyProduction = true;
		}

		if (!deliveredShips.isEmpty()) {
			info.addPara("Strategic Assembly completed %s: %s.", pad, h,
					deliveredShips.size() == 1 ? "1 ship" : deliveredShips.size() + " ships",
					String.join(", ", deliveredShips));
			anyProduction = true;
		}

		if (!deliveredWeapons.isEmpty()) {
			info.addPara("Strategic Assembly completed %s: %s.", pad, h,
					deliveredWeapons.size() == 1 ? "1 weapon batch" : deliveredWeapons.size() + " weapon batches",
					String.join(", ", deliveredWeapons));
			anyProduction = true;
		}

		if (!trainingExpeditionLoot.isEmpty()) {
			info.addPara("Training Expeditions found: %s.", pad, h, String.join("; ", trainingExpeditionLoot));
			anyProduction = true;
		}

		if (upkeepCharged > 0f) {
			info.addPara("Station upkeep cost %s credits.", pad, bad, fmt(upkeepCharged));
			anyProduction = true;
		}

		if (!anyProduction) {
			info.addPara("Nothing to report yet.", pad);
		}
	}

	/** Adds an icon + "123x Name" row for a produced quantity; does nothing (and returns false) if none was produced. */
	private boolean addQuantityRow(TooltipMakerAPI info, float pad, String commodityId, float quantity) {
		if (quantity <= 0f) return false;

		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(commodityId);
		TooltipMakerAPI row = info.beginImageWithText(spec.getIconName(), 32f);
		row.addPara(fmt(quantity) + "x " + spec.getName(), Misc.getHighlightColor(), 0f);
		info.addImageWithText(pad * 0.5f);
		return true;
	}

	private static String commodityIcon(String commodityId) {
		return Global.getSettings().getCommoditySpec(commodityId).getIconName();
	}

	private static String fmt(float value) {
		return "" + (int) value;
	}
}
