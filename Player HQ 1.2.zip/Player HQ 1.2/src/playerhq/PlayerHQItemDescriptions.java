package playerhq;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.loading.Description;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;

/**
 * Patches the shared, ID-keyed descriptions of vanilla special items to note the effects they
 * have when installed in a Player HQ module. Runs once per game load; idempotent (checks for its
 * own marker before appending) so repeated loads don't duplicate the text.
 */
public class PlayerHQItemDescriptions {

	private static final String MARKER = "== Player HQ effects ==";

	public static void apply() {
		appendBlock(Items.MANTLE_BORE,
				"Materials Acquisition Hub: increases resource collection efficiency from "
						+ Math.round(MiningHangarModule.EFFICIENCY_BASE * 100f) + "% to "
						+ Math.round(MiningHangarModule.EFFICIENCY_WITH_BORE * 100f) + "%.");

		appendBlock(Items.DEALMAKER_HOLOSUITE,
				"Resort (as VR Suites): +" + Math.round(RecreationalHubModule.HOLOSUITE_BONUS * 100f) + "% income.\n"
						+ "Military Paradigm: contributes to Marine training speed.");

		appendBlock(Items.ORBITAL_FUSION_LAMP,
				"Resort (as Build Beach Resort): +" + Math.round(RecreationalHubModule.FUSION_LAMP_BONUS * 100f) + "% income.\n"
						+ "Manufactorium: reduces the ore cost of refining metals and transplutonics per batch. (-2)\n"
						+ "Bio-Dome: required to build.");

		appendBlock(Items.CATALYTIC_CORE,
				"Manufactorium: increases metals and transplutonics output per batch. (+"
						+ (int) IndustrialHubModule.CATALYTIC_CORE_OUTPUT_BONUS + ")");

		appendBlock(Items.SYNCHROTRON,
				"Manufactorium: unlocks production of Fuel from Volatiles. ("
						+ (int) IndustrialHubModule.FUEL_PER_BATCH + " fuel per "
						+ (int) IndustrialHubModule.VOLATILES_PER_FUEL_BATCH + " volatile)");

		appendBlock(Items.PLASMA_DYNAMO,
				"Materials Acquisition Hub: adds " + MiningHangarModule.PLASMA_DYNAMO_VOLATILES_ECON_UNITS
						+ " econ-unit worth of volatiles to the system's collection total.");

		String nanoforgeShared = "Manufactorium: unlocks production of Domestic Goods, Luxury Goods, and Heavy Armaments.\n"
				+ "Strategic Assembly: reduces ship and weapon construction costs.";
		appendBlock(Items.CORRUPTED_NANOFORGE, nanoforgeShared
				+ "\nStrategic Assembly discount (Corrupted): "
				+ Math.round(AssemblyBayModule.CORRUPTED_NANOFORGE_DISCOUNT * 100f) + "%.");
		appendBlock(Items.PRISTINE_NANOFORGE, nanoforgeShared
				+ "\nStrategic Assembly discount (Pristine): "
				+ Math.round(AssemblyBayModule.PRISTINE_NANOFORGE_DISCOUNT * 100f) + "%.");
	}

	private static void appendBlock(String itemId, String body) {
		Description desc = Global.getSettings().getDescription(itemId, Description.Type.RESOURCE);
		if (desc == null) return;

		String text = desc.getText1();
		if (text != null && text.contains(MARKER)) return;

		String addition = "\n\n" + MARKER + "\n" + body;
		desc.setText1((text == null ? "" : text) + addition);
	}
}
