package playerhq.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

/**
 * The Market Place Station Upgrade adds two real submarkets (see {@code data/campaign/submarkets.csv}),
 * both opened through the same vanilla trade screen used at any planet or station, alongside the
 * station's own Storage tab. Selling is still entirely hand-simulated: the player deposits weapons,
 * fighter wings, blueprints, and installable hull mods directly through the vanilla trade screen into
 * the Market Place's own storage submarket ({@link MarketPlaceStorageSubmarketPlugin}, "Agora"; free
 * transfer, no tariff, restricted to those four item types so nothing the player actually wants to
 * keep -- a Nanoforge waiting to be installed, say -- can end up in it by mistake), and once a month a
 * random budget of merchant credits buys up whatever's sitting there, priciest items first, until the
 * budget runs out or there's nothing left it can afford -- see {@link #collectMerchantIncome}. Buying
 * is the other submarket, {@link BlackMarketSubmarketPlugin} ("Exchange"), buy-only, restocked monthly
 * with a curated, rarity-weighted mix of weapons, fighter wings, blueprints, and hull mods.
 */
public class MarketPlaceModule {

	public static final String MEMORY_KEY = "$playerhq_module_marketplace";
	/** Legacy memory key from before the Agora inventory became a real submarket -- see {@link #getInventory}. */
	public static final String INVENTORY_MEMORY_KEY = "$playerhq_module_marketplace_inventory";

	public static final String MARKETPLACE_SUBMARKET_ID = "playerhq_marketplace";
	public static final String BLACKMARKET_SUBMARKET_ID = "playerhq_blackmarket";

	public static final float CREDIT_COST = 5000f;
	public static final float METALS_COST = 500f;
	public static final float TRANSPLUTONICS_COST = 50f;
	public static final float HEAVY_MACHINERY_COST = 10f;

	/** Random monthly credit budget merchants spend buying stock out of the Agora inventory -- see {@link #collectMerchantIncome}. */
	public static final float MIN_MERCHANT_BUDGET = 0f;
	public static final float MAX_MERCHANT_BUDGET = 1000000f;

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void install(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (isBuilt(station) || !hasCost(station, playerFleet)) return;

		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		MarketAPI market = station.getMarket();
		if (market != null) {
			if (!market.hasSubmarket(MARKETPLACE_SUBMARKET_ID)) {
				market.addSubmarket(MARKETPLACE_SUBMARKET_ID);
			}
			if (!market.hasSubmarket(BLACKMARKET_SUBMARKET_ID)) {
				market.addSubmarket(BLACKMARKET_SUBMARKET_ID);
			}
		}

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	/**
	 * Uninstalling (not dismantling) returns half the build resources to the station's own inventory,
	 * and empties whatever's currently in the Agora's own inventory back into station storage
	 * too. The Exchange's stock is merchant-owned, not the player's, so it's simply discarded.
	 */
	public static void uninstall(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(Commodities.METALS, METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);
			storage.addAll(getInventory(station));
		}
		removeMarketSubmarkets(station);
		clearState(station);
	}

	/** Dismantle-time refund -- the station is going away, so this goes to the fleet's cargo instead, same as the other Station Upgrades items. */
	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);
		cargo.addAll(getInventory(station));
		removeMarketSubmarkets(station);
		clearState(station);
	}

	private static void removeMarketSubmarkets(SectorEntityToken station) {
		MarketAPI market = station.getMarket();
		if (market == null) return;
		if (market.hasSubmarket(MARKETPLACE_SUBMARKET_ID)) {
			market.removeSubmarket(MARKETPLACE_SUBMARKET_ID);
		}
		if (market.hasSubmarket(BLACKMARKET_SUBMARKET_ID)) {
			market.removeSubmarket(BLACKMARKET_SUBMARKET_ID);
		}
	}

	private static void clearState(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(INVENTORY_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(EXTRA_MERCHANT_BUDGET_MEMORY_KEY);
	}

	/**
	 * The Agora's own dedicated storage -- the {@link #MARKETPLACE_SUBMARKET_ID} real submarket's
	 * cargo, separate from the station's main inventory, and restricted by
	 * {@link MarketPlaceStorageSubmarketPlugin} itself to weapons, fighter wings, blueprints, and
	 * installable hull mods. If the submarket isn't installed yet, returns an empty throwaway cargo.
	 */
	public static CargoAPI getInventory(SectorEntityToken station) {
		MarketAPI market = station.getMarket();
		if (market != null && market.hasSubmarket(MARKETPLACE_SUBMARKET_ID)) {
			CargoAPI cargo = market.getSubmarket(MARKETPLACE_SUBMARKET_ID).getCargo();
			migrateLegacyInventory(station, cargo);
			return cargo;
		}
		return Global.getFactory().createCargo(true);
	}

	/**
	 * One-time migration for saves built with an earlier version of this mod, where the Agora
	 * inventory was a plain memory-stored cargo instead of a real submarket's. Folds any leftover items
	 * into the submarket's cargo and clears the old key so this only ever runs once per station.
	 */
	@SuppressWarnings("unchecked")
	private static void migrateLegacyInventory(SectorEntityToken station, CargoAPI submarketCargo) {
		Object o = station.getMemoryWithoutUpdate().get(INVENTORY_MEMORY_KEY);
		if (o instanceof CargoAPI) {
			submarketCargo.addAll((CargoAPI) o);
			station.getMemoryWithoutUpdate().unset(INVENTORY_MEMORY_KEY);
		}
	}

	/**
	 * A throwaway copy of the player's fleet cargo containing only weapons, fighter wings,
	 * blueprints, and installable hull mods -- kept as a programmatic helper (not currently wired to
	 * any menu; the player deposits directly through the Agora tab), so nothing else in the fleet's
	 * cargo (resources, crew, other special items like Nanoforges you'd actually want to install
	 * somewhere, etc.) can end up in the Agora inventory and get swept up by a merchant by mistake.
	 */
	public static CargoAPI getDepositCandidates(CampaignFleetAPI playerFleet) {
		CargoAPI copy = Global.getFactory().createCargo(true);
		for (CargoStackAPI stack : playerFleet.getCargo().getStacksCopy()) {
			if (isDepositable(stack)) {
				copy.addFromStack(stack);
			}
		}
		return copy;
	}

	/**
	 * Weapons, fighter wings, blueprints (ship/weapon/fighter), and installable hull mods -- nothing
	 * else. Used both by {@link #getDepositCandidates} and by {@link MarketPlaceStorageSubmarketPlugin}
	 * to enforce the same restriction on the real submarket tab itself, so the two can never disagree
	 * about what's allowed in.
	 */
	public static boolean isDepositable(CargoStackAPI stack) {
		if (stack.isWeaponStack()) return true;
		if (stack.isFighterWingStack()) return true;
		if (stack.isSpecialStack()) {
			SpecialItemData data = stack.getSpecialDataIfSpecial();
			if (data == null) return false;
			String id = data.getId();
			return Items.TAG_MODSPEC.equals(id) || Items.SHIP_BP.equals(id)
					|| Items.WEAPON_BP.equals(id) || Items.FIGHTER_BP.equals(id);
		}
		return false;
	}

	/** Moves exactly what was picked out of the player's real fleet cargo and into the Agora inventory. */
	public static void depositPicked(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI picked) {
		if (picked == null || picked.isEmpty()) return;
		for (CargoStackAPI stack : picked.getStacksCopy()) {
			playerFleet.getCargo().removeItems(stack.getType(), stack.getData(), stack.getSize());
		}
		getInventory(station).addAll(picked);
	}

	/** Moves exactly what was picked out of the Agora inventory and into the player's fleet cargo. */
	public static void withdrawPicked(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI picked) {
		if (picked == null || picked.isEmpty()) return;
		CargoAPI inventory = getInventory(station);
		for (CargoStackAPI stack : picked.getStacksCopy()) {
			inventory.removeItems(stack.getType(), stack.getData(), stack.getSize());
		}
		playerFleet.getCargo().addAll(picked);
	}

	public static float getTotalValue(CargoAPI cargo) {
		float total = 0f;
		for (CargoStackAPI stack : cargo.getStacksCopy()) {
			total += stack.getBaseValuePerUnit() * stack.getSize();
		}
		return total;
	}

	/** Running total of what the player's spent buying from the Exchange since the last Agora merchant sweep -- see {@link #addExchangeSpend}. */
	public static final String EXTRA_MERCHANT_BUDGET_MEMORY_KEY = "$playerhq_module_extra_merchant_budget";

	/**
	 * Called by {@link BlackMarketSubmarketPlugin} whenever the player buys something from the
	 * Exchange -- accumulates the credits spent so next month's Agora merchant budget (see
	 * {@link #collectMerchantIncome}) comes out that much higher, on top of the usual random roll.
	 */
	public static void addExchangeSpend(SectorEntityToken station, float amountSpent) {
		if (amountSpent <= 0f) return;
		float current = station.getMemoryWithoutUpdate().getFloat(EXTRA_MERCHANT_BUDGET_MEMORY_KEY);
		station.getMemoryWithoutUpdate().set(EXTRA_MERCHANT_BUDGET_MEMORY_KEY, current + amountSpent);
	}

	/**
	 * Merchants visiting the station buy up to a random amount of credits' worth of whatever's sitting
	 * in the Agora inventory each month, removing it and paying the player -- a random budget
	 * between {@link #MIN_MERCHANT_BUDGET} and {@link #MAX_MERCHANT_BUDGET}, plus whatever's built up
	 * in {@link #EXTRA_MERCHANT_BUDGET_MEMORY_KEY} from the player's own Exchange purchases since the
	 * last sweep (consumed here, so it doesn't double up next month). The priciest items (by
	 * per-unit value) are bought first, and the budget works its way down through cheaper ones from
	 * there, stopping once nothing left in the inventory fits what's left of the budget. Returns the
	 * credits actually paid out, for the monthly status report.
	 */
	public static float collectMerchantIncome(SectorEntityToken station) {
		if (!isBuilt(station)) return 0f;
		CargoAPI inventory = getInventory(station);
		if (inventory.isEmpty()) return 0f;

		float extra = station.getMemoryWithoutUpdate().getFloat(EXTRA_MERCHANT_BUDGET_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(EXTRA_MERCHANT_BUDGET_MEMORY_KEY);

		float budget = MIN_MERCHANT_BUDGET + (float) Math.random() * (MAX_MERCHANT_BUDGET - MIN_MERCHANT_BUDGET) + extra;
		float spent = 0f;

		List<CargoStackAPI> stacks = new ArrayList<CargoStackAPI>(inventory.getStacksCopy());
		Collections.sort(stacks, new Comparator<CargoStackAPI>() {
			@Override
			public int compare(CargoStackAPI a, CargoStackAPI b) {
				return Float.compare(b.getBaseValuePerUnit(), a.getBaseValuePerUnit());
			}
		});

		for (CargoStackAPI stack : stacks) {
			float unitValue = stack.getBaseValuePerUnit();
			if (unitValue <= 0f) continue;
			float remainingBudget = budget - spent;
			if (remainingBudget <= 0f) break;

			float unitsAffordable = (float) Math.floor(remainingBudget / unitValue);
			float unitsToSell = Math.min(stack.getSize(), unitsAffordable);
			if (unitsToSell <= 0f) continue;

			inventory.removeItems(stack.getType(), stack.getData(), unitsToSell);
			spent += unitsToSell * unitValue;
		}

		if (spent <= 0f) return 0f;
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet != null) playerFleet.getCargo().getCredits().add(spent);
		return spent;
	}
}
