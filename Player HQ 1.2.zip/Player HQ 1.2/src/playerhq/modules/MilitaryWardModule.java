package playerhq.modules;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelAtEntity;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelData;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelRank;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class MilitaryWardModule {

	public static final String MEMORY_KEY = "$playerhq_module_militaryward";
	public static final String HOLOSUITE_MEMORY_KEY = "$playerhq_module_militaryward_holosuite";
	public static final String DRONE_REPLICATOR_MEMORY_KEY = "$playerhq_module_militaryward_dronereplicator";
	public static final String AICORE_MEMORY_KEY = "$playerhq_module_militaryward_aicore";

	public static final float CREDIT_COST = 75000f;
	public static final float METALS_COST = 4000f;
	public static final float TRANSPLUTONICS_COST = 2000f;
	public static final float HEAVY_MACHINERY_COST = 200f;

	public static final float MAX_PERSONNEL = 5000f;

	public static final float CREW_PRODUCTION_PER_MONTH = 250f;
	public static final float MARINE_PRODUCTION_PER_MONTH = 100f;

	public static final float CREW_STIPEND_PER_UNIT = 0.10f;
	public static final float MARINE_STIPEND_PER_UNIT = 5f;

	// Marine training: a fraction of the marine XP pool's "full" value (xp/num ratio) gained each
	// month. Real ground-raid combat can grant a large chunk of this in a single good raid, so even
	// the fastest configuration here (both special items plus the best AI core) is meant to stay
	// well below that -- these facilities season marines over months and years, not single fights.
	public static final float TRAINING_RATE_HOLODECK_ONLY = 0.03f;
	public static final float TRAINING_RATE_DRONE_REPLICATOR_ONLY = 0.03f;
	public static final float TRAINING_RATE_BOTH = 0.08f;

	public static final float AI_CORE_COST = 1f;

	/**
	 * While the Military Paradigm is built and the station is orbiting a colonized planet, its
	 * marines patrol the colony below -- boosting ground defenses and stability.
	 */
	public static final float MILITARY_WARD_DEFENSE_BONUS = 0.50f;
	public static final float MILITARY_WARD_STABILITY_BONUS = 1f;
	public static final String MILITARY_WARD_BONUS_MARKET_MEMORY_KEY = "$playerhq_module_militaryward_bonus_market";
	private static final String MILITARY_WARD_DEFENSE_MOD_ID = "playerhq_militaryward_defense";
	private static final String MILITARY_WARD_STABILITY_MOD_ID = "playerhq_militaryward_stability";

	/** How many Expedition Bays can ultimately be built once the Training Expedition HQ is up. */
	public static final int MAX_TRAINING_EXPEDITION_BAYS = 4;

	/** Total ship "points" required to crew any one Expedition Bay -- a frigate costs 1, a destroyer costs 2. */
	public static final int TRAINING_EXPEDITION_BAY_POINTS_REQUIRED = 4;
	public static final int TRAINING_EXPEDITION_FRIGATE_POINTS = 1;
	public static final int TRAINING_EXPEDITION_DESTROYER_POINTS = 2;

	/** Flat Heavy Armaments cost to build any one Expedition Bay, on top of its dynamic Crew cost. */
	public static final float TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST = 10f;
	/** Flat Heavy Machinery cost to build any one Expedition Bay, refunded at the same half rate as the Heavy Armaments cost. */
	public static final float TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST = 10f;

	public static final String TRAINING_EXPEDITIONS_HQ_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_hq";
	public static final float TRAINING_EXPEDITIONS_HQ_METALS_COST = 500f;
	public static final float TRAINING_EXPEDITIONS_HQ_TRANSPLUTONICS_COST = 50f;
	public static final float TRAINING_EXPEDITIONS_HQ_VOLATILES_COST = 20f;

	public static final String TRAINING_EXPEDITIONS_BAY_COUNT_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_baycount";
	public static final String TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_ships";
	/** Crew actually charged to build each bay -- the sum of its ships' minimum crew requirements at the time it was built, refunded in full (not at {@link ConstructPlayerHQAbility#REFUND_FRACTION}) when the bay is disbanded. */
	public static final String TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_crewcost";
	public static final String TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_touring";
	public static final String TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_fleet";
	public static final String TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_planet";
	public static final String TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_dayoffset";
	public static final String TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_lootlog";

	/** How many different planets a bay's training fleet visits over the course of one monthly cycle. */
	public static final int TRAINING_EXPEDITIONS_VISITS_PER_MONTH = 3;

	/** Days actually spent in orbit of each planet visited. */
	public static final int TRAINING_EXPEDITIONS_ORBIT_DAYS = 8;

	/**
	 * Travel time (in days), spent only once at the very start of the monthly cycle (station to the
	 * first planet) and once at the very end (the last planet back to the station) -- moving on to
	 * the next planet in between visits is treated as immediate. No fleet movement is actually
	 * simulated (the touring fleet is simply parked in orbit of whichever planet it's currently
	 * visiting); this is purely status text and a time budget.
	 */
	public static final int TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS = 1;

	/**
	 * Full length of a bay's monthly cycle, in days -- launches day 1, and is back at the station
	 * well before the next day 1, even in the shortest (28-day) month.
	 */
	public static final int TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS = TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS * 2
			+ TRAINING_EXPEDITIONS_ORBIT_DAYS * TRAINING_EXPEDITIONS_VISITS_PER_MONTH;

	/** Which day (1-indexed) of a planet's orbit the single loot roll for that visit happens on. */
	public static final int TRAINING_EXPEDITIONS_LOOT_ROLL_DAY = 6;

	/** Chance of a find, rolled once every {@link #RUINS_ROLL_INTERVAL_DAYS} days spent in orbit of a planet with the given ruins tier. */
	public static final float RUINS_CHANCE_SCATTERED = 0.01f;
	public static final float RUINS_CHANCE_WIDESPREAD = 0.02f;
	public static final float RUINS_CHANCE_EXTENSIVE = 0.03f;
	public static final float RUINS_CHANCE_VAST = 0.04f;

	/** With the Salvaging skill, every roll's chance is improved by this same flat amount, regardless of ruins tier. */
	public static final float SALVAGING_SKILL_BONUS = 0.01f;

	/** Ships found as loot are capped to hulls this cheap or less. */
	public static final float MAX_LOOT_SHIP_VALUE = 200000f;

	/**
	 * Odds that a ship found as loot turns out to be a derelict with D-mods, rolled cumulatively
	 * (worst tier first) so they don't stack: 1% chance of 3 D-mods, 10% chance of 2, 30% chance of
	 * 1, and otherwise (59%) none at all.
	 */
	public static final float LOOT_SHIP_CHANCE_3_DMODS = 0.01f;
	public static final float LOOT_SHIP_CHANCE_2_DMODS = 0.10f;
	public static final float LOOT_SHIP_CHANCE_1_DMOD = 0.30f;
	public static final int MAX_LOOT_SHIP_DMODS = 3;

	// Loot category weights -- weapons/fighters most common, hullmods/blueprints less so, ships and
	// special items rarest of all. Applied only after the daily ruins-chance roll above already
	// succeeded, so the overall odds of any single item stay modest.
	private static final float LOOT_WEIGHT_WEAPON = 40f;
	private static final float LOOT_WEIGHT_FIGHTER = 28f;
	private static final float LOOT_WEIGHT_HULLMOD = 14f;
	private static final float LOOT_WEIGHT_BLUEPRINT = 12f;
	private static final float LOOT_WEIGHT_SHIP = 4f;
	private static final float LOOT_WEIGHT_SPECIAL_ITEM = 2f;

	private static final String[] SPECIAL_ITEM_LOOT_POOL = {
			Items.CORRUPTED_NANOFORGE, Items.PRISTINE_NANOFORGE, Items.SYNCHROTRON,
			Items.ORBITAL_FUSION_LAMP, Items.MANTLE_BORE, Items.CATALYTIC_CORE,
			Items.SOIL_NANITES, Items.BIOFACTORY_EMBRYO, Items.FULLERENE_SPOOL,
			Items.PLASMA_DYNAMO, Items.CRYOARITHMETIC_ENGINE, Items.DRONE_REPLICATOR,
			Items.DEALMAKER_HOLOSUITE,
	};

	public static final String[] IMAGE_PATHS = {
			"graphics/modules/military_ward.jpg",
			"graphics/modules/military_ward_2.jpg",
			"graphics/modules/military_ward_3.jpg",
			"graphics/modules/military_ward_4.jpg",
			"graphics/modules/military_ward_5.jpg",
			"graphics/modules/military_ward_6.jpg",
			"graphics/modules/military_ward_7.jpg",
			"graphics/modules/military_ward_8.jpg",
			"graphics/modules/military_ward_9.jpg",
			"graphics/modules/military_ward_10.jpg",
			"graphics/modules/military_ward_11.jpg",
			"graphics/modules/military_ward_12.jpg",
			"graphics/modules/military_ward_13.jpg",
	};

	public static String getRandomImagePath() {
		int index = (int) (Math.random() * IMAGE_PATHS.length);
		if (index >= IMAGE_PATHS.length) index = IMAGE_PATHS.length - 1;
		return IMAGE_PATHS[index];
	}

	public static final String[] TRAINING_EXPEDITION_IMAGE_PATHS = {
			"graphics/modules/training_expedition.jpg",
			"graphics/modules/training_expedition_2.jpg",
			"graphics/modules/training_expedition_3.jpg",
			"graphics/modules/training_expedition_4.jpg",
			"graphics/modules/training_expedition_5.jpg",
	};

	public static String getRandomTrainingExpeditionImagePath() {
		int index = (int) (Math.random() * TRAINING_EXPEDITION_IMAGE_PATHS.length);
		if (index >= TRAINING_EXPEDITION_IMAGE_PATHS.length) index = TRAINING_EXPEDITION_IMAGE_PATHS.length - 1;
		return TRAINING_EXPEDITION_IMAGE_PATHS[index];
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
		updateDefenseAndStabilityBonus(station);
	}

	private static void clearDefenseAndStabilityBonus(SectorEntityToken station) {
		String marketId = station.getMemoryWithoutUpdate().getString(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY);
		if (marketId == null) return;

		MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);
		if (market != null) {
			market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(MILITARY_WARD_DEFENSE_MOD_ID);
			market.getStability().unmodifyFlat(MILITARY_WARD_STABILITY_MOD_ID);
		}
		station.getMemoryWithoutUpdate().unset(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY);
	}

	/**
	 * Moves the Military Paradigm's ground defense and stability bonus to whatever colonized planet
	 * the station is currently orbiting (if any), removing it from wherever it was previously
	 * applied. Meant to be called on build and once every monthly tick, since the station's orbit
	 * can change between ticks.
	 */
	public static void updateDefenseAndStabilityBonus(SectorEntityToken station) {
		clearDefenseAndStabilityBonus(station);

		if (!isBuilt(station)) return;

		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return;

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(
				MILITARY_WARD_DEFENSE_MOD_ID, 1f + MILITARY_WARD_DEFENSE_BONUS, "Military Paradigm (Player HQ)");
		market.getStability().modifyFlat(MILITARY_WARD_STABILITY_MOD_ID, MILITARY_WARD_STABILITY_BONUS, "Military Paradigm (Player HQ)");
		station.getMemoryWithoutUpdate().set(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY, market.getId());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;

		clearDefenseAndStabilityBonus(station);

		CargoAPI cargo = playerFleet.getCargo();
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);

		if (hasHolosuiteInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
		}
		if (hasDroneReplicatorInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		}
		String aiCoreTier = getInstalledAICoreTier(station);
		if (aiCoreTier != null) {
			cargo.addCommodity(aiCoreTier, AI_CORE_COST);
		}

		// Dismantle-time refund -- the station is going away, so every committed ship across every
		// Expedition Bay goes back to the fleet's own mothballed-ship storage, same as every other
		// resource refunded here.
		if (hasTrainingExpeditionHQBuilt(station)) {
			disbandAllBaysInto(station, cargo, playerFleet.getFaction().getId());
			cargo.addCommodity(Commodities.METALS, TRAINING_EXPEDITIONS_HQ_METALS_COST * fraction);
			cargo.addCommodity(Commodities.RARE_METALS, TRAINING_EXPEDITIONS_HQ_TRANSPLUTONICS_COST * fraction);
			cargo.addCommodity(Commodities.VOLATILES, TRAINING_EXPEDITIONS_HQ_VOLATILES_COST * fraction);
			station.getMemoryWithoutUpdate().unset(TRAINING_EXPEDITIONS_HQ_MEMORY_KEY);
		}
	}

	public static boolean hasHolosuiteInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasHolosuiteAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE);
	}

	public static void installHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().set(HOLOSUITE_MEMORY_KEY, true);
	}

	public static void uninstallHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasHolosuiteInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().unset(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR);
	}

	public static void installDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, true);
	}

	public static void uninstallDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasDroneReplicatorInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().unset(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static String getInstalledAICoreTier(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getString(AICORE_MEMORY_KEY);
	}

	public static boolean hasAICoreInstalled(SectorEntityToken station) {
		return getInstalledAICoreTier(station) != null;
	}

	public static boolean hasGammaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.GAMMA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasBetaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.BETA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasAlphaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ALPHA_CORE) >= AI_CORE_COST;
	}

	public static void installAICore(SectorEntityToken station, CampaignFleetAPI playerFleet, String coreCommodityId) {
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, coreCommodityId) < AI_CORE_COST) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, coreCommodityId, AI_CORE_COST);
		station.getMemoryWithoutUpdate().set(AICORE_MEMORY_KEY, coreCommodityId);
	}

	/**
	 * Pulls the currently installed AI core back out and returns it to the station's inventory, so
	 * a different tier can be installed in its place. No loss on the swap -- this isn't a
	 * dismantle-and-refund, just moving the same core back out.
	 */
	public static void uninstallAICore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return;

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(tier, AI_CORE_COST);
		}
		station.getMemoryWithoutUpdate().unset(AICORE_MEMORY_KEY);
	}

	/**
	 * Beta/Gamma/Alpha cores each add their own extra multiple of the base training rate on top of
	 * it (Beta +1x, Gamma +2x, Alpha +3x), rather than just replacing it -- so installing one is
	 * always a straightforward improvement over having none.
	 */
	public static float getAICoreTrainingMultiplier(SectorEntityToken station) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return 1f;
		if (Commodities.BETA_CORE.equals(tier)) return 2f;
		if (Commodities.GAMMA_CORE.equals(tier)) return 3f;
		if (Commodities.ALPHA_CORE.equals(tier)) return 4f;
		return 1f;
	}

	private static float getBaseTrainingRatio(SectorEntityToken station) {
		boolean holosuite = hasHolosuiteInstalled(station);
		boolean drone = hasDroneReplicatorInstalled(station);
		if (holosuite && drone) return TRAINING_RATE_BOTH;
		if (holosuite) return TRAINING_RATE_HOLODECK_ONLY;
		if (drone) return TRAINING_RATE_DRONE_REPLICATOR_ONLY;
		return 0f;
	}

	public static float getTrainingRatioPerMonth(SectorEntityToken station) {
		return getBaseTrainingRatio(station) * getAICoreTrainingMultiplier(station);
	}

	/** Raw training points the currently stored Marines would gain this month, at the current combined training bonus -- the same figure {@link #applyTraining} actually adds. */
	public static float getExpectedMonthlyTrainingXP(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return 0f;
		float marines = storageSubmarket.getCargo().getMarines();
		if (marines <= 0f) return 0f;
		return getTrainingRatioPerMonth(station) * marines;
	}

	private static SubmarketAPI getStorageSubmarket(SectorEntityToken station) {
		if (station.getMarket() == null) return null;
		return station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE);
	}

	private static void addCrewCapped(CargoAPI storage, float amount) {
		int current = storage.getCrew();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addCrew(toAdd);
	}

	private static void addMarinesCapped(CargoAPI storage, float amount) {
		int current = storage.getMarines();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addMarines(toAdd);
	}

	/**
	 * The station has no life support set up for people outside the Military Paradigm and Recreational
	 * Hub, so Crew and Marines held in storage are hard-capped at {@link #MAX_PERSONNEL} each --
	 * whether they got there from this module's own production or the player manually depositing
	 * them. Run this regularly (not just once a month) so a manual over-deposit gets corrected
	 * quickly rather than sitting over the cap for a long stretch.
	 */
	public static void enforceCap(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;
		CargoAPI storage = storageSubmarket.getCargo();

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();

		int crew = storage.getCrew();
		if (crew > (int) MAX_PERSONNEL) {
			int excess = crew - (int) MAX_PERSONNEL;
			storage.removeCrew(excess);
			if (playerFleet != null) playerFleet.getCargo().addCrew(excess);
		}

		int marines = storage.getMarines();
		if (marines > (int) MAX_PERSONNEL) {
			int excess = marines - (int) MAX_PERSONNEL;
			storage.removeMarines(excess);
			if (playerFleet != null) playerFleet.getCargo().addMarines(excess);
		}
	}

	private static void applyTraining(SectorEntityToken station, SubmarketAPI storageSubmarket) {
		float ratio = getTrainingRatioPerMonth(station);
		if (ratio <= 0f) return;

		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return;

		// Keep the tracked bucket's headcount in sync with the real, current storage count before
		// adding XP -- it's only otherwise updated by the game when the player opens/transacts with
		// this submarket directly, and could be stale by the time our monthly tick runs.
		at.data.numMayHaveChanged(marines, true);
		at.data.addXP(ratio * marines);
	}

	public static void accumulateMonthly(SectorEntityToken station) {
		if (!isBuilt(station)) return;

		// The station's orbit can change between ticks, so keep the defense/stability bonus pointed
		// at whatever colonized planet (if any) it's currently orbiting.
		updateDefenseAndStabilityBonus(station);

		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;
		CargoAPI storage = storageSubmarket.getCargo();

		addCrewCapped(storage, CREW_PRODUCTION_PER_MONTH);
		addMarinesCapped(storage, MARINE_PRODUCTION_PER_MONTH);

		float stipend = storage.getCrew() * CREW_STIPEND_PER_UNIT + storage.getMarines() * MARINE_STIPEND_PER_UNIT;
		if (stipend > 0f) {
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (playerFleet != null) playerFleet.getCargo().getCredits().subtract(stipend);
		}

		applyTraining(station, storageSubmarket);
	}

	/**
	 * @return the current training rank of marines stored at this station (Regular/Experienced/
	 * Veteran/Elite), or null if no marines are currently stored there.
	 */
	public static PersonnelRank getStoredMarineRank(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return null;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return null;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return null;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getRank();
	}

	public static float getStoredMarineTrainingPercent(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return 0f;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return 0f;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return 0f;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getXPLevel() * 100f;
	}

	public static class MarineTransferSnapshot {
		float stationNum;
		float stationXP;
		float fleetNum;
		float fleetXP;
	}

	/**
	 * Captures the marine headcount/XP on both sides -- the station's storage and the player's
	 * fleet -- right before the cargo transfer screen opens, so {@link #reconcileMarineTransfer}
	 * has a clean "before" picture to work from.
	 */
	public static MarineTransferSnapshot snapshotMarineXP(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		MarineTransferSnapshot snap = new MarineTransferSnapshot();

		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return snap;

		snap.stationNum = storageSubmarket.getCargo().getMarines();
		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		at.data.numMayHaveChanged(snap.stationNum, true);
		snap.stationXP = at.data.xp;

		PersonnelData fleetData = PlayerFleetPersonnelTracker.getInstance().getMarineData();
		snap.fleetNum = playerFleet.getCargo().getMarines();
		fleetData.numMayHaveChanged(snap.fleetNum, true);
		snap.fleetXP = fleetData.xp;

		return snap;
	}

	/**
	 * The station's cargo screen is the same bare loot-transfer UI the vanilla game uses for an
	 * abandoned station, not a real market trade screen -- so it never fires the game's own
	 * marine-XP transfer hooks ({@code PlayerFleetPersonnelTracker} only reacts to transactions at
	 * a fully-fledged market). Left alone, that means marines picked up here always come back as
	 * raw Regulars, even if they were trained to Veteran while sitting in storage.
	 * <p>
	 * This reconciles the before/after marine counts by hand once the cargo screen closes and moves
	 * the earned XP share along with whichever marines actually crossed over -- the same
	 * XP-preserving math the vanilla transaction hook itself uses -- so training earned at the
	 * station isn't lost the moment those marines are taken into the fleet.
	 */
	public static void reconcileMarineTransfer(SectorEntityToken station, CampaignFleetAPI playerFleet, MarineTransferSnapshot before) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;

		float stationNumAfter = storageSubmarket.getCargo().getMarines();
		float fleetNumAfter = playerFleet.getCargo().getMarines();

		int withdrawn = Math.round(before.stationNum - stationNumAfter);
		if (withdrawn == 0) return;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		PersonnelData fleetData = PlayerFleetPersonnelTracker.getInstance().getMarineData();

		if (withdrawn > 0) {
			// Marines moved station -> fleet: they take their trained share of the station's XP with them.
			float xpPerMarine = before.stationNum > 0 ? before.stationXP / before.stationNum : 0f;
			float xpMoved = xpPerMarine * withdrawn;

			at.data.num = stationNumAfter;
			at.data.xp = Math.max(0f, before.stationXP - xpMoved);

			fleetData.num = fleetNumAfter;
			fleetData.xp = Math.min(before.fleetXP + xpMoved, Math.max(0f, fleetNumAfter));
		} else {
			// Marines moved fleet -> station: same idea, in reverse.
			int deposited = -withdrawn;
			float xpPerMarine = before.fleetNum > 0 ? before.fleetXP / before.fleetNum : 0f;
			float xpMoved = xpPerMarine * deposited;

			fleetData.num = fleetNumAfter;
			fleetData.xp = Math.max(0f, before.fleetXP - xpMoved);

			at.data.num = stationNumAfter;
			at.data.xp = Math.min(before.stationXP + xpMoved, Math.max(0f, stationNumAfter));
		}

		PlayerFleetPersonnelTracker.getInstance().update();
	}

	// ===================== Training Expedition HQ =====================

	private static String bayKey(String base, int bayIndex) {
		return base + "_" + bayIndex;
	}

	/** Whether the Training Expedition HQ itself has been built. It doesn't build a bay by itself -- bays are built separately, afterward. */
	public static boolean hasTrainingExpeditionHQBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(TRAINING_EXPEDITIONS_HQ_MEMORY_KEY);
	}

	public static boolean hasTrainingExpeditionHQCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= TRAINING_EXPEDITIONS_HQ_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRAINING_EXPEDITIONS_HQ_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= TRAINING_EXPEDITIONS_HQ_VOLATILES_COST;
	}

	public static void buildTrainingExpeditionHQ(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (hasTrainingExpeditionHQBuilt(station)) return;
		if (!hasTrainingExpeditionHQCost(station, playerFleet)) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, TRAINING_EXPEDITIONS_HQ_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRAINING_EXPEDITIONS_HQ_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, TRAINING_EXPEDITIONS_HQ_VOLATILES_COST);

		station.getMemoryWithoutUpdate().set(TRAINING_EXPEDITIONS_HQ_MEMORY_KEY, true);
	}

	/**
	 * Whether the given fixed bay slot (0-based, always in [0, {@link #MAX_TRAINING_EXPEDITION_BAYS}))
	 * currently has ships committed to it. Slots are independent and keep their identity across
	 * uninstalls -- uninstalling Bay 1 never shifts Bay 2/3/4 down into it, so Bay 1 stays open and
	 * ready to be re-crewed on its own, without disturbing any other bay.
	 */
	public static boolean isExpeditionBayBuilt(SectorEntityToken station, int bayIndex) {
		return getCommittedShips(station, bayIndex) != null;
	}

	/** How many of the {@link #MAX_TRAINING_EXPEDITION_BAYS} fixed slots currently have a crewed bay -- derived by checking each slot, not stored. */
	public static int getTrainingExpeditionBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (isExpeditionBayBuilt(station, i)) count++;
		}
		return count;
	}

	/** Whether another Expedition Bay can be built -- the HQ has to be up first, and at least one of the fixed slots has to still be empty. */
	public static boolean canBuildAnotherExpeditionBay(SectorEntityToken station) {
		return hasTrainingExpeditionHQBuilt(station) && getTrainingExpeditionBayCount(station) < MAX_TRAINING_EXPEDITION_BAYS;
	}

	/** Whether the given Expedition Bay currently has a training fleet out touring the system. */
	public static boolean isBayTouring(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY, bayIndex));
	}

	/** Whether any built Expedition Bay currently has a training fleet out touring the system. */
	public static boolean isTouring(SectorEntityToken station) {
		return getTouringBayCount(station) > 0;
	}

	/** How many of the built Expedition Bays currently have a training fleet out touring the system. */
	public static int getTouringBayCount(SectorEntityToken station) {
		int touring = 0;
		for (int i = 0; i < MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (isBayTouring(station, i)) touring++;
		}
		return touring;
	}

	/**
	 * Frigate- or destroyer-sized haulage/support ships available to commit to a bay -- covers plain
	 * freighters (as well as combat, armored, and phased freighter hulls), civilian transports, troop
	 * transports, phased transports, and shuttles (anything the game itself tags with the Freighter,
	 * Transport, Civilian, or Phase hints), but only at frigate or destroyer hull size, and only
	 * pristine ships with no D-mods. Doesn't matter whether they're actively part of your fleet's
	 * combat roster or mothballed in storage, combined across your active fleet, your fleet's cargo
	 * storage, and the station's own storage. The current flagship is never offered up, so committing
	 * ships can't leave the fleet without one.
	 */
	public static List<FleetMemberAPI> getFreighterCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		List<FleetMemberAPI> result = new ArrayList<FleetMemberAPI>();
		addActiveCandidatesFrom(playerFleet, result);
		addCandidatesFrom(playerFleet.getCargo(), playerFleet.getFaction().getId(), result);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			addCandidatesFrom(storage, playerFleet.getFaction().getId(), result);
		}
		return result;
	}

	private static boolean isEligibleFreighter(FleetMemberAPI m) {
		if (m.getHullSpec() == null) return false;
		Set<ShipHullSpecAPI.ShipTypeHints> hints = m.getHullSpec().getHints();
		boolean eligibleRole = hints.contains(ShipHullSpecAPI.ShipTypeHints.FREIGHTER)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.TRANSPORT)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.CIVILIAN)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.PHASE);
		if (!eligibleRole) return false;
		HullSize size = m.getHullSpec().getHullSize();
		if (size != HullSize.FRIGATE && size != HullSize.DESTROYER) return false;
		if (m.getVariant() != null && DModManager.getNumDMods(m.getVariant()) > 0) return false;
		return true;
	}

	/** Frigates cost {@link #TRAINING_EXPEDITION_FRIGATE_POINTS}, destroyers cost {@link #TRAINING_EXPEDITION_DESTROYER_POINTS}. */
	public static int getShipPoints(FleetMemberAPI m) {
		if (m.getHullSpec() == null) return 0;
		HullSize size = m.getHullSpec().getHullSize();
		if (size == HullSize.DESTROYER) return TRAINING_EXPEDITION_DESTROYER_POINTS;
		if (size == HullSize.FRIGATE) return TRAINING_EXPEDITION_FRIGATE_POINTS;
		return 0;
	}

	public static int getTotalShipPoints(List<FleetMemberAPI> members) {
		int total = 0;
		for (FleetMemberAPI m : members) {
			total += getShipPoints(m);
		}
		return total;
	}

	private static void addActiveCandidatesFrom(CampaignFleetAPI fleet, List<FleetMemberAPI> out) {
		if (fleet == null || fleet.getFleetData() == null) return;
		for (FleetMemberAPI m : fleet.getFleetData().getMembersListCopy()) {
			if (m.isFlagship()) continue;
			if (isEligibleFreighter(m)) out.add(m);
		}
	}

	private static void addCandidatesFrom(CargoAPI cargo, String factionId, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : mothballed.getMembersListCopy()) {
			if (isEligibleFreighter(m)) out.add(m);
		}
	}

	public static int countAvailableFreighters(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return getFreighterCandidates(station, playerFleet).size();
	}

	/** True if some combination of the available candidates could add up to exactly the required points total. */
	public static boolean hasEnoughPointsAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		int frigates = 0;
		int destroyers = 0;
		for (FleetMemberAPI m : getFreighterCandidates(station, playerFleet)) {
			int pts = getShipPoints(m);
			if (pts == TRAINING_EXPEDITION_DESTROYER_POINTS) destroyers++;
			else if (pts == TRAINING_EXPEDITION_FRIGATE_POINTS) frigates++;
		}
		// Points needed is even (4), and every combination of 1s and 2s that sums to it needs at most
		// TRAINING_EXPEDITION_BAY_POINTS_REQUIRED frigates, or fewer destroyers making up the rest.
		for (int d = 0; d * TRAINING_EXPEDITION_DESTROYER_POINTS <= TRAINING_EXPEDITION_BAY_POINTS_REQUIRED; d++) {
			int remaining = TRAINING_EXPEDITION_BAY_POINTS_REQUIRED - d * TRAINING_EXPEDITION_DESTROYER_POINTS;
			if (d <= destroyers && remaining <= frigates) return true;
		}
		return false;
	}

	/** Sums each ship's minimum crew requirement -- the dynamic Crew cost charged to build a bay with these ships. */
	public static int getRequiredCrewForShips(List<FleetMemberAPI> ships) {
		int total = 0;
		for (FleetMemberAPI m : ships) {
			total += Math.round(m.getMinCrew());
		}
		return total;
	}

	/** Pulls the chosen ship out of wherever it actually is -- the active fleet roster, the fleet's cargo storage, or the station's storage. */
	private static void removeShipFromWhereverItIs(SectorEntityToken station, CampaignFleetAPI playerFleet, FleetMemberAPI m) {
		if (playerFleet.getFleetData() != null && playerFleet.getFleetData().getMembersListCopy().contains(m)) {
			playerFleet.getFleetData().removeFleetMember(m);
			playerFleet.getFleetData().ensureHasFlagship();
			return;
		}

		CargoAPI fleetCargo = playerFleet.getCargo();
		fleetCargo.initMothballedShips(playerFleet.getFaction().getId());
		if (fleetCargo.getMothballedShips() != null && fleetCargo.getMothballedShips().getMembersListCopy().contains(m)) {
			fleetCargo.getMothballedShips().removeFleetMember(m);
			return;
		}

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.initMothballedShips(playerFleet.getFaction().getId());
			if (storage.getMothballedShips() != null) {
				storage.getMothballedShips().removeFleetMember(m);
			}
		}
	}

	/**
	 * Builds one Expedition Bay (up to {@link #MAX_TRAINING_EXPEDITION_BAYS} total, HQ required first)
	 * using the player's chosen frigates and destroyers -- picked by hand from
	 * {@link #getFreighterCandidates}, and must add up to exactly
	 * {@link #TRAINING_EXPEDITION_BAY_POINTS_REQUIRED} points (a frigate costs
	 * {@link #TRAINING_EXPEDITION_FRIGATE_POINTS}, a destroyer costs {@link #TRAINING_EXPEDITION_DESTROYER_POINTS}).
	 * The ships themselves -- the same {@link FleetMemberAPI} instances, fits and all -- are held in the
	 * station's memory for as long as that bay is active, so they can be reused for its monthly touring
	 * fleet without ever being recreated. Building the bay also costs Crew -- the sum of the chosen
	 * ships' minimum crew requirements, drawn only from the station's own storage -- plus a flat
	 * {@link #TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST} Heavy Armaments and a flat
	 * {@link #TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST} Heavy Machinery (both drawn from the
	 * fleet's cargo and the station's storage combined, like most other resource costs). The Crew and
	 * ships are fully refunded if the bay is later uninstalled; the Heavy Armaments and Heavy
	 * Machinery refund at the usual half rate. Builds into the specific fixed slot given by bayIndex
	 * (0-based) -- that slot must currently be empty -- rather than always appending after the last
	 * built bay, so a freed-up slot (Bay 1 after it's uninstalled, say) can be re-crewed in place
	 * instead of forcing the next build into whatever slot happens to be highest.
	 */
	public static void buildExpeditionBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet,
			int bayIndex, List<FleetMemberAPI> chosen) {
		if (bayIndex < 0 || bayIndex >= MAX_TRAINING_EXPEDITION_BAYS) return;
		if (!hasTrainingExpeditionHQBuilt(station) || isExpeditionBayBuilt(station, bayIndex)) return;
		if (chosen == null || chosen.isEmpty()) return;
		if (getTotalShipPoints(chosen) != TRAINING_EXPEDITION_BAY_POINTS_REQUIRED) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		// Crew is only ever drawn from the station's own storage, never the fleet's.
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HAND_WEAPONS)
				< TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST) return;
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY)
				< TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HAND_WEAPONS, TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex), new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, bayIndex), crewNeeded);
	}

	/** Whether there's enough Heavy Armaments available (fleet + station combined) to build another bay. */
	public static boolean hasHeavyArmamentsForBay(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HAND_WEAPONS)
				>= TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST;
	}

	/** Whether there's enough Heavy Machinery available (fleet + station combined) to build another bay. */
	public static boolean hasHeavyMachineryForBay(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY)
				>= TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST;
	}

	/**
	 * Recalls every touring bay and empties the given destination cargo's ships into it, refunds each
	 * bay's Crew cost in full (the whole amount charged to build it, not the usual half) and its
	 * Heavy Armaments and Heavy Machinery costs at the usual half rate, then clears all bay memory.
	 */
	private static void disbandAllBaysInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		if (getTrainingExpeditionBayCount(station) < 1) return;

		if (destination != null) {
			destination.initMothballedShips(factionId);
		}

		for (int i = 0; i < MAX_TRAINING_EXPEDITION_BAYS; i++) {
			// Slots are independent now (see isExpeditionBayBuilt) -- skip any that were never built,
			// or an empty slot would still get a Heavy Armaments/Heavy Machinery refund below.
			if (!isExpeditionBayBuilt(station, i)) continue;

			if (isBayTouring(station, i)) {
				recallTouringFleet(station, i);
			}
			List<FleetMemberAPI> ships = getCommittedShips(station, i);
			if (ships != null && !ships.isEmpty() && destination != null && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					mothballed.addFleetMember(m);
				}
			}
			if (destination != null) {
				int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, i));
				if (crewCost > 0) {
					destination.addCrew(crewCost);
				}
				destination.addCommodity(Commodities.HAND_WEAPONS,
						TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
				destination.addCommodity(Commodities.HEAVY_MACHINERY,
						TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
			}
			clearBayMemory(station, i);
		}
	}

	/**
	 * Uninstalls just one Expedition Bay (not the whole HQ) -- recalls its touring fleet if it's
	 * out, returns its committed ships and refunds its Crew cost in full to the station's storage,
	 * refunds its flat Heavy Armaments and Heavy Machinery costs at the usual half rate. The bay
	 * slot itself keeps its identity -- it's simply left empty and can be re-crewed on its own
	 * without disturbing any other bay.
	 */
	public static void uninstallExpeditionBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MAX_TRAINING_EXPEDITION_BAYS) return;
		if (!isExpeditionBayBuilt(station, bayIndex)) return;

		if (isBayTouring(station, bayIndex)) {
			recallTouringFleet(station, bayIndex);
		}

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.initMothballedShips(playerFleet.getFaction().getId());
			List<FleetMemberAPI> ships = getCommittedShips(station, bayIndex);
			if (ships != null && !ships.isEmpty() && storage.getMothballedShips() != null) {
				FleetDataAPI mothballed = storage.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					mothballed.addFleetMember(m);
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) {
				storage.addCrew(crewCost);
			}
			storage.addCommodity(Commodities.HAND_WEAPONS,
					TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
			storage.addCommodity(Commodities.HEAVY_MACHINERY,
					TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
		}

		clearBayMemory(station, bayIndex);
	}

	/** Disbanding the whole HQ while the station still exists returns every committed ship (across every Expedition Bay) and half the HQ's resource cost to the station's own inventory. */
	public static void uninstallTrainingExpeditions(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasTrainingExpeditionHQBuilt(station)) return;

		disbandAllBaysInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
			storage.addCommodity(Commodities.METALS, TRAINING_EXPEDITIONS_HQ_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, TRAINING_EXPEDITIONS_HQ_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.VOLATILES, TRAINING_EXPEDITIONS_HQ_VOLATILES_COST * fraction);
		}

		station.getMemoryWithoutUpdate().unset(TRAINING_EXPEDITIONS_HQ_MEMORY_KEY);
	}

	/**
	 * Dismantling requires every installed upgrade to be uninstalled first, same as the other
	 * modules, plus the Training Expedition HQ (and every Expedition Bay it holds) already disbanded.
	 */
	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasHolosuiteInstalled(station) && !hasDroneReplicatorInstalled(station)
				&& !hasAICoreInstalled(station) && !hasTrainingExpeditionHQBuilt(station);
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet);
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getCommittedShips(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	private static CampaignFleetAPI getTouringFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY, bayIndex));
	}

	/** The full ordered list of planet ids a bay's current (or most recent) tour is/was visiting. Empty if it's never launched. */
	@SuppressWarnings("unchecked")
	private static List<String> getExpeditionPlanetIds(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<String>) o : new ArrayList<String>();
	}

	/**
	 * Which planet (0 = first visited) a bay's tour is currently at, based purely on how far into its
	 * {@link #TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS}-day cycle it is. Clamped to the last planet
	 * actually chosen for this tour, in case the system had fewer than
	 * {@link #TRAINING_EXPEDITIONS_VISITS_PER_MONTH} planets to visit.
	 */
	private static int getVisitIndexForDayOffset(SectorEntityToken station, int bayIndex, int dayOffset) {
		int intoOrbitPhase = dayOffset - TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS;
		if (intoOrbitPhase < 0) intoOrbitPhase = 0;
		int visitIndex = intoOrbitPhase / TRAINING_EXPEDITIONS_ORBIT_DAYS;

		int available = getExpeditionPlanetIds(station, bayIndex).size();
		int maxIndex = Math.max(0, Math.min(TRAINING_EXPEDITIONS_VISITS_PER_MONTH, available) - 1);
		if (visitIndex > maxIndex) visitIndex = maxIndex;
		return visitIndex;
	}

	/** The planet a bay's touring fleet is currently (or was most recently) parked in orbit of. Null if it's never launched. */
	public static String getExpeditionPlanetId(SectorEntityToken station, int bayIndex) {
		List<String> ids = getExpeditionPlanetIds(station, bayIndex);
		if (ids.isEmpty()) return null;
		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex));
		return ids.get(getVisitIndexForDayOffset(station, bayIndex, dayOffset));
	}

	/** Display name of the planet a bay's touring fleet is at, or null if it's never launched / the planet's gone missing. */
	public static String getExpeditionPlanetName(SectorEntityToken station, int bayIndex) {
		PlanetAPI planet = findPlanet(station.getStarSystem(), getExpeditionPlanetId(station, bayIndex));
		return planet != null ? planet.getName() : null;
	}

	/**
	 * A short status phrase for the given bay -- docked at the station, moving out to its first
	 * planet, conducting a training exercise in orbit of whichever planet it's currently visiting, or
	 * heading back -- based purely on how far into its {@link #TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS}-day
	 * cycle it currently is. The overall three-phase shape of this text is unchanged from before; only
	 * the day thresholds and the fact that "in orbit" can now mean any of several planets in turn.
	 */
	public static String getBayStatusText(SectorEntityToken station, int bayIndex) {
		if (!isBayTouring(station, bayIndex)) {
			return "docked at the station, awaiting its next departure on the 1st of the month";
		}

		String planetName = getExpeditionPlanetName(station, bayIndex);
		String planet = planetName != null ? planetName : "a planet";
		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex));
		int orbitPhaseEnd = TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS
				+ TRAINING_EXPEDITIONS_ORBIT_DAYS * TRAINING_EXPEDITIONS_VISITS_PER_MONTH;

		if (dayOffset < TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS) {
			return "moving to " + planet;
		}
		if (dayOffset >= orbitPhaseEnd) {
			return "returning to the station";
		}
		return "conducting a training exercise in orbit of " + planet;
	}

	/**
	 * Picks which planet the next leg of a tour should visit: whichever non-star, not-yet-chosen
	 * planet in the system has the best ruins condition (so a visit there has the best odds of
	 * turning something up), ties broken randomly. If nothing eligible has a ruins condition, a
	 * random eligible planet is picked instead -- it's still a cosmetic visit, just an uneventful one.
	 * If every planet in the system has already been chosen (a small system), repeats are allowed
	 * rather than cutting the tour short.
	 */
	private static PlanetAPI pickExpeditionPlanet(StarSystemAPI system, Set<String> alreadyChosen) {
		if (system == null) return null;

		List<PlanetAPI> planets = new ArrayList<PlanetAPI>();
		for (PlanetAPI p : system.getPlanets()) {
			if (!p.isStar() && (alreadyChosen == null || !alreadyChosen.contains(p.getId()))) planets.add(p);
		}
		if (planets.isEmpty()) {
			for (PlanetAPI p : system.getPlanets()) {
				if (!p.isStar()) planets.add(p);
			}
		}
		if (planets.isEmpty()) return null;

		float bestChance = -1f;
		List<PlanetAPI> best = new ArrayList<PlanetAPI>();
		for (PlanetAPI p : planets) {
			float chance = getRuinsChance(p.getMarket());
			if (chance > bestChance) {
				bestChance = chance;
				best.clear();
				best.add(p);
			} else if (chance == bestChance) {
				best.add(p);
			}
		}
		if (bestChance <= 0f) return pickRandom(planets);
		return pickRandom(best);
	}

	/** Launches every built Expedition Bay that isn't currently out on tour -- called once a month, on day 1. */
	public static void launchTrainingExpeditionIfDue(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		for (int bayIndex = 0; bayIndex < MAX_TRAINING_EXPEDITION_BAYS; bayIndex++) {
			launchBay(station, bayIndex);
		}
	}

	/** Parks the fleet in a stable orbit of the given planet -- purely cosmetic, no travel is actually simulated. */
	private static void positionFleetAtPlanet(CampaignFleetAPI fleet, PlanetAPI planet) {
		fleet.setCircularOrbitPointingDown(planet, (float) (Math.random() * 360f),
				planet.getRadius() + 250f, TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS * 2f);
	}

	private static void launchBay(SectorEntityToken station, int bayIndex) {
		if (isBayTouring(station, bayIndex)) return;

		List<FleetMemberAPI> ships = getCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return;

		StarSystemAPI system = station.getStarSystem();
		List<String> planetIds = new ArrayList<String>();
		Set<String> chosen = new HashSet<String>();
		for (int i = 0; i < TRAINING_EXPEDITIONS_VISITS_PER_MONTH; i++) {
			PlanetAPI planet = pickExpeditionPlanet(system, chosen);
			if (planet == null) break;
			planetIds.add(planet.getId());
			chosen.add(planet.getId());
		}
		if (planetIds.isEmpty()) return;

		PlanetAPI firstPlanet = findPlanet(system, planetIds.get(0));
		if (firstPlanet == null) return;

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Training Expedition - Bay " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_MAKE_NON_HOSTILE, true);
		fleet.setNoEngaging(TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS * 2f);
		system.addEntity(fleet);
		// Parked at the first planet for the start of the tour -- moves on to each subsequent planet
		// in turn as the tour progresses (see advanceBayDaily), with no travel actually simulated.
		positionFleetAtPlanet(fleet, firstPlanet);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY, bayIndex), new ArrayList<String>(planetIds));
		mem.set(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex), 0);
		mem.set(bayKey(TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY, bayIndex), true);
	}

	/** Advances every touring Expedition Bay by one day -- called once a day. */
	public static void advanceTrainingExpeditionDaily(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_TRAINING_EXPEDITION_BAYS; bayIndex++) {
			advanceBayDaily(station, bayIndex);
		}
	}

	/**
	 * Advances a day-out tour by one day: moves the fleet on to its next planet the moment a new
	 * visit's orbit begins, rolls for loot once (on {@link #TRAINING_EXPEDITIONS_LOOT_ROLL_DAY} of
	 * each visit), and recalls the fleet once the whole tour has run its length.
	 */
	private static void advanceBayDaily(SectorEntityToken station, int bayIndex) {
		if (!isBayTouring(station, bayIndex)) return;

		CampaignFleetAPI fleet = getTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) {
			clearTouringState(station, bayIndex);
			return;
		}

		int dayOffset = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex)) + 1;
		if (dayOffset >= TRAINING_EXPEDITIONS_TOUR_LENGTH_DAYS) {
			recallTouringFleet(station, bayIndex);
			return;
		}

		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex), dayOffset);

		int orbitPhaseEnd = TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS
				+ TRAINING_EXPEDITIONS_ORBIT_DAYS * TRAINING_EXPEDITIONS_VISITS_PER_MONTH;
		if (dayOffset < TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS || dayOffset >= orbitPhaseEnd) return;

		int intoOrbitPhase = dayOffset - TRAINING_EXPEDITIONS_TRANSIT_PHASE_DAYS;
		int dayOfThisOrbit = intoOrbitPhase % TRAINING_EXPEDITIONS_ORBIT_DAYS + 1;

		PlanetAPI planet = findPlanet(station.getStarSystem(), getExpeditionPlanetId(station, bayIndex));
		if (planet == null) return;

		// The first day of a new visit's orbit -- move the fleet there (skipped for the very first
		// planet, since launchBay already parked it there).
		if (dayOfThisOrbit == 1 && intoOrbitPhase >= TRAINING_EXPEDITIONS_ORBIT_DAYS) {
			positionFleetAtPlanet(fleet, planet);
		}

		if (dayOfThisOrbit == TRAINING_EXPEDITIONS_LOOT_ROLL_DAY) {
			rollForLoot(station, planet);
		}
	}

	/** Pulls the ships back out of the temporary fleet (so they aren't lost) and despawns it. */
	private static void recallTouringFleet(SectorEntityToken station, int bayIndex) {
		CampaignFleetAPI fleet = getTouringFleet(station, bayIndex);
		if (fleet != null) {
			List<FleetMemberAPI> ships = getCommittedShips(station, bayIndex);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearTouringState(station, bayIndex);
	}

	private static void clearTouringState(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_DAY_OFFSET_MEMORY_KEY, bayIndex));
	}

	private static void clearBayMemory(SectorEntityToken station, int bayIndex) {
		clearTouringState(station, bayIndex);
		station.getMemoryWithoutUpdate().unset(bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, bayIndex));
	}

	private static PlanetAPI findPlanet(StarSystemAPI system, String planetId) {
		if (system == null || planetId == null) return null;
		for (PlanetAPI p : system.getPlanets()) {
			if (planetId.equals(p.getId())) return p;
		}
		return null;
	}

	/** Ruins condition tier, 1 (Scattered) through 4 (Vast); 0 if the market has no ruins condition. */
	private static int getRuinsTier(MarketAPI market) {
		if (market == null) return 0;
		if (market.hasCondition(Conditions.RUINS_VAST)) return 4;
		if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) return 3;
		if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) return 2;
		if (market.hasCondition(Conditions.RUINS_SCATTERED)) return 1;
		return 0;
	}

	private static float getBaseRuinsChanceForTier(int tier) {
		switch (tier) {
			case 4: return RUINS_CHANCE_VAST;
			case 3: return RUINS_CHANCE_EXTENSIVE;
			case 2: return RUINS_CHANCE_WIDESPREAD;
			case 1: return RUINS_CHANCE_SCATTERED;
			default: return 0f;
		}
	}

	/** The player's Salvaging skill sharpens the crew's eye for anything worth finding, by the same flat amount at every ruins tier. */
	private static boolean hasSalvagingSkill() {
		return Global.getSector().getPlayerStats() != null
				&& Global.getSector().getPlayerStats().getSkillLevel(Skills.SALVAGING) > 0;
	}

	private static float getRuinsChance(MarketAPI market) {
		int tier = getRuinsTier(market);
		if (tier <= 0) return 0f;

		float chance = getBaseRuinsChanceForTier(tier);
		if (hasSalvagingSkill()) {
			chance += SALVAGING_SKILL_BONUS;
		}
		return chance;
	}

	/** Rolled once per day the touring fleet spends in orbit of a planet with a ruins condition. */
	private static void rollForLoot(SectorEntityToken station, PlanetAPI planet) {
		MarketAPI market = planet.getMarket();
		if (market == null) return;

		float chance = getRuinsChance(market);
		if (chance <= 0f) return;
		if (Math.random() >= chance) return;

		String lootLine = generateLoot(station);
		if (lootLine == null) return;

		logLoot(station, planet.getName(), lootLine);
	}

	@SuppressWarnings("unchecked")
	private static void logLoot(SectorEntityToken station, String planetName, String lootLine) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		Object o = mem.get(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY);
		List<String> log = (o instanceof List) ? (List<String>) o : new ArrayList<String>();
		log.add(lootLine + " -- found at " + planetName);
		mem.set(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY, log);
	}

	/** Loot found so far on the current (or most recently concluded) tour, for the monthly status report. */
	@SuppressWarnings("unchecked")
	public static List<String> getTrainingExpeditionLootThisMonth(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY);
		return (o instanceof List) ? new ArrayList<String>((List<String>) o) : new ArrayList<String>();
	}

	public static void clearTrainingExpeditionLootThisMonth(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY);
	}

	private static <T> T pickRandom(List<T> list) {
		if (list == null || list.isEmpty()) return null;
		return list.get((int) (Math.random() * list.size()));
	}

	private static FighterWingSpecAPI pickRandomRegularFighter() {
		List<FighterWingSpecAPI> pool = new ArrayList<FighterWingSpecAPI>();
		for (FighterWingSpecAPI spec : Global.getSettings().getAllFighterWingSpecs()) {
			if (spec.isRegularFighter()) pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static HullModSpecAPI pickRandomHullMod() {
		List<HullModSpecAPI> pool = new ArrayList<HullModSpecAPI>();
		for (HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
			if (spec.isHidden() || spec.isHiddenEverywhere() || spec.isAlwaysUnlocked()) continue;
			pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static boolean isLootableHullSize(HullSize size) {
		return size == HullSize.FRIGATE || size == HullSize.DESTROYER
				|| size == HullSize.CRUISER || size == HullSize.CAPITAL_SHIP;
	}

	/** Variant ids for hulls cheap enough to show up as ship loot -- used to actually spawn the found ship. */
	private static List<String> getLootableShipVariantIds() {
		List<String> result = new ArrayList<String>();
		for (String variantId : Global.getSettings().getAllVariantIds()) {
			ShipVariantAPI variant = Global.getSettings().getVariant(variantId);
			if (variant == null) continue;
			ShipHullSpecAPI hull = variant.getHullSpec();
			if (hull == null || hull.isDHull()) continue;
			if (hull.getBaseValue() > MAX_LOOT_SHIP_VALUE) continue;
			if (!isLootableHullSize(hull.getHullSize())) continue;
			result.add(variantId);
		}
		return result;
	}

	/** Hull specs (one per hull id) cheap enough to show up as a ship blueprint. */
	private static List<ShipHullSpecAPI> getLootableHullSpecs() {
		List<ShipHullSpecAPI> result = new ArrayList<ShipHullSpecAPI>();
		Set<String> seen = new HashSet<String>();
		for (ShipHullSpecAPI hull : Global.getSettings().getAllShipHullSpecs()) {
			if (hull.isDHull()) continue;
			if (hull.getBaseValue() > MAX_LOOT_SHIP_VALUE) continue;
			if (!isLootableHullSize(hull.getHullSize())) continue;
			if (seen.add(hull.getHullId())) result.add(hull);
		}
		return result;
	}

	/** Rolls, cumulatively (worst first), how many D-mods a found ship should have -- see {@link #LOOT_SHIP_CHANCE_3_DMODS} and friends. */
	private static int rollLootShipDMods() {
		float roll = (float) Math.random();
		if (roll < LOOT_SHIP_CHANCE_3_DMODS) return 3;
		if (roll < LOOT_SHIP_CHANCE_3_DMODS + LOOT_SHIP_CHANCE_2_DMODS) return 2;
		if (roll < LOOT_SHIP_CHANCE_3_DMODS + LOOT_SHIP_CHANCE_2_DMODS + LOOT_SHIP_CHANCE_1_DMOD) return 1;
		return 0;
	}

	private static String generateShip(String factionId, CargoAPI storage) {
		String variantId = pickRandom(getLootableShipVariantIds());
		if (variantId == null) return null;

		FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, variantId);

		int dmodsWanted = rollLootShipDMods();
		if (dmodsWanted > 0) {
			DModManager.addDMods(member.getVariant(), false, dmodsWanted, null);
		}
		int dmodsActual = Math.min(DModManager.getNumDMods(member.getVariant()), MAX_LOOT_SHIP_DMODS);

		storage.initMothballedShips(factionId);
		storage.getMothballedShips().addFleetMember(member);

		String dmodNote = dmodsActual > 0 ? ", " + dmodsActual + " D-mod" + (dmodsActual > 1 ? "s" : "") : "";
		return "1 " + member.getHullSpec().getHullName() + " (ship" + dmodNote + ", stored at the station)";
	}

	private static String generateBlueprint(CargoAPI storage) {
		int roll = (int) (Math.random() * 3);
		if (roll == 0) {
			WeaponSpecAPI spec = pickRandom(Global.getSettings().getAllWeaponSpecs());
			if (spec == null) return null;
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.WEAPON_BP, spec.getWeaponId()), 1);
			return "1 blueprint: " + spec.getWeaponName() + " (weapon)";
		} else if (roll == 1) {
			FighterWingSpecAPI spec = pickRandomRegularFighter();
			if (spec == null) return null;
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FIGHTER_BP, spec.getId()), 1);
			return "1 blueprint: " + spec.getWingName() + " (fighter wing)";
		} else {
			ShipHullSpecAPI spec = pickRandom(getLootableHullSpecs());
			if (spec == null) return null;
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SHIP_BP, spec.getHullId()), 1);
			return "1 blueprint: " + spec.getHullName() + " (ship)";
		}
	}

	private static String generateLoot(SectorEntityToken station) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return null;

		WeightedRandomPicker<String> categoryPicker = new WeightedRandomPicker<String>();
		categoryPicker.add("weapon", LOOT_WEIGHT_WEAPON);
		categoryPicker.add("fighter", LOOT_WEIGHT_FIGHTER);
		categoryPicker.add("hullmod", LOOT_WEIGHT_HULLMOD);
		categoryPicker.add("blueprint", LOOT_WEIGHT_BLUEPRINT);
		categoryPicker.add("ship", LOOT_WEIGHT_SHIP);
		categoryPicker.add("special", LOOT_WEIGHT_SPECIAL_ITEM);
		String category = categoryPicker.pick();
		if (category == null) return null;

		if (category.equals("weapon")) {
			WeaponSpecAPI spec = pickRandom(Global.getSettings().getAllWeaponSpecs());
			if (spec == null) return null;
			storage.addWeapons(spec.getWeaponId(), 1);
			return "1 " + spec.getWeaponName() + " (weapon)";
		}
		if (category.equals("fighter")) {
			FighterWingSpecAPI spec = pickRandomRegularFighter();
			if (spec == null) return null;
			storage.addFighters(spec.getId(), 1);
			return "1 " + spec.getWingName() + " (fighter wing)";
		}
		if (category.equals("hullmod")) {
			HullModSpecAPI spec = pickRandomHullMod();
			if (spec == null) return null;
			storage.addHullmods(spec.getId(), 1);
			return "1 " + spec.getDisplayName() + " (hull mod)";
		}
		if (category.equals("blueprint")) {
			return generateBlueprint(storage);
		}
		if (category.equals("ship")) {
			return generateShip(Factions.PLAYER, storage);
		}
		if (category.equals("special")) {
			String itemId = SPECIAL_ITEM_LOOT_POOL[(int) (Math.random() * SPECIAL_ITEM_LOOT_POOL.length)];
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
			SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec(itemId);
			return "1 " + (spec != null ? spec.getName() : itemId) + " (special item)";
		}
		return null;
	}
}
