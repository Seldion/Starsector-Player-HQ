package playerhq.modules;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.PlayerMarketTransaction;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SubmarketPlugin.TransferAction;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;

/**
 * Backs the Player HQ Market Place's Exchange submarket (see {@code data/campaign/submarkets.csv}),
 * opened through the real vanilla trade screen. A curated, no-questions-asked stock, fully re-rolled
 * the first time it's opened in a new campaign month (see {@link #updateCargoPrePlayerInteraction}).
 * Buy only -- the player can browse and buy from it, but can't sell anything to it; selling only ever
 * happens through the separate Agora inventory's monthly merchant sweep (see {@link MarketPlaceModule}).
 * <p>
 * Every restock always includes {@value #WEAPON_TYPES} distinct weapon types and {@value #WING_TYPES}
 * distinct fighter wing types, each stocked as a stack of a random size from 1 to {@value #MAX_STACK_SIZE}
 * units -- pricier items are still rarer to be chosen for the roster at all. Hull mods and blueprints
 * are much rarer: each restock has an independent {@value #HULLMOD_CHANCE} chance of including
 * {@value #HULLMOD_TYPES} hull mod types, and an independent {@value #BLUEPRINT_CHANCE} chance of
 * including {@value #BLUEPRINT_TYPES} blueprint, each always a single unit since they're one-time-use.
 * <p>
 * There's no overall credit cap on a restock any more -- what the player spends buying from this
 * market instead flows into next month's Agora merchant budget, via {@link #reportPlayerMarketTransaction}
 * and {@link MarketPlaceModule#addExchangeSpend}.
 */
public class BlackMarketSubmarketPlugin extends BaseSubmarketPlugin {

	public static final int HULLMOD_TYPES = 2;
	public static final int BLUEPRINT_TYPES = 1;
	public static final int WING_TYPES = 5;
	public static final int WEAPON_TYPES = 12;

	/** Independent per-restock chance for hull mods (as a category) to show up at all. */
	private static final float HULLMOD_CHANCE = 0.25f;
	/** Independent per-restock chance for the blueprint (as a category) to show up at all. */
	private static final float BLUEPRINT_CHANCE = 0.25f;

	/** Weapons and fighter wings stock as a random-sized stack from 1 up to this many units. */
	private static final int MAX_STACK_SIZE = 10;

	/** Blueprints are priced as a flat multiple of the underlying item's own base value, for rarity weighting only. */
	private static final float BLUEPRINT_VALUE_MULT = 2f;

	/** Floor used when weighting rarity by cost, so near-worthless items don't completely dominate the picker. */
	private static final float RARITY_VALUE_FLOOR = 100f;

	private enum Kind { WEAPON, FIGHTER, HULLMOD, SHIP_BP, WEAPON_BP, FIGHTER_BP }

	private static class StockEntry {
		final Kind kind;
		final String id;
		final int quantity;
		StockEntry(Kind kind, String id, int quantity) {
			this.kind = kind;
			this.id = id;
			this.quantity = quantity;
		}
	}

	/** Which campaign month (cycle * 12 + month, so it never repeats) this was last restocked for. */
	private int lastRestockMonthIndex = Integer.MIN_VALUE;

	@Override
	public void init(SubmarketAPI submarket) {
		super.init(submarket);
	}

	@Override
	public String getName() {
		return "Exchange";
	}

	@Override
	public boolean isBlackMarket() {
		return true;
	}

	/** No tariff -- it's the player's own station. */
	@Override
	public float getTariff() {
		return 0f;
	}

	/** Purely a custom stockpile -- shouldn't nudge the wider game economy's supply/demand tracking. */
	@Override
	public boolean isParticipatesInEconomy() {
		return false;
	}

	/** Buy only -- the player can't sell anything to this market. */
	@Override
	public boolean isIllegalOnSubmarket(CargoStackAPI stack, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) return true;
		return super.isIllegalOnSubmarket(stack, action);
	}

	@Override
	public boolean isIllegalOnSubmarket(FleetMemberAPI member, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) return true;
		return super.isIllegalOnSubmarket(member, action);
	}

	@Override
	public String getIllegalTransferText(CargoStackAPI stack, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "This market doesn't buy from you -- deposit items at the Agora instead";
		}
		return super.getIllegalTransferText(stack, action);
	}

	@Override
	public String getIllegalTransferText(FleetMemberAPI member, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "This market doesn't buy from you -- deposit items at the Agora instead";
		}
		return super.getIllegalTransferText(member, action);
	}

	/**
	 * Whatever the player spends buying from the Exchange doesn't just vanish -- it's tracked and
	 * added on top of next month's random Agora merchant budget (see
	 * {@link MarketPlaceModule#addExchangeSpend} and {@link MarketPlaceModule#collectMerchantIncome}).
	 * Deliberately doesn't call {@code super} -- {@link #isParticipatesInEconomy()} is false, so the
	 * base implementation would no-op anyway, and this shouldn't touch supply/demand tracking either way.
	 */
	@Override
	public void reportPlayerMarketTransaction(PlayerMarketTransaction transaction) {
		float spent = -transaction.getCreditValue();
		if (spent <= 0f) return;
		SectorEntityToken entity = market.getPrimaryEntity();
		if (entity != null) {
			MarketPlaceModule.addExchangeSpend(entity, spent);
		}
	}

	/**
	 * Fully re-rolls the first time this is opened in a new campaign month -- whatever wasn't bought
	 * since the last restock is simply replaced. See the class doc for exactly what gets picked.
	 */
	@Override
	public void updateCargoPrePlayerInteraction() {
		sinceLastCargoUpdate = 0f;

		int monthIndex = Global.getSector().getClock().getCycle() * 12 + Global.getSector().getClock().getMonth();
		if (monthIndex == lastRestockMonthIndex) return;
		lastRestockMonthIndex = monthIndex;

		CargoAPI cargo = getCargo();
		cargo.clear();

		List<StockEntry> entries = new ArrayList<StockEntry>();

		if (itemGenRandom.nextFloat() < HULLMOD_CHANCE) {
			WeightedRandomPicker<HullModSpecAPI> hullModPicker = buildHullModPicker();
			for (int i = 0; i < HULLMOD_TYPES && !hullModPicker.isEmpty(); i++) {
				HullModSpecAPI spec = hullModPicker.pickAndRemove();
				if (spec != null) entries.add(new StockEntry(Kind.HULLMOD, spec.getId(), 1));
			}
		}

		if (itemGenRandom.nextFloat() < BLUEPRINT_CHANCE) {
			for (int i = 0; i < BLUEPRINT_TYPES; i++) {
				StockEntry blueprint = pickOneBlueprint();
				if (blueprint != null) entries.add(blueprint);
			}
		}

		WeightedRandomPicker<FighterWingSpecAPI> fighterPicker = buildFighterPicker();
		for (int i = 0; i < WING_TYPES && !fighterPicker.isEmpty(); i++) {
			FighterWingSpecAPI spec = fighterPicker.pickAndRemove();
			if (spec != null) entries.add(new StockEntry(Kind.FIGHTER, spec.getId(), randomStackSize()));
		}

		WeightedRandomPicker<WeaponSpecAPI> weaponPicker = buildWeaponPicker();
		for (int i = 0; i < WEAPON_TYPES && !weaponPicker.isEmpty(); i++) {
			WeaponSpecAPI spec = weaponPicker.pickAndRemove();
			if (spec != null) entries.add(new StockEntry(Kind.WEAPON, spec.getWeaponId(), randomStackSize()));
		}

		for (StockEntry e : entries) {
			switch (e.kind) {
			case WEAPON:
				cargo.addWeapons(e.id, e.quantity);
				break;
			case FIGHTER:
				cargo.addFighters(e.id, e.quantity);
				break;
			case HULLMOD:
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.TAG_MODSPEC, e.id), e.quantity);
				break;
			case SHIP_BP:
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SHIP_BP, e.id), e.quantity);
				break;
			case WEAPON_BP:
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.WEAPON_BP, e.id), e.quantity);
				break;
			case FIGHTER_BP:
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FIGHTER_BP, e.id), e.quantity);
				break;
			}
		}

		cargo.sort();
	}

	/** 1 to {@value #MAX_STACK_SIZE}, inclusive. */
	private int randomStackSize() {
		return 1 + itemGenRandom.nextInt(MAX_STACK_SIZE);
	}

	private StockEntry pickOneBlueprint() {
		WeightedRandomPicker<String> bpTypePicker = new WeightedRandomPicker<String>();
		bpTypePicker.add("ship", 50f);
		bpTypePicker.add("weapon", 30f);
		bpTypePicker.add("fighter", 20f);
		String bpType = bpTypePicker.pick();
		if (bpType == null) return null;

		if (bpType.equals("ship")) {
			ShipHullSpecAPI spec = buildShipBlueprintPicker().pick();
			if (spec == null) return null;
			return new StockEntry(Kind.SHIP_BP, spec.getHullId(), 1);
		} else if (bpType.equals("weapon")) {
			WeaponSpecAPI spec = buildWeaponPicker().pick();
			if (spec == null) return null;
			return new StockEntry(Kind.WEAPON_BP, spec.getWeaponId(), 1);
		} else {
			FighterWingSpecAPI spec = buildFighterPicker().pick();
			if (spec == null) return null;
			return new StockEntry(Kind.FIGHTER_BP, spec.getId(), 1);
		}
	}

	private WeightedRandomPicker<WeaponSpecAPI> buildWeaponPicker() {
		WeightedRandomPicker<WeaponSpecAPI> picker = new WeightedRandomPicker<WeaponSpecAPI>();
		for (WeaponSpecAPI spec : Global.getSettings().getAllWeaponSpecs()) {
			if (spec.getBaseValue() <= 0f) continue;
			if (spec.hasTag(Tags.WEAPON_NO_SELL)) continue;
			picker.add(spec, rarityWeight(spec.getBaseValue()));
		}
		return picker;
	}

	private WeightedRandomPicker<FighterWingSpecAPI> buildFighterPicker() {
		WeightedRandomPicker<FighterWingSpecAPI> picker = new WeightedRandomPicker<FighterWingSpecAPI>();
		for (FighterWingSpecAPI spec : Global.getSettings().getAllFighterWingSpecs()) {
			if (!spec.isRegularFighter()) continue;
			if (spec.getBaseValue() <= 0f) continue;
			picker.add(spec, rarityWeight(spec.getBaseValue()));
		}
		return picker;
	}

	private WeightedRandomPicker<ShipHullSpecAPI> buildShipBlueprintPicker() {
		WeightedRandomPicker<ShipHullSpecAPI> picker = new WeightedRandomPicker<ShipHullSpecAPI>();
		for (ShipHullSpecAPI spec : Global.getSettings().getAllShipHullSpecs()) {
			if (!spec.isBaseHull()) continue;
			if (spec.getBaseValue() <= 0f) continue;
			if (spec.hasTag(Tags.NO_BP_DROP) || spec.hasTag(Tags.RESTRICTED)) continue;
			picker.add(spec, rarityWeight(spec.getBaseValue() * BLUEPRINT_VALUE_MULT));
		}
		return picker;
	}

	private WeightedRandomPicker<HullModSpecAPI> buildHullModPicker() {
		WeightedRandomPicker<HullModSpecAPI> picker = new WeightedRandomPicker<HullModSpecAPI>();
		for (HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
			if (spec.isHidden() || spec.isAlwaysUnlocked()) continue;
			if (spec.getBaseValue() <= 0f) continue;
			picker.add(spec, rarityWeight(spec.getBaseValue()));
		}
		return picker;
	}

	/** Inverse-value weighting -- the pricier an item is, the less likely it is to be picked. */
	private static float rarityWeight(float value) {
		return 1f / Math.max(value, RARITY_VALUE_FLOOR);
	}
}
