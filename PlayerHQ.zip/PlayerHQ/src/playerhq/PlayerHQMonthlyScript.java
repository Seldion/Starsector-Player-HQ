package playerhq;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignClockAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;
import playerhq.modules.StationItemsModule;
import playerhq.util.PlayerHQUtils;

public class PlayerHQMonthlyScript implements EveryFrameScript {

	private int lastCheckedDay = -1;
	private int lastProductionCheckDay = -1;

	private boolean done = false;

	@Override
	public boolean isDone() {
		return done;
	}

	@Override
	public boolean runWhilePaused() {
		return false;
	}

	@Override
	public void advance(float amount) {
		SectorEntityToken station = PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
		if (station == null) {
			done = true;
			return;
		}

		CampaignClockAPI clock = Global.getSector().getClock();
		int day = clock.getDay();

		if (day != lastProductionCheckDay) {
			AssemblyBayModule.advanceProduction(station);
			MilitaryWardModule.enforceCap(station);
			lastProductionCheckDay = day;
		}

		if (day == 1 && lastCheckedDay != 1) {
			runMonthlyTick(station);
		}

		lastCheckedDay = day;
	}

	private void runMonthlyTick(SectorEntityToken station) {
		MiningHangarModule.MiningResult miningResult = null;
		if (MiningHangarModule.isBuilt(station)) {
			miningResult = MiningHangarModule.collectResources(station);
		}

		IndustrialHubModule.IndustrialHubResult industrialResult = null;
		if (IndustrialHubModule.isBuilt(station)) {
			industrialResult = IndustrialHubModule.process(station);
		}

		HydroponicsHubModule.HydroponicsResult hydroponicsResult = null;
		if (HydroponicsHubModule.isBuilt(station)) {
			hydroponicsResult = HydroponicsHubModule.produce(station);
		}

		StationItemsModule.updateDroneReplicatorDefenseBonus(station);

		if (AssemblyBayModule.isBuilt(station)) {
			AssemblyBayModule.accumulateMonthly(station);
		}

		if (MilitaryWardModule.isBuilt(station)) {
			MilitaryWardModule.accumulateMonthly(station);
		}

		float upkeepCharged = ConstructPlayerHQAbility.chargeMonthlyUpkeep(station);

		float recreationIncome = 0f;
		if (RecreationalHubModule.isBuilt(station)) {
			recreationIncome = RecreationalHubModule.collectIncome(station);
		}

		PlayerHQMonthlyReportIntel.report(miningResult, industrialResult, hydroponicsResult, recreationIncome, upkeepCharged);
	}
}
