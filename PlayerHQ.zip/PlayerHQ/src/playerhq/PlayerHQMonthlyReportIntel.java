package playerhq;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import playerhq.modules.HydroponicsHubModule.HydroponicsResult;
import playerhq.modules.IndustrialHubModule.IndustrialHubResult;
import playerhq.modules.MiningHangarModule.MiningResult;

public class PlayerHQMonthlyReportIntel extends BaseIntelPlugin {

	private final MiningResult mining;
	private final IndustrialHubResult industrial;
	private final HydroponicsResult hydroponics;
	private final float recreationIncome;
	private final float upkeepCharged;

	public PlayerHQMonthlyReportIntel(MiningResult mining, IndustrialHubResult industrial, HydroponicsResult hydroponics,
			float recreationIncome, float upkeepCharged) {
		this.mining = mining;
		this.industrial = industrial;
		this.hydroponics = hydroponics;
		this.recreationIncome = recreationIncome;
		this.upkeepCharged = upkeepCharged;
	}

	private static boolean hasActivity(MiningResult mining, IndustrialHubResult industrial, HydroponicsResult hydroponics,
			float recreationIncome, float upkeepCharged) {
		if (recreationIncome > 0f || upkeepCharged > 0f) return true;
		if (mining != null && (mining.ore > 0f || mining.rareOre > 0f || mining.volatiles > 0f || mining.organics > 0f
				|| mining.oreLostToCap > 0f || mining.rareOreLostToCap > 0f
				|| mining.volatilesLostToCap > 0f || mining.organicsLostToCap > 0f)) {
			return true;
		}
		if (industrial != null && (industrial.metals > 0f || industrial.transplutonics > 0f
				|| industrial.heavyMachinery > 0f || industrial.supplies > 0f || industrial.drugs > 0f || industrial.organs > 0f
				|| industrial.domesticGoods > 0f || industrial.luxuryGoods > 0f || industrial.heavyArmaments > 0f)) {
			return true;
		}
		if (hydroponics != null && (hydroponics.food > 0f || hydroponics.organics > 0f
				|| hydroponics.foodLostToCap > 0f || hydroponics.organicsLostToCap > 0f)) {
			return true;
		}
		return false;
	}

	public static void report(MiningResult mining, IndustrialHubResult industrial, HydroponicsResult hydroponics,
			float recreationIncome, float upkeepCharged) {
		if (!hasActivity(mining, industrial, hydroponics, recreationIncome, upkeepCharged)) return;

		List<IntelInfoPlugin> old = new ArrayList<IntelInfoPlugin>(
				Global.getSector().getIntelManager().getIntel(PlayerHQMonthlyReportIntel.class));
		for (IntelInfoPlugin plugin : old) {
			Global.getSector().getIntelManager().removeIntel(plugin);
		}

		PlayerHQMonthlyReportIntel intel = new PlayerHQMonthlyReportIntel(mining, industrial, hydroponics, recreationIncome, upkeepCharged);
		Global.getSector().getIntelManager().addIntel(intel);
	}

	@Override
	protected String getName() {
		return "Player HQ Monthly Report";
	}

	@Override
	public String getIcon() {
		return Global.getSettings().getCommoditySpec(Commodities.ORE).getIconName();
	}

	@Override
	protected void addBulletPoints(TooltipMakerAPI info, ListInfoMode mode, boolean isUpdate, Color tc, float initPad) {
		addLines(info, initPad);
	}

	@Override
	public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		float opad = 10f;
		info.addPara(getName(), opad);
		addLines(info, opad);
	}

	private void addLines(TooltipMakerAPI info, float pad) {
		Color h = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();

		if (mining != null) {
			if (!mining.contributingPlanets.isEmpty()) {
				info.addPara("Materials Acquisition Hub drew from: %s.", pad, h, String.join(", ", mining.contributingPlanets));
			}
			if (mining.ore > 0f) {
				info.addPara("Materials Acquisition Hub collected %s ore.", pad, h, fmt(mining.ore));
			}
			if (mining.rareOre > 0f) {
				info.addPara("Materials Acquisition Hub collected %s transplutonic ore.", pad, h, fmt(mining.rareOre));
			}
			if (mining.volatiles > 0f) {
				info.addPara("Materials Acquisition Hub collected %s volatiles.", pad, h, fmt(mining.volatiles));
			}
			if (mining.organics > 0f) {
				info.addPara("Materials Acquisition Hub collected %s organics.", pad, h, fmt(mining.organics));
			}
			if (mining.oreLostToCap > 0f) {
				info.addPara("The station's ore storage is full (10,000 cap) - %s ore could not be collected.",
						pad, bad, fmt(mining.oreLostToCap));
			}
			if (mining.rareOreLostToCap > 0f) {
				info.addPara("The station's transplutonic ore storage is full (10,000 cap) - %s transplutonic ore could not be collected.",
						pad, bad, fmt(mining.rareOreLostToCap));
			}
			if (mining.volatilesLostToCap > 0f) {
				info.addPara("The station's volatiles storage is full (10,000 cap) - %s volatiles could not be collected.",
						pad, bad, fmt(mining.volatilesLostToCap));
			}
			if (mining.organicsLostToCap > 0f) {
				info.addPara("The station's organics storage is full (10,000 cap) - %s organics could not be collected.",
						pad, bad, fmt(mining.organicsLostToCap));
			}
		}

		if (industrial != null) {
			if (industrial.metals > 0f) {
				info.addPara("Manufactorium refined %s metals.", pad, h, fmt(industrial.metals));
			}
			if (industrial.transplutonics > 0f) {
				info.addPara("Manufactorium refined %s transplutonics.", pad, h, fmt(industrial.transplutonics));
			}
			if (industrial.heavyMachinery > 0f) {
				info.addPara("Manufactorium produced %s heavy machinery.", pad, h, fmt(industrial.heavyMachinery));
			}
			if (industrial.supplies > 0f) {
				info.addPara("Manufactorium produced %s supplies.", pad, h, fmt(industrial.supplies));
			}
			if (industrial.drugs > 0f) {
				info.addPara("Manufactorium produced %s recreational drugs.", pad, h, fmt(industrial.drugs));
			}
			if (industrial.organs > 0f) {
				info.addPara("Manufactorium produced %s organs.", pad, h, fmt(industrial.organs));
			}
			if (industrial.domesticGoods > 0f) {
				info.addPara("Manufactorium produced %s domestic goods.", pad, h, fmt(industrial.domesticGoods));
			}
			if (industrial.luxuryGoods > 0f) {
				info.addPara("Manufactorium produced %s luxury goods.", pad, h, fmt(industrial.luxuryGoods));
			}
			if (industrial.heavyArmaments > 0f) {
				info.addPara("Manufactorium produced %s heavy armaments.", pad, h, fmt(industrial.heavyArmaments));
			}
		}

		if (hydroponics != null) {
			if (hydroponics.food > 0f) {
				info.addPara("Bio-Dome produced %s food.", pad, h, fmt(hydroponics.food));
			}
			if (hydroponics.organics > 0f) {
				info.addPara("Bio-Dome produced %s organics.", pad, h, fmt(hydroponics.organics));
			}
			if (hydroponics.foodLostToCap > 0f) {
				info.addPara("The station's food storage is full (10,000 cap) - %s food could not be produced.",
						pad, bad, fmt(hydroponics.foodLostToCap));
			}
			if (hydroponics.organicsLostToCap > 0f) {
				info.addPara("The station's organics storage is full (10,000 cap) - %s organics could not be produced.",
						pad, bad, fmt(hydroponics.organicsLostToCap));
			}
		}

		if (recreationIncome > 0f) {
			info.addPara("Resort generated %s credits in income.", pad, h, fmt(recreationIncome));
		}

		if (upkeepCharged > 0f) {
			info.addPara("Station upkeep cost %s credits.", pad, bad, fmt(upkeepCharged));
		}
	}

	private static String fmt(float value) {
		return "" + (int) value;
	}
}
