package playerhq;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

public class PlayerHQModPlugin extends BaseModPlugin {

	@Override
	public void onGameLoad(boolean newGame) {
		if (!Global.getSector().getListenerManager().hasListenerOfClass(PlayerHQIncomeReportListener.class)) {
			Global.getSector().getListenerManager().addListener(new PlayerHQIncomeReportListener(), true);
		}
	}
}
