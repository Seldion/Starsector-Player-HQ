package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;
import playerhq.util.PlayerHQUtils;

import java.util.Map;

public class PlayerHQBuildChoiceDialogPlugin implements InteractionDialogPlugin {

	private static final String OPTION_LOWTECH = "playerhq_build_lowtech";
	private static final String OPTION_HIGHTECH = "playerhq_build_hightech";
	private static final String OPTION_CANCEL = "playerhq_build_cancel";

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;
	private OptionPanelAPI options;

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		this.text = dialog.getTextPanel();
		this.options = dialog.getOptionPanel();

		text.addPara("Choose a design for the Player HQ station. Both designs share the same base "
				+ "cost; each additionally requires a specific AI core to complete construction.");

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		CargoAPI cargo = playerFleet.getCargo();

		addBenefitsPreview(playerFleet);

		boolean hasGamma = ConstructPlayerHQAbility.hasCore(cargo, Commodities.GAMMA_CORE);
		boolean hasBeta = ConstructPlayerHQAbility.hasCore(cargo, Commodities.BETA_CORE);

		options.addOption("Build Low-Tech HQ", OPTION_LOWTECH, "Requires one Gamma Core in addition to the base cost.");
		options.setEnabled(OPTION_LOWTECH, hasGamma);

		options.addOption("Build High-Tech HQ", OPTION_HIGHTECH, "Requires one Beta Core in addition to the base cost.");
		options.setEnabled(OPTION_HIGHTECH, hasBeta);

		options.addOption("Cancel", OPTION_CANCEL);

		dialog.setPromptText("Construct Player HQ");
	}

	/**
	 * A quick breakdown of what building here would be worth -- the raw resources a Materials Acquisition Hub
	 * would pull in from this system, and the income a Resort would generate if the
	 * station ends up orbiting a colonized planet -- so the player can weigh the location before
	 * committing to a design.
	 */
	private void addBenefitsPreview(CampaignFleetAPI playerFleet) {
		StarSystemAPI system = playerFleet.getStarSystem();
		if (system == null) return;

		boolean hasAnyBenefit = false;

		java.util.List<String> miningLines = MiningHangarModule.getExpectedMonthlyHarvestForSystem(system);
		MarketAPI orbitMarket = PlayerHQUtils.getPreviewOrbitMarket(playerFleet);
		float recIncome = RecreationalHubModule.getExpectedIncomeForMarket(orbitMarket);

		boolean hasMiningBenefit = !miningLines.isEmpty()
				&& !miningLines.get(0).startsWith("No mineable");
		if (hasMiningBenefit || recIncome > 0f) {
			text.addPara("Expected benefits of building here:");
			hasAnyBenefit = true;
		}

		if (hasMiningBenefit) {
			text.addPara("Materials Acquisition Hub (if built): " + miningLines.get(0).replace("Expected monthly harvest: ", ""));
		}

		if (recIncome > 0f) {
			text.addPara(String.format("Resort (if built): ~%s credits/month, from %s.",
					(int) recIncome, orbitMarket.getName()));
		}

		if (!hasAnyBenefit) {
			text.addPara("No mineable resources detected here, and this isn't orbit of a colonized "
					+ "planet, so a Materials Acquisition Hub or Resort wouldn't have much to work with at "
					+ "this location.");
		}
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (OPTION_CANCEL.equals(optionData)) {
			dialog.dismissAsCancel();
			return;
		}

		boolean lowTech = OPTION_LOWTECH.equals(optionData);
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		CargoAPI cargo = playerFleet.getCargo();

		String requiredCore = lowTech ? Commodities.GAMMA_CORE : Commodities.BETA_CORE;
		if (!ConstructPlayerHQAbility.hasSharedCost(cargo) || !ConstructPlayerHQAbility.hasCore(cargo, requiredCore)) {
			text.addPara("You no longer have the resources required for this design.");
			options.setEnabled(OPTION_LOWTECH, ConstructPlayerHQAbility.hasCore(cargo, Commodities.GAMMA_CORE));
			options.setEnabled(OPTION_HIGHTECH, ConstructPlayerHQAbility.hasCore(cargo, Commodities.BETA_CORE));
			return;
		}

		ConstructPlayerHQAbility.buildStation(playerFleet, lowTech);
		text.addPara("Construction of the Player HQ (" + (lowTech ? "Low-Tech" : "High-Tech") + ") is complete.");
		dialog.dismiss();
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
