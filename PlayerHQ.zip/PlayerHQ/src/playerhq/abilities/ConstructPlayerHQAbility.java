package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import playerhq.Ids;
import playerhq.PlayerHQMonthlyScript;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;
import playerhq.modules.StationItemsModule;
import playerhq.util.PlayerHQUtils;

import java.awt.Color;

public class ConstructPlayerHQAbility extends BaseDurationAbility {

	public static final float CREDIT_COST = 50000f;
	public static final float METALS_COST = 5000f;
	public static final float TRANSPLUTONICS_COST = 1000f;
	public static final float VOLATILES_COST = 600f;

	public static final float CORE_COST = 1f;

	public static final float HEAVY_MACHINERY_REQUIRED = 200f;

	public static final float REFUND_FRACTION = 0.5f;

	public static final float POPULATED_ORBIT_UPKEEP = 20000f;

	public static final String TAG_LOWTECH = "playerhq_lowtech";
	public static final String TAG_HIGHTECH = "playerhq_hightech";

	@Override
	protected void activateImpl() {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return;

		Global.getSector().getCampaignUI().showInteractionDialog(
				new PlayerHQBuildChoiceDialogPlugin(), playerFleet);
	}

	public static boolean hasSharedCost(CargoAPI cargo) {
		return cargo.getCredits().get() >= CREDIT_COST
				&& cargo.getCommodityQuantity(Commodities.METALS) >= METALS_COST
				&& cargo.getCommodityQuantity(Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& cargo.getCommodityQuantity(Commodities.VOLATILES) >= VOLATILES_COST
				&& cargo.getCommodityQuantity(Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_REQUIRED;
	}

	public static boolean hasCore(CargoAPI cargo, String coreCommodityId) {
		return cargo.getCommodityQuantity(coreCommodityId) >= CORE_COST;
	}

	public static void buildStation(CampaignFleetAPI playerFleet, boolean lowTech) {
		CargoAPI cargo = playerFleet.getCargo();
		cargo.getCredits().subtract(CREDIT_COST);
		cargo.removeCommodity(Commodities.METALS, METALS_COST);
		cargo.removeCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		cargo.removeCommodity(Commodities.VOLATILES, VOLATILES_COST);
		cargo.removeCommodity(lowTech ? Commodities.GAMMA_CORE : Commodities.BETA_CORE, CORE_COST);

		StarSystemAPI system = playerFleet.getStarSystem();
		String entityTypeId = lowTech ? Ids.STATION_ENTITY_LOWTECH : Ids.STATION_ENTITY_HIGHTECH;
		String displayName = "Player HQ (" + (lowTech ? "Low-Tech" : "High-Tech") + ")";
		String entityId = "playerhq_station_" + Misc.genUID();

		SectorEntityToken station = system.addCustomEntity(entityId, displayName, entityTypeId, "neutral");
		PlayerHQUtils.placeStationInOrbit(station, playerFleet);

		station.addTag(Ids.TAG_STATION);
		station.addTag(lowTech ? TAG_LOWTECH : TAG_HIGHTECH);

		Misc.setAbandonedStationMarket("playerhq_market_" + Misc.genUID(), station);
		station.setCustomDescriptionId(Ids.STATION_DESCRIPTION_ID);
		station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo().initMothballedShips(Factions.PLAYER);

		Global.getSector().addScript(new PlayerHQMonthlyScript());
	}

	public static MarketAPI getColonizedOrbitMarket(SectorEntityToken station) {
		SectorEntityToken focus = station.getOrbitFocus();
		if (!(focus instanceof PlanetAPI)) return null;

		MarketAPI market = focus.getMarket();
		if (market == null) return null;
		if (market.isPlanetConditionMarketOnly()) return null;
		if (market.getSize() <= 0) return null;

		return market;
	}

	public static boolean isOrbitingColonizedPlanet(SectorEntityToken station) {
		return getColonizedOrbitMarket(station) != null;
	}

	public static boolean isUpkeepApplicable(SectorEntityToken station) {
		MarketAPI market = getColonizedOrbitMarket(station);
		return market != null && !market.isPlayerOwned();
	}

	public static float chargeMonthlyUpkeep(SectorEntityToken station) {
		if (!isUpkeepApplicable(station)) return 0f;

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return 0f;

		playerFleet.getCargo().getCredits().subtract(POPULATED_ORBIT_UPKEEP);
		return POPULATED_ORBIT_UPKEEP;
	}

	public static boolean isExistingStationLowTech(SectorEntityToken station) {
		return station.hasTag(TAG_LOWTECH);
	}

	public static void dismantleStation(CampaignFleetAPI playerFleet) {
		SectorEntityToken station = PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
		if (station == null) return;

		boolean lowTech = isExistingStationLowTech(station);

		CargoAPI cargo = playerFleet.getCargo();
		cargo.addCommodity(Commodities.METALS, METALS_COST * REFUND_FRACTION);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * REFUND_FRACTION);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * REFUND_FRACTION);
		cargo.addCommodity(lowTech ? Commodities.GAMMA_CORE : Commodities.BETA_CORE, CORE_COST);

		MiningHangarModule.refund(station, playerFleet);
		RecreationalHubModule.refund(station, playerFleet);
		IndustrialHubModule.refund(station, playerFleet);
		HydroponicsHubModule.refund(station, playerFleet);
		AssemblyBayModule.refund(station, playerFleet);
		MilitaryWardModule.refund(station, playerFleet);
		StationItemsModule.refundDroneReplicator(station, playerFleet);

		if (station.getMarket() != null) {
			Global.getSector().getEconomy().removeMarket(station.getMarket());
		}

		if (station.getContainingLocation() != null) {
			station.getContainingLocation().removeEntity(station);
		}
	}

	private static boolean canBuildAnywhere() {
		return !PlayerHQUtils.entityWithTagExistsAnywhere(Ids.TAG_STATION);
	}

	@Override
	public boolean isUsable() {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return false;

		if (!canBuildAnywhere()) return false;

		StarSystemAPI system = playerFleet.getStarSystem();

		if (system == null || playerFleet.isInHyperspace() || playerFleet.isInHyperspaceTransition()) {
			return false;
		}

		boolean nearValidLocation = PlayerHQUtils.playerFleetInAsteroidBelt(playerFleet)
				|| PlayerHQUtils.playerFleetInAsteroidField(playerFleet)
				|| PlayerHQUtils.playerFleetNearPlanet(playerFleet);
		if (!nearValidLocation) return false;

		if (PlayerHQUtils.playerFleetTooCloseToJumpPoint(playerFleet)) return false;

		if (!hasSharedCost(playerFleet.getCargo())) return false;

		return super.isUsable();
	}

	@Override
	public boolean hasTooltip() {
		return true;
	}

	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
		Color highlight = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();
		float pad = 10f;

		if (!canBuildAnywhere()) {
			tooltip.addTitle("Construct Player HQ");
			tooltip.addPara("A Player HQ station already exists. Fly up to it and interact with it directly "
					+ "to access its inventory, transfer ships, refit at its dockyard, or dismantle it.", pad);
			return;
		}

		tooltip.addTitle("Construct Player HQ");
		tooltip.addPara("Construct a Player HQ station in orbit of a planet or within an asteroid belt or "
				+ "field. Choose between a low-tech and high-tech design. The station is unowned, cannot "
				+ "be attacked or taken over, and does not count as a colony. Only one may exist at a time.",
				pad);
		tooltip.addPara("Costs %s credits, %s metals, %s transplutonics, and %s volatiles, plus one Gamma "
				+ "Core (low-tech) or one Beta Core (high-tech). Also requires %s heavy machinery on hand "
				+ "to perform the construction (not consumed).", pad, highlight,
				new String[] { (int) CREDIT_COST + "", (int) METALS_COST + "", (int) TRANSPLUTONICS_COST + "",
						(int) VOLATILES_COST + "", (int) HEAVY_MACHINERY_REQUIRED + "" });
		tooltip.addPara("If built in orbit of a colonized planet not owned by you, the station costs %s "
				+ "credits per month to maintain. This upkeep is waived if built over one of your own "
				+ "colonies.", pad, highlight, (int) POPULATED_ORBIT_UPKEEP + "");

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return;
		StarSystemAPI system = playerFleet.getStarSystem();

		if (system == null || playerFleet.isInHyperspace() || playerFleet.isInHyperspaceTransition()) {
			tooltip.addPara("You cannot construct a Player HQ station in hyperspace.", bad, pad);
		} else {
			boolean nearValidLocation = PlayerHQUtils.playerFleetInAsteroidBelt(playerFleet)
					|| PlayerHQUtils.playerFleetInAsteroidField(playerFleet)
					|| PlayerHQUtils.playerFleetNearPlanet(playerFleet);
			if (!nearValidLocation) {
				tooltip.addPara("Your fleet must be in orbit of a planet, or within an asteroid belt "
						+ "or asteroid field, to construct a Player HQ station here.", bad, pad);
			}
			if (PlayerHQUtils.playerFleetTooCloseToJumpPoint(playerFleet)) {
				tooltip.addPara("You cannot construct a Player HQ station so close to a jump point.", bad, pad);
			}
		}

		if (!hasSharedCost(playerFleet.getCargo())) {
			tooltip.addPara("Insufficient credits or resources.", bad, pad);
		}
	}

	@Override
	public boolean isTooltipExpandable() {
		return false;
	}

	@Override
	protected void applyEffect(float amount, float level) { }

	@Override
	protected void deactivateImpl() { }

	@Override
	protected void cleanupImpl() { }
}
