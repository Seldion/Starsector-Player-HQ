package playerhq.modules;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class IndustrialHubModule {

	public static final String MEMORY_KEY = "$playerhq_module_industrial";
	public static final String NANOFORGE_MEMORY_KEY = "$playerhq_module_industrial_nanoforge";
	public static final String NANOFORGE_ITEM_KEY = "$playerhq_module_industrial_nanoforge_item";
	public static final String BIOFACTORY_MEMORY_KEY = "$playerhq_module_industrial_biofactory";
	public static final String FUSION_LAMP_MEMORY_KEY = "$playerhq_module_industrial_fusionlamp";
	public static final String CATALYTIC_CORE_MEMORY_KEY = "$playerhq_module_industrial_catalyticcore";

	public static final float CREDIT_COST = 50000f;
	public static final float METALS_COST = 2000f;
	public static final float TRANSPLUTONICS_COST = 500f;
	public static final float VOLATILES_COST = 500f;

	public static final float ORE_PER_METAL = 5f;
	public static final float RARE_ORE_PER_TRANSPLUTONIC = 5f;
	public static final float ORE_PER_METAL_WITH_LAMP = 3f;
	public static final float RARE_ORE_PER_TRANSPLUTONIC_WITH_LAMP = 3f;

	public static final float CATALYTIC_CORE_OUTPUT_BONUS = 2f;

	public static final float HEAVY_MACHINERY_METALS_COST = 10f;
	public static final float HEAVY_MACHINERY_TRANSPLUTONICS_COST = 5f;
	public static final float HEAVY_MACHINERY_BATCH_OUTPUT = 10f;

	public static final float SUPPLIES_BATCH_ORGANICS_COST = 1f;
	public static final float SUPPLIES_BATCH_METALS_COST = 1f;
	public static final float SUPPLIES_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float SUPPLIES_BATCH_VOLATILES_COST = 1f;
	public static final float SUPPLIES_BATCH_FOOD_COST = 1f;
	public static final float SUPPLIES_BATCH_OUTPUT = 15f;

	public static final float HEAVY_ARMAMENTS_BATCH_METALS_COST = 10f;
	public static final float HEAVY_ARMAMENTS_BATCH_TRANSPLUTONICS_COST = 10f;
	public static final float HEAVY_ARMAMENTS_BATCH_VOLATILES_COST = 5f;
	public static final float HEAVY_ARMAMENTS_BATCH_OUTPUT = 10f;

	public static final float DRUGS_BATCH_ORGANICS_COST = 3f;
	public static final float DRUGS_BATCH_METALS_COST = 1f;
	public static final float DRUGS_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float DRUGS_BATCH_OUTPUT = 15f;

	public static final float ORGANS_BATCH_ORGANICS_COST = 10f;
	public static final float ORGANS_BATCH_OUTPUT = 5f;

	public static final float DOMESTIC_GOODS_BATCH_METALS_COST = 1f;
	public static final float DOMESTIC_GOODS_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float DOMESTIC_GOODS_BATCH_ORGANICS_COST = 1f;
	public static final float DOMESTIC_GOODS_BATCH_OUTPUT = 10f;

	public static final float LUXURY_GOODS_BATCH_METALS_COST = 2f;
	public static final float LUXURY_GOODS_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float LUXURY_GOODS_BATCH_ORGANICS_COST = 2f;
	public static final float LUXURY_GOODS_BATCH_DRUGS_COST = 1f;
	public static final float LUXURY_GOODS_BATCH_OUTPUT = 10f;

	public static final float MAX_STORED_RESOURCES = 10000f;

	public static final String IMAGE_PATH = "graphics/modules/industrial_hub.jpg";

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= VOLATILES_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, VOLATILES_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;

		CargoAPI cargo = playerFleet.getCargo();
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * fraction);

		if (hasNanoforgeInstalled(station)) {
			String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
			if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
		}
		if (hasBiofactoryInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.BIOFACTORY_EMBRYO, null), 1);
		}
		if (hasFusionLampInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null), 1);
		}
		if (hasCatalyticCoreInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.CATALYTIC_CORE, null), 1);
		}
	}

	public static boolean hasNanoforgeInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(NANOFORGE_MEMORY_KEY);
	}

	public static boolean hasNanoforgeInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.CORRUPTED_NANOFORGE, null)) >= 1
				|| cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.PRISTINE_NANOFORGE, null)) >= 1;
	}

	public static void installNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		CargoAPI cargo = playerFleet.getCargo();
		String itemId = null;
		if (cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.PRISTINE_NANOFORGE, null)) >= 1) {
			itemId = Items.PRISTINE_NANOFORGE;
		} else if (cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.CORRUPTED_NANOFORGE, null)) >= 1) {
			itemId = Items.CORRUPTED_NANOFORGE;
		}
		if (itemId == null) return;

		cargo.removeItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
		station.getMemoryWithoutUpdate().set(NANOFORGE_ITEM_KEY, itemId);
		station.getMemoryWithoutUpdate().set(NANOFORGE_MEMORY_KEY, true);
	}

	public static void uninstallNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasNanoforgeInstalled(station)) return;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_ITEM_KEY);
	}

	public static boolean hasBiofactoryInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(BIOFACTORY_MEMORY_KEY);
	}

	public static boolean hasBiofactoryInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.BIOFACTORY_EMBRYO, null)) >= 1;
	}

	public static void installBiofactory(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(Items.BIOFACTORY_EMBRYO, null), 1);
		station.getMemoryWithoutUpdate().set(BIOFACTORY_MEMORY_KEY, true);
	}

	public static void uninstallBiofactory(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasBiofactoryInstalled(station)) return;
		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.BIOFACTORY_EMBRYO, null), 1);
		station.getMemoryWithoutUpdate().unset(BIOFACTORY_MEMORY_KEY);
	}

	public static boolean hasFusionLampInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(FUSION_LAMP_MEMORY_KEY);
	}

	public static boolean hasFusionLampInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null)) >= 1;
	}

	public static void installFusionLamp(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null), 1);
		station.getMemoryWithoutUpdate().set(FUSION_LAMP_MEMORY_KEY, true);
	}

	public static void uninstallFusionLamp(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasFusionLampInstalled(station)) return;
		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null), 1);
		station.getMemoryWithoutUpdate().unset(FUSION_LAMP_MEMORY_KEY);
	}

	public static boolean hasCatalyticCoreInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(CATALYTIC_CORE_MEMORY_KEY);
	}

	public static boolean hasCatalyticCoreInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.CATALYTIC_CORE, null)) >= 1;
	}

	public static void installCatalyticCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(Items.CATALYTIC_CORE, null), 1);
		station.getMemoryWithoutUpdate().set(CATALYTIC_CORE_MEMORY_KEY, true);
	}

	public static void uninstallCatalyticCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasCatalyticCoreInstalled(station)) return;
		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.CATALYTIC_CORE, null), 1);
		station.getMemoryWithoutUpdate().unset(CATALYTIC_CORE_MEMORY_KEY);
	}

	public static float getOrePerMetal(SectorEntityToken station) {
		return hasFusionLampInstalled(station) ? ORE_PER_METAL_WITH_LAMP : ORE_PER_METAL;
	}

	public static float getRareOrePerTransplutonic(SectorEntityToken station) {
		return hasFusionLampInstalled(station) ? RARE_ORE_PER_TRANSPLUTONIC_WITH_LAMP : RARE_ORE_PER_TRANSPLUTONIC;
	}

	public static float getMetalsOutputPerBatch(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station) ? 1f + CATALYTIC_CORE_OUTPUT_BONUS : 1f;
	}

	public static float getTransplutonicsOutputPerBatch(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station) ? 1f + CATALYTIC_CORE_OUTPUT_BONUS : 1f;
	}

	public static class IndustrialHubResult {
		public float metals;
		public float transplutonics;
		public float heavyMachinery;
		public float supplies;
		public float drugs;
		public float organs;
		public float domesticGoods;
		public float luxuryGoods;
		public float heavyArmaments;
	}

	private static float convert(CargoAPI storage, String[] inputIds, float[] inputAmounts,
			String outputId, float outputAmount, float maxStorage) {
		float maxBatches = Float.MAX_VALUE;
		for (int i = 0; i < inputIds.length; i++) {
			float available = storage.getCommodityQuantity(inputIds[i]);
			float batchesForInput = available / inputAmounts[i];
			if (batchesForInput < maxBatches) maxBatches = batchesForInput;
		}

		float space = maxStorage - storage.getCommodityQuantity(outputId);
		if (space <= 0f) return 0f;
		float batchesForOutput = space / outputAmount;
		if (batchesForOutput < maxBatches) maxBatches = batchesForOutput;

		float batches = (float) Math.floor(maxBatches);
		if (batches <= 0f) return 0f;

		for (int i = 0; i < inputIds.length; i++) {
			storage.removeCommodity(inputIds[i], batches * inputAmounts[i]);
		}
		storage.addCommodity(outputId, batches * outputAmount);
		return batches * outputAmount;
	}

	public static IndustrialHubResult process(SectorEntityToken station) {
		IndustrialHubResult result = new IndustrialHubResult();
		if (!isBuilt(station)) return result;
		if (station.getMarket() == null) return result;

		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		result.metals = convert(storage, new String[] { Commodities.ORE }, new float[] { getOrePerMetal(station) },
				Commodities.METALS, getMetalsOutputPerBatch(station), MAX_STORED_RESOURCES);
		result.transplutonics = convert(storage, new String[] { Commodities.RARE_ORE }, new float[] { getRareOrePerTransplutonic(station) },
				Commodities.RARE_METALS, getTransplutonicsOutputPerBatch(station), MAX_STORED_RESOURCES);

		result.heavyMachinery = convert(storage,
				new String[] { Commodities.METALS, Commodities.RARE_METALS },
				new float[] { HEAVY_MACHINERY_METALS_COST, HEAVY_MACHINERY_TRANSPLUTONICS_COST },
				Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_BATCH_OUTPUT, MAX_STORED_RESOURCES);
		result.supplies = convert(storage,
				new String[] { Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES, Commodities.FOOD },
				new float[] { SUPPLIES_BATCH_ORGANICS_COST, SUPPLIES_BATCH_METALS_COST, SUPPLIES_BATCH_TRANSPLUTONICS_COST,
						SUPPLIES_BATCH_VOLATILES_COST, SUPPLIES_BATCH_FOOD_COST },
				Commodities.SUPPLIES, SUPPLIES_BATCH_OUTPUT, MAX_STORED_RESOURCES);

		// Biofactory runs before the Nanoforge so freshly-produced drugs are available the
		// same month for the Nanoforge's Luxury Goods line, which consumes drugs as an input.
		if (hasBiofactoryInstalled(station)) {
			result.drugs = convert(storage,
					new String[] { Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS },
					new float[] { DRUGS_BATCH_ORGANICS_COST, DRUGS_BATCH_METALS_COST, DRUGS_BATCH_TRANSPLUTONICS_COST },
					Commodities.DRUGS, DRUGS_BATCH_OUTPUT, MAX_STORED_RESOURCES);
			result.organs = convert(storage,
					new String[] { Commodities.ORGANICS }, new float[] { ORGANS_BATCH_ORGANICS_COST },
					Commodities.ORGANS, ORGANS_BATCH_OUTPUT, MAX_STORED_RESOURCES);
		}

		if (hasNanoforgeInstalled(station)) {
			result.domesticGoods = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS },
					new float[] { DOMESTIC_GOODS_BATCH_METALS_COST, DOMESTIC_GOODS_BATCH_TRANSPLUTONICS_COST, DOMESTIC_GOODS_BATCH_ORGANICS_COST },
					Commodities.DOMESTIC_GOODS, DOMESTIC_GOODS_BATCH_OUTPUT, MAX_STORED_RESOURCES);
			result.luxuryGoods = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS, Commodities.DRUGS },
					new float[] { LUXURY_GOODS_BATCH_METALS_COST, LUXURY_GOODS_BATCH_TRANSPLUTONICS_COST,
							LUXURY_GOODS_BATCH_ORGANICS_COST, LUXURY_GOODS_BATCH_DRUGS_COST },
					Commodities.LUXURY_GOODS, LUXURY_GOODS_BATCH_OUTPUT, MAX_STORED_RESOURCES);
			result.heavyArmaments = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES },
					new float[] { HEAVY_ARMAMENTS_BATCH_METALS_COST, HEAVY_ARMAMENTS_BATCH_TRANSPLUTONICS_COST,
							HEAVY_ARMAMENTS_BATCH_VOLATILES_COST },
					Commodities.HAND_WEAPONS, HEAVY_ARMAMENTS_BATCH_OUTPUT, MAX_STORED_RESOURCES);
		}

		return result;
	}
}
