package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import playerhq.abilities.ConstructPlayerHQAbility;

public class StationItemsModule {

	public static final String DRONE_REPLICATOR_MEMORY_KEY = "$playerhq_stationitem_dronereplicator";
	public static final String DRONE_REPLICATOR_DEFENSE_MARKET_KEY = "$playerhq_stationitem_dronereplicator_market";
	private static final String DRONE_REPLICATOR_DEFENSE_MOD_ID = "playerhq_drone_replicator_defense";

	public static final float DRONE_REPLICATOR_RECREATION_BONUS = 0.10f;
	public static final float DRONE_REPLICATOR_MINING_BONUS = 0.05f;
	public static final float DRONE_REPLICATOR_DEFENSE_BONUS = 0.5f;
	public static final int DRONE_REPLICATOR_HYDROPONICS_BONUS_ECON_UNITS = 1;

	public static boolean hasDroneReplicatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null)) >= 1;
	}

	public static void installDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, true);
		updateDroneReplicatorDefenseBonus(station);
	}

	public static void refundDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasDroneReplicatorInstalled(station)) return;

		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, false);
		clearDroneReplicatorDefenseBonus(station);
	}

	private static void clearDroneReplicatorDefenseBonus(SectorEntityToken station) {
		String marketId = station.getMemoryWithoutUpdate().getString(DRONE_REPLICATOR_DEFENSE_MARKET_KEY);
		if (marketId == null) return;

		MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);
		if (market != null) {
			market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(DRONE_REPLICATOR_DEFENSE_MOD_ID);
		}
		station.getMemoryWithoutUpdate().unset(DRONE_REPLICATOR_DEFENSE_MARKET_KEY);
	}

	/**
	 * Moves the ground defenses bonus to whatever colonized planet the station is currently
	 * orbiting (if any), removing it from wherever it was previously applied. Meant to be
	 * called on install and once every monthly tick, since the station's orbit can change
	 * between ticks.
	 */
	public static void updateDroneReplicatorDefenseBonus(SectorEntityToken station) {
		clearDroneReplicatorDefenseBonus(station);

		if (!hasDroneReplicatorInstalled(station)) return;

		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return;

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(
				DRONE_REPLICATOR_DEFENSE_MOD_ID, 1f + DRONE_REPLICATOR_DEFENSE_BONUS, "Combat Drone Replicator (Player HQ)");
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_DEFENSE_MARKET_KEY, market.getId());
	}
}
