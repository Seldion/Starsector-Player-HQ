package playerhq.modules;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class HydroponicsHubModule {

	public static final String MEMORY_KEY = "$playerhq_module_hydroponics";
	public static final String NANITES_MEMORY_KEY = "$playerhq_module_hydroponics_nanites";

	public static final float CREDIT_COST = 15000f;
	public static final float METALS_COST = 1000f;
	public static final float ORGANICS_COST = 2000f;
	public static final float FUSION_LAMP_COST = 1f;

	public static final int ECON_UNIT_VALUE = MiningHangarModule.ECON_UNIT_VALUE;

	public static final int FOOD_ECON_UNITS_BASE = 2;
	public static final int ORGANICS_ECON_UNITS_BASE = 1;
	public static final int NANITES_BONUS_ECON_UNITS = 1;

	public static final float MAX_STORED_RESOURCES = 10000f;

	public static final String IMAGE_PATH = "graphics/modules/hydroponics_hub.jpg";

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasFusionLampInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null)) >= FUSION_LAMP_COST;
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ORGANICS) >= ORGANICS_COST
				&& hasFusionLampInCargo(playerFleet.getCargo());
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.ORGANICS, ORGANICS_COST);
		playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null), FUSION_LAMP_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;

		CargoAPI cargo = playerFleet.getCargo();
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.ORGANICS, ORGANICS_COST * fraction);
		cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null), FUSION_LAMP_COST);

		if (hasNanitesInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SOIL_NANITES, null), 1);
		}
	}

	public static boolean hasNanitesInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(NANITES_MEMORY_KEY);
	}

	public static boolean hasNanitesInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.SOIL_NANITES, null)) >= 1;
	}

	public static void installNanites(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SOIL_NANITES, null), 1);
		station.getMemoryWithoutUpdate().set(NANITES_MEMORY_KEY, true);
	}

	public static void uninstallNanites(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasNanitesInstalled(station)) return;
		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SOIL_NANITES, null), 1);
		station.getMemoryWithoutUpdate().unset(NANITES_MEMORY_KEY);
	}

	public static int getFoodEconUnits(SectorEntityToken station) {
		int units = FOOD_ECON_UNITS_BASE;
		if (hasNanitesInstalled(station)) units += NANITES_BONUS_ECON_UNITS;
		if (StationItemsModule.hasDroneReplicatorInstalled(station)) units += StationItemsModule.DRONE_REPLICATOR_HYDROPONICS_BONUS_ECON_UNITS;
		return units;
	}

	public static int getOrganicsEconUnits(SectorEntityToken station) {
		int units = ORGANICS_ECON_UNITS_BASE;
		if (hasNanitesInstalled(station)) units += NANITES_BONUS_ECON_UNITS;
		if (StationItemsModule.hasDroneReplicatorInstalled(station)) units += StationItemsModule.DRONE_REPLICATOR_HYDROPONICS_BONUS_ECON_UNITS;
		return units;
	}

	public static class HydroponicsResult {
		public float food;
		public float organics;
		public float foodLostToCap;
		public float organicsLostToCap;
	}

	public static HydroponicsResult produce(SectorEntityToken station) {
		HydroponicsResult result = new HydroponicsResult();
		if (!isBuilt(station)) return result;
		if (station.getMarket() == null) return result;

		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		float attemptedFood = getFoodEconUnits(station) * ECON_UNIT_VALUE;
		float attemptedOrganics = getOrganicsEconUnits(station) * ECON_UNIT_VALUE;

		result.food = addCapped(storage, Commodities.FOOD, attemptedFood);
		result.organics = addCapped(storage, Commodities.ORGANICS, attemptedOrganics);

		result.foodLostToCap = attemptedFood - result.food;
		result.organicsLostToCap = attemptedOrganics - result.organics;

		return result;
	}

	private static float addCapped(CargoAPI storage, String commodityId, float amount) {
		if (amount <= 0f) return 0f;
		float space = MAX_STORED_RESOURCES - storage.getCommodityQuantity(commodityId);
		if (space <= 0f) return 0f;
		float toAdd = Math.min(amount, space);
		storage.addCommodity(commodityId, toAdd);
		return toAdd;
	}
}
