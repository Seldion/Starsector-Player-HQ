package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelAtEntity;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelRank;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class MilitaryWardModule {

	public static final String MEMORY_KEY = "$playerhq_module_militaryward";
	public static final String HOLOSUITE_MEMORY_KEY = "$playerhq_module_militaryward_holosuite";
	public static final String DRONE_REPLICATOR_MEMORY_KEY = "$playerhq_module_militaryward_dronereplicator";
	public static final String AICORE_MEMORY_KEY = "$playerhq_module_militaryward_aicore";

	public static final float CREDIT_COST = 75000f;
	public static final float METALS_COST = 4000f;
	public static final float TRANSPLUTONICS_COST = 2000f;

	public static final float MAX_PERSONNEL = 5000f;

	public static final float CREW_PRODUCTION_PER_MONTH = 250f;
	public static final float MARINE_PRODUCTION_PER_MONTH = 100f;

	public static final float CREW_STIPEND_PER_UNIT = 0.10f;
	public static final float MARINE_STIPEND_PER_UNIT = 5f;

	// Marine training: a fraction of the marine XP pool's "full" value (xp/num ratio) gained each
	// month. Real ground-raid combat can grant a large chunk of this in a single good raid, so even
	// the fastest configuration here (both special items plus the best AI core) is meant to stay
	// well below that -- these facilities season marines over months and years, not single fights.
	public static final float TRAINING_RATE_HOLODECK_ONLY = 0.03f;
	public static final float TRAINING_RATE_DRONE_REPLICATOR_ONLY = 0.03f;
	public static final float TRAINING_RATE_BOTH = 0.08f;

	public static final float AI_CORE_COST = 1f;

	public static final String[] IMAGE_PATHS = {
			"graphics/modules/military_ward.jpg",
			"graphics/modules/military_ward_2.jpg",
			"graphics/modules/military_ward_3.jpg",
			"graphics/modules/military_ward_4.jpg",
			"graphics/modules/military_ward_5.jpg",
			"graphics/modules/military_ward_6.jpg",
			"graphics/modules/military_ward_7.jpg",
			"graphics/modules/military_ward_8.jpg",
			"graphics/modules/military_ward_9.jpg",
			"graphics/modules/military_ward_10.jpg",
			"graphics/modules/military_ward_11.jpg",
			"graphics/modules/military_ward_12.jpg",
			"graphics/modules/military_ward_13.jpg",
	};

	public static String getRandomImagePath() {
		int index = (int) (Math.random() * IMAGE_PATHS.length);
		if (index >= IMAGE_PATHS.length) index = IMAGE_PATHS.length - 1;
		return IMAGE_PATHS[index];
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;

		CargoAPI cargo = playerFleet.getCargo();
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);

		if (hasHolosuiteInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
		}
		if (hasDroneReplicatorInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		}
		String aiCoreTier = getInstalledAICoreTier(station);
		if (aiCoreTier != null) {
			cargo.addCommodity(aiCoreTier, AI_CORE_COST);
		}
	}

	public static boolean hasHolosuiteInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasHolosuiteInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null)) >= 1;
	}

	public static void installHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
		station.getMemoryWithoutUpdate().set(HOLOSUITE_MEMORY_KEY, true);
	}

	public static void uninstallHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasHolosuiteInstalled(station)) return;
		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
		station.getMemoryWithoutUpdate().unset(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null)) >= 1;
	}

	public static void installDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, true);
	}

	public static void uninstallDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasDroneReplicatorInstalled(station)) return;
		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		station.getMemoryWithoutUpdate().unset(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static String getInstalledAICoreTier(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getString(AICORE_MEMORY_KEY);
	}

	public static boolean hasAICoreInstalled(SectorEntityToken station) {
		return getInstalledAICoreTier(station) != null;
	}

	public static boolean hasGammaCoreInCargo(CargoAPI cargo) {
		return cargo.getCommodityQuantity(Commodities.GAMMA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasBetaCoreInCargo(CargoAPI cargo) {
		return cargo.getCommodityQuantity(Commodities.BETA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasAlphaCoreInCargo(CargoAPI cargo) {
		return cargo.getCommodityQuantity(Commodities.ALPHA_CORE) >= AI_CORE_COST;
	}

	public static void installAICore(SectorEntityToken station, CampaignFleetAPI playerFleet, String coreCommodityId) {
		CargoAPI cargo = playerFleet.getCargo();
		if (cargo.getCommodityQuantity(coreCommodityId) < AI_CORE_COST) return;

		cargo.removeCommodity(coreCommodityId, AI_CORE_COST);
		station.getMemoryWithoutUpdate().set(AICORE_MEMORY_KEY, coreCommodityId);
	}

	/**
	 * Pulls the currently installed AI core back out and returns it in full to the player's fleet
	 * cargo, so a different tier can be installed in its place. No loss on the swap -- this isn't a
	 * dismantle-and-refund, just moving the same core back out.
	 */
	public static void uninstallAICore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return;

		playerFleet.getCargo().addCommodity(tier, AI_CORE_COST);
		station.getMemoryWithoutUpdate().unset(AICORE_MEMORY_KEY);
	}

	/**
	 * Beta/Gamma/Alpha cores each add their own extra multiple of the base training rate on top of
	 * it (Beta +1x, Gamma +2x, Alpha +3x), rather than just replacing it -- so installing one is
	 * always a straightforward improvement over having none.
	 */
	public static float getAICoreTrainingMultiplier(SectorEntityToken station) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return 1f;
		if (Commodities.BETA_CORE.equals(tier)) return 2f;
		if (Commodities.GAMMA_CORE.equals(tier)) return 3f;
		if (Commodities.ALPHA_CORE.equals(tier)) return 4f;
		return 1f;
	}

	private static float getBaseTrainingRatio(SectorEntityToken station) {
		boolean holosuite = hasHolosuiteInstalled(station);
		boolean drone = hasDroneReplicatorInstalled(station);
		if (holosuite && drone) return TRAINING_RATE_BOTH;
		if (holosuite) return TRAINING_RATE_HOLODECK_ONLY;
		if (drone) return TRAINING_RATE_DRONE_REPLICATOR_ONLY;
		return 0f;
	}

	public static float getTrainingRatioPerMonth(SectorEntityToken station) {
		return getBaseTrainingRatio(station) * getAICoreTrainingMultiplier(station);
	}

	private static SubmarketAPI getStorageSubmarket(SectorEntityToken station) {
		if (station.getMarket() == null) return null;
		return station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE);
	}

	private static void addCrewCapped(CargoAPI storage, float amount) {
		int current = storage.getCrew();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addCrew(toAdd);
	}

	private static void addMarinesCapped(CargoAPI storage, float amount) {
		int current = storage.getMarines();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addMarines(toAdd);
	}

	/**
	 * The station has no life support set up for people outside the Military Paradigm and Recreational
	 * Hub, so Crew and Marines held in storage are hard-capped at {@link #MAX_PERSONNEL} each --
	 * whether they got there from this module's own production or the player manually depositing
	 * them. Run this regularly (not just once a month) so a manual over-deposit gets corrected
	 * quickly rather than sitting over the cap for a long stretch.
	 */
	public static void enforceCap(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;
		CargoAPI storage = storageSubmarket.getCargo();

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();

		int crew = storage.getCrew();
		if (crew > (int) MAX_PERSONNEL) {
			int excess = crew - (int) MAX_PERSONNEL;
			storage.removeCrew(excess);
			if (playerFleet != null) playerFleet.getCargo().addCrew(excess);
		}

		int marines = storage.getMarines();
		if (marines > (int) MAX_PERSONNEL) {
			int excess = marines - (int) MAX_PERSONNEL;
			storage.removeMarines(excess);
			if (playerFleet != null) playerFleet.getCargo().addMarines(excess);
		}
	}

	private static void applyTraining(SectorEntityToken station, SubmarketAPI storageSubmarket) {
		float ratio = getTrainingRatioPerMonth(station);
		if (ratio <= 0f) return;

		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return;

		// Keep the tracked bucket's headcount in sync with the real, current storage count before
		// adding XP -- it's only otherwise updated by the game when the player opens/transacts with
		// this submarket directly, and could be stale by the time our monthly tick runs.
		at.data.numMayHaveChanged(marines, true);
		at.data.addXP(ratio * marines);
	}

	public static void accumulateMonthly(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;
		CargoAPI storage = storageSubmarket.getCargo();

		addCrewCapped(storage, CREW_PRODUCTION_PER_MONTH);
		addMarinesCapped(storage, MARINE_PRODUCTION_PER_MONTH);

		float stipend = storage.getCrew() * CREW_STIPEND_PER_UNIT + storage.getMarines() * MARINE_STIPEND_PER_UNIT;
		if (stipend > 0f) {
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (playerFleet != null) playerFleet.getCargo().getCredits().subtract(stipend);
		}

		applyTraining(station, storageSubmarket);
	}

	/**
	 * @return the current training rank of marines stored at this station (Regular/Experienced/
	 * Veteran/Elite), or null if no marines are currently stored there.
	 */
	public static PersonnelRank getStoredMarineRank(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return null;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return null;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return null;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getRank();
	}

	public static float getStoredMarineTrainingPercent(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return 0f;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return 0f;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return 0f;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getXPLevel() * 100f;
	}
}
