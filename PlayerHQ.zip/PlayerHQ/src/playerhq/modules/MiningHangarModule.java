package playerhq.modules;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class MiningHangarModule {

	public static final String MEMORY_KEY = "$playerhq_module_mining";
	public static final String BORE_MEMORY_KEY = "$playerhq_module_mining_bore";

	public static final float METALS_COST = 1000f;
	public static final float TRANSPLUTONICS_COST = 400f;
	public static final float VOLATILES_COST = 200f;

	public static final float EFFICIENCY_BASE = 0.15f;
	public static final float EFFICIENCY_WITH_BORE = 0.25f;

	public static final float MAX_STORED_RESOURCES = 10000f;

	public static final int ECON_UNIT_VALUE = 400;

	public static final String IMAGE_PATH = "graphics/modules/mining_hangar.jpg";

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasBoreInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(BORE_MEMORY_KEY);
	}

	public static boolean hasBoreInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.MANTLE_BORE, null)) >= 1;
	}

	public static void installBore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(Items.MANTLE_BORE, null), 1);
		station.getMemoryWithoutUpdate().set(BORE_MEMORY_KEY, true);
	}

	public static void uninstallBore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasBoreInstalled(station)) return;
		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.MANTLE_BORE, null), 1);
		station.getMemoryWithoutUpdate().unset(BORE_MEMORY_KEY);
	}

	public static float getEfficiency(SectorEntityToken station) {
		return hasBoreInstalled(station) ? EFFICIENCY_WITH_BORE : EFFICIENCY_BASE;
	}

	/** Station-item efficiency bonus, as a flat percentage-point addition (e.g. 0.05 = +5 points). */
	public static float getStationItemBonus(SectorEntityToken station) {
		float bonus = 0f;
		if (StationItemsModule.hasDroneReplicatorInstalled(station)) bonus += StationItemsModule.DRONE_REPLICATOR_MINING_BONUS;
		return bonus;
	}

	/**
	 * Base/bore efficiency combined with any station-item bonuses -- the actual effective collection
	 * rate. Bonuses stack additively onto the percentage itself (25% base + 5% bonus = 30%), not as a
	 * multiplier of it (which would give 25% * 1.05 = 26.25%).
	 */
	public static float getCombinedEfficiency(SectorEntityToken station) {
		return getEfficiency(station) + getStationItemBonus(station);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= VOLATILES_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, VOLATILES_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;

		CargoAPI cargo = playerFleet.getCargo();
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * fraction);

		if (hasBoreInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.MANTLE_BORE, null), 1);
		}
	}

	private static final String[] ORE_TIER_NAMES = { "none", "sparse", "moderate", "abundant", "rich", "ultrarich" };
	private static final String[] FOUR_TIER_NAMES = { "none", "trace/low", "diffuse/common", "abundant", "plentiful" };

	private static int tierIndexOre(MarketAPI market, String sparse, String moderate, String abundant, String rich, String ultrarich) {
		if (market.hasCondition(ultrarich)) return 5;
		if (market.hasCondition(rich)) return 4;
		if (market.hasCondition(abundant)) return 3;
		if (market.hasCondition(moderate)) return 2;
		if (market.hasCondition(sparse)) return 1;
		return 0;
	}

	private static int tierIndexFour(MarketAPI market, String lowest, String low, String high, String highest) {
		if (market.hasCondition(highest)) return 4;
		if (market.hasCondition(high)) return 3;
		if (market.hasCondition(low)) return 2;
		if (market.hasCondition(lowest)) return 1;
		return 0;
	}

	// Modifier values, matching the deposit tiers used by the vanilla Mining industry:
	// ore/rare ore tiers 1-5 (sparse..ultrarich) => -1, 0, +1, +2, +3
	// organics/volatiles tiers 1-4 (trace..plentiful) => -1, 0, +1, +2
	private static final int[] ORE_TIER_MODIFIERS = { 0, -1, 0, 1, 2, 3 };
	private static final int[] FOUR_TIER_MODIFIERS = { 0, -1, 0, 1, 2 };

	private static class EconTotals {
		int oreUnits;
		int rareOreUnits;
		int volatilesUnits;
		int organicsUnits;
		final List<String> contributingPlanets = new ArrayList<String>();
	}

	private static EconTotals computeEconTotals(StarSystemAPI system) {
		EconTotals totals = new EconTotals();
		if (system == null) return totals;

		int oreModSum = 0;
		boolean oreHasDeposit = false;
		int rareOreModSum = 0;
		boolean rareOreHasDeposit = false;
		int volatilesModSum = 0;
		boolean volatilesHasDeposit = false;
		int organicsModSum = 0;
		boolean organicsHasDeposit = false;

		for (PlanetAPI planet : system.getPlanets()) {
			if (planet.isStar()) continue;
			MarketAPI market = planet.getMarket();
			if (market == null) continue;

			boolean contributed = false;

			int oreTier = tierIndexOre(market, Conditions.ORE_SPARSE, Conditions.ORE_MODERATE,
					Conditions.ORE_ABUNDANT, Conditions.ORE_RICH, Conditions.ORE_ULTRARICH);
			if (oreTier > 0) {
				oreModSum += ORE_TIER_MODIFIERS[oreTier];
				oreHasDeposit = true;
				contributed = true;
			}

			int rareOreTier = tierIndexOre(market, Conditions.RARE_ORE_SPARSE, Conditions.RARE_ORE_MODERATE,
					Conditions.RARE_ORE_ABUNDANT, Conditions.RARE_ORE_RICH, Conditions.RARE_ORE_ULTRARICH);
			if (rareOreTier > 0) {
				rareOreModSum += ORE_TIER_MODIFIERS[rareOreTier];
				rareOreHasDeposit = true;
				contributed = true;
			}

			int volatilesTier = tierIndexFour(market, Conditions.VOLATILES_TRACE, Conditions.VOLATILES_DIFFUSE,
					Conditions.VOLATILES_ABUNDANT, Conditions.VOLATILES_PLENTIFUL);
			if (volatilesTier > 0) {
				volatilesModSum += FOUR_TIER_MODIFIERS[volatilesTier];
				volatilesHasDeposit = true;
				contributed = true;
			}

			int organicsTier = tierIndexFour(market, Conditions.ORGANICS_TRACE, Conditions.ORGANICS_COMMON,
					Conditions.ORGANICS_ABUNDANT, Conditions.ORGANICS_PLENTIFUL);
			if (organicsTier > 0) {
				organicsModSum += FOUR_TIER_MODIFIERS[organicsTier];
				organicsHasDeposit = true;
				contributed = true;
			}

			if (contributed) {
				totals.contributingPlanets.add(planet.getName());
			}
		}

		totals.oreUnits = oreHasDeposit ? Math.max(1, oreModSum) : 0;
		totals.rareOreUnits = rareOreHasDeposit ? Math.max(1, rareOreModSum) : 0;
		totals.volatilesUnits = volatilesHasDeposit ? Math.max(1, volatilesModSum) : 0;
		totals.organicsUnits = organicsHasDeposit ? Math.max(1, organicsModSum) : 0;

		return totals;
	}

	public static class MiningResult {
		public float ore;
		public float rareOre;
		public float volatiles;
		public float organics;
		public float oreLostToCap;
		public float rareOreLostToCap;
		public float volatilesLostToCap;
		public float organicsLostToCap;
		public final List<String> contributingPlanets = new ArrayList<String>();
	}

	public static MiningResult collectResources(SectorEntityToken station) {
		MiningResult result = new MiningResult();

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return result;

		EconTotals totals = computeEconTotals(system);
		result.contributingPlanets.addAll(totals.contributingPlanets);

		if (station.getMarket() == null) return result;
		float efficiency = getCombinedEfficiency(station);
		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		float attemptedOre = totals.oreUnits * ECON_UNIT_VALUE * efficiency;
		float attemptedRareOre = totals.rareOreUnits * ECON_UNIT_VALUE * efficiency;
		float attemptedVolatiles = totals.volatilesUnits * ECON_UNIT_VALUE * efficiency;
		float attemptedOrganics = totals.organicsUnits * ECON_UNIT_VALUE * efficiency;

		result.ore = addCapped(storage, Commodities.ORE, attemptedOre);
		result.rareOre = addCapped(storage, Commodities.RARE_ORE, attemptedRareOre);
		result.volatiles = addCapped(storage, Commodities.VOLATILES, attemptedVolatiles);
		result.organics = addCapped(storage, Commodities.ORGANICS, attemptedOrganics);

		result.oreLostToCap = attemptedOre - result.ore;
		result.rareOreLostToCap = attemptedRareOre - result.rareOre;
		result.volatilesLostToCap = attemptedVolatiles - result.volatiles;
		result.organicsLostToCap = attemptedOrganics - result.organics;

		return result;
	}

	private static float addCapped(CargoAPI storage, String commodityId, float amount) {
		if (amount <= 0f) return 0f;
		float space = MAX_STORED_RESOURCES - storage.getCommodityQuantity(commodityId);
		if (space <= 0f) return 0f;
		float toAdd = Math.min(amount, space);
		storage.addCommodity(commodityId, toAdd);
		return toAdd;
	}

	/**
	 * A single-line summary of what the Materials Acquisition Hub is expected to pull in across the whole system
	 * each month, given its current efficiency and station-item bonuses.
	 */
	public static List<String> getExpectedMonthlyHarvest(SectorEntityToken station) {
		StarSystemAPI system = station.getStarSystem();
		return formatExpectedHarvest(system, getCombinedEfficiency(station));
	}

	/**
	 * The same expected-harvest summary, but usable before a station exists yet -- for previewing
	 * what a Materials Acquisition Hub would pull in here, at base efficiency with no bonuses.
	 */
	public static List<String> getExpectedMonthlyHarvestForSystem(StarSystemAPI system) {
		return formatExpectedHarvest(system, EFFICIENCY_BASE);
	}

	private static List<String> formatExpectedHarvest(StarSystemAPI system, float efficiency) {
		List<String> lines = new ArrayList<String>();
		if (system == null) return lines;

		EconTotals totals = computeEconTotals(system);
		float ore = totals.oreUnits * ECON_UNIT_VALUE * efficiency;
		float rareOre = totals.rareOreUnits * ECON_UNIT_VALUE * efficiency;
		float volatiles = totals.volatilesUnits * ECON_UNIT_VALUE * efficiency;
		float organics = totals.organicsUnits * ECON_UNIT_VALUE * efficiency;

		if (ore <= 0f && rareOre <= 0f && volatiles <= 0f && organics <= 0f) {
			lines.add("No mineable resource deposits detected in this system.");
			return lines;
		}

		lines.add(String.format("Expected monthly harvest: ~%s ore, ~%s rare ore, ~%s volatiles, ~%s organics.",
				(int) ore, (int) rareOre, (int) volatiles, (int) organics));
		return lines;
	}

	public static List<String> getSystemBreakdown(SectorEntityToken station) {
		List<String> lines = new ArrayList<String>();

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return lines;

		for (PlanetAPI planet : system.getPlanets()) {
			if (planet.isStar()) continue;
			MarketAPI market = planet.getMarket();
			if (market == null) {
				lines.add(planet.getName() + ": no market data available");
				continue;
			}

			String ore = ORE_TIER_NAMES[tierIndexOre(market, Conditions.ORE_SPARSE, Conditions.ORE_MODERATE,
					Conditions.ORE_ABUNDANT, Conditions.ORE_RICH, Conditions.ORE_ULTRARICH)];
			String rareOre = ORE_TIER_NAMES[tierIndexOre(market, Conditions.RARE_ORE_SPARSE, Conditions.RARE_ORE_MODERATE,
					Conditions.RARE_ORE_ABUNDANT, Conditions.RARE_ORE_RICH, Conditions.RARE_ORE_ULTRARICH)];
			String volatiles = FOUR_TIER_NAMES[tierIndexFour(market, Conditions.VOLATILES_TRACE, Conditions.VOLATILES_DIFFUSE,
					Conditions.VOLATILES_ABUNDANT, Conditions.VOLATILES_PLENTIFUL)];
			String organics = FOUR_TIER_NAMES[tierIndexFour(market, Conditions.ORGANICS_TRACE, Conditions.ORGANICS_COMMON,
					Conditions.ORGANICS_ABUNDANT, Conditions.ORGANICS_PLENTIFUL)];

			lines.add(planet.getName() + " - ore: " + ore + ", rare ore: " + rareOre
					+ ", volatiles: " + volatiles + ", organics: " + organics);
		}

		EconTotals totals = computeEconTotals(system);
		float efficiency = getCombinedEfficiency(station);

		lines.add("System totals - ore: " + totals.oreUnits + " econ-units (" + (totals.oreUnits * ECON_UNIT_VALUE)
				+ " raw, " + (int) (totals.oreUnits * ECON_UNIT_VALUE * efficiency) + " collected/month)");
		lines.add("System totals - rare ore: " + totals.rareOreUnits + " econ-units (" + (totals.rareOreUnits * ECON_UNIT_VALUE)
				+ " raw, " + (int) (totals.rareOreUnits * ECON_UNIT_VALUE * efficiency) + " collected/month)");
		lines.add("System totals - volatiles: " + totals.volatilesUnits + " econ-units (" + (totals.volatilesUnits * ECON_UNIT_VALUE)
				+ " raw, " + (int) (totals.volatilesUnits * ECON_UNIT_VALUE * efficiency) + " collected/month)");
		lines.add("System totals - organics: " + totals.organicsUnits + " econ-units (" + (totals.organicsUnits * ECON_UNIT_VALUE)
				+ " raw, " + (int) (totals.organicsUnits * ECON_UNIT_VALUE * efficiency) + " collected/month)");

		return lines;
	}
}
