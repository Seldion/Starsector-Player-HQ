package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.InteractionDialogImageVisual;
import com.fs.starfarer.api.campaign.BaseCustomProductionPickerDelegateImpl;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CoreInteractionListener;
import com.fs.starfarer.api.campaign.CoreUITabId;
import com.fs.starfarer.api.campaign.FactionProductionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.VisualPanelAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.loading.Description;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;
import playerhq.Ids;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;
import playerhq.modules.StationItemsModule;
import playerhq.util.PlayerHQUtils;

import org.lwjgl.input.Keyboard;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PlayerHQStationCMD extends BaseCommandPlugin {

	private static final String OPT_INVENTORY = "playerhq_inventory";
	private static final String OPT_SHIPS = "playerhq_ships";
	private static final String OPT_MODULES = "playerhq_modules";
	private static final String OPT_STATION_ITEMS = "playerhq_station_items";
	private static final String OPT_DISMANTLE = "playerhq_dismantle";
	private static final String OPT_CONFIRM_DISMANTLE = "playerhq_confirmDismantle";
	private static final String OPT_CANCEL_DISMANTLE = "playerhq_cancelDismantle";
	private static final String OPT_LEAVE = "playerhq_leave";

	private static final String OPT_MODULES_BACK = "playerhq_modules_back";
	private static final String OPT_MINING_VIEW = "playerhq_module_mining_view";
	private static final String OPT_MINING_BUILD = "playerhq_module_mining_build";
	private static final String OPT_MINING_INSTALL_BORE = "playerhq_module_mining_install_bore";
	private static final String OPT_MINING_UNINSTALL_BORE = "playerhq_module_mining_uninstall_bore";
	private static final String OPT_RECREATION_VIEW = "playerhq_module_recreation_view";
	private static final String OPT_RECREATION_BUILD = "playerhq_module_recreation_build";
	private static final String OPT_RECREATION_INSTALL_HOLOSUITE = "playerhq_module_recreation_install_holosuite";
	private static final String OPT_RECREATION_UNINSTALL_HOLOSUITE = "playerhq_module_recreation_uninstall_holosuite";
	private static final String OPT_RECREATION_INSTALL_FUSIONLAMP = "playerhq_module_recreation_install_fusionlamp";
	private static final String OPT_RECREATION_UNINSTALL_FUSIONLAMP = "playerhq_module_recreation_uninstall_fusionlamp";
	private static final String OPT_INDUSTRIAL_VIEW = "playerhq_module_industrial_view";
	private static final String OPT_INDUSTRIAL_BUILD = "playerhq_module_industrial_build";
	private static final String OPT_INDUSTRIAL_INSTALL_NANOFORGE = "playerhq_module_industrial_install_nanoforge";
	private static final String OPT_INDUSTRIAL_UNINSTALL_NANOFORGE = "playerhq_module_industrial_uninstall_nanoforge";
	private static final String OPT_INDUSTRIAL_INSTALL_BIOFACTORY = "playerhq_module_industrial_install_biofactory";
	private static final String OPT_INDUSTRIAL_UNINSTALL_BIOFACTORY = "playerhq_module_industrial_uninstall_biofactory";
	private static final String OPT_INDUSTRIAL_INSTALL_FUSIONLAMP = "playerhq_module_industrial_install_fusionlamp";
	private static final String OPT_INDUSTRIAL_UNINSTALL_FUSIONLAMP = "playerhq_module_industrial_uninstall_fusionlamp";
	private static final String OPT_INDUSTRIAL_INSTALL_CATALYTICCORE = "playerhq_module_industrial_install_catalyticcore";
	private static final String OPT_INDUSTRIAL_UNINSTALL_CATALYTICCORE = "playerhq_module_industrial_uninstall_catalyticcore";
	private static final String OPT_HYDROPONICS_VIEW = "playerhq_module_hydroponics_view";
	private static final String OPT_HYDROPONICS_BUILD = "playerhq_module_hydroponics_build";
	private static final String OPT_HYDROPONICS_INSTALL_NANITES = "playerhq_module_hydroponics_install_nanites";
	private static final String OPT_HYDROPONICS_UNINSTALL_NANITES = "playerhq_module_hydroponics_uninstall_nanites";

	private static final String OPT_ASSEMBLY_VIEW = "playerhq_module_assembly_view";
	private static final String OPT_ASSEMBLY_BUILD = "playerhq_module_assembly_build";
	private static final String OPT_ASSEMBLY_INSTALL_NANOFORGE = "playerhq_module_assembly_install_nanoforge";
	private static final String OPT_ASSEMBLY_UNINSTALL_NANOFORGE = "playerhq_module_assembly_uninstall_nanoforge";
	private static final String OPT_ASSEMBLY_INSTALL_GENERATION_BOOST = "playerhq_module_assembly_install_generation_boost";
	private static final String OPT_ASSEMBLY_UNINSTALL_GENERATION_BOOST = "playerhq_module_assembly_uninstall_generation_boost";

	private static final String OPT_MILITARYWARD_VIEW = "playerhq_module_militaryward_view";
	private static final String OPT_MILITARYWARD_BUILD = "playerhq_module_militaryward_build";
	private static final String OPT_MILITARYWARD_INSTALL_HOLOSUITE = "playerhq_module_militaryward_install_holosuite";
	private static final String OPT_MILITARYWARD_UNINSTALL_HOLOSUITE = "playerhq_module_militaryward_uninstall_holosuite";
	private static final String OPT_MILITARYWARD_INSTALL_DRONE_REPLICATOR = "playerhq_module_militaryward_install_dronereplicator";
	private static final String OPT_MILITARYWARD_UNINSTALL_DRONE_REPLICATOR = "playerhq_module_militaryward_uninstall_dronereplicator";
	private static final String OPT_MILITARYWARD_INSTALL_AICORE = "playerhq_module_militaryward_install_aicore";
	private static final String OPT_MILITARYWARD_UNINSTALL_AICORE = "playerhq_module_militaryward_uninstall_aicore";
	private static final String OPT_MILITARYWARD_AICORE_BACK = "playerhq_module_militaryward_aicore_back";
	private static final String OPT_MILITARYWARD_INSTALL_GAMMA_CORE = "playerhq_module_militaryward_install_gammacore";
	private static final String OPT_MILITARYWARD_INSTALL_BETA_CORE = "playerhq_module_militaryward_install_betacore";
	private static final String OPT_MILITARYWARD_INSTALL_ALPHA_CORE = "playerhq_module_militaryward_install_alphacore";

	private static final String OPT_MODULE_DETAIL_BACK = "playerhq_module_detail_back";

	private static final String OPT_ORDER_CUSTOM_PRODUCTION = "playerhq_order_custom_production";

	private static final String OPT_STATIONITEM_INSTALL_DRONE_REPLICATOR = "playerhq_stationitem_install_dronereplicator";
	private static final String OPT_STATIONITEM_UNINSTALL_DRONE_REPLICATOR = "playerhq_stationitem_uninstall_dronereplicator";
	private static final String OPT_STATION_ITEMS_BACK = "playerhq_station_items_back";

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;
	private OptionPanelAPI options;
	private VisualPanelAPI visual;
	private SectorEntityToken station;
	private CampaignFleetAPI playerFleet;

	@Override
	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.text = dialog.getTextPanel();
		this.options = dialog.getOptionPanel();
		this.visual = dialog.getVisualPanel();
		this.station = dialog.getInteractionTarget();
		this.playerFleet = Global.getSector().getPlayerFleet();

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

		if (command.equals("init")) {
			updateColonyInfoDescription();
			showMainMenu();
		} else if (command.equals("inventory")) {
			showInventory();
		} else if (command.equals("ships")) {
			showShips();
		} else if (command.equals("modules")) {
			showModulesMenu();
		} else if (command.equals("stationItemsView")) {
			showStationItemsMenu();
		} else if (command.equals("stationItemsBack")) {
			showMainMenu();
		} else if (command.equals("stationItemsInstallDroneReplicator")) {
			doInstallDroneReplicator();
		} else if (command.equals("stationItemsUninstallDroneReplicator")) {
			doUninstallDroneReplicator();
		} else if (command.equals("miningView")) {
			showMiningHangarDetail();
		} else if (command.equals("miningBuild")) {
			doBuildMiningHangar();
		} else if (command.equals("miningInstallBore")) {
			doInstallMantleBore();
		} else if (command.equals("miningUninstallBore")) {
			doUninstallMantleBore();
		} else if (command.equals("recreationView")) {
			showRecreationalHubDetail();
		} else if (command.equals("recreationBuild")) {
			doBuildRecreationalHub();
		} else if (command.equals("recreationInstallHolosuite")) {
			doInstallHolosuite();
		} else if (command.equals("recreationUninstallHolosuite")) {
			doUninstallHolosuite();
		} else if (command.equals("recreationInstallFusionLamp")) {
			doInstallFusionLamp();
		} else if (command.equals("recreationUninstallFusionLamp")) {
			doUninstallFusionLamp();
		} else if (command.equals("industrialView")) {
			showIndustrialHubDetail();
		} else if (command.equals("industrialBuild")) {
			doBuildIndustrialHub();
		} else if (command.equals("industrialInstallNanoforge")) {
			doInstallNanoforge();
		} else if (command.equals("industrialUninstallNanoforge")) {
			doUninstallNanoforge();
		} else if (command.equals("industrialInstallBiofactory")) {
			doInstallBiofactory();
		} else if (command.equals("industrialUninstallBiofactory")) {
			doUninstallBiofactory();
		} else if (command.equals("industrialInstallFusionLamp")) {
			doInstallIndustrialFusionLamp();
		} else if (command.equals("industrialUninstallFusionLamp")) {
			doUninstallIndustrialFusionLamp();
		} else if (command.equals("industrialInstallCatalyticCore")) {
			doInstallCatalyticCore();
		} else if (command.equals("industrialUninstallCatalyticCore")) {
			doUninstallCatalyticCore();
		} else if (command.equals("hydroponicsView")) {
			showHydroponicsHubDetail();
		} else if (command.equals("hydroponicsBuild")) {
			doBuildHydroponicsHub();
		} else if (command.equals("hydroponicsInstallNanites")) {
			doInstallSoilNanites();
		} else if (command.equals("hydroponicsUninstallNanites")) {
			doUninstallSoilNanites();
		} else if (command.equals("assemblyView")) {
			showAssemblyBayDetail();
		} else if (command.equals("assemblyBuild")) {
			doBuildAssemblyBay();
		} else if (command.equals("assemblyInstallNanoforge")) {
			doInstallAssemblyNanoforge();
		} else if (command.equals("assemblyUninstallNanoforge")) {
			doUninstallAssemblyNanoforge();
		} else if (command.equals("assemblyInstallGenerationBoost")) {
			doInstallAssemblyGenerationBoost();
		} else if (command.equals("assemblyUninstallGenerationBoost")) {
			doUninstallAssemblyGenerationBoost();
		} else if (command.equals("militaryWardView")) {
			showMilitaryWardDetail();
		} else if (command.equals("militaryWardBuild")) {
			doBuildMilitaryWard();
		} else if (command.equals("militaryWardInstallHolosuite")) {
			doInstallMilitaryWardHolosuite();
		} else if (command.equals("militaryWardUninstallHolosuite")) {
			doUninstallMilitaryWardHolosuite();
		} else if (command.equals("militaryWardInstallDroneReplicator")) {
			doInstallMilitaryWardDroneReplicator();
		} else if (command.equals("militaryWardUninstallDroneReplicator")) {
			doUninstallMilitaryWardDroneReplicator();
		} else if (command.equals("militaryWardInstallAICoreMenu")) {
			showMilitaryWardAICoreMenu();
		} else if (command.equals("militaryWardUninstallAICore")) {
			doUninstallMilitaryWardAICore();
		} else if (command.equals("militaryWardAICoreBack")) {
			showMilitaryWardDetail();
		} else if (command.equals("militaryWardInstallGammaCore")) {
			doInstallMilitaryWardAICore(Commodities.GAMMA_CORE);
		} else if (command.equals("militaryWardInstallBetaCore")) {
			doInstallMilitaryWardAICore(Commodities.BETA_CORE);
		} else if (command.equals("militaryWardInstallAlphaCore")) {
			doInstallMilitaryWardAICore(Commodities.ALPHA_CORE);
		} else if (command.equals("orderCustomProduction")) {
			doOrderCustomProduction();
		} else if (command.equals("confirmDismantle")) {
			showConfirmDismantle();
		} else if (command.equals("doDismantle")) {
			doDismantle();
		}

		return true;
	}

	private String getSkinLabel() {
		return ConstructPlayerHQAbility.isExistingStationLowTech(station) ? "Low-Tech" : "High-Tech";
	}

	/**
	 * Refreshes the flavor text shown on the vanilla "Colony Info [M]" screen so it reflects what
	 * the station is currently orbiting, since {@link com.fs.starfarer.api.util.Misc#setAbandonedStationMarket}
	 * only ever sets that text once, generically, at construction time.
	 */
	private void updateColonyInfoDescription() {
		Description desc = Global.getSettings().getDescription(station.getCustomDescriptionId(), Description.Type.CUSTOM);
		if (desc == null) return;

		desc.setText1(getColonyInfoText());
	}

	private String getColonyInfoText() {
		MarketAPI colonizedMarket = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (colonizedMarket != null) {
			return "The station sits in orbit above " + colonizedMarket.getName()
					+ ", its drones busy with assisting the colony and resource collection.";
		}

		SectorEntityToken focus = station.getOrbitFocus();
		if (focus instanceof PlanetAPI) {
			return "The station sits in orbit, " + focus.getName()
					+ " silent below as the station's drones buzz around with resource collection.";
		}

		if (focus != null) {
			return "The station drifts among the space rocks as drones buzz busily by, small asteroids "
					+ "plinking off the station's armor from time to time.";
		}

		return "The station drifts alone in open space, its drones running quiet maintenance loops.";
	}

	private void restoreDefaultVisual() {
		InteractionDialogImageVisual defaultVisual = station.getCustomInteractionDialogImageVisual();
		if (defaultVisual != null) {
			visual.showImageVisual(defaultVisual);
		}
	}

	private void showMainMenu() {
		restoreDefaultVisual();

		text.addPara("The Player HQ station (" + getSkinLabel() + ") floats silently, its automated "
				+ "systems standing ready to receive you.");

		addStorageSummary();

		options.clearOptions();
		options.addOption("Access station inventory", OPT_INVENTORY,
				"Transfer cargo between your fleet and the station's storage.");
		options.addOption("Manage Fleet", OPT_SHIPS,
				"Store or retrieve ships using the station's hangar space. Press R once there to refit.");
		options.addOption("Modules", OPT_MODULES,
				"Build modules that expand what this station can do.");

		boolean assemblyBuilt = AssemblyBayModule.isBuilt(station);
		options.addOption("Order Custom Production", OPT_ORDER_CUSTOM_PRODUCTION, assemblyBuilt
				? "Search the Strategic Assembly's catalog of known ship and weapon designs and order one directly."
				: "Requires the Strategic Assembly module. Build one under Modules.");
		options.setEnabled(OPT_ORDER_CUSTOM_PRODUCTION, assemblyBuilt);

		options.addOption("Station Upgrades", OPT_STATION_ITEMS,
				"Install special items on the station itself, giving bonuses across its modules.");
		options.addOption("Dismantle station", OPT_DISMANTLE,
				"Refunds half of the resources spent to build it and any of its modules, plus the AI core "
				+ "and any special items installed. Credits spent are not refunded. The station is "
				+ "destroyed and a new one can then be constructed.");
		options.addOption("Leave", OPT_LEAVE);

		options.setShortcut(OPT_INVENTORY, Keyboard.KEY_I, false, false, false, true);
		options.setShortcut(OPT_SHIPS, Keyboard.KEY_F, false, false, false, true);
		options.setShortcut(OPT_MODULES, Keyboard.KEY_M, false, false, false, true);
		if (assemblyBuilt) {
			options.setShortcut(OPT_ORDER_CUSTOM_PRODUCTION, Keyboard.KEY_O, false, false, false, true);
		}
		options.setShortcut(OPT_STATION_ITEMS, Keyboard.KEY_Q, false, false, false, true);
		options.setShortcut(OPT_DISMANTLE, Keyboard.KEY_D, false, false, false, true);
		options.setShortcut(OPT_LEAVE, Keyboard.KEY_L, false, false, false, true);

		dialog.setPromptText("Player HQ");
		dialog.setOptionOnEscape("Leave", OPT_LEAVE);
	}

	/**
	 * A quick, per-line rundown of what the station has in storage -- raw resources and produced
	 * goods, plus Crew and Marines -- shown on the main splash screen. Ships and weapons are left
	 * out since those are managed through Manage Fleet / the Strategic Assembly instead. Only non-zero
	 * quantities are listed, to keep an early-game station's screen from being cluttered with zeros.
	 */
	private void addStorageSummary() {
		if (station.getMarket() == null) return;
		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		String[][] commodities = {
				{ Commodities.ORE, "Ore" },
				{ Commodities.RARE_ORE, "Rare Ore" },
				{ Commodities.VOLATILES, "Volatiles" },
				{ Commodities.ORGANICS, "Organics" },
				{ Commodities.METALS, "Metals" },
				{ Commodities.RARE_METALS, "Transplutonics" },
				{ Commodities.HEAVY_MACHINERY, "Heavy Machinery" },
				{ Commodities.SUPPLIES, "Supplies" },
				{ Commodities.DOMESTIC_GOODS, "Domestic Goods" },
				{ Commodities.LUXURY_GOODS, "Luxury Goods" },
				{ Commodities.HAND_WEAPONS, "Heavy Armaments" },
				{ Commodities.DRUGS, "Drugs" },
				{ Commodities.ORGANS, "Organs" },
				{ Commodities.FOOD, "Food" },
		};

		boolean any = false;
		for (String[] entry : commodities) {
			int qty = (int) storage.getCommodityQuantity(entry[0]);
			if (qty <= 0) continue;
			if (!any) {
				text.addPara("Station storage:");
				any = true;
			}
			text.addPara(entry[1] + ": " + qty);
		}

		int crew = storage.getCrew();
		if (crew > 0) {
			if (!any) {
				text.addPara("Station storage:");
				any = true;
			}
			text.addPara("Crew: " + crew);
		}

		int marines = storage.getMarines();
		if (marines > 0) {
			if (!any) {
				text.addPara("Station storage:");
				any = true;
			}
			text.addPara("Marines: " + marines);
		}
	}

	private void showInventory() {
		options.clearOptions();
		dialog.setPromptText("");

		visual.showCore(CoreUITabId.CARGO, station, new CoreInteractionListener() {
			@Override
			public void coreUIDismissed() {
				showMainMenu();
			}
		});
	}

	private void showShips() {
		options.clearOptions();
		dialog.setPromptText("");

		visual.showCore(CoreUITabId.FLEET, station, new CoreInteractionListener() {
			@Override
			public void coreUIDismissed() {
				showMainMenu();
			}
		});
	}

	private void showModulesMenu() {
		restoreDefaultVisual();

		text.addPara("Select a module to build or review.");

		boolean miningBuilt = MiningHangarModule.isBuilt(station);
		boolean recreationBuilt = RecreationalHubModule.isBuilt(station);
		boolean recreationAvailable = recreationBuilt || RecreationalHubModule.canBuild(station);

		options.clearOptions();
		options.addOption("Materials Acquisition Hub" + (miningBuilt ? " (Built)" : ""), OPT_MINING_VIEW,
				"Collects a share of the system's ore, rare ore, volatiles, and organics every month.");
		if (recreationAvailable) {
			options.addOption("Resort" + (recreationBuilt ? " (Built)" : ""), OPT_RECREATION_VIEW,
					"Lets colonists from a nearby colonized planet visit the station, generating income "
					+ "every month. Only buildable while orbiting a colonized planet.");
		} else {
			options.addOption("Resort (Requires orbit of a colonized planet)", OPT_RECREATION_VIEW);
			options.setEnabled(OPT_RECREATION_VIEW, false);
		}

		boolean industrialBuilt = IndustrialHubModule.isBuilt(station);
		options.addOption("Manufactorium" + (industrialBuilt ? " (Built)" : ""), OPT_INDUSTRIAL_VIEW,
				"Refines ore and rare ore into metals and transplutonics, and produces heavy machinery "
				+ "and supplies, every month.");

		boolean hydroponicsBuilt = HydroponicsHubModule.isBuilt(station);
		options.addOption("Bio-Dome" + (hydroponicsBuilt ? " (Built)" : ""), OPT_HYDROPONICS_VIEW,
				"Produces food and organics every month.");

		boolean assemblyBuilt = AssemblyBayModule.isBuilt(station);
		options.addOption("Strategic Assembly" + (assemblyBuilt ? " (Built)" : ""), OPT_ASSEMBLY_VIEW,
				"Allows construction of ships and weapons from known blueprints, funded by a production "
				+ "capacity that grows over time.");

		boolean militaryWardBuilt = MilitaryWardModule.isBuilt(station);
		options.addOption("Military Paradigm" + (militaryWardBuilt ? " (Built)" : ""), OPT_MILITARYWARD_VIEW,
				"Slowly produces Crew and Marines, up to a cap, and can train stored Marines over time.");

		options.addOption("Back", OPT_MODULES_BACK);

		dialog.setPromptText("Player HQ - Modules");
		dialog.setOptionOnEscape("Back", OPT_MODULES_BACK);
	}

	private void showMiningHangarDetail() {
		try {
			Global.getSettings().loadTexture(MiningHangarModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(MiningHangarModule.IMAGE_PATH, 480, 300));

		boolean built = MiningHangarModule.isBuilt(station);
		boolean boreInstalled = MiningHangarModule.hasBoreInstalled(station);

		if (built) {
			text.addPara(String.format("The Materials Acquisition Hub is operational, pulling in a %s%% share of the ore, "
					+ "rare ore, volatiles, and organics available from bodies in this system every month, "
					+ "deposited straight into the station's storage, up to a cap of %s of each resource.",
					Math.round(MiningHangarModule.getCombinedEfficiency(station) * 100f),
					(int) MiningHangarModule.MAX_STORED_RESOURCES));
			for (String line : MiningHangarModule.getExpectedMonthlyHarvest(station)) {
				text.addPara(line);
			}
			if (boreInstalled) {
				text.addPara("An Autonomous Mantle Bore is installed, boosting collection efficiency.");
			} else {
				text.addPara(String.format("Installing an Autonomous Mantle Bore would boost collection "
						+ "efficiency from %s%% to %s%%.",
						Math.round(MiningHangarModule.EFFICIENCY_BASE * 100f),
						Math.round(MiningHangarModule.EFFICIENCY_WITH_BORE * 100f)));
			}

			if (station.getMarket() != null) {
				CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
				text.addPara(String.format("Current storage: %s/%s ore, %s/%s transplutonic ore, "
						+ "%s/%s volatiles, %s/%s organics.",
						(int) storage.getCommodityQuantity(Commodities.ORE), (int) MiningHangarModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.RARE_ORE), (int) MiningHangarModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.VOLATILES), (int) MiningHangarModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.ORGANICS), (int) MiningHangarModule.MAX_STORED_RESOURCES));
			}
		} else {
			text.addPara("Build a Materials Acquisition Hub to automatically collect a share of the ore, rare ore, "
					+ "volatiles, and organics available from bodies in this system every month, "
					+ "deposited straight into the station's storage.");
			text.addPara(String.format("Costs %s metals, %s transplutonics, and %s volatiles, drawn from "
					+ "your fleet's cargo and the station's own storage combined.",
					(int) MiningHangarModule.METALS_COST, (int) MiningHangarModule.TRANSPLUTONICS_COST,
					(int) MiningHangarModule.VOLATILES_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Materials Acquisition Hub", OPT_MINING_BUILD);
			options.setEnabled(OPT_MINING_BUILD, MiningHangarModule.hasCost(station, playerFleet));
		} else if (!boreInstalled) {
			options.addOption("Install Autonomous Mantle Bore", OPT_MINING_INSTALL_BORE,
					"Consumes one Autonomous Mantle Bore from your fleet's cargo.");
			options.setEnabled(OPT_MINING_INSTALL_BORE, MiningHangarModule.hasBoreInCargo(playerFleet.getCargo()));
		} else {
			options.addOption("Uninstall Autonomous Mantle Bore", OPT_MINING_UNINSTALL_BORE,
					"Removes the bore and returns it in full to your fleet's cargo.");
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Materials Acquisition Hub");
	}

	private void doBuildMiningHangar() {
		if (MiningHangarModule.isBuilt(station) || !MiningHangarModule.hasCost(station, playerFleet)) {
			showMiningHangarDetail();
			return;
		}

		MiningHangarModule.build(station, playerFleet);
		text.addPara("The Materials Acquisition Hub is now operational.");

		showMiningHangarDetail();
	}

	private void doInstallMantleBore() {
		if (!MiningHangarModule.isBuilt(station) || MiningHangarModule.hasBoreInstalled(station)
				|| !MiningHangarModule.hasBoreInCargo(playerFleet.getCargo())) {
			showMiningHangarDetail();
			return;
		}

		MiningHangarModule.installBore(station, playerFleet);
		text.addPara("The Autonomous Mantle Bore has been installed in the Materials Acquisition Hub.");

		showMiningHangarDetail();
	}

	private void doUninstallMantleBore() {
		if (!MiningHangarModule.isBuilt(station) || !MiningHangarModule.hasBoreInstalled(station)) {
			showMiningHangarDetail();
			return;
		}

		MiningHangarModule.uninstallBore(station, playerFleet);
		text.addPara("The Autonomous Mantle Bore has been removed from the Materials Acquisition Hub and returned to your fleet's cargo.");

		showMiningHangarDetail();
	}

	private void showRecreationalHubDetail() {
		String imagePath = RecreationalHubModule.getRandomImagePath();
		try {
			Global.getSettings().loadTexture(imagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(imagePath, 480, 300));

		boolean built = RecreationalHubModule.isBuilt(station);
		boolean holosuiteInstalled = RecreationalHubModule.hasHolosuiteInstalled(station);
		boolean fusionLampInstalled = RecreationalHubModule.hasFusionLampInstalled(station);

		if (built) {
			float income = RecreationalHubModule.getFinalIncome(station);
			float bonusPercent = (RecreationalHubModule.getIncomeMultiplier(station) - 1f) * 100f;
			text.addPara(String.format("The Resort is operational, drawing colonists from the "
					+ "nearby colony to spend their credits at the station. Currently generating %s credits "
					+ "per month (+%s%% bonus from installed upgrades).", (int) income, Math.round(bonusPercent)));
			if (!holosuiteInstalled) {
				text.addPara(String.format("Installing a Dealmaker Holosuite would boost income by %s%%.",
						Math.round(RecreationalHubModule.HOLOSUITE_BONUS * 100f)));
			} else {
				text.addPara("A Dealmaker Holosuite is installed, letting colonists use its VR suits for fun.");
			}
			if (!fusionLampInstalled) {
				text.addPara(String.format("Installing an Orbital Fusion Lamp would boost income by %s%%.",
						Math.round(RecreationalHubModule.FUSION_LAMP_BONUS * 100f)));
			} else {
				text.addPara("An Orbital Fusion Lamp is installed, simulating a tropical beach for colonists "
						+ "to relax on and swim.");
			}
		} else {
			text.addPara("Build a Resort to let colonists from the nearby colonized planet visit "
					+ "the station, generating income every month based on the colony's size.");
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics, and %s volatiles. "
					+ "Resource costs are drawn from your fleet's cargo and the station's own storage combined.",
					(int) RecreationalHubModule.CREDIT_COST, (int) RecreationalHubModule.METALS_COST,
					(int) RecreationalHubModule.TRANSPLUTONICS_COST, (int) RecreationalHubModule.VOLATILES_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Resort", OPT_RECREATION_BUILD);
			options.setEnabled(OPT_RECREATION_BUILD, RecreationalHubModule.canBuild(station)
					&& RecreationalHubModule.hasCost(station, playerFleet));
		} else {
			if (!holosuiteInstalled) {
				options.addOption("Install Dealmaker Holosuite", OPT_RECREATION_INSTALL_HOLOSUITE,
						"Consumes one Dealmaker Holosuite from your fleet's cargo.");
				options.setEnabled(OPT_RECREATION_INSTALL_HOLOSUITE,
						RecreationalHubModule.hasHolosuiteInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Dealmaker Holosuite", OPT_RECREATION_UNINSTALL_HOLOSUITE,
						"Removes the Holosuite and returns it in full to your fleet's cargo.");
			}
			if (!fusionLampInstalled) {
				options.addOption("Install Orbital Fusion Lamp", OPT_RECREATION_INSTALL_FUSIONLAMP,
						"Consumes one Orbital Fusion Lamp from your fleet's cargo.");
				options.setEnabled(OPT_RECREATION_INSTALL_FUSIONLAMP,
						RecreationalHubModule.hasFusionLampInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Orbital Fusion Lamp", OPT_RECREATION_UNINSTALL_FUSIONLAMP,
						"Removes the Fusion Lamp and returns it in full to your fleet's cargo.");
			}
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Resort");
	}

	private void doBuildRecreationalHub() {
		if (RecreationalHubModule.isBuilt(station) || !RecreationalHubModule.canBuild(station)
				|| !RecreationalHubModule.hasCost(station, playerFleet)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.build(station, playerFleet);
		text.addPara("The Resort is now operational.");

		showRecreationalHubDetail();
	}

	private void doInstallHolosuite() {
		if (!RecreationalHubModule.isBuilt(station) || RecreationalHubModule.hasHolosuiteInstalled(station)
				|| !RecreationalHubModule.hasHolosuiteInCargo(playerFleet.getCargo())) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.installHolosuite(station, playerFleet);
		text.addPara("The Dealmaker Holosuite has been installed in the Resort.");

		showRecreationalHubDetail();
	}

	private void doUninstallHolosuite() {
		if (!RecreationalHubModule.isBuilt(station) || !RecreationalHubModule.hasHolosuiteInstalled(station)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.uninstallHolosuite(station, playerFleet);
		text.addPara("The Dealmaker Holosuite has been removed from the Resort and returned to your fleet's cargo.");

		showRecreationalHubDetail();
	}

	private void doInstallFusionLamp() {
		if (!RecreationalHubModule.isBuilt(station) || RecreationalHubModule.hasFusionLampInstalled(station)
				|| !RecreationalHubModule.hasFusionLampInCargo(playerFleet.getCargo())) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.installFusionLamp(station, playerFleet);
		text.addPara("The Orbital Fusion Lamp has been installed in the Resort.");

		showRecreationalHubDetail();
	}

	private void doUninstallFusionLamp() {
		if (!RecreationalHubModule.isBuilt(station) || !RecreationalHubModule.hasFusionLampInstalled(station)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.uninstallFusionLamp(station, playerFleet);
		text.addPara("The Orbital Fusion Lamp has been removed from the Resort and returned to your fleet's cargo.");

		showRecreationalHubDetail();
	}

	private void showIndustrialHubDetail() {
		try {
			Global.getSettings().loadTexture(IndustrialHubModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(IndustrialHubModule.IMAGE_PATH, 480, 300));

		boolean built = IndustrialHubModule.isBuilt(station);
		boolean nanoforgeInstalled = IndustrialHubModule.hasNanoforgeInstalled(station);
		boolean biofactoryInstalled = IndustrialHubModule.hasBiofactoryInstalled(station);
		boolean fusionLampInstalled = IndustrialHubModule.hasFusionLampInstalled(station);
		boolean catalyticCoreInstalled = IndustrialHubModule.hasCatalyticCoreInstalled(station);

		if (built) {
			text.addPara("The Manufactorium is operational, refining ores and producing Heavy Machinery and Supplies.");

			if (catalyticCoreInstalled) {
				text.addPara("A Catalytic Core is installed, boosting the yield of metals and transplutonics "
						+ "from ore refining.");
			}
			if (fusionLampInstalled) {
				text.addPara("An Orbital Fusion Lamp is installed, reducing the ore cost of refining metals "
						+ "and transplutonics.");
			}
			if (nanoforgeInstalled) {
				text.addPara("A Nanoforge is installed, allowing production of Domestic Goods, Luxury Goods, "
						+ "and Heavy Armaments.");
			}
			if (biofactoryInstalled) {
				text.addPara("A Biofactory Embryo is installed, allowing production of recreational drugs "
						+ "and organs.");
			}

			if (station.getMarket() != null) {
				CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
				text.addPara(String.format("Current storage: %s/%s metals, %s/%s transplutonics, "
						+ "%s/%s heavy machinery, %s/%s supplies, %s/%s drugs, %s/%s organs, %s/%s domestic goods, "
						+ "%s/%s luxury goods, %s/%s heavy armaments.",
						(int) storage.getCommodityQuantity(Commodities.METALS), (int) IndustrialHubModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.RARE_METALS), (int) IndustrialHubModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.HEAVY_MACHINERY), (int) IndustrialHubModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.SUPPLIES), (int) IndustrialHubModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.DRUGS), (int) IndustrialHubModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.ORGANS), (int) IndustrialHubModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.DOMESTIC_GOODS), (int) IndustrialHubModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.LUXURY_GOODS), (int) IndustrialHubModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.HAND_WEAPONS), (int) IndustrialHubModule.MAX_STORED_RESOURCES));
			}
		} else {
			text.addPara("Build a Manufactorium to refine the station's stored ore into metals and "
					+ "rare ore into transplutonics every month.");
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics, and %s volatiles. "
					+ "Resource costs are drawn from your fleet's cargo and the station's own storage combined.",
					(int) IndustrialHubModule.CREDIT_COST, (int) IndustrialHubModule.METALS_COST,
					(int) IndustrialHubModule.TRANSPLUTONICS_COST, (int) IndustrialHubModule.VOLATILES_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Manufactorium", OPT_INDUSTRIAL_BUILD);
			options.setEnabled(OPT_INDUSTRIAL_BUILD, IndustrialHubModule.hasCost(station, playerFleet));
		} else {
			if (!nanoforgeInstalled) {
				options.addOption("Install Nanoforge", OPT_INDUSTRIAL_INSTALL_NANOFORGE,
						"Consumes one Corrupted or Pristine Nanoforge from your fleet's cargo.");
				options.setEnabled(OPT_INDUSTRIAL_INSTALL_NANOFORGE,
						IndustrialHubModule.hasNanoforgeInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Nanoforge", OPT_INDUSTRIAL_UNINSTALL_NANOFORGE,
						"Removes the Nanoforge and returns it in full to your fleet's cargo.");
			}
			if (!biofactoryInstalled) {
				options.addOption("Install Biofactory Embryo", OPT_INDUSTRIAL_INSTALL_BIOFACTORY,
						"Consumes one Biofactory Embryo from your fleet's cargo.");
				options.setEnabled(OPT_INDUSTRIAL_INSTALL_BIOFACTORY,
						IndustrialHubModule.hasBiofactoryInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Biofactory Embryo", OPT_INDUSTRIAL_UNINSTALL_BIOFACTORY,
						"Removes the Biofactory Embryo and returns it in full to your fleet's cargo.");
			}
			if (!fusionLampInstalled) {
				options.addOption("Install Orbital Fusion Lamp", OPT_INDUSTRIAL_INSTALL_FUSIONLAMP,
						"Consumes one Orbital Fusion Lamp from your fleet's cargo.");
				options.setEnabled(OPT_INDUSTRIAL_INSTALL_FUSIONLAMP,
						IndustrialHubModule.hasFusionLampInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Orbital Fusion Lamp", OPT_INDUSTRIAL_UNINSTALL_FUSIONLAMP,
						"Removes the Fusion Lamp and returns it in full to your fleet's cargo.");
			}
			if (!catalyticCoreInstalled) {
				options.addOption("Install Catalytic Core", OPT_INDUSTRIAL_INSTALL_CATALYTICCORE,
						"Consumes one Catalytic Core from your fleet's cargo.");
				options.setEnabled(OPT_INDUSTRIAL_INSTALL_CATALYTICCORE,
						IndustrialHubModule.hasCatalyticCoreInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Catalytic Core", OPT_INDUSTRIAL_UNINSTALL_CATALYTICCORE,
						"Removes the Catalytic Core and returns it in full to your fleet's cargo.");
			}
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Manufactorium");
	}

	private void doBuildIndustrialHub() {
		if (IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasCost(station, playerFleet)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.build(station, playerFleet);
		text.addPara("The Manufactorium is now operational.");

		showIndustrialHubDetail();
	}

	private void doInstallNanoforge() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasNanoforgeInstalled(station)
				|| !IndustrialHubModule.hasNanoforgeInCargo(playerFleet.getCargo())) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.installNanoforge(station, playerFleet);
		text.addPara("The Nanoforge has been installed in the Manufactorium.");

		showIndustrialHubDetail();
	}

	private void doUninstallNanoforge() {
		if (!IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasNanoforgeInstalled(station)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.uninstallNanoforge(station, playerFleet);
		text.addPara("The Nanoforge has been removed from the Manufactorium and returned to your fleet's cargo.");

		showIndustrialHubDetail();
	}

	private void doInstallBiofactory() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasBiofactoryInstalled(station)
				|| !IndustrialHubModule.hasBiofactoryInCargo(playerFleet.getCargo())) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.installBiofactory(station, playerFleet);
		text.addPara("The Biofactory Embryo has been installed in the Manufactorium.");

		showIndustrialHubDetail();
	}

	private void doUninstallBiofactory() {
		if (!IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasBiofactoryInstalled(station)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.uninstallBiofactory(station, playerFleet);
		text.addPara("The Biofactory Embryo has been removed from the Manufactorium and returned to your fleet's cargo.");

		showIndustrialHubDetail();
	}

	private void doInstallIndustrialFusionLamp() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasFusionLampInstalled(station)
				|| !IndustrialHubModule.hasFusionLampInCargo(playerFleet.getCargo())) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.installFusionLamp(station, playerFleet);
		text.addPara("The Orbital Fusion Lamp has been installed in the Manufactorium.");

		showIndustrialHubDetail();
	}

	private void doUninstallIndustrialFusionLamp() {
		if (!IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasFusionLampInstalled(station)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.uninstallFusionLamp(station, playerFleet);
		text.addPara("The Orbital Fusion Lamp has been removed from the Manufactorium and returned to your fleet's cargo.");

		showIndustrialHubDetail();
	}

	private void doInstallCatalyticCore() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasCatalyticCoreInstalled(station)
				|| !IndustrialHubModule.hasCatalyticCoreInCargo(playerFleet.getCargo())) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.installCatalyticCore(station, playerFleet);
		text.addPara("The Catalytic Core has been installed in the Manufactorium.");

		showIndustrialHubDetail();
	}

	private void doUninstallCatalyticCore() {
		if (!IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasCatalyticCoreInstalled(station)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.uninstallCatalyticCore(station, playerFleet);
		text.addPara("The Catalytic Core has been removed from the Manufactorium and returned to your fleet's cargo.");

		showIndustrialHubDetail();
	}

	private void showHydroponicsHubDetail() {
		try {
			Global.getSettings().loadTexture(HydroponicsHubModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(HydroponicsHubModule.IMAGE_PATH, 480, 300));

		boolean built = HydroponicsHubModule.isBuilt(station);
		boolean nanitesInstalled = HydroponicsHubModule.hasNanitesInstalled(station);

		if (built) {
			text.addPara(String.format("The Bio-Dome is operational, producing %s food and %s organics "
					+ "every month.",
					HydroponicsHubModule.getFoodEconUnits(station) * HydroponicsHubModule.ECON_UNIT_VALUE,
					HydroponicsHubModule.getOrganicsEconUnits(station) * HydroponicsHubModule.ECON_UNIT_VALUE));
			if (nanitesInstalled) {
				text.addPara("Soil Nanites are installed, boosting food and organics production.");
			} else {
				text.addPara(String.format("Installing Soil Nanites would increase both food and organics "
						+ "production by %s each.",
						HydroponicsHubModule.NANITES_BONUS_ECON_UNITS * HydroponicsHubModule.ECON_UNIT_VALUE));
			}

			if (station.getMarket() != null) {
				CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
				text.addPara(String.format("Current storage: %s/%s food, %s/%s organics.",
						(int) storage.getCommodityQuantity(Commodities.FOOD), (int) HydroponicsHubModule.MAX_STORED_RESOURCES,
						(int) storage.getCommodityQuantity(Commodities.ORGANICS), (int) HydroponicsHubModule.MAX_STORED_RESOURCES));
			}
		} else {
			text.addPara("Build a Bio-Dome to automatically produce food and organics every month.");
			text.addPara(String.format("Costs %s credits, %s metals, and %s organics (drawn from your fleet's "
					+ "cargo and the station's own storage combined), plus one Orbital Fusion Lamp consumed "
					+ "from your fleet's cargo.",
					(int) HydroponicsHubModule.CREDIT_COST, (int) HydroponicsHubModule.METALS_COST,
					(int) HydroponicsHubModule.ORGANICS_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Bio-Dome", OPT_HYDROPONICS_BUILD);
			options.setEnabled(OPT_HYDROPONICS_BUILD, HydroponicsHubModule.hasCost(station, playerFleet));
		} else if (!nanitesInstalled) {
			options.addOption("Install Soil Nanites", OPT_HYDROPONICS_INSTALL_NANITES,
					"Consumes one Soil Nanites from your fleet's cargo.");
			options.setEnabled(OPT_HYDROPONICS_INSTALL_NANITES,
					HydroponicsHubModule.hasNanitesInCargo(playerFleet.getCargo()));
		} else {
			options.addOption("Uninstall Soil Nanites", OPT_HYDROPONICS_UNINSTALL_NANITES,
					"Removes the Soil Nanites and returns them in full to your fleet's cargo.");
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Bio-Dome");
	}

	private void doBuildHydroponicsHub() {
		if (HydroponicsHubModule.isBuilt(station) || !HydroponicsHubModule.hasCost(station, playerFleet)) {
			showHydroponicsHubDetail();
			return;
		}

		HydroponicsHubModule.build(station, playerFleet);
		text.addPara("The Bio-Dome is now operational.");

		showHydroponicsHubDetail();
	}

	private void doInstallSoilNanites() {
		if (!HydroponicsHubModule.isBuilt(station) || HydroponicsHubModule.hasNanitesInstalled(station)
				|| !HydroponicsHubModule.hasNanitesInCargo(playerFleet.getCargo())) {
			showHydroponicsHubDetail();
			return;
		}

		HydroponicsHubModule.installNanites(station, playerFleet);
		text.addPara("The Soil Nanites have been installed in the Bio-Dome.");

		showHydroponicsHubDetail();
	}

	private void doUninstallSoilNanites() {
		if (!HydroponicsHubModule.isBuilt(station) || !HydroponicsHubModule.hasNanitesInstalled(station)) {
			showHydroponicsHubDetail();
			return;
		}

		HydroponicsHubModule.uninstallNanites(station, playerFleet);
		text.addPara("The Soil Nanites have been removed from the Bio-Dome and returned to your fleet's cargo.");

		showHydroponicsHubDetail();
	}

	private void showAssemblyBayDetail() {
		try {
			Global.getSettings().loadTexture(AssemblyBayModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(AssemblyBayModule.IMAGE_PATH, 480, 300));

		boolean built = AssemblyBayModule.isBuilt(station);
		boolean nanoforgeInstalled = AssemblyBayModule.hasNanoforgeInstalled(station);
		boolean alphaCoreInstalled = AssemblyBayModule.hasAlphaCoreInstalled(station);
		boolean cryoInstalled = AssemblyBayModule.hasCryoarithmeticEngineInstalled(station);

		if (built) {
			float pool = AssemblyBayModule.getPoolValue(station);
			float monthlyGen = AssemblyBayModule.getMonthlyGeneration(station);
			text.addPara(String.format("The Strategic Assembly is operational, capable of constructing ships and "
					+ "weapons from known blueprints. Its production capacity currently stands at %s / %s "
					+ "credits, growing by %s credits per month.",
					(int) pool, (int) AssemblyBayModule.POOL_MAX, (int) monthlyGen));
			text.addPara("Use \"Order Custom Production\" from the station's main menu to search known "
					+ "designs and place an order.");

			AssemblyBayModule.ProductionOrder activeOrder = AssemblyBayModule.getActiveOrder(station);
			if (activeOrder == null) {
				text.addPara("Nothing is currently in production.");
			} else {
				int daysLeft = (int) Math.ceil(AssemblyBayModule.getDaysRemaining(station));
				String queuedNote = activeOrder.started ? "" : ", waiting behind an earlier order";
				text.addPara(String.format("Currently building: %s%s - %s %s remaining.",
						activeOrder.name, queuedNote, daysLeft, daysLeft == 1 ? "day" : "days"));

				int queueLen = AssemblyBayModule.getQueueLength(station);
				if (queueLen > 1) {
					text.addPara((queueLen - 1) + " more order(s) waiting in the production line.");
				}
			}

			if (nanoforgeInstalled) {
				text.addPara(String.format("A Nanoforge is installed, reducing construction costs by %s%%.",
						Math.round(AssemblyBayModule.getNanoforgeDiscount(station) * 100f)));
			} else {
				text.addPara(String.format("Installing a Corrupted Nanoforge would reduce construction costs "
						+ "by %s%%; a Pristine Nanoforge would reduce them by %s%%.",
						Math.round(AssemblyBayModule.CORRUPTED_NANOFORGE_DISCOUNT * 100f),
						Math.round(AssemblyBayModule.PRISTINE_NANOFORGE_DISCOUNT * 100f)));
			}

			if (alphaCoreInstalled && cryoInstalled) {
				text.addPara("A Dedicated AI System is installed, doubling the Bay's monthly production "
						+ "capacity growth.");
			} else {
				text.addPara(String.format("Installing a Dedicated AI System (an Alpha Core and a Cryoarithmetic "
						+ "Engine together) would double the Bay's monthly production capacity growth, from %s to "
						+ "%s credits. Both are required at once; installing only one grants no bonus.",
						(int) AssemblyBayModule.POOL_MONTHLY_BASE, (int) AssemblyBayModule.POOL_MONTHLY_WITH_BONUS));
			}
		} else {
			text.addPara("Build a Strategic Assembly to construct ships and weapons from your known blueprints, "
					+ "drawing on a production capacity that grows over time.");
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics, and %s volatiles. "
					+ "Resource costs are drawn from your fleet's cargo and the station's own storage combined.",
					(int) AssemblyBayModule.CREDIT_COST, (int) AssemblyBayModule.METALS_COST,
					(int) AssemblyBayModule.TRANSPLUTONICS_COST, (int) AssemblyBayModule.VOLATILES_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Strategic Assembly", OPT_ASSEMBLY_BUILD);
			options.setEnabled(OPT_ASSEMBLY_BUILD, AssemblyBayModule.hasCost(station, playerFleet));
		} else {
			if (!nanoforgeInstalled) {
				options.addOption("Install Nanoforge", OPT_ASSEMBLY_INSTALL_NANOFORGE,
						"Consumes one Corrupted or Pristine Nanoforge from your fleet's cargo.");
				options.setEnabled(OPT_ASSEMBLY_INSTALL_NANOFORGE,
						AssemblyBayModule.hasNanoforgeInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Nanoforge", OPT_ASSEMBLY_UNINSTALL_NANOFORGE,
						"Removes the Nanoforge and returns it in full to your fleet's cargo.");
			}
			if (!(alphaCoreInstalled && cryoInstalled)) {
				options.addOption("Install Dedicated AI System", OPT_ASSEMBLY_INSTALL_GENERATION_BOOST,
						"Consumes one Alpha Core and one Cryoarithmetic Engine from your fleet's cargo at the same time.");
				options.setEnabled(OPT_ASSEMBLY_INSTALL_GENERATION_BOOST,
						AssemblyBayModule.hasGenerationBoostInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Dedicated AI System", OPT_ASSEMBLY_UNINSTALL_GENERATION_BOOST,
						"Removes the Alpha Core and Cryoarithmetic Engine and returns them in full to your fleet's cargo.");
			}
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Strategic Assembly");
	}

	private void doBuildAssemblyBay() {
		if (AssemblyBayModule.isBuilt(station) || !AssemblyBayModule.hasCost(station, playerFleet)) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.build(station, playerFleet);
		text.addPara("The Strategic Assembly is now operational.");

		showAssemblyBayDetail();
	}

	private void doInstallAssemblyNanoforge() {
		if (!AssemblyBayModule.isBuilt(station) || AssemblyBayModule.hasNanoforgeInstalled(station)
				|| !AssemblyBayModule.hasNanoforgeInCargo(playerFleet.getCargo())) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.installNanoforge(station, playerFleet);
		text.addPara("The Nanoforge has been installed in the Strategic Assembly.");

		showAssemblyBayDetail();
	}

	private void doUninstallAssemblyNanoforge() {
		if (!AssemblyBayModule.isBuilt(station) || !AssemblyBayModule.hasNanoforgeInstalled(station)) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.uninstallNanoforge(station, playerFleet);
		text.addPara("The Nanoforge has been removed from the Strategic Assembly and returned to your fleet's cargo.");

		showAssemblyBayDetail();
	}

	private void doInstallAssemblyGenerationBoost() {
		boolean alreadyInstalled = AssemblyBayModule.hasAlphaCoreInstalled(station)
				&& AssemblyBayModule.hasCryoarithmeticEngineInstalled(station);
		if (!AssemblyBayModule.isBuilt(station) || alreadyInstalled
				|| !AssemblyBayModule.hasGenerationBoostInCargo(playerFleet.getCargo())) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.installGenerationBoost(station, playerFleet);
		text.addPara("The Dedicated AI System has been installed in the Strategic Assembly, doubling its monthly "
				+ "production capacity growth.");

		showAssemblyBayDetail();
	}

	private void doUninstallAssemblyGenerationBoost() {
		boolean installed = AssemblyBayModule.hasAlphaCoreInstalled(station)
				&& AssemblyBayModule.hasCryoarithmeticEngineInstalled(station);
		if (!AssemblyBayModule.isBuilt(station) || !installed) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.uninstallGenerationBoost(station, playerFleet);
		text.addPara("The Dedicated AI System has been removed from the Strategic Assembly and returned to your fleet's cargo.");

		showAssemblyBayDetail();
	}

	private void showMilitaryWardDetail() {
		String imagePath = MilitaryWardModule.getRandomImagePath();
		try {
			Global.getSettings().loadTexture(imagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(imagePath, 480, 300));

		boolean built = MilitaryWardModule.isBuilt(station);
		boolean holosuiteInstalled = MilitaryWardModule.hasHolosuiteInstalled(station);
		boolean droneReplicatorInstalled = MilitaryWardModule.hasDroneReplicatorInstalled(station);
		boolean aiCoreInstalled = MilitaryWardModule.hasAICoreInstalled(station);

		if (built) {
			text.addPara(String.format("The Military Paradigm is fully functional, slowly producing Crew and "
					+ "training Marines. Since the station is mostly automated, space for crew quarters is "
					+ "limited, allowing only up to %s of each to be held at the station.",
					(int) MilitaryWardModule.MAX_PERSONNEL));

			CargoAPI storage = null;
			if (station.getMarket() != null) {
				storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
				text.addPara(String.format("Current storage: %s/%s crew, %s/%s marines.",
						storage.getCrew(), (int) MilitaryWardModule.MAX_PERSONNEL,
						storage.getMarines(), (int) MilitaryWardModule.MAX_PERSONNEL));
			}

			boolean hasStoredMarines = storage != null && storage.getMarines() > 0;

			if (hasStoredMarines) {
				com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelRank rank = MilitaryWardModule.getStoredMarineRank(station);
				if (rank != null) {
					text.addPara(String.format("Stored Marines are currently rated %s (%s%% of the way to Elite).",
							rank.name, (int) MilitaryWardModule.getStoredMarineTrainingPercent(station)));
				}

				if (holosuiteInstalled || droneReplicatorInstalled) {
					List<String> installedNames = new ArrayList<String>();
					if (holosuiteInstalled) installedNames.add("Dealmaker Holosuite");
					if (droneReplicatorInstalled) installedNames.add("Combat Drone Replicator");
					if (aiCoreInstalled) installedNames.add(getAICoreDisplayName(MilitaryWardModule.getInstalledAICoreTier(station)));

					float ratio = MilitaryWardModule.getTrainingRatioPerMonth(station);
					text.addPara(String.format("%s installed, improving Marine training speed by %s%% per month.",
							String.join(", ", installedNames), Math.round(ratio * 100f)));
				}
			}
		} else {
			text.addPara("Build a Military Paradigm to slowly produce Crew and Marines and give them a place "
					+ "to be housed and trained aboard the station.");
			text.addPara(String.format("Costs %s credits, %s metals, and %s transplutonics. Resource costs "
					+ "are drawn from your fleet's cargo and the station's own storage combined.",
					(int) MilitaryWardModule.CREDIT_COST, (int) MilitaryWardModule.METALS_COST,
					(int) MilitaryWardModule.TRANSPLUTONICS_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Military Paradigm", OPT_MILITARYWARD_BUILD);
			options.setEnabled(OPT_MILITARYWARD_BUILD, MilitaryWardModule.hasCost(station, playerFleet));
		} else {
			if (!holosuiteInstalled) {
				options.addOption("Install Holosuite", OPT_MILITARYWARD_INSTALL_HOLOSUITE,
						"Consumes one Dealmaker Holosuite from your fleet's cargo. Trains stored Marines over "
						+ "time via realistic simulated combat.");
				options.setEnabled(OPT_MILITARYWARD_INSTALL_HOLOSUITE,
						MilitaryWardModule.hasHolosuiteInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Holosuite", OPT_MILITARYWARD_UNINSTALL_HOLOSUITE,
						"Removes the Holosuite and returns it in full to your fleet's cargo.");
			}
			if (!droneReplicatorInstalled) {
				options.addOption("Install Combat Drone Replicator", OPT_MILITARYWARD_INSTALL_DRONE_REPLICATOR,
						"Consumes one Combat Drone Replicator from your fleet's cargo. Trains stored Marines "
						+ "over time via semi-realistic terrain combat against training drones.");
				options.setEnabled(OPT_MILITARYWARD_INSTALL_DRONE_REPLICATOR,
						MilitaryWardModule.hasDroneReplicatorInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall Combat Drone Replicator", OPT_MILITARYWARD_UNINSTALL_DRONE_REPLICATOR,
						"Removes the Combat Drone Replicator and returns it in full to your fleet's cargo.");
			}
			if (!aiCoreInstalled) {
				options.addOption("Install AI Core", OPT_MILITARYWARD_INSTALL_AICORE,
						"Install a Gamma, Beta, or Alpha Core to boost Marine training speed.");
				options.setEnabled(OPT_MILITARYWARD_INSTALL_AICORE,
						MilitaryWardModule.hasGammaCoreInCargo(playerFleet.getCargo())
								|| MilitaryWardModule.hasBetaCoreInCargo(playerFleet.getCargo())
								|| MilitaryWardModule.hasAlphaCoreInCargo(playerFleet.getCargo()));
			} else {
				options.addOption("Uninstall AI Core", OPT_MILITARYWARD_UNINSTALL_AICORE,
						"Removes the installed core and returns it in full to your fleet's cargo, so a "
						+ "different tier can be installed in its place.");
			}
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Military Paradigm");
	}

	private String getAICoreDisplayName(String coreCommodityId) {
		if (Commodities.ALPHA_CORE.equals(coreCommodityId)) return "Alpha Core";
		if (Commodities.BETA_CORE.equals(coreCommodityId)) return "Beta Core";
		if (Commodities.GAMMA_CORE.equals(coreCommodityId)) return "Gamma Core";
		return "AI Core";
	}

	private void showMilitaryWardAICoreMenu() {
		if (!MilitaryWardModule.isBuilt(station) || MilitaryWardModule.hasAICoreInstalled(station)) {
			showMilitaryWardDetail();
			return;
		}

		restoreDefaultVisual();
		text.addPara("Choose which AI core to install in the Military Paradigm. Only one may be installed.");

		options.clearOptions();
		options.addOption("Install Gamma Core", OPT_MILITARYWARD_INSTALL_GAMMA_CORE,
				"Consumes one Gamma Core from your fleet's cargo. Multiplies training speed by 3x.");
		options.setEnabled(OPT_MILITARYWARD_INSTALL_GAMMA_CORE,
				MilitaryWardModule.hasGammaCoreInCargo(playerFleet.getCargo()));
		options.addOption("Install Beta Core", OPT_MILITARYWARD_INSTALL_BETA_CORE,
				"Consumes one Beta Core from your fleet's cargo. Multiplies training speed by 2x.");
		options.setEnabled(OPT_MILITARYWARD_INSTALL_BETA_CORE,
				MilitaryWardModule.hasBetaCoreInCargo(playerFleet.getCargo()));
		options.addOption("Install Alpha Core", OPT_MILITARYWARD_INSTALL_ALPHA_CORE,
				"Consumes one Alpha Core from your fleet's cargo. Multiplies training speed by 4x.");
		options.setEnabled(OPT_MILITARYWARD_INSTALL_ALPHA_CORE,
				MilitaryWardModule.hasAlphaCoreInCargo(playerFleet.getCargo()));
		options.addOption("Back", OPT_MILITARYWARD_AICORE_BACK);

		dialog.setPromptText("Military Paradigm - Install AI Core");
	}

	private void doBuildMilitaryWard() {
		if (MilitaryWardModule.isBuilt(station) || !MilitaryWardModule.hasCost(station, playerFleet)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.build(station, playerFleet);
		text.addPara("The Military Paradigm is now operational.");

		showMilitaryWardDetail();
	}

	private void doInstallMilitaryWardHolosuite() {
		if (!MilitaryWardModule.isBuilt(station) || MilitaryWardModule.hasHolosuiteInstalled(station)
				|| !MilitaryWardModule.hasHolosuiteInCargo(playerFleet.getCargo())) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.installHolosuite(station, playerFleet);
		text.addPara("The Holosuite has been installed in the Military Paradigm.");

		showMilitaryWardDetail();
	}

	private void doUninstallMilitaryWardHolosuite() {
		if (!MilitaryWardModule.isBuilt(station) || !MilitaryWardModule.hasHolosuiteInstalled(station)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.uninstallHolosuite(station, playerFleet);
		text.addPara("The Holosuite has been removed from the Military Paradigm and returned to your fleet's cargo.");

		showMilitaryWardDetail();
	}

	private void doInstallMilitaryWardDroneReplicator() {
		if (!MilitaryWardModule.isBuilt(station) || MilitaryWardModule.hasDroneReplicatorInstalled(station)
				|| !MilitaryWardModule.hasDroneReplicatorInCargo(playerFleet.getCargo())) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.installDroneReplicator(station, playerFleet);
		text.addPara("The Combat Drone Replicator has been installed in the Military Paradigm.");

		showMilitaryWardDetail();
	}

	private void doUninstallMilitaryWardDroneReplicator() {
		if (!MilitaryWardModule.isBuilt(station) || !MilitaryWardModule.hasDroneReplicatorInstalled(station)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.uninstallDroneReplicator(station, playerFleet);
		text.addPara("The Combat Drone Replicator has been removed from the Military Paradigm and returned to your fleet's cargo.");

		showMilitaryWardDetail();
	}

	private void doInstallMilitaryWardAICore(String coreCommodityId) {
		if (!MilitaryWardModule.isBuilt(station) || MilitaryWardModule.hasAICoreInstalled(station)
				|| playerFleet.getCargo().getCommodityQuantity(coreCommodityId) < MilitaryWardModule.AI_CORE_COST) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.installAICore(station, playerFleet, coreCommodityId);
		text.addPara("The AI core has been installed in the Military Paradigm.");

		showMilitaryWardDetail();
	}

	private void doUninstallMilitaryWardAICore() {
		if (!MilitaryWardModule.isBuilt(station) || !MilitaryWardModule.hasAICoreInstalled(station)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.uninstallAICore(station, playerFleet);
		text.addPara("The AI core has been removed from the Military Paradigm and returned to your fleet's cargo.");

		showMilitaryWardDetail();
	}

	private void doOrderCustomProduction() {
		if (!AssemblyBayModule.isBuilt(station)) {
			showMainMenu();
			return;
		}

		dialog.showCustomProductionPicker(new PlayerHQProductionPickerDelegate(station, playerFleet, text));
	}

	/**
	 * Hands off to the game's own built-in "Custom Order" production picker -- the same UI used for
	 * colony industries, and the one Random Assortment of Things also reuses for its settlements --
	 * pre-filled with the Strategic Assembly's known ship hulls and weapons and capped by its current
	 * production capacity. Confirmed items are fed into the Strategic Assembly's own production queue
	 * (with its per-item build-day timers) rather than delivered instantly.
	 */
	private static class PlayerHQProductionPickerDelegate extends BaseCustomProductionPickerDelegateImpl {

		private final SectorEntityToken station;
		private final CampaignFleetAPI playerFleet;
		private final TextPanelAPI text;

		PlayerHQProductionPickerDelegate(SectorEntityToken station, CampaignFleetAPI playerFleet, TextPanelAPI text) {
			this.station = station;
			this.playerFleet = playerFleet;
			this.text = text;
		}

		@Override
		public Set<String> getAvailableShipHulls() {
			return new LinkedHashSet<String>(Global.getSector().getPlayerFaction().getKnownShips());
		}

		@Override
		public Set<String> getAvailableWeapons() {
			return new LinkedHashSet<String>(Global.getSector().getPlayerFaction().getKnownWeapons());
		}

		@Override
		public Set<String> getAvailableFighters() {
			return null;
		}

		@Override
		public float getCostMult() {
			return 1f - AssemblyBayModule.getNanoforgeDiscount(station);
		}

		@Override
		public float getMaximumValue() {
			return AssemblyBayModule.getPoolValue(station);
		}

		@Override
		public void notifyProductionSelected(FactionProductionAPI production) {
			int builtCount = 0;
			int failedCount = 0;

			for (FactionProductionAPI.ItemInProductionAPI item : production.getCurrent()) {
				FactionProductionAPI.ProductionItemType type = item.getType();
				if (type != FactionProductionAPI.ProductionItemType.SHIP
						&& type != FactionProductionAPI.ProductionItemType.WEAPON) continue;

				for (int i = 0; i < item.getQuantity(); i++) {
					boolean success = type == FactionProductionAPI.ProductionItemType.SHIP
							? AssemblyBayModule.buildShip(station, playerFleet, item.getSpecId())
							: AssemblyBayModule.buildWeapon(station, playerFleet, item.getSpecId());
					if (success) builtCount++; else failedCount++;
				}
			}

			if (builtCount > 0 && failedCount == 0) {
				text.addPara("Order placed: " + builtCount + " item(s) added to the production queue.");
			} else if (builtCount > 0) {
				text.addPara("Order partially placed: " + builtCount + " item(s) queued, "
						+ failedCount + " could not be completed.");
			} else if (failedCount > 0) {
				text.addPara("The order could not be completed.");
			}

			if (builtCount > 0) {
				float totalDays = AssemblyBayModule.getTotalQueueDaysRemaining(station);
				text.addPara(String.format("The full production queue will be clear in ~%s day(s).",
						(int) Math.ceil(totalDays)));
			}
		}
	}

	private void showStationItemsMenu() {
		restoreDefaultVisual();

		boolean droneReplicatorInstalled = StationItemsModule.hasDroneReplicatorInstalled(station);

		text.addPara("Special Items can be installed to give the station an overall boost.");

		if (droneReplicatorInstalled) {
			text.addPara("Combat Drone Replicator has been installed and repurposed to not only produce "
					+ "combat drones for the colony below but servant, mining, and farm drones as well.");
			text.addPara(String.format("Increases the Mining Efficiency by %s%%.",
					Math.round(StationItemsModule.DRONE_REPLICATOR_MINING_BONUS * 100f)));
			text.addPara(String.format("Increases Resort income by %s%%.",
					Math.round(StationItemsModule.DRONE_REPLICATOR_RECREATION_BONUS * 100f)));
			text.addPara(String.format("Bio-Dome gains +%s to organics and food production.",
					StationItemsModule.DRONE_REPLICATOR_HYDROPONICS_BONUS_ECON_UNITS));
			text.addPara(String.format("Gives a %sx bonus to the colony it is orbiting, if orbiting a colony.",
					StationItemsModule.DRONE_REPLICATOR_DEFENSE_BONUS));
		} else {
			text.addPara(String.format("Combat Drone Replicator: %s%% bonus to Materials Acquisition Hub efficiency, %s%% bonus "
					+ "to Resort income, +%s to Bio-Dome organics and food production, and a "
					+ "%sx bonus to the ground defenses of a colony it orbits.",
					Math.round(StationItemsModule.DRONE_REPLICATOR_MINING_BONUS * 100f),
					Math.round(StationItemsModule.DRONE_REPLICATOR_RECREATION_BONUS * 100f),
					StationItemsModule.DRONE_REPLICATOR_HYDROPONICS_BONUS_ECON_UNITS,
					StationItemsModule.DRONE_REPLICATOR_DEFENSE_BONUS));
		}

		options.clearOptions();
		if (!droneReplicatorInstalled) {
			options.addOption("Install Combat Drone Replicator", OPT_STATIONITEM_INSTALL_DRONE_REPLICATOR,
					"Consumes one Drone Replicator from your fleet's cargo.");
			options.setEnabled(OPT_STATIONITEM_INSTALL_DRONE_REPLICATOR,
					StationItemsModule.hasDroneReplicatorInCargo(playerFleet.getCargo()));
		} else {
			options.addOption("Uninstall Combat Drone Replicator", OPT_STATIONITEM_UNINSTALL_DRONE_REPLICATOR,
					"Removes the Combat Drone Replicator and returns it in full to your fleet's cargo.");
		}
		options.addOption("Back", OPT_STATION_ITEMS_BACK);

		dialog.setPromptText("Station Upgrades");
		dialog.setOptionOnEscape("Back", OPT_STATION_ITEMS_BACK);
	}

	private void doInstallDroneReplicator() {
		if (StationItemsModule.hasDroneReplicatorInstalled(station)
				|| !StationItemsModule.hasDroneReplicatorInCargo(playerFleet.getCargo())) {
			showStationItemsMenu();
			return;
		}

		StationItemsModule.installDroneReplicator(station, playerFleet);
		text.addPara("The Combat Drone Replicator has been installed on the station.");

		showStationItemsMenu();
	}

	private void doUninstallDroneReplicator() {
		if (!StationItemsModule.hasDroneReplicatorInstalled(station)) {
			showStationItemsMenu();
			return;
		}

		StationItemsModule.refundDroneReplicator(station, playerFleet);
		text.addPara("The Combat Drone Replicator has been removed from the station and returned to your fleet's cargo.");

		showStationItemsMenu();
	}

	private void showConfirmDismantle() {
		text.addPara("Are you sure you want to dismantle the Player HQ station? This cannot be undone.");

		MarketAPI market = station.getMarket();
		boolean storageHasContents = market != null
				&& !market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo().isEmpty();
		if (storageHasContents) {
			text.addPara("The station's storage still holds cargo or ships. Anything you haven't "
					+ "transferred out will be lost when it's dismantled.", Misc.getNegativeHighlightColor());
		}

		options.clearOptions();
		options.addOption("Confirm dismantle", OPT_CONFIRM_DISMANTLE);
		options.addOption("Back", OPT_CANCEL_DISMANTLE);
	}

	private void doDismantle() {
		ConstructPlayerHQAbility.dismantleStation(playerFleet);
		text.addPara("The Player HQ station has been dismantled. Half of its resource cost, its AI core, "
				+ "half of the resource cost of any modules built on it, and any special items installed "
				+ "in those modules, have been returned to your cargo hold. Credits spent are not refunded.");

		options.clearOptions();
		options.addOption("Leave", OPT_LEAVE);
		dialog.setPromptText("");
	}
}
