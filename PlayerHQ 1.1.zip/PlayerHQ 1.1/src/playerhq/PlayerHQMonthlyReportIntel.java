package playerhq;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.HydroponicsHubModule.HydroponicsResult;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.IndustrialHubModule.IndustrialHubResult;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.MiningHangarModule.MiningResult;
import playerhq.modules.RecreationalHubModule;
import playerhq.modules.StationItemsModule;
import playerhq.util.PlayerHQUtils;

/**
 * A single, persistent status report -- styled after the settlement report from Random
 * Assortment of Things -- covering where the station is built, what's built on it, and what it
 * produced last month. Unlike the old one-shot version, this same instance is reused and updated
 * in place every month rather than being deleted and recreated, so it doesn't disappear from the
 * Intel screen between checks.
 */
public class PlayerHQMonthlyReportIntel extends BaseIntelPlugin {

	private SectorEntityToken station;

	private MiningResult mining;
	private IndustrialHubResult industrial;
	private HydroponicsResult hydroponics;
	private float recreationIncome;
	private float upkeepCharged;
	private List<String> deliveredShips = new ArrayList<String>();
	private List<String> deliveredWeapons = new ArrayList<String>();
	private List<String> trainingExpeditionLoot = new ArrayList<String>();

	public static void report(SectorEntityToken station, MiningResult mining, IndustrialHubResult industrial,
			HydroponicsResult hydroponics, float recreationIncome, float upkeepCharged,
			List<String> deliveredShips, List<String> deliveredWeapons, List<String> trainingExpeditionLoot) {
		if (station == null) return;

		PlayerHQMonthlyReportIntel intel = (PlayerHQMonthlyReportIntel)
				Global.getSector().getIntelManager().getFirstIntel(PlayerHQMonthlyReportIntel.class);
		boolean isNew = intel == null;
		if (isNew) {
			intel = new PlayerHQMonthlyReportIntel();
		}

		intel.station = station;
		intel.mining = mining;
		intel.industrial = industrial;
		intel.hydroponics = hydroponics;
		intel.recreationIncome = recreationIncome;
		intel.upkeepCharged = upkeepCharged;
		intel.deliveredShips = deliveredShips != null ? deliveredShips : new ArrayList<String>();
		intel.deliveredWeapons = deliveredWeapons != null ? deliveredWeapons : new ArrayList<String>();
		intel.trainingExpeditionLoot = trainingExpeditionLoot != null ? trainingExpeditionLoot : new ArrayList<String>();

		if (isNew) {
			Global.getSector().getIntelManager().addIntel(intel);
		} else {
			intel.sendUpdateIfPlayerHasIntel(null, false);
		}
	}

	/** Removes the persistent report entirely -- called when the station itself is dismantled. */
	public static void removeIfPresent() {
		IntelInfoPlugin intel = Global.getSector().getIntelManager().getFirstIntel(PlayerHQMonthlyReportIntel.class);
		if (intel != null) {
			Global.getSector().getIntelManager().removeIntel(intel);
		}
	}

	@Override
	protected String getName() {
		return "Player HQ Status Report";
	}

	@Override
	public String getIcon() {
		return Global.getSettings().getCommoditySpec(Commodities.ORE).getIconName();
	}

	@Override
	protected void addBulletPoints(TooltipMakerAPI info, ListInfoMode mode, boolean isUpdate, Color tc, float initPad) {
		addLines(info, initPad);
	}

	@Override
	public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		float opad = 10f;
		info.addPara(getName(), opad);
		addLines(info, opad);
	}

	private void addLines(TooltipMakerAPI info, float pad) {
		Color h = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();

		if (station == null || !station.isAlive()) {
			info.addPara("The station no longer exists.", pad, bad);
			return;
		}

		info.addPara(PlayerHQUtils.getStationLocationSummary(station), pad, h);

		List<String> modules = getModulesBuiltSummary(station);
		if (modules.isEmpty()) {
			info.addPara("No modules have been built yet.", pad);
		} else {
			info.addPara("Modules: %s.", pad, h, String.join(", ", modules));
		}

		info.addPara("Last month's production:", pad);

		boolean anyProduction = false;

		if (mining != null) {
			if (!mining.contributingPlanets.isEmpty()) {
				info.addPara("Materials Acquisition Hub drew from: %s.", pad, h, String.join(", ", mining.contributingPlanets));
			}
			if (mining.ore > 0f) {
				info.addPara("Materials Acquisition Hub collected %s ore.", pad, h, fmt(mining.ore));
				anyProduction = true;
			}
			if (mining.rareOre > 0f) {
				info.addPara("Materials Acquisition Hub collected %s transplutonic ore.", pad, h, fmt(mining.rareOre));
				anyProduction = true;
			}
			if (mining.volatiles > 0f) {
				info.addPara("Materials Acquisition Hub collected %s volatiles.", pad, h, fmt(mining.volatiles));
				anyProduction = true;
			}
			if (mining.organics > 0f) {
				info.addPara("Materials Acquisition Hub collected %s organics.", pad, h, fmt(mining.organics));
				anyProduction = true;
			}
			if (mining.oreLostToCap > 0f) {
				info.addPara("The station's ore storage is full (10,000 cap) - %s ore could not be collected.",
						pad, bad, fmt(mining.oreLostToCap));
			}
			if (mining.rareOreLostToCap > 0f) {
				info.addPara("The station's transplutonic ore storage is full (10,000 cap) - %s transplutonic ore could not be collected.",
						pad, bad, fmt(mining.rareOreLostToCap));
			}
			if (mining.volatilesLostToCap > 0f) {
				info.addPara("The station's volatiles storage is full (10,000 cap) - %s volatiles could not be collected.",
						pad, bad, fmt(mining.volatilesLostToCap));
			}
			if (mining.organicsLostToCap > 0f) {
				info.addPara("The station's organics storage is full (10,000 cap) - %s organics could not be collected.",
						pad, bad, fmt(mining.organicsLostToCap));
			}
		}

		if (industrial != null) {
			if (industrial.metals > 0f) {
				info.addPara("Manufactorium refined %s metals.", pad, h, fmt(industrial.metals));
				anyProduction = true;
			}
			if (industrial.transplutonics > 0f) {
				info.addPara("Manufactorium refined %s transplutonics.", pad, h, fmt(industrial.transplutonics));
				anyProduction = true;
			}
			if (industrial.heavyMachinery > 0f) {
				info.addPara("Manufactorium produced %s heavy machinery.", pad, h, fmt(industrial.heavyMachinery));
				anyProduction = true;
			}
			if (industrial.supplies > 0f) {
				info.addPara("Manufactorium produced %s supplies.", pad, h, fmt(industrial.supplies));
				anyProduction = true;
			}
			if (industrial.drugs > 0f) {
				info.addPara("Manufactorium produced %s recreational drugs.", pad, h, fmt(industrial.drugs));
				anyProduction = true;
			}
			if (industrial.organs > 0f) {
				info.addPara("Manufactorium produced %s organs.", pad, h, fmt(industrial.organs));
				anyProduction = true;
			}
			if (industrial.domesticGoods > 0f) {
				info.addPara("Manufactorium produced %s domestic goods.", pad, h, fmt(industrial.domesticGoods));
				anyProduction = true;
			}
			if (industrial.luxuryGoods > 0f) {
				info.addPara("Manufactorium produced %s luxury goods.", pad, h, fmt(industrial.luxuryGoods));
				anyProduction = true;
			}
			if (industrial.heavyArmaments > 0f) {
				info.addPara("Manufactorium produced %s heavy armaments.", pad, h, fmt(industrial.heavyArmaments));
				anyProduction = true;
			}
		}

		if (hydroponics != null) {
			if (hydroponics.food > 0f) {
				info.addPara("Bio-Dome produced %s food.", pad, h, fmt(hydroponics.food));
				anyProduction = true;
			}
			if (hydroponics.organics > 0f) {
				info.addPara("Bio-Dome produced %s organics.", pad, h, fmt(hydroponics.organics));
				anyProduction = true;
			}
			if (hydroponics.foodLostToCap > 0f) {
				info.addPara("The station's food storage is full (10,000 cap) - %s food could not be produced.",
						pad, bad, fmt(hydroponics.foodLostToCap));
			}
			if (hydroponics.organicsLostToCap > 0f) {
				info.addPara("The station's organics storage is full (10,000 cap) - %s organics could not be produced.",
						pad, bad, fmt(hydroponics.organicsLostToCap));
			}
		}

		if (recreationIncome > 0f) {
			info.addPara("Resort generated %s credits in income.", pad, h, fmt(recreationIncome));
			anyProduction = true;
		}

		if (!deliveredShips.isEmpty()) {
			info.addPara("Strategic Assembly completed %s: %s.", pad, h,
					deliveredShips.size() == 1 ? "1 ship" : deliveredShips.size() + " ships",
					String.join(", ", deliveredShips));
			anyProduction = true;
		}

		if (!deliveredWeapons.isEmpty()) {
			info.addPara("Strategic Assembly completed %s: %s.", pad, h,
					deliveredWeapons.size() == 1 ? "1 weapon batch" : deliveredWeapons.size() + " weapon batches",
					String.join(", ", deliveredWeapons));
			anyProduction = true;
		}

		if (!trainingExpeditionLoot.isEmpty()) {
			info.addPara("Training Expeditions found: %s.", pad, h, String.join("; ", trainingExpeditionLoot));
			anyProduction = true;
		}

		if (upkeepCharged > 0f) {
			info.addPara("Station upkeep cost %s credits.", pad, bad, fmt(upkeepCharged));
			anyProduction = true;
		}

		if (!anyProduction) {
			info.addPara("Nothing of note to report.", pad);
		}
	}

	private static List<String> getModulesBuiltSummary(SectorEntityToken station) {
		List<String> lines = new ArrayList<String>();

		if (MiningHangarModule.isBuilt(station)) {
			lines.add("Materials Acquisition Hub" + (MiningHangarModule.hasBoreInstalled(station)
					? " (Autonomous Mantle Bore)" : ""));
		}

		if (RecreationalHubModule.isBuilt(station)) {
			List<String> items = new ArrayList<String>();
			if (RecreationalHubModule.hasHolosuiteInstalled(station)) items.add("Dealmaker Holosuite");
			if (RecreationalHubModule.hasFusionLampInstalled(station)) items.add("Orbital Fusion Lamp");
			lines.add("Resort" + (items.isEmpty() ? "" : " (" + String.join(", ", items) + ")"));
		}

		if (IndustrialHubModule.isBuilt(station)) {
			List<String> items = new ArrayList<String>();
			if (IndustrialHubModule.hasNanoforgeInstalled(station)) items.add("Nanoforge");
			if (IndustrialHubModule.hasBiofactoryInstalled(station)) items.add("Biofactory Embryo");
			if (IndustrialHubModule.hasFusionLampInstalled(station)) items.add("Orbital Fusion Lamp");
			if (IndustrialHubModule.hasCatalyticCoreInstalled(station)) items.add("Catalytic Core");
			lines.add("Manufactorium" + (items.isEmpty() ? "" : " (" + String.join(", ", items) + ")"));
		}

		if (HydroponicsHubModule.isBuilt(station)) {
			lines.add("Bio-Dome" + (HydroponicsHubModule.hasNanitesInstalled(station) ? " (Soil Nanites)" : ""));
		}

		if (AssemblyBayModule.isBuilt(station)) {
			List<String> items = new ArrayList<String>();
			if (AssemblyBayModule.hasNanoforgeInstalled(station)) items.add("Nanoforge");
			if (AssemblyBayModule.hasAlphaCoreInstalled(station) && AssemblyBayModule.hasCryoarithmeticEngineInstalled(station)) {
				items.add("Dedicated AI System");
			}
			lines.add("Strategic Assembly" + (items.isEmpty() ? "" : " (" + String.join(", ", items) + ")"));
		}

		if (MilitaryWardModule.isBuilt(station)) {
			List<String> items = new ArrayList<String>();
			if (MilitaryWardModule.hasHolosuiteInstalled(station)) items.add("Holosuite");
			if (MilitaryWardModule.hasDroneReplicatorInstalled(station)) items.add("Combat Drone Replicator");
			String coreTier = MilitaryWardModule.getInstalledAICoreTier(station);
			if (Commodities.ALPHA_CORE.equals(coreTier)) items.add("Alpha Core");
			else if (Commodities.BETA_CORE.equals(coreTier)) items.add("Beta Core");
			else if (Commodities.GAMMA_CORE.equals(coreTier)) items.add("Gamma Core");
			if (MilitaryWardModule.hasTrainingExpeditionsInstalled(station)) {
				items.add("Training Expeditions (" + MilitaryWardModule.getTrainingExpeditionBayCount(station)
						+ "/" + MilitaryWardModule.MAX_TRAINING_EXPEDITION_BAYS + " bays)");
			}
			lines.add("Military Paradigm" + (items.isEmpty() ? "" : " (" + String.join(", ", items) + ")"));
		}

		if (StationItemsModule.hasDroneReplicatorInstalled(station)) {
			lines.add("Combat Drone Replicator (station-wide)");
		}

		return lines;
	}

	private static String fmt(float value) {
		return "" + (int) value;
	}
}
