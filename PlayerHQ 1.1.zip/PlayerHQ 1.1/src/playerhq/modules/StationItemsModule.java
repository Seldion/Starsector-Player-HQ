package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class StationItemsModule {

	public static final String DRONE_REPLICATOR_MEMORY_KEY = "$playerhq_stationitem_dronereplicator";
	public static final String DRONE_REPLICATOR_DEFENSE_MARKET_KEY = "$playerhq_stationitem_dronereplicator_market";
	private static final String DRONE_REPLICATOR_DEFENSE_MOD_ID = "playerhq_drone_replicator_defense";

	public static final float DRONE_REPLICATOR_RECREATION_BONUS = 0.10f;
	public static final float DRONE_REPLICATOR_MINING_BONUS = 0.05f;
	public static final float DRONE_REPLICATOR_DEFENSE_BONUS = 0.5f;
	public static final int DRONE_REPLICATOR_HYDROPONICS_BONUS_ECON_UNITS = 1;

	// -- Accessibility: a station-wide stat that scales the Resort's income. Starts at a base
	// of 25% (meaning the Resort only realizes 25% of its base income) and is improved by
	// station-wide upgrades. At 100% the Resort earns its full base income; each point above
	// that keeps scaling income up further.
	public static final String SPACE_ELEVATOR_MEMORY_KEY = "$playerhq_stationitem_spaceelevator";
	public static final String PUBLIC_SHUTTLES_MEMORY_KEY = "$playerhq_stationitem_publicshuttles";

	public static final float BASE_ACCESSIBILITY = 25f;
	public static final float SPACE_ELEVATOR_ACCESSIBILITY_BONUS = 50f;
	public static final float PUBLIC_SHUTTLES_ACCESSIBILITY_BONUS = 25f;

	/** The player's own Industrial Planning skill treats the station like one of their colonies for this bonus. */
	public static final float INDUSTRIAL_PLANNING_ACCESSIBILITY_BONUS = 15f;

	public static final float SPACE_ELEVATOR_METALS_COST = 2000f;
	public static final float SPACE_ELEVATOR_TRANSPLUTONICS_COST = 500f;
	public static final float SPACE_ELEVATOR_HEAVY_MACHINERY_COST = 100f;

	public static final float PUBLIC_SHUTTLES_METALS_COST = 1000f;
	public static final float PUBLIC_SHUTTLES_TRANSPLUTONICS_COST = 250f;
	public static final float PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST = 50f;

	public static float getAccessibility(SectorEntityToken station) {
		float accessibility = BASE_ACCESSIBILITY;
		if (hasSpaceElevatorInstalled(station)) accessibility += SPACE_ELEVATOR_ACCESSIBILITY_BONUS;
		if (hasPublicShuttlesInstalled(station)) accessibility += PUBLIC_SHUTTLES_ACCESSIBILITY_BONUS;
		if (hasIndustrialPlanningSkill()) accessibility += INDUSTRIAL_PLANNING_ACCESSIBILITY_BONUS;
		return accessibility;
	}

	public static float getAccessibilityMultiplier(SectorEntityToken station) {
		return getAccessibility(station) / 100f;
	}

	/** Whether the player character currently has the Industrial Planning skill. */
	public static boolean hasIndustrialPlanningSkill() {
		return Global.getSector().getPlayerStats() != null
				&& Global.getSector().getPlayerStats().getSkillLevel(Skills.INDUSTRIAL_PLANNING) > 0;
	}

	public static boolean hasSpaceElevatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(SPACE_ELEVATOR_MEMORY_KEY);
	}

	/** @deprecated fleet-cargo-only check, left in case anything external still calls it -- use the combined check below instead. */
	public static boolean hasSpaceElevatorInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.FULLERENE_SPOOL, null)) >= 1;
	}

	public static boolean hasSpaceElevatorCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.FULLERENE_SPOOL)
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= SPACE_ELEVATOR_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= SPACE_ELEVATOR_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= SPACE_ELEVATOR_HEAVY_MACHINERY_COST;
	}

	public static void installSpaceElevator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSpaceElevatorCost(station, playerFleet)) return;
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.FULLERENE_SPOOL, 1);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, SPACE_ELEVATOR_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, SPACE_ELEVATOR_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, SPACE_ELEVATOR_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, true);
	}

	/** Dismantle-time refund -- the station is going away, so this still goes to the fleet's cargo. */
	public static void refundSpaceElevator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSpaceElevatorInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FULLERENE_SPOOL, null), 1);
		cargo.addCommodity(Commodities.METALS, SPACE_ELEVATOR_METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, SPACE_ELEVATOR_TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, SPACE_ELEVATOR_HEAVY_MACHINERY_COST * fraction);
		station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, false);
	}

	/** Uninstalling (not dismantling) returns half the build resources and the special item to the station's own inventory instead. */
	public static void uninstallSpaceElevator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSpaceElevatorInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FULLERENE_SPOOL, null), 1);
			storage.addCommodity(Commodities.METALS, SPACE_ELEVATOR_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, SPACE_ELEVATOR_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.HEAVY_MACHINERY, SPACE_ELEVATOR_HEAVY_MACHINERY_COST * fraction);
		}
		station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, false);
	}

	public static boolean hasPublicShuttlesInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(PUBLIC_SHUTTLES_MEMORY_KEY);
	}

	public static boolean hasPublicShuttlesCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= PUBLIC_SHUTTLES_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= PUBLIC_SHUTTLES_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST;
	}

	public static void installPublicShuttles(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasPublicShuttlesCost(station, playerFleet)) return;
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, PUBLIC_SHUTTLES_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, PUBLIC_SHUTTLES_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, true);
	}

	/** Dismantle-time refund -- the station is going away, so this still goes to the fleet's cargo. */
	public static void refundPublicShuttles(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasPublicShuttlesInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.addCommodity(Commodities.METALS, PUBLIC_SHUTTLES_METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, PUBLIC_SHUTTLES_TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST * fraction);
		station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, false);
	}

	/** Uninstalling (not dismantling) returns half the build resources to the station's own inventory instead. */
	public static void uninstallPublicShuttles(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasPublicShuttlesInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(Commodities.METALS, PUBLIC_SHUTTLES_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, PUBLIC_SHUTTLES_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.HEAVY_MACHINERY, PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST * fraction);
		}
		station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, false);
	}

	public static boolean hasDroneReplicatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR);
	}

	public static void installDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, true);
		updateDroneReplicatorDefenseBonus(station);
	}

	/** Dismantle-time refund -- the station is going away, so this still goes to the fleet's cargo. */
	public static void refundDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasDroneReplicatorInstalled(station)) return;

		playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, false);
		clearDroneReplicatorDefenseBonus(station);
	}

	/** Uninstalling (not dismantling) deposits the item into the station's own inventory instead. */
	public static void uninstallDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasDroneReplicatorInstalled(station)) return;

		PlayerHQUtils.addToStationInventory(station, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, false);
		clearDroneReplicatorDefenseBonus(station);
	}

	private static void clearDroneReplicatorDefenseBonus(SectorEntityToken station) {
		String marketId = station.getMemoryWithoutUpdate().getString(DRONE_REPLICATOR_DEFENSE_MARKET_KEY);
		if (marketId == null) return;

		MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);
		if (market != null) {
			market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(DRONE_REPLICATOR_DEFENSE_MOD_ID);
		}
		station.getMemoryWithoutUpdate().unset(DRONE_REPLICATOR_DEFENSE_MARKET_KEY);
	}

	/**
	 * Moves the ground defenses bonus to whatever colonized planet the station is currently
	 * orbiting (if any), removing it from wherever it was previously applied. Meant to be
	 * called on install and once every monthly tick, since the station's orbit can change
	 * between ticks.
	 */
	public static void updateDroneReplicatorDefenseBonus(SectorEntityToken station) {
		clearDroneReplicatorDefenseBonus(station);

		if (!hasDroneReplicatorInstalled(station)) return;

		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return;

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(
				DRONE_REPLICATOR_DEFENSE_MOD_ID, 1f + DRONE_REPLICATOR_DEFENSE_BONUS, "Combat Drone Replicator (Player HQ)");
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_DEFENSE_MARKET_KEY, market.getId());
	}
}
