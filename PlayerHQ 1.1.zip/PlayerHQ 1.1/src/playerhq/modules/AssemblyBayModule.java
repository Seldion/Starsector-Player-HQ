package playerhq.modules;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignClockAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI.ShipTypeHints;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.ListMap;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class AssemblyBayModule {

	public static final String MEMORY_KEY = "$playerhq_module_assembly";
	public static final String NANOFORGE_MEMORY_KEY = "$playerhq_module_assembly_nanoforge";
	public static final String NANOFORGE_ITEM_KEY = "$playerhq_module_assembly_nanoforge_item";
	public static final String ALPHACORE_MEMORY_KEY = "$playerhq_module_assembly_alphacore";
	public static final String CRYOARITHMETIC_MEMORY_KEY = "$playerhq_module_assembly_cryoarithmetic";
	public static final String POOL_MEMORY_KEY = "$playerhq_module_assembly_pool";

	public static final float CREDIT_COST = 50000f;
	public static final float METALS_COST = 10000f;
	public static final float TRANSPLUTONICS_COST = 5000f;
	public static final float VOLATILES_COST = 2000f;
	public static final float HEAVY_MACHINERY_COST = 1000f;

	public static final float POOL_MAX = 1000000f;
	public static final float POOL_MONTHLY_BASE = 10000f;
	public static final float POOL_MONTHLY_WITH_BONUS = 20000f;

	public static final float CORRUPTED_NANOFORGE_DISCOUNT = 0.15f;
	public static final float PRISTINE_NANOFORGE_DISCOUNT = 0.30f;

	public static final float ALPHA_CORE_COST = 1f;

	public static final String IMAGE_PATH = "graphics/modules/assembly_bay.jpg";

	public static final String QUEUE_MEMORY_KEY = "$playerhq_module_assembly_queue";
	public static final String DELIVERED_SHIPS_KEY = "$playerhq_module_assembly_delivered_ships";
	public static final String DELIVERED_WEAPONS_KEY = "$playerhq_module_assembly_delivered_weapons";

	/** 1 day of build time per 5,000 credits of an item's (discounted) cost. */
	public static final float DAYS_PER_CREDIT_COST = 1f / 5000f;
	public static final float MIN_BUILD_DAYS = 1f;

	/**
	 * A single ship or weapon order sitting in the Strategic Assembly's production line. Credits and
	 * production capacity are charged the moment the order is placed; only the actual delivery of
	 * the finished item into the station's storage is delayed until its build time elapses. Only
	 * one order is ever actively "in production" at a time -- this is a single small production
	 * line, not a full shipyard -- so later orders wait behind it.
	 */
	public static class ProductionOrder implements Serializable {
		private static final long serialVersionUID = 1L;

		public String category; // "ship" or "weapon"
		public String id;
		public String name;
		public float cost;
		public float durationDays;
		public boolean started;
		public long startTimestamp;
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= VOLATILES_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, VOLATILES_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
		station.getMemoryWithoutUpdate().set(POOL_MEMORY_KEY, 0f);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;

		CargoAPI cargo = playerFleet.getCargo();
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);

		if (hasNanoforgeInstalled(station)) {
			String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
			if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
		}
		if (hasAlphaCoreInstalled(station)) {
			cargo.addCommodity(Commodities.ALPHA_CORE, ALPHA_CORE_COST);
		}
		if (hasCryoarithmeticEngineInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null), 1);
		}
	}

	public static boolean hasNanoforgeInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(NANOFORGE_MEMORY_KEY);
	}

	public static boolean hasNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CORRUPTED_NANOFORGE)
				|| PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	public static boolean hasCorruptedNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CORRUPTED_NANOFORGE);
	}

	public static boolean hasPristineNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	public static void installCorruptedNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		installNanoforgeTier(station, playerFleet, Items.CORRUPTED_NANOFORGE);
	}

	public static void installPristineNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		installNanoforgeTier(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	private static void installNanoforgeTier(SectorEntityToken station, CampaignFleetAPI playerFleet, String itemId) {
		if (!PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, itemId)) return;

		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, itemId, 1);
		station.getMemoryWithoutUpdate().set(NANOFORGE_ITEM_KEY, itemId);
		station.getMemoryWithoutUpdate().set(NANOFORGE_MEMORY_KEY, true);
	}

	public static void uninstallNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasNanoforgeInstalled(station)) return;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
		PlayerHQUtils.addToStationInventory(station, itemId, 1);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_ITEM_KEY);
	}

	public static float getNanoforgeDiscount(SectorEntityToken station) {
		if (!hasNanoforgeInstalled(station)) return 0f;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (Items.PRISTINE_NANOFORGE.equals(itemId)) return PRISTINE_NANOFORGE_DISCOUNT;
		return CORRUPTED_NANOFORGE_DISCOUNT;
	}

	public static boolean hasAlphaCoreInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(ALPHACORE_MEMORY_KEY);
	}

	public static boolean hasAlphaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ALPHA_CORE) >= ALPHA_CORE_COST;
	}

	public static boolean hasCryoarithmeticEngineInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(CRYOARITHMETIC_MEMORY_KEY);
	}

	public static boolean hasCryoarithmeticEngineAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CRYOARITHMETIC_ENGINE);
	}

	/**
	 * The Alpha Core and Cryoarithmetic Engine are installed together as a single
	 * combined upgrade -- both items must be on hand, and both are consumed at once.
	 */
	public static boolean hasGenerationBoostAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return hasAlphaCoreAvailable(station, playerFleet) && hasCryoarithmeticEngineAvailable(station, playerFleet);
	}

	public static void installGenerationBoost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasGenerationBoostAvailable(station, playerFleet)) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.ALPHA_CORE, ALPHA_CORE_COST);
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.CRYOARITHMETIC_ENGINE, 1);
		station.getMemoryWithoutUpdate().set(ALPHACORE_MEMORY_KEY, true);
		station.getMemoryWithoutUpdate().set(CRYOARITHMETIC_MEMORY_KEY, true);
	}

	public static void uninstallGenerationBoost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!(hasAlphaCoreInstalled(station) && hasCryoarithmeticEngineInstalled(station))) return;

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(Commodities.ALPHA_CORE, ALPHA_CORE_COST);
		}
		PlayerHQUtils.addToStationInventory(station, Items.CRYOARITHMETIC_ENGINE, 1);
		station.getMemoryWithoutUpdate().unset(ALPHACORE_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(CRYOARITHMETIC_MEMORY_KEY);
	}

	public static float getMonthlyGeneration(SectorEntityToken station) {
		return (hasAlphaCoreInstalled(station) && hasCryoarithmeticEngineInstalled(station))
				? POOL_MONTHLY_WITH_BONUS : POOL_MONTHLY_BASE;
	}

	public static float getPoolValue(SectorEntityToken station) {
		if (!isBuilt(station)) return 0f;
		return station.getMemoryWithoutUpdate().getFloat(POOL_MEMORY_KEY);
	}

	private static void setPoolValue(SectorEntityToken station, float value) {
		if (value < 0f) value = 0f;
		if (value > POOL_MAX) value = POOL_MAX;
		station.getMemoryWithoutUpdate().set(POOL_MEMORY_KEY, value);
	}

	/**
	 * Called once per monthly tick to grow the Bay's production capacity.
	 */
	public static void accumulateMonthly(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		setPoolValue(station, getPoolValue(station) + getMonthlyGeneration(station));
	}

	public static float getShipCost(SectorEntityToken station, ShipHullSpecAPI hull) {
		return hull.getBaseValue() * (1f - getNanoforgeDiscount(station));
	}

	public static float getWeaponCost(SectorEntityToken station, WeaponSpecAPI weapon) {
		return weapon.getBaseValue() * (1f - getNanoforgeDiscount(station));
	}

	public static boolean canAfford(SectorEntityToken station, CampaignFleetAPI playerFleet, float cost) {
		return cost <= getPoolValue(station) && playerFleet.getCargo().getCredits().get() >= cost;
	}

	private static String getFirstVariantId(String hullId) {
		ListMap<String> variantsByHull = Global.getSettings().getHullIdToVariantListMap();
		List<String> variants = variantsByHull.get(hullId);
		if (variants == null || variants.isEmpty()) return null;
		return variants.get(0);
	}

	public static float getBuildDurationDays(float cost) {
		float days = (float) Math.ceil(cost * DAYS_PER_CREDIT_COST);
		return Math.max(MIN_BUILD_DAYS, days);
	}

	@SuppressWarnings("unchecked")
	public static List<ProductionOrder> getQueue(SectorEntityToken station) {
		Object stored = station.getMemoryWithoutUpdate().get(QUEUE_MEMORY_KEY);
		if (stored instanceof List) {
			return new ArrayList<ProductionOrder>((List<ProductionOrder>) stored);
		}
		return new ArrayList<ProductionOrder>();
	}

	private static void setQueue(SectorEntityToken station, List<ProductionOrder> queue) {
		station.getMemoryWithoutUpdate().set(QUEUE_MEMORY_KEY, new ArrayList<ProductionOrder>(queue));
	}

	public static ProductionOrder getActiveOrder(SectorEntityToken station) {
		List<ProductionOrder> queue = getQueue(station);
		return queue.isEmpty() ? null : queue.get(0);
	}

	public static int getQueueLength(SectorEntityToken station) {
		return getQueue(station).size();
	}

	/**
	 * Total days until every order currently in the production line -- the active one plus
	 * everything waiting behind it -- has been delivered.
	 */
	public static float getTotalQueueDaysRemaining(SectorEntityToken station) {
		List<ProductionOrder> queue = getQueue(station);
		if (queue.isEmpty()) return 0f;

		float total = getDaysRemaining(station);
		for (int i = 1; i < queue.size(); i++) {
			total += queue.get(i).durationDays;
		}
		return total;
	}

	/**
	 * Days left on the order currently under construction. Returns its full duration if it hasn't
	 * started yet (still waiting behind an earlier order), or 0 if nothing is queued.
	 */
	public static float getDaysRemaining(SectorEntityToken station) {
		ProductionOrder active = getActiveOrder(station);
		if (active == null) return 0f;
		if (!active.started) return active.durationDays;

		float elapsed = Global.getSector().getClock().getElapsedDaysSince(active.startTimestamp);
		return Math.max(0f, active.durationDays - elapsed);
	}

	private static void enqueue(SectorEntityToken station, ProductionOrder order) {
		List<ProductionOrder> queue = getQueue(station);
		queue.add(order);
		setQueue(station, queue);
	}

	private static void deliverOrder(SectorEntityToken station, ProductionOrder order) {
		if (station.getMarket() == null) return;
		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		if ("ship".equals(order.category)) {
			String variantId = getFirstVariantId(order.id);
			if (variantId != null) {
				storage.addMothballedShip(FleetMemberType.SHIP, variantId, null);
				appendDelivered(station, DELIVERED_SHIPS_KEY, order.name);
			}
		} else if ("weapon".equals(order.category)) {
			storage.addWeapons(order.id, 1);
			appendDelivered(station, DELIVERED_WEAPONS_KEY, order.name);
		}
	}

	@SuppressWarnings("unchecked")
	private static List<String> getStringList(SectorEntityToken station, String key) {
		Object stored = station.getMemoryWithoutUpdate().get(key);
		if (stored instanceof List) {
			return new ArrayList<String>((List<String>) stored);
		}
		return new ArrayList<String>();
	}

	private static void appendDelivered(SectorEntityToken station, String key, String name) {
		List<String> list = getStringList(station, key);
		list.add(name);
		station.getMemoryWithoutUpdate().set(key, list);
	}

	/** Ship names delivered out of the production line since the last time this was cleared. */
	public static List<String> getDeliveredShipsThisMonth(SectorEntityToken station) {
		return getStringList(station, DELIVERED_SHIPS_KEY);
	}

	/** Weapon names delivered out of the production line since the last time this was cleared. */
	public static List<String> getDeliveredWeaponsThisMonth(SectorEntityToken station) {
		return getStringList(station, DELIVERED_WEAPONS_KEY);
	}

	/** Called once the monthly report has read off what was delivered, to start the next month fresh. */
	public static void clearDeliveredThisMonth(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(DELIVERED_SHIPS_KEY);
		station.getMemoryWithoutUpdate().unset(DELIVERED_WEAPONS_KEY);
	}

	/**
	 * Advances the production line by one step: starts the next order's timer if it hasn't begun
	 * yet, or delivers it into storage and moves on if its build time has elapsed. Meant to be
	 * called every tick so the timer is exact rather than snapped to monthly checks.
	 */
	public static void advanceProduction(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		if (station.getMarket() == null) return;

		List<ProductionOrder> queue = getQueue(station);
		if (queue.isEmpty()) return;

		ProductionOrder active = queue.get(0);
		CampaignClockAPI clock = Global.getSector().getClock();

		if (!active.started) {
			active.started = true;
			active.startTimestamp = clock.getTimestamp();
			setQueue(station, queue);
			return;
		}

		float elapsed = clock.getElapsedDaysSince(active.startTimestamp);
		if (elapsed < active.durationDays) return;

		deliverOrder(station, active);
		queue.remove(0);
		setQueue(station, queue);
	}

	public static boolean buildShip(SectorEntityToken station, CampaignFleetAPI playerFleet, String hullId) {
		if (!isBuilt(station)) return false;
		if (station.getMarket() == null) return false;

		ShipHullSpecAPI hull = Global.getSettings().getHullSpec(hullId);
		if (hull == null) return false;
		if (!Global.getSector().getPlayerFaction().knowsShip(hullId)) return false;

		String variantId = getFirstVariantId(hullId);
		if (variantId == null) return false;

		float cost = getShipCost(station, hull);
		if (!canAfford(station, playerFleet, cost)) return false;

		playerFleet.getCargo().getCredits().subtract(cost);
		setPoolValue(station, getPoolValue(station) - cost);

		ProductionOrder order = new ProductionOrder();
		order.category = "ship";
		order.id = hullId;
		order.name = hull.getHullName();
		order.cost = cost;
		order.durationDays = getBuildDurationDays(cost);
		enqueue(station, order);
		return true;
	}

	public static boolean buildWeapon(SectorEntityToken station, CampaignFleetAPI playerFleet, String weaponId) {
		if (!isBuilt(station)) return false;
		if (station.getMarket() == null) return false;

		WeaponSpecAPI weapon = Global.getSettings().getWeaponSpec(weaponId);
		if (weapon == null) return false;
		if (!Global.getSector().getPlayerFaction().knowsWeapon(weaponId)) return false;

		float cost = getWeaponCost(station, weapon);
		if (!canAfford(station, playerFleet, cost)) return false;

		playerFleet.getCargo().getCredits().subtract(cost);
		setPoolValue(station, getPoolValue(station) - cost);

		ProductionOrder order = new ProductionOrder();
		order.category = "weapon";
		order.id = weaponId;
		order.name = weapon.getWeaponName();
		order.cost = cost;
		order.durationDays = getBuildDurationDays(cost);
		enqueue(station, order);
		return true;
	}

	/**
	 * Known, constructible ship hulls, sorted by name for a stable order between
	 * the list being shown and a slot being selected.
	 */
	public static List<ShipHullSpecAPI> getKnownBuildableHulls() {
		List<ShipHullSpecAPI> result = new ArrayList<ShipHullSpecAPI>();

		FactionAPI playerFaction = Global.getSector().getPlayerFaction();
		if (playerFaction == null) return result;

		ListMap<String> variantsByHull = Global.getSettings().getHullIdToVariantListMap();

		for (ShipHullSpecAPI spec : Global.getSettings().getAllShipHullSpecs()) {
			if (spec.isDHull()) continue;

			java.util.EnumSet<ShipTypeHints> hints = spec.getHints();
			if (hints.contains(ShipTypeHints.STATION)) continue;
			if (hints.contains(ShipTypeHints.MODULE)) continue;
			if (hints.contains(ShipTypeHints.UNDER_PARENT)) continue;
			if (hints.contains(ShipTypeHints.HIDE_IN_CODEX)) continue;

			if (!playerFaction.knowsShip(spec.getHullId())) continue;

			List<String> variants = variantsByHull.get(spec.getHullId());
			if (variants == null || variants.isEmpty()) continue;

			result.add(spec);
		}

		Collections.sort(result, new Comparator<ShipHullSpecAPI>() {
			@Override
			public int compare(ShipHullSpecAPI a, ShipHullSpecAPI b) {
				return a.getHullName().compareToIgnoreCase(b.getHullName());
			}
		});

		return result;
	}

	/**
	 * Known, constructible weapons, sorted by name for a stable order between
	 * the list being shown and a slot being selected.
	 */
	public static List<WeaponSpecAPI> getKnownBuildableWeapons() {
		List<WeaponSpecAPI> result = new ArrayList<WeaponSpecAPI>();

		FactionAPI playerFaction = Global.getSector().getPlayerFaction();
		if (playerFaction == null) return result;

		for (WeaponSpecAPI spec : Global.getSettings().getAllWeaponSpecs()) {
			if (!playerFaction.knowsWeapon(spec.getWeaponId())) continue;
			result.add(spec);
		}

		Collections.sort(result, new Comparator<WeaponSpecAPI>() {
			@Override
			public int compare(WeaponSpecAPI a, WeaponSpecAPI b) {
				return a.getWeaponName().compareToIgnoreCase(b.getWeaponName());
			}
		});

		return result;
	}
}
