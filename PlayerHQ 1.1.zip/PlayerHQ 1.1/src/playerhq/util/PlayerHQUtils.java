package playerhq.util;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainPlugin;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidBeltTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import playerhq.abilities.ConstructPlayerHQAbility;

public class PlayerHQUtils {

	public static final float PLANET_CONSTRUCTION_RANGE = 1000f;

	public static final float MIN_JUMP_POINT_DISTANCE = 300f;

	public static float getAngleFromPlayerFleet(SectorEntityToken target, SectorEntityToken playerFleet) {
		float focusX = target.getLocation().x;
		float focusY = target.getLocation().y;
		float playerX = playerFleet.getLocation().x;
		float playerY = playerFleet.getLocation().y;
		float angle = (float) Math.toDegrees(Math.atan2(focusY - playerY, focusX - playerX));
		return angle + 180f;
	}

	public static boolean playerFleetInAsteroidBelt(SectorEntityToken playerFleet) {
		if (playerFleet.getStarSystem() == null) return false;
		for (Object object : playerFleet.getStarSystem().getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) object;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if (plugin instanceof AsteroidBeltTerrainPlugin && !(plugin instanceof AsteroidFieldTerrainPlugin)
					&& plugin.containsEntity(playerFleet)) {
				return true;
			}
		}
		return false;
	}

	public static boolean playerFleetInAsteroidField(SectorEntityToken playerFleet) {
		if (playerFleet.getStarSystem() == null) return false;
		for (Object object : playerFleet.getStarSystem().getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) object;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if (plugin instanceof AsteroidFieldTerrainPlugin && plugin.containsEntity(playerFleet)) {
				return true;
			}
		}
		return false;
	}

	public static SectorEntityToken getFocusOfAsteroidBelt(SectorEntityToken playerFleet) {
		for (Object object : playerFleet.getStarSystem().getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) object;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if (plugin instanceof AsteroidBeltTerrainPlugin && !(plugin instanceof AsteroidFieldTerrainPlugin)
					&& plugin.containsEntity(playerFleet)) {
				return terrain.getOrbitFocus();
			}
		}
		return null;
	}

	public static Float getAsteroidBeltOrbitDays(SectorEntityToken playerFleet) {
		for (Object object : playerFleet.getStarSystem().getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) object;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if (plugin instanceof AsteroidBeltTerrainPlugin && !(plugin instanceof AsteroidFieldTerrainPlugin)
					&& plugin.containsEntity(playerFleet)) {
				AsteroidBeltTerrainPlugin belt = (AsteroidBeltTerrainPlugin) plugin;
				if (belt.params != null) {
					return (belt.params.minOrbitDays + belt.params.maxOrbitDays) / 2f;
				}
			}
		}
		return null;
	}

	public static OrbitAPI getAsteroidFieldOrbit(SectorEntityToken playerFleet) {
		for (Object object : playerFleet.getStarSystem().getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) object;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if (plugin instanceof AsteroidFieldTerrainPlugin && plugin.containsEntity(playerFleet)) {
				return ((AsteroidFieldTerrainPlugin) plugin).getEntity().getOrbit();
			}
		}
		return null;
	}

	public static SectorEntityToken getAsteroidFieldEntity(SectorEntityToken playerFleet) {
		for (Object object : playerFleet.getStarSystem().getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) object;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if (plugin instanceof AsteroidFieldTerrainPlugin && plugin.containsEntity(playerFleet)) {
				return terrain;
			}
		}
		return null;
	}

	public static PlanetAPI getClosestPlanet(CampaignFleetAPI playerFleet) {
		StarSystemAPI system = playerFleet.getStarSystem();
		if (system == null || playerFleet.isInHyperspace() || playerFleet.isInHyperspaceTransition()) {
			return null;
		}

		PlanetAPI closest = null;
		float closestDist = Float.MAX_VALUE;
		for (PlanetAPI planet : system.getPlanets()) {
			if (planet.isStar()) continue;
			float dist = Misc.getDistance(playerFleet, planet);
			if (dist < closestDist) {
				closest = planet;
				closestDist = dist;
			}
		}
		return closest;
	}

	public static boolean playerFleetNearPlanet(CampaignFleetAPI playerFleet) {
		PlanetAPI closest = getClosestPlanet(playerFleet);
		if (closest == null) return false;
		return Misc.getDistance(playerFleet, closest) <= PLANET_CONSTRUCTION_RANGE;
	}

	/**
	 * The colonized planet market a Player HQ station would end up orbiting if built right now, or
	 * null if the fleet isn't near a planet or that planet isn't a real colony -- mirrors the same
	 * checks {@link playerhq.abilities.ConstructPlayerHQAbility#getColonizedOrbitMarket} applies to
	 * an already-built station, but usable before one exists yet.
	 */
	public static com.fs.starfarer.api.campaign.econ.MarketAPI getPreviewOrbitMarket(CampaignFleetAPI playerFleet) {
		if (!playerFleetNearPlanet(playerFleet)) return null;

		PlanetAPI planet = getClosestPlanet(playerFleet);
		if (planet == null) return null;

		com.fs.starfarer.api.campaign.econ.MarketAPI market = planet.getMarket();
		if (market == null) return null;
		if (market.isPlanetConditionMarketOnly()) return null;
		if (market.getSize() <= 0) return null;

		return market;
	}

	public static boolean playerFleetTooCloseToJumpPoint(SectorEntityToken playerFleet) {
		if (playerFleet.getStarSystem() == null) return false;
		for (Object object : playerFleet.getStarSystem().getEntities(JumpPointAPI.class)) {
			JumpPointAPI jp = (JumpPointAPI) object;
			if (Misc.getDistance(playerFleet, jp) < MIN_JUMP_POINT_DISTANCE) {
				return true;
			}
		}
		return false;
	}

	public static boolean entityWithTagExistsAnywhere(String tag) {
		return findFirstEntityWithTagAnywhere(tag) != null;
	}

	public static SectorEntityToken findFirstEntityWithTagAnywhere(String tag) {
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			for (SectorEntityToken entity : system.getEntitiesWithTag(tag)) {
				return entity;
			}
		}
		return null;
	}

	public static void placeStationInOrbit(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (playerFleetNearPlanet(playerFleet)) {
			PlanetAPI planet = getClosestPlanet(playerFleet);
			if (planet != null) {
				float orbitRadius = planet.getRadius() + 300f;
				float orbitAngle = getAngleFromPlayerFleet(planet, playerFleet);
				station.setCircularOrbitPointingDown(planet, orbitAngle, orbitRadius, 30f);
				return;
			}
		}

		if (playerFleetInAsteroidBelt(playerFleet)) {
			SectorEntityToken focus = getFocusOfAsteroidBelt(playerFleet);
			if (focus != null) {
				float orbitRadius = Misc.getDistance(focus, playerFleet);
				float orbitAngle = getAngleFromPlayerFleet(focus, playerFleet);
				Float beltOrbitDays = getAsteroidBeltOrbitDays(playerFleet);
				float orbitDays = beltOrbitDays != null ? beltOrbitDays : Math.max(orbitRadius / 10f, 20f);
				station.setCircularOrbitPointingDown(focus, orbitAngle, orbitRadius, orbitDays);
				return;
			}
		}

		if (playerFleetInAsteroidField(playerFleet)) {
			OrbitAPI asteroidOrbit = getAsteroidFieldOrbit(playerFleet);
			if (asteroidOrbit != null) {
				station.setCircularOrbitWithSpin(asteroidOrbit.getFocus(),
						getAngleFromPlayerFleet(asteroidOrbit.getFocus(), playerFleet),
						Misc.getDistance(playerFleet, asteroidOrbit.getFocus()),
						asteroidOrbit.getOrbitalPeriod(), 5f, 10f);
				return;
			}
			SectorEntityToken fieldEntity = getAsteroidFieldEntity(playerFleet);
			if (fieldEntity != null) {
				station.setCircularOrbitWithSpin(fieldEntity,
						getAngleFromPlayerFleet(fieldEntity, playerFleet),
						Misc.getDistance(playerFleet, fieldEntity), 40f, 5f, 10f);
				return;
			}
		}

		station.setLocation(playerFleet.getLocation().x, playerFleet.getLocation().y);
	}

	/**
	 * A short, factual line describing where the station is currently sitting, for use in reports
	 * -- e.g. "In orbit of Chalcedon in the Askonia system." Mirrors the same orbit checks used
	 * elsewhere (colonized planet / empty planet / asteroid belt or field / adrift with no orbit).
	 */
	public static String getStationLocationSummary(SectorEntityToken station) {
		StarSystemAPI system = station.getStarSystem();
		String systemName = system != null ? system.getBaseName() : "an unknown system";

		MarketAPI colonizedMarket = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (colonizedMarket != null) {
			return "In orbit of " + colonizedMarket.getName() + " in the " + systemName + " system.";
		}

		SectorEntityToken focus = station.getOrbitFocus();
		if (focus instanceof PlanetAPI) {
			return "In orbit of " + focus.getName() + " in the " + systemName + " system.";
		}

		if (focus != null) {
			return "Within an asteroid belt in the " + systemName + " system.";
		}

		return "Adrift in open space in the " + systemName + " system.";
	}

	public static CargoAPI getStationStorageCargo(SectorEntityToken station) {
		if (station == null || station.getMarket() == null) return null;
		return station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
	}

	/** Whether the station's own storage is currently holding any ships. */
	public static boolean hasShipsInStationStorage(SectorEntityToken station) {
		CargoAPI storage = getStationStorageCargo(station);
		if (storage == null) return false;
		return storage.getMothballedShips() != null && storage.getMothballedShips().getNumMembers() > 0;
	}

	/**
	 * Empties the station's storage of everything except ships (which are expected to already be
	 * gone by the time this is called -- dismantling is blocked while any remain) into a floating
	 * cargo pod container at the station's location, so nothing the player left behind is silently
	 * lost when the station itself is removed.
	 */
	public static void jettisonStationStorage(SectorEntityToken station) {
		CargoAPI storage = getStationStorageCargo(station);
		if (storage == null || storage.isEmpty() || station.getContainingLocation() == null) return;

		com.fs.starfarer.api.campaign.CustomCampaignEntityAPI pods =
				com.fs.starfarer.api.util.Misc.addCargoPods(station.getContainingLocation(), station.getLocation());
		pods.getCargo().addAll(storage, false);
	}

	public static float getCombinedCommodityQuantity(SectorEntityToken station, CampaignFleetAPI playerFleet, String commodityId) {
		float total = playerFleet.getCargo().getCommodityQuantity(commodityId);
		CargoAPI storage = getStationStorageCargo(station);
		if (storage != null) {
			total += storage.getCommodityQuantity(commodityId);
		}
		return total;
	}

	public static void removeCombinedCommodity(SectorEntityToken station, CampaignFleetAPI playerFleet, String commodityId, float amount) {
		float remaining = amount;

		CargoAPI storage = getStationStorageCargo(station);
		if (storage != null) {
			float fromStation = Math.min(storage.getCommodityQuantity(commodityId), remaining);
			if (fromStation > 0f) {
				storage.removeCommodity(commodityId, fromStation);
				remaining -= fromStation;
			}
		}

		if (remaining > 0f) {
			playerFleet.getCargo().removeCommodity(commodityId, remaining);
		}
	}

	/**
	 * Special-item (Nanoforge, AI core stand-ins, Holosuite, etc.) quantity combined across the
	 * fleet's cargo and the station's own storage -- lets "install X" actions pull an item the
	 * player already dropped off at the station, not just what's on the ships with them.
	 */
	public static int getCombinedSpecialItemQuantity(SectorEntityToken station, CampaignFleetAPI playerFleet, String itemId) {
		int total = (int) playerFleet.getCargo().getQuantity(CargoItemType.SPECIAL, new SpecialItemData(itemId, null));
		CargoAPI storage = getStationStorageCargo(station);
		if (storage != null) {
			total += (int) storage.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(itemId, null));
		}
		return total;
	}

	public static boolean hasCombinedSpecialItem(SectorEntityToken station, CampaignFleetAPI playerFleet, String itemId) {
		return getCombinedSpecialItemQuantity(station, playerFleet, itemId) >= 1;
	}

	/** Removes from the station's storage first, then the fleet's cargo for any remainder. */
	public static void removeCombinedSpecialItem(SectorEntityToken station, CampaignFleetAPI playerFleet, String itemId, int amount) {
		int remaining = amount;

		CargoAPI storage = getStationStorageCargo(station);
		if (storage != null) {
			int fromStation = Math.min((int) storage.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(itemId, null)), remaining);
			if (fromStation > 0) {
				storage.removeItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), fromStation);
				remaining -= fromStation;
			}
		}

		if (remaining > 0) {
			playerFleet.getCargo().removeItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), remaining);
		}
	}

	/** Uninstalling a module item deposits it into the station's own inventory, not the fleet's cargo hold. */
	public static void addToStationInventory(SectorEntityToken station, String itemId, int amount) {
		CargoAPI storage = getStationStorageCargo(station);
		if (storage != null) {
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), amount);
		}
	}
}
