package com.fs.starfarer.api.impl.campaign.rulecmd;

import playerhq.mode.HQMode;
import java.util.List;
import java.util.Map;

import org.lwjgl.input.Keyboard;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CoreInteractionListener;
import com.fs.starfarer.api.campaign.CoreUITabId;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.VisualPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.util.Misc.Token;
import playerhq.visual.OrderShips;
import playerhq.visual.StarfarerRules;

public class PlayerHqVisualStationCMD extends BaseCommandPlugin {

	private static final String OPT_INVENTORY = "playerhq_v_inventory";
	private static final String OPT_SHIPS = "playerhq_v_ships";
	private static final String OPT_SHOPPING = "playerhq_v_shopping";
	private static final String OPT_CHARTER = "playerhq_v_charter";
	private static final String OPT_DISMANTLE = "playerhq_v_dismantle";
	private static final String OPT_ORDER = "playerhq_v_order_ships";
	private static final String OPT_LEAVE = "playerhq_v_leave";
	private static final String OPT_ESCAPE = "playerhq_v_escape";

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;
	private OptionPanelAPI options;
	private VisualPanelAPI visual;
	private SectorEntityToken station;

	@Override
	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.text = dialog.getTextPanel();
		this.options = dialog.getOptionPanel();
		this.visual = dialog.getVisualPanel();
		this.station = dialog.getInteractionTarget();

		dialog.setOptionOnEscape("Leave", OPT_LEAVE);

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

		if (command.equals("init")) {
			dialog.getVisualPanel().showImageVisual(new com.fs.starfarer.api.InteractionDialogImageVisual(
					"graphics/stations/player_hq_interaction.jpg", 480f, 300f));
			text.addPara("The station floats silently, its automated systems standing ready to receive you.");
			showMainMenu();
		} else if (command.equals("inventory")) {
			showCoreScreen(CoreUITabId.CARGO);
		} else if (command.equals("ships")) {
			showCoreScreen(CoreUITabId.FLEET);
		} else if (command.equals("order")) {
			if (OrderShips.assembly(station) == null) {
				showMainMenu();
			} else {
				dialog.showCustomProductionPicker(new OrderShips.Picker(station, text));
			}
		} else if (command.equals("shopping") || command.equals("charter")) {
			final boolean shopping = command.equals("shopping");
			final SectorEntityToken target = station;
			if (shopping ? !playerhq.shopping.ShoppingAccess.available(target) : !playerhq.charter.CharterAccess.available(target)) {
				showMainMenu();
			} else {
				dialog.dismiss();
				playerhq.visual.PatrolPick.defer(new Runnable() {
					@Override
					public void run() {
						com.fs.starfarer.api.campaign.InteractionDialogPlugin plugin = shopping
								? new playerhq.PlayerHQRemoteShoppingDialogPlugin(target)
								: new playerhq.PlayerHQRemoteCharterDialogPlugin(target);
						Global.getSector().getCampaignUI().showInteractionDialog(plugin, target);
					}
				});
			}
		} else if (command.equals("dismantle")) {
			if (playerhq.visual.TestStation.moduleCount() > 0) {
				showMainMenu();
			} else {
				playerhq.abilities.ConstructPlayerHQAbility.dismantleStation(com.fs.starfarer.api.Global.getSector().getPlayerFleet());
				dialog.dismiss();
			}
		} else if (command.equals("escape")) {
			dialog.dismiss();
		}
		return true;
	}

	private void showMainMenu() {
		options.clearOptions();
		options.addOption("Inventory", OPT_INVENTORY, "Transfer cargo between your fleet and the station's storage.");
		options.addOption("Manage Fleet", OPT_SHIPS, "Store or manage ships using the station's hangar space.");
		boolean assembly = OrderShips.assembly(station) != null;
		playerhq.visual.AssemblyIndustry asm = OrderShips.assembly(station);
		String orderTip = assembly
				? "Order ships, weapons and fighters from the Strategic Assembly. They are delivered to the station's storage as soon as you pay."
				: "Requires the Strategic Assembly. Build one in the Colonies screen.";
		if (assembly && StarfarerRules.on() && asm != null) {
			orderTip += " Order pool: " + (int) asm.pool() + " / " + (int) asm.poolMax() + ". Orders cost credits and must fit inside the pool.";
		}
		options.addOption("Order Ships", OPT_ORDER, orderTip);
		options.setEnabled(OPT_ORDER, assembly);
		boolean shoppingOk = playerhq.shopping.ShoppingAccess.available(station);
		options.addOption("Shopping List", OPT_SHOPPING, shoppingOk
				? "Set a list of ships and items for the Exchange and the Trade Fleet to buy automatically."
				: "Requires the Market Place. Build one in the Colonies screen.");
		options.setEnabled(OPT_SHOPPING, shoppingOk);
		boolean charterOk = playerhq.charter.CharterAccess.available(station);
		options.addOption("Courier Charters", OPT_CHARTER, charterOk
				? "Choose the colonies your Transport Fleets collect from and what each of your locations should be kept stocked with."
				: "Requires a Transport Fleet. Buy one at the Fleet HQ.");
		options.setEnabled(OPT_CHARTER, charterOk);
		options.addOption("Dismantle Player HQ", OPT_DISMANTLE, "Removes the station and returns half of its build materials. Every structure must be removed first.");
		options.setEnabled(OPT_DISMANTLE, playerhq.visual.TestStation.moduleCount() == 0);
		options.addOption("Leave", OPT_LEAVE);

		options.setShortcut(OPT_INVENTORY, Keyboard.KEY_I, false, false, false, true);
		options.setShortcut(OPT_SHIPS, Keyboard.KEY_F, false, false, false, true);
		if (assembly) options.setShortcut(OPT_ORDER, Keyboard.KEY_O, false, false, false, true);
		if (shoppingOk) options.setShortcut(OPT_SHOPPING, Keyboard.KEY_S, false, false, false, true);
		if (charterOk) options.setShortcut(OPT_CHARTER, Keyboard.KEY_C, false, false, false, true);
		options.setShortcut(OPT_LEAVE, Keyboard.KEY_L, false, false, false, true);
		dialog.setPromptText("Player HQ");
	}

	private void showCoreScreen(CoreUITabId tab) {
		options.clearOptions();
		dialog.setPromptText("");
		dialog.setOptionOnEscape(null, null);
		visual.showCore(tab, station, new CoreInteractionListener() {
			@Override
			public void coreUIDismissed() {
				dialog.setOptionOnEscape("Leave", OPT_LEAVE);
				showMainMenu();
			}
		});
	}
}
