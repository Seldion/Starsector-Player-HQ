package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoPickerListener;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import org.lwjgl.input.Keyboard;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * The window shown when a Transport Fleet called for Resupply reaches you, in every mode. Same layout as the Courier
 * Fleet's "Your Fleet" window: Cargo space / Fuel / Crew counters, a confirm button and Done, and
 * Ctrl-click to take all of an item. The fleet offers whatever the station's storage holds, up to
 * what its own holds can carry; what is not taken simply stays in the station's storage. Closing
 * the window sends the fleet straight back.
 */
public class ResupplyMeetingDialogPlugin implements InteractionDialogPlugin {

	private final CargoAPI storage;
	private final float capCargo;
	private final float capFuel;
	private final float capCrew;
	private final Runnable onDone;

	private InteractionDialogAPI dialog;
	private boolean pickerShown = false;
	private boolean finished = false;

	private final Set<String> takeAll = new HashSet<String>();
	private String heldId = null;
	private boolean heldFromSource = false;
	private float heldAmount = 0f;

	public ResupplyMeetingDialogPlugin(CargoAPI storage, float capCargo, float capFuel, float capCrew, Runnable onDone) {
		this.storage = storage;
		this.capCargo = capCargo;
		this.capFuel = capFuel;
		this.capCrew = capCrew;
		this.onDone = onDone;
	}

	private static boolean ctrlDown() {
		try {
			return Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) || Keyboard.isKeyDown(Keyboard.KEY_RCONTROL);
		} catch (Throwable t) {
			return false;
		}
	}

	private CargoAPI offer() {
		CargoAPI offer = Global.getFactory().createCargo(true);
		if (storage == null) return offer;
		offer.addSupplies(Math.min(storage.getSupplies(), capCargo));
		offer.addFuel(Math.min(storage.getFuel(), capFuel));
		offer.addCrew((int) Math.min(storage.getCrew(), capCrew));
		return offer;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		dialog.getTextPanel().addPara("The fleet has brought you the supplies you requested, move what you want "
				+ "from the fleet's holds to your own.");
		dialog.getOptionPanel().addOption("Done", "playerhq_resupply_done");
		dialog.setOptionOnEscape("Done", "playerhq_resupply_done");
	}

	private void finish() {
		if (finished) return;
		finished = true;
		dialog.dismiss();
		if (onDone != null) onDone.run();
	}

	private void showPicker() {
		final CargoAPI offer = offer();
		dialog.getOptionPanel().clearOptions();
		dialog.showCargoPickerDialog("Resupply", "Take", "Done", true, 310f, offer, new CargoPickerListener() {
			@Override
			public void pickedCargo(CargoAPI picked) {
				float supplies = picked.getSupplies();
				float fuel = picked.getFuel();
				int crew = picked.getCrew();
				if (heldFromSource && heldId != null && heldAmount > 0f) {
					if (Commodities.SUPPLIES.equals(heldId)) supplies = Math.max(0f, supplies - heldAmount);
					if (Commodities.FUEL.equals(heldId)) fuel = Math.max(0f, fuel - heldAmount);
					if (Commodities.CREW.equals(heldId)) crew = Math.max(0, crew - (int) heldAmount);
				}
				if (takeAll.contains(Commodities.SUPPLIES)) supplies = offer.getSupplies();
				if (takeAll.contains(Commodities.FUEL)) fuel = offer.getFuel();
				if (takeAll.contains(Commodities.CREW)) crew = offer.getCrew();
				supplies = Math.min(supplies, offer.getSupplies());
				fuel = Math.min(fuel, offer.getFuel());
				crew = Math.min(crew, offer.getCrew());
				if (storage != null) {
					supplies = Math.min(supplies, storage.getSupplies());
					fuel = Math.min(fuel, storage.getFuel());
					crew = Math.min(crew, (int) storage.getCrew());
				}
				CampaignFleetAPI player = Global.getSector().getPlayerFleet();
				if (player != null && storage != null) {
					if (supplies > 0f) {
						storage.removeSupplies(supplies);
						player.getCargo().addSupplies(supplies);
					}
					if (fuel > 0f) {
						storage.removeFuel(fuel);
						player.getCargo().addFuel(fuel);
					}
					if (crew > 0) {
						storage.removeCrew(crew);
						player.getCargo().addCrew(crew);
					}
				}
				takeAll.clear();
				finish();
			}

			@Override
			public void cancelledCargoSelection() {
				takeAll.clear();
				finish();
			}

			@Override
			public void recreateTextPanel(TooltipMakerAPI panel, CargoAPI cargo, CargoStackAPI pickedUp,
					boolean pickedUpFromSource, CargoAPI combined) {
				heldId = null;
				heldFromSource = false;
				heldAmount = 0f;
				float heldSupplies = 0f, heldFuel = 0f;
				int heldCrew = 0;
				if (pickedUp != null && !pickedUp.isNull()) {
					Object data = pickedUp.getData();
					heldId = data == null ? null : String.valueOf(data);
					heldFromSource = pickedUpFromSource;
					if (heldFromSource) heldAmount = pickedUp.getSize();
					if (heldFromSource && heldId != null) {
						if (Commodities.SUPPLIES.equals(heldId)) heldSupplies = pickedUp.getSize();
						if (Commodities.FUEL.equals(heldId)) heldFuel = pickedUp.getSize();
						if (Commodities.CREW.equals(heldId)) heldCrew = (int) pickedUp.getSize();
					}
					if (heldId != null && ctrlDown()) {
						if (heldFromSource) takeAll.add(heldId);
						else takeAll.remove(heldId);
					}
				}

				CampaignFleetAPI player = Global.getSector().getPlayerFleet();
				float cargoFree = player == null ? 0f : Math.max(0f, player.getCargo().getSpaceLeft());
				float fuelFree = player == null ? 0f : Math.max(0, player.getCargo().getFreeFuelSpace());
				int crewFree = player == null ? 0 : Math.max(0, player.getCargo().getFreeCrewSpace());
				float cargoUsed = Math.max(0f, combined.getSupplies() - heldSupplies);
				float fuelUsed = Math.max(0f, combined.getFuel() - heldFuel);
				int crewUsed = Math.max(0, combined.getCrew() - heldCrew);
				boolean over = cargoUsed > cargoFree + 0.01f;
				boolean fuelOver = fuelUsed > fuelFree + 0.01f;
				boolean crewOver = crewUsed > crewFree;

				panel.addPara("The fleet has brought you the supplies you requested, move what you want from the fleet's "
						+ "holds to your own.", 0f);
				panel.addPara("Hold Ctrl and click an item to take all of it. Whatever you leave behind stays in the "
						+ "Player HQ's storage.", 3f);
				panel.addPara("Cargo space: %s / %s", 10f,
						over ? Misc.getNegativeHighlightColor() : Misc.getHighlightColor(),
						"" + (int) cargoUsed, "" + (int) cargoFree);
				panel.addPara("Fuel: %s / %s", 3f,
						fuelOver ? Misc.getNegativeHighlightColor() : Misc.getHighlightColor(),
						"" + (int) fuelUsed, "" + (int) fuelFree);
				panel.addPara("Crew: %s / %s", 3f,
						crewOver ? Misc.getNegativeHighlightColor() : Misc.getHighlightColor(),
						"" + crewUsed, "" + crewFree);
			}
		});
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		finish();
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) {
		if (!pickerShown && !finished) {
			pickerShown = true;
			showPicker();
		}
	}

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
