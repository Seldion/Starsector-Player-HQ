package playerhq.abilities;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.util.IntervalUtil;

import playerhq.mode.HQMode;
import playerhq.visual.FleetKind;
import playerhq.visual.Fleets;

public class CallAbilityGrant implements EveryFrameScript {

	private final IntervalUtil interval = new IntervalUtil(2f, 3f);
	private final String abilityId;
	private boolean done = false;

	public static void install() {
		if (!HQMode.isChosen()) return;
		String id = playerhq.visual.CallFleetAbility.ID;
		if (Global.getSector().getCharacterData().getAbilities().contains(id)) return;
		Global.getSector().addTransientScript(new CallAbilityGrant(id));
	}

	private CallAbilityGrant(String abilityId) {
		this.abilityId = abilityId;
	}

	@Override
	public boolean isDone() {
		return done;
	}

	@Override
	public boolean runWhilePaused() {
		return false;
	}

	@Override
	public void advance(float amount) {
		interval.advance(amount);
		if (!interval.intervalElapsed()) return;
		if (!ready()) return;
		Global.getSector().getCharacterData().addAbility(abilityId);
		done = true;
	}

	private boolean ready() {
		return Fleets.owned(FleetKind.LOGISTICS) > 0;
	}
}
