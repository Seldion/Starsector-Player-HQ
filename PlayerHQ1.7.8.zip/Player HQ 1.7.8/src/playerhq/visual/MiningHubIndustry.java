package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class MiningHubIndustry extends ModuleStructure implements MonthlyProducer {

	public static final float EFFICIENCY = 0.20f;
	public static final int ECON_UNIT_VALUE = 400;

	public static final float[] AI_BONUS = { 0.05f, 0.10f, 0.15f };

	private static final int[] ORE_TIER_MODIFIERS = { 0, -1, 0, 1, 2, 3 };
	private static final int[] FOUR_TIER_MODIFIERS = { 0, -1, 0, 1, 2 };

	private static int tierOre(MarketAPI m, String a, String b, String c, String d, String e) {
		if (m.hasCondition(e)) return 5;
		if (m.hasCondition(d)) return 4;
		if (m.hasCondition(c)) return 3;
		if (m.hasCondition(b)) return 2;
		if (m.hasCondition(a)) return 1;
		return 0;
	}

	private static int tierFour(MarketAPI m, String a, String b, String c, String d) {
		if (m.hasCondition(d)) return 4;
		if (m.hasCondition(c)) return 3;
		if (m.hasCondition(b)) return 2;
		if (m.hasCondition(a)) return 1;
		return 0;
	}

	private MarketAPI orbitedPlanetMarket() {
		if (market == null) return null;
		SectorEntityToken entity = market.getPrimaryEntity();
		if (entity == null) return null;
		SectorEntityToken focus = entity.getOrbitFocus();
		if (!(focus instanceof PlanetAPI)) return null;
		return ((PlanetAPI) focus).getMarket();
	}

	private boolean inBeltOrField() {
		if (market == null) return false;
		SectorEntityToken entity = market.getPrimaryEntity();
		if (entity == null) return false;
		SectorEntityToken focus = entity.getOrbitFocus();
		return focus != null && !(focus instanceof PlanetAPI);
	}

	private static int tierOf(String coreId) {
		if (Commodities.GAMMA_CORE.equals(coreId)) return 0;
		if (Commodities.BETA_CORE.equals(coreId)) return 1;
		if (Commodities.ALPHA_CORE.equals(coreId)) return 2;
		return -1;
	}

	public float aiMult() {
		int t = tierOf(getAICoreId());
		return t < 0 ? 1f : 1f + AI_BONUS[t];
	}

	public float[] expected() {
		float[] out = new float[4];
		float unit = ECON_UNIT_VALUE * EFFICIENCY;
		MarketAPI m = orbitedPlanetMarket();
		if (m != null) {
			int ore = tierOre(m, Conditions.ORE_SPARSE, Conditions.ORE_MODERATE, Conditions.ORE_ABUNDANT,
					Conditions.ORE_RICH, Conditions.ORE_ULTRARICH);
			int rare = tierOre(m, Conditions.RARE_ORE_SPARSE, Conditions.RARE_ORE_MODERATE, Conditions.RARE_ORE_ABUNDANT,
					Conditions.RARE_ORE_RICH, Conditions.RARE_ORE_ULTRARICH);
			int vol = tierFour(m, Conditions.VOLATILES_TRACE, Conditions.VOLATILES_DIFFUSE, Conditions.VOLATILES_ABUNDANT,
					Conditions.VOLATILES_PLENTIFUL);
			int org = tierFour(m, Conditions.ORGANICS_TRACE, Conditions.ORGANICS_COMMON, Conditions.ORGANICS_ABUNDANT,
					Conditions.ORGANICS_PLENTIFUL);
			if (ore > 0) out[0] = Math.max(1, ORE_TIER_MODIFIERS[ore]) * unit;
			if (rare > 0) out[1] = Math.max(1, ORE_TIER_MODIFIERS[rare]) * unit;
			if (vol > 0) out[2] = Math.max(1, FOUR_TIER_MODIFIERS[vol]) * unit;
			if (org > 0) out[3] = Math.max(1, FOUR_TIER_MODIFIERS[org]) * unit;
		} else if (inBeltOrField()) {
			out[0] = unit;
			out[1] = unit;
			out[2] = unit;
		}
		float mult = aiMult();
		for (int i = 0; i < out.length; i++) out[i] = (float) Math.floor(out[i] * mult);
		return out;
	}

	@Override
	public boolean canInstallAICores() {
		return true;
	}

	@Override
	protected void applyAICoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void updateAICoreToSupplyAndDemandModifiers() {
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode) {
		if (coreId == null) {
			if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP) {
				tooltip.addPara("No AI core currently assigned. Installing one improves resource gathering.", 0f);
			}
			return;
		}
		int t = tierOf(coreId);
		if (t < 0) return;
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(coreId);
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		text.addPara("%s: Improves resource gathering.", 0f, Misc.getHighlightColor(), spec.getName());
		tooltip.addImageWithText(10f);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		addAICoreSection(tooltip, getAICoreId(), mode);
	}

	@Override
	public String produceMonthly() {
		CargoAPI storage = Production.storage(market);
		if (storage == null) return null;
		float[] e = expected();
		float ore = Production.addCapped(storage, Commodities.ORE, e[0]);
		float rare = Production.addCapped(storage, Commodities.RARE_ORE, e[1]);
		float vol = Production.addCapped(storage, Commodities.VOLATILES, e[2]);
		float org = Production.addCapped(storage, Commodities.ORGANICS, e[3]);
		if (ore + rare + vol + org <= 0f) return null;
		return "sent in a fresh haul";
	}

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		if (mode == IndustryTooltipMode.ADD_INDUSTRY) return;
		if (orbitedPlanetMarket() == null && !inBeltOrField()) {
			tooltip.addPara("The station does not orbit a planet, asteroid belt or asteroid field, so there is nothing to mine.", Misc.getNegativeHighlightColor(), 10f);
			return;
		}
		float[] e = expected();
		if (e[0] + e[1] + e[2] + e[3] <= 0f) {
			tooltip.addPara("No mineable resource deposits detected here.", Misc.getNegativeHighlightColor(), 10f);
			return;
		}
		tooltip.addPara("The drones are hard at work, and what they gather is delivered to the station's storage each month.", 10f);
		sfTips(tooltip, e);
	}

	private void sfTips(TooltipMakerAPI tooltip, float[] e) {
		if (!StarfarerRules.on()) return;
		tooltip.addPara("Expected monthly haul: %s ore, %s rare ore, %s volatiles, %s organics.", 6f, Misc.getHighlightColor(),
				"" + (int) e[0], "" + (int) e[1], "" + (int) e[2], "" + (int) e[3]);
		CargoAPI storage = Production.storage(market);
		if (storage == null) return;
		tooltip.addPara("Current storage: %s/%s ore, %s/%s rare ore, %s/%s volatiles, %s/%s organics.", 3f, Misc.getHighlightColor(),
				"" + (int) storage.getCommodityQuantity(Commodities.ORE), "" + (int) Production.cap(Commodities.ORE),
				"" + (int) storage.getCommodityQuantity(Commodities.RARE_ORE), "" + (int) Production.cap(Commodities.RARE_ORE),
				"" + (int) storage.getCommodityQuantity(Commodities.VOLATILES), "" + (int) Production.cap(Commodities.VOLATILES),
				"" + (int) storage.getCommodityQuantity(Commodities.ORGANICS), "" + (int) Production.cap(Commodities.ORGANICS));
	}
}
