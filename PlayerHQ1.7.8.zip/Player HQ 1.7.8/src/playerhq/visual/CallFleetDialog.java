package playerhq.visual;

import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;

public class CallFleetDialog implements InteractionDialogPlugin {

	private static final String SEND_RESUPPLY = "playerhq_v_send_resupply";
	private static final String SEND_RETRIEVAL = "playerhq_v_send_retrieval";
	private static final String CANCEL = "playerhq_v_call_cancel";

	private InteractionDialogAPI dialog;

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		dialog.setPromptText("Call Fleet");
		boolean busy = Fleets.callBusy();
		dialog.getTextPanel().addPara("Choose what the Transport Fleet is called for. Transport Fleets ready: " + Fleets.readyCount() + ". Calls left: " + Fleets.chargesLeft() + " of " + Fleets.CALL_CHARGES + ".");
		boolean ready = !busy && Fleets.ready(null) != null && Fleets.chargesLeft() > 0;
		dialog.getOptionPanel().addOption("Resupply", SEND_RESUPPLY, "Loads up at the station for a day, then brings you Supplies, Fuel and Crew from the station's storage, up to what its holds can carry.");
		dialog.getOptionPanel().addOption("Transport", SEND_RETRIEVAL, "Loads up at the station for a day, then comes to meet you. Whatever you hand it is deposited into the station's storage as soon as the window closes.");
		dialog.getOptionPanel().setEnabled(SEND_RESUPPLY, ready);
		dialog.getOptionPanel().setEnabled(SEND_RETRIEVAL, ready);
		dialog.getOptionPanel().addOption("Cancel", CANCEL);
		dialog.setOptionOnEscape("Cancel", CANCEL);
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (SEND_RESUPPLY.equals(optionData) || SEND_RETRIEVAL.equals(optionData)) {
			Fleets.call(null, SEND_RESUPPLY.equals(optionData));
		}
		dialog.dismiss();
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
