package playerhq.visual;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class ManufactoriumIndustry extends SlotIndustry implements MonthlyProducer {

	public static class Product {
		public final String key;
		public final String name;
		public final String[] inputs;
		public final float[] amounts;
		public final String output;
		public final float outPerBatch;
		public final boolean refining;

		public Product(String key, String name, String[] inputs, float[] amounts, String output, float outPerBatch, boolean refining) {
			this.key = key;
			this.name = name;
			this.inputs = inputs;
			this.amounts = amounts;
			this.output = output;
			this.outPerBatch = outPerBatch;
			this.refining = refining;
		}
	}

	public static final Product[] PRODUCTS = {
		new Product("metals", "Metals", new String[] { Commodities.ORE }, new float[] { 5f }, Commodities.METALS, 1f, true),
		new Product("transplutonics", "Transplutonics", new String[] { Commodities.RARE_ORE }, new float[] { 5f }, Commodities.RARE_METALS, 1f, true),
		new Product("heavyMachinery", "Heavy Machinery", new String[] { Commodities.METALS, Commodities.RARE_METALS }, new float[] { 10f, 5f }, Commodities.HEAVY_MACHINERY, 10f, false),
		new Product("supplies", "Supplies", new String[] { Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES, Commodities.FOOD }, new float[] { 1f, 1f, 1f, 1f, 1f }, Commodities.SUPPLIES, 15f, false),
		new Product("fuel", "Fuel", new String[] { Commodities.VOLATILES }, new float[] { 1f }, Commodities.FUEL, 10f, false),
		new Product("drugs", "Drugs", new String[] { Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS }, new float[] { 3f, 1f, 1f }, Commodities.DRUGS, 15f, false),
		new Product("organs", "Organs", new String[] { Commodities.ORGANICS }, new float[] { 10f }, Commodities.ORGANS, 5f, false),
		new Product("domesticGoods", "Domestic Goods", new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS }, new float[] { 1f, 1f, 1f }, Commodities.DOMESTIC_GOODS, 10f, false),
		new Product("luxuryGoods", "Luxury Goods", new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS, Commodities.DRUGS }, new float[] { 2f, 1f, 2f, 1f }, Commodities.LUXURY_GOODS, 10f, false),
		new Product("heavyArmaments", "Heavy Armaments", new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES }, new float[] { 10f, 10f, 5f }, Commodities.HAND_WEAPONS, 10f, false)
	};

	public static final float BASE_COST_MULT = 4f;
	public static final float CAP_NONE = 50f;
	public static final float CAP_CORRUPTED = 100f;
	public static final float CAP_PRISTINE = 200f;
	public static final float CAP_REFINING = 1000f;

	protected HashSet<String> off = new HashSet<String>();

	public static final float SF_CAP_NO_ITEM = 50f;
	public static final float SF_CAP_ITEM = 200f;
	public static final float SF_CAP_REFINING = 500f;
	public static final float SF_CAP_REFINING_CATALYTIC = 2000f;
	public static final float SF_NO_ITEM_MULT = 2f;
	public static final float SF_NO_NANOFORGE_MULT = 3f;
	public static final float SF_CORRUPTED_MULT = 2f;
	public static final float SF_CATALYTIC_ORE_REDUCTION = 2f;
	public static final float SF_CATALYTIC_OUTPUT_BONUS = 2f;

	private static final int SLOT_NANOFORGE = 0;
	private static final int SLOT_BIOFACTORY = 1;
	private static final int SLOT_CATALYTIC = 2;
	private static final int SLOT_SYNCHROTRON = 3;

	@Override
	protected String[] slotTitles() {
		if (StarfarerRules.on()) return new String[] { "Nanoforge", "Biofactory Embryo", "Catalytic Core", "Synchrotron Core" };
		return new String[] { "Nanoforge" };
	}

	@Override
	protected String[][] slotAllowed() {
		if (StarfarerRules.on()) {
			return new String[][] { { Items.PRISTINE_NANOFORGE, Items.CORRUPTED_NANOFORGE }, { Items.BIOFACTORY_EMBRYO },
					{ Items.CATALYTIC_CORE }, { Items.SYNCHROTRON } };
		}
		return new String[][] { { Items.PRISTINE_NANOFORGE, Items.CORRUPTED_NANOFORGE } };
	}

	@Override
	protected String slotEffectText(int slot, SpecialItemData data) {
		if (!StarfarerRules.on()) return "Increased monthly production.";
		if (slot == SLOT_NANOFORGE) {
			return Items.PRISTINE_NANOFORGE.equals(data.getId())
					? "Domestic Goods, Luxury Goods and Heavy Armaments cost normal inputs and can make 200 per month."
					: "Domestic Goods, Luxury Goods and Heavy Armaments cost double inputs and can make 200 per month.";
		}
		if (slot == SLOT_BIOFACTORY) return "Drugs and Organs cost normal inputs and can make 200 per month.";
		if (slot == SLOT_CATALYTIC) return "Refining Metals and Transplutonics takes 3 ore for 3 output instead of 5 for 1, with up to 2,000 refined per month.";
		return "Fuel costs normal inputs and can make 200 per month.";
	}

	@Override
	public boolean canInstallAICores() {
		return !StarfarerRules.on();
	}

	@Override
	protected void applyAICoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void updateAICoreToSupplyAndDemandModifiers() {
	}

	public boolean isEnabled(String key) {
		if (off == null) off = new HashSet<String>();
		return !off.contains(key);
	}

	public void setEnabled(String key, boolean enabled) {
		if (off == null) off = new HashSet<String>();
		if (enabled) off.remove(key); else off.add(key);
	}

	public float costMultiplier() {
		String id = getAICoreId();
		if (Commodities.GAMMA_CORE.equals(id)) return 3f;
		if (Commodities.BETA_CORE.equals(id)) return 2f;
		if (Commodities.ALPHA_CORE.equals(id)) return 1f;
		return BASE_COST_MULT;
	}

	public float outputCap() {
		if (slotHas(0, Items.PRISTINE_NANOFORGE)) return CAP_PRISTINE;
		if (slotHas(0, Items.CORRUPTED_NANOFORGE)) return CAP_CORRUPTED;
		return CAP_NONE;
	}

	private float sfMult(String key) {
		if (key.equals("domesticGoods") || key.equals("luxuryGoods") || key.equals("heavyArmaments")) {
			if (slotHas(SLOT_NANOFORGE, Items.PRISTINE_NANOFORGE)) return 1f;
			if (slotHas(SLOT_NANOFORGE, Items.CORRUPTED_NANOFORGE)) return SF_CORRUPTED_MULT;
			return SF_NO_NANOFORGE_MULT;
		}
		if (key.equals("drugs") || key.equals("organs")) return slotItem(SLOT_BIOFACTORY) != null ? 1f : SF_NO_ITEM_MULT;
		if (key.equals("fuel")) return slotItem(SLOT_SYNCHROTRON) != null ? 1f : SF_NO_ITEM_MULT;
		return 1f;
	}

	private float sfCap(String key) {
		if (key.equals("domesticGoods") || key.equals("luxuryGoods") || key.equals("heavyArmaments")) {
			return slotItem(SLOT_NANOFORGE) != null ? SF_CAP_ITEM : SF_CAP_NO_ITEM;
		}
		if (key.equals("drugs") || key.equals("organs")) return slotItem(SLOT_BIOFACTORY) != null ? SF_CAP_ITEM : SF_CAP_NO_ITEM;
		if (key.equals("fuel")) return slotItem(SLOT_SYNCHROTRON) != null ? SF_CAP_ITEM : SF_CAP_NO_ITEM;
		return SF_CAP_ITEM;
	}

	private static float batches(CargoAPI storage, String[] inputs, float[] per, String output, float outPer, float maxBatches) {
		float mb = maxBatches;
		for (int i = 0; i < inputs.length; i++) mb = Math.min(mb, storage.getCommodityQuantity(inputs[i]) / per[i]);
		float space = Production.cap(output) - storage.getCommodityQuantity(output);
		if (space <= 0f) return 0f;
		mb = Math.min(mb, space / outPer);
		float n = (float) Math.floor(mb);
		if (n <= 0f) return 0f;
		for (int i = 0; i < inputs.length; i++) storage.removeCommodity(inputs[i], n * per[i]);
		storage.addCommodity(output, n * outPer);
		return n * outPer;
	}

	private static float refine(CargoAPI storage, String input, float inAmount, String output, float outAmount, float maxOut) {
		float space = Production.cap(output) - storage.getCommodityQuantity(output);
		if (space <= 0f) return 0f;
		float out = Math.min(maxOut, (float) Math.floor(storage.getCommodityQuantity(input) / inAmount) * outAmount);
		out = (float) Math.floor(Math.min(out, space));
		if (out <= 0f) return 0f;
		storage.removeCommodity(input, out / outAmount * inAmount);
		storage.addCommodity(output, out);
		return out;
	}

	private Map<String, Float> runStarfarer(CargoAPI storage) {
		Map<String, Float> result = new LinkedHashMap<String, Float>();
		boolean catalytic = slotItem(SLOT_CATALYTIC) != null;
		for (Product p : PRODUCTS) {
			if (!isEnabled(p.key)) continue;
			float out;
			if (p.refining) {
				float inAmount = catalytic ? p.amounts[0] - SF_CATALYTIC_ORE_REDUCTION : p.amounts[0];
				float outAmount = catalytic ? p.outPerBatch + SF_CATALYTIC_OUTPUT_BONUS : p.outPerBatch;
				out = refine(storage, p.inputs[0], inAmount, p.output, outAmount, catalytic ? SF_CAP_REFINING_CATALYTIC : SF_CAP_REFINING);
			} else {
				float m = sfMult(p.key);
				float[] per = new float[p.amounts.length];
				for (int i = 0; i < per.length; i++) per[i] = p.amounts[i] * m;
				out = batches(storage, p.inputs, per, p.output, p.outPerBatch, sfCap(p.key) / p.outPerBatch);
			}
			if (out > 0f) result.put(p.name, out);
		}
		return result;
	}

	protected Map<String, Float> run(CargoAPI storage) {
		Map<String, Float> result = new LinkedHashMap<String, Float>();
		if (storage == null) return result;
		if (StarfarerRules.on()) return runStarfarer(storage);
		float mult = costMultiplier();
		float cap = outputCap();
		for (Product p : PRODUCTS) {
			if (!isEnabled(p.key)) continue;
			float[] per = new float[p.amounts.length];
			for (int i = 0; i < per.length; i++) per[i] = p.refining ? p.amounts[i] : p.amounts[i] * mult;
			float out = Production.convert(storage, p.inputs, per, p.output, p.outPerBatch, p.refining ? CAP_REFINING : cap);
			if (out > 0f) result.put(p.name, out);
		}
		return result;
	}

	private static String describe(Map<String, Float> m) {
		StringBuilder sb = new StringBuilder();
		for (Map.Entry<String, Float> e : m.entrySet()) {
			if (sb.length() > 0) sb.append(", ");
			sb.append((int) (float) e.getValue()).append(" ").append(e.getKey());
		}
		return sb.toString();
	}

	@Override
	public String produceMonthly() {
		Map<String, Float> r = run(Production.storage(market));
		if (r.isEmpty()) return null;
		return "finished a production run";
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode) {
		if (StarfarerRules.on()) return;
		if (coreId == null) {
			if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP) {
				tooltip.addPara("No AI core currently assigned. Installing one lowers production costs.", 0f);
			}
			return;
		}
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(coreId);
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		text.addPara("%s: Lowers production costs.", 0f, Misc.getHighlightColor(), spec.getName());
		tooltip.addImageWithText(10f);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		addAICoreSection(tooltip, getAICoreId(), mode);
	}

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		if (mode == IndustryTooltipMode.ADD_INDUSTRY) return;
		tooltip.addPara("The assembly lines turn the station's stored materials into goods each month.", 10f);
		CargoAPI storage = Production.storage(market);
		if (storage == null) return;
		Map<String, Float> preview = run(storage.createCopy());
		if (preview.isEmpty()) {
			tooltip.addPara("Nothing can be produced next month from what the station's storage holds.", Misc.getGrayColor(), 3f);
		} else {
			tooltip.addPara("The assembly lines have enough materials to keep running next month.", 3f);
			if (StarfarerRules.on()) tooltip.addPara("Next month's run: %s.", 3f, Misc.getHighlightColor(), describe(preview));
		}
		if (StarfarerRules.on()) {
			tooltip.addPara("Input cost multipliers: Domestic Goods, Luxury Goods and Heavy Armaments %sx, Drugs and Organs %sx, Fuel %sx.", 6f,
					Misc.getHighlightColor(), "" + (int) sfMult("domesticGoods"), "" + (int) sfMult("drugs"), "" + (int) sfMult("fuel"));
			tooltip.addPara("Monthly output limits: Domestic Goods, Luxury Goods and Heavy Armaments %s, Drugs and Organs %s, Fuel %s, Heavy Machinery and Supplies %s.", 3f,
					Misc.getHighlightColor(), "" + (int) sfCap("domesticGoods"), "" + (int) sfCap("drugs"), "" + (int) sfCap("fuel"), "" + (int) sfCap("supplies"));
			boolean cat = slotItem(SLOT_CATALYTIC) != null;
			tooltip.addPara("Refining: %s ore for %s Metals, %s rare ore for %s Transplutonics, up to %s refined a month.", 3f, Misc.getHighlightColor(),
					"" + (int) (cat ? 3 : 5), "" + (int) (cat ? 3 : 1), "" + (int) (cat ? 3 : 5), "" + (int) (cat ? 3 : 1),
					"" + (int) (cat ? SF_CAP_REFINING_CATALYTIC : SF_CAP_REFINING));
		}
	}
}
