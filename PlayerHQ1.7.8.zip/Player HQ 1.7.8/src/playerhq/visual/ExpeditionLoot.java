package playerhq.visual;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.procgen.SalvageEntityGenDataSpec;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageEntity;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class ExpeditionLoot {

	public static final float MAX_SHIP_VALUE = 200000f;
	public static final int MAX_DMODS = 3;
	public static final float SHIP_SPACE = 50f;

	private static final String[] SPECIAL_ITEMS = {
			Items.CORRUPTED_NANOFORGE, Items.PRISTINE_NANOFORGE, Items.SYNCHROTRON,
			Items.ORBITAL_FUSION_LAMP, Items.MANTLE_BORE, Items.CATALYTIC_CORE,
			Items.SOIL_NANITES, Items.BIOFACTORY_EMBRYO, Items.FULLERENE_SPOOL,
			Items.PLASMA_DYNAMO, Items.CRYOARITHMETIC_ENGINE, Items.DRONE_REPLICATOR,
			Items.DEALMAKER_HOLOSUITE,
	};

	private static final String[] BLOCKED_HULLMODS = { "Dynamic Utility System" };

	public static int ruinsTier(MarketAPI market) {
		if (market == null) return 0;
		if (market.hasCondition(Conditions.RUINS_VAST)) return 4;
		if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) return 3;
		if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) return 2;
		if (market.hasCondition(Conditions.RUINS_SCATTERED)) return 1;
		return 0;
	}

	public static float chance(MarketAPI market) {
		int tier = ruinsTier(market);
		if (tier <= 0) return 0f;
		float chance = tier == 4 ? 0.14f : tier == 3 ? 0.06f : tier == 2 ? 0.04f : 0.02f;
		if (Global.getSector().getPlayerStats() != null && Global.getSector().getPlayerStats().getSkillLevel(Skills.SALVAGING) > 0) {
			chance += 0.02f;
		}
		return chance;
	}

	public static float used(CargoAPI hold) {
		if (hold == null) return 0f;
		hold.updateSpaceUsed();
		float used = hold.getSpaceUsed();
		if (hold.getMothballedShips() != null) used += hold.getMothballedShips().getMembersListCopy().size() * SHIP_SPACE;
		return used;
	}

	public static boolean roll(CargoAPI hold, MarketAPI market) {
		float chance = chance(market);
		if (chance <= 0f || Math.random() >= chance) return false;
		return generate(hold) != null;
	}

	private static <T> T pickRandom(List<T> list) {
		if (list == null || list.isEmpty()) return null;
		return list.get((int) (Math.random() * list.size()));
	}

	private static boolean blocked(HullModSpecAPI spec) {
		if (spec == null || spec.getDisplayName() == null) return false;
		for (String name : BLOCKED_HULLMODS) if (name.equalsIgnoreCase(spec.getDisplayName())) return true;
		return false;
	}

	private static HullModSpecAPI randomHullMod() {
		List<HullModSpecAPI> pool = new ArrayList<HullModSpecAPI>();
		for (HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
			if (spec.isHidden() || spec.isHiddenEverywhere() || spec.isAlwaysUnlocked() || spec.hasTag(Tags.HULLMOD_NO_DROP)) continue;
			if (blocked(spec)) continue;
			pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static FighterWingSpecAPI randomFighter() {
		List<FighterWingSpecAPI> pool = new ArrayList<FighterWingSpecAPI>();
		for (FighterWingSpecAPI spec : Global.getSettings().getAllFighterWingSpecs()) {
			if (!spec.isRegularFighter() || spec.hasTag(Tags.NO_DROP)) continue;
			pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static WeaponSpecAPI randomWeapon() {
		List<WeaponSpecAPI> pool = new ArrayList<WeaponSpecAPI>();
		for (WeaponSpecAPI spec : Global.getSettings().getAllWeaponSpecs()) {
			if (spec.hasTag(Tags.NO_DROP)) continue;
			if (spec.getAIHints() != null && spec.getAIHints().contains(WeaponAPI.AIHints.SYSTEM)) continue;
			WeaponAPI.WeaponType type = spec.getType();
			if (type != WeaponAPI.WeaponType.BALLISTIC && type != WeaponAPI.WeaponType.ENERGY
					&& type != WeaponAPI.WeaponType.MISSILE) continue;
			pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static boolean droppable(ShipHullSpecAPI hull) {
		if (hull == null || hull.isDHull()) return false;
		if (hull.hasTag(Tags.NO_DROP)) return false;
		EnumSet<ShipHullSpecAPI.ShipTypeHints> hints = hull.getHints();
		if (hints != null) {
			if (hints.contains(ShipHullSpecAPI.ShipTypeHints.MODULE)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.STATION)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.UNDER_PARENT)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.HIDE_IN_CODEX)) return false;
		}
		return true;
	}

	private static boolean lootableSize(HullSize size) {
		return size == HullSize.FRIGATE || size == HullSize.DESTROYER || size == HullSize.CRUISER || size == HullSize.CAPITAL_SHIP;
	}

	private static List<String> lootableVariants() {
		List<String> result = new ArrayList<String>();
		for (String id : Global.getSettings().getAllVariantIds()) {
			if (id.endsWith("_Hull")) continue;
			ShipVariantAPI variant;
			try {
				variant = Global.getSettings().getVariant(id);
			} catch (Throwable t) {
				continue;
			}
			if (variant == null) continue;
			ShipHullSpecAPI hull = variant.getHullSpec();
			if (!droppable(hull)) continue;
			if (hull.getBaseValue() > MAX_SHIP_VALUE) continue;
			if (!lootableSize(hull.getHullSize())) continue;
			result.add(id);
		}
		return result;
	}

	private static int rollDMods() {
		float roll = (float) Math.random();
		if (roll < 0.01f) return 3;
		if (roll < 0.11f) return 2;
		if (roll < 0.41f) return 1;
		return 0;
	}

	private static String ship(CargoAPI hold) {
		String variantId = pickRandom(lootableVariants());
		if (variantId == null) return null;
		FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, variantId);
		int wanted = rollDMods();
		if (wanted > 0) DModManager.addDMods(member.getVariant(), false, wanted, null);
		int actual = Math.min(DModManager.getNumDMods(member.getVariant()), MAX_DMODS);
		hold.initMothballedShips(Factions.PLAYER);
		hold.getMothballedShips().addFleetMember(member);
		return "1 " + member.getHullSpec().getHullName() + " (ship" + (actual > 0 ? ", " + actual + " D-mod" + (actual > 1 ? "s" : "") : "") + ")";
	}

	private static String drop(CargoAPI hold, String group) {
		for (int attempt = 0; attempt < 5; attempt++) {
			SalvageEntityGenDataSpec.DropData drop = new SalvageEntityGenDataSpec.DropData();
			drop.chances = 1;
			drop.group = group;
			drop.valueMult = 1f;
			List<SalvageEntityGenDataSpec.DropData> random = new ArrayList<SalvageEntityGenDataSpec.DropData>();
			random.add(drop);
			CargoAPI result;
			try {
				result = SalvageEntity.generateSalvage(new java.util.Random(), 1f, 1f, 1f, 1f,
						new ArrayList<SalvageEntityGenDataSpec.DropData>(), random);
			} catch (Throwable t) {
				return null;
			}
			if (result == null) continue;
			List<CargoStackAPI> stacks = result.getStacksCopy();
			if (stacks == null || stacks.isEmpty()) continue;
			StringBuilder line = new StringBuilder();
			for (CargoStackAPI stack : stacks) {
				if (stack == null || stack.isNull()) continue;
				if (stack.isModSpecStack() && blocked(stack.getHullModSpecIfHullMod())) continue;
				hold.addFromStack(stack);
				if (line.length() > 0) line.append(", ");
				line.append((int) stack.getSize()).append(" ").append(stack.getDisplayName());
			}
			if (line.length() > 0) return line.toString();
		}
		return null;
	}

	public static String generate(CargoAPI hold) {
		if (hold == null) return null;
		WeightedRandomPicker<String> picker = new WeightedRandomPicker<String>();
		picker.add("weapon", 40f);
		picker.add("fighter", 28f);
		picker.add("hullmod", 14f);
		picker.add("blueprint", 12f);
		picker.add("ship", 4f);
		picker.add("special", 2f);
		String category = picker.pick();
		if (category == null) return null;
		if (category.equals("weapon")) {
			WeaponSpecAPI spec = randomWeapon();
			if (spec == null) return null;
			hold.addWeapons(spec.getWeaponId(), 1);
			return "1 " + spec.getWeaponName();
		}
		if (category.equals("fighter")) {
			FighterWingSpecAPI spec = randomFighter();
			if (spec == null) return null;
			hold.addFighters(spec.getId(), 1);
			return "1 " + spec.getWingName();
		}
		if (category.equals("hullmod")) {
			String line = drop(hold, "any_hullmod_low");
			if (line != null) return line;
			HullModSpecAPI spec = randomHullMod();
			if (spec == null) return null;
			hold.addHullmods(spec.getId(), 1);
			return "1 " + spec.getDisplayName();
		}
		if (category.equals("blueprint")) return drop(hold, "blueprints_low");
		if (category.equals("ship")) return ship(hold);
		if (category.equals("special")) {
			String itemId = SPECIAL_ITEMS[(int) (Math.random() * SPECIAL_ITEMS.length)];
			hold.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
			SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec(itemId);
			return "1 " + (spec != null ? spec.getName() : itemId);
		}
		return null;
	}
}
