package playerhq.visual;

import java.util.ArrayList;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.events.HostileActivityEventIntel;
import com.fs.starfarer.api.impl.campaign.intel.events.HostileActivityManager;
import com.fs.starfarer.api.util.IntervalUtil;

public class HostileGuard implements EveryFrameScript {

	private static HostileGuard active;

	private final EveryFrameScript original;
	private final IntervalUtil interval = new IntervalUtil(0.02f, 0.04f);
	private boolean onlyStation = false;

	public HostileGuard(EveryFrameScript original) {
		this.original = original;
	}

	public static void install() {
		active = null;
		SectorAPI sector = Global.getSector();
		for (EveryFrameScript e : new ArrayList<EveryFrameScript>(sector.getScripts())) {
			if (e.getClass() == HostileActivityManager.class) {
				sector.removeScript(e);
				active = new HostileGuard(e);
				sector.addTransientScript(active);
				return;
			}
		}
	}

	public static void beforeSave() {
		if (active == null) return;
		Global.getSector().removeTransientScript(active);
		Global.getSector().addScript(active.original);
	}

	public static void afterSave() {
		if (active == null) return;
		Global.getSector().removeScript(active.original);
		Global.getSector().addTransientScript(active);
	}

	private static boolean stationIsOnlyPlayerMarket() {
		SectorEntityToken station = TestStation.find();
		if (station == null || station.getMarket() == null) return false;
		for (MarketAPI m : Global.getSector().getEconomy().getMarketsCopy()) {
			if (m == station.getMarket()) continue;
			if (Factions.PLAYER.equals(m.getFactionId())) return false;
		}
		return true;
	}

	@Override
	public boolean isDone() {
		return original.isDone();
	}

	@Override
	public boolean runWhilePaused() {
		return original.runWhilePaused();
	}

	@Override
	public void advance(float amount) {
		interval.advance(amount);
		if (interval.intervalElapsed()) onlyStation = stationIsOnlyPlayerMarket();
		if (onlyStation) {
			HostileActivityEventIntel intel = HostileActivityEventIntel.get();
			if (intel != null) intel.endImmediately();
			return;
		}
		original.advance(amount);
	}
}
