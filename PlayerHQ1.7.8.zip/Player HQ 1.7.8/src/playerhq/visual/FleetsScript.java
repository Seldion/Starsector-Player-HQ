package playerhq.visual;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.util.IntervalUtil;

public class FleetsScript implements EveryFrameScript {

	private final IntervalUtil interval = new IntervalUtil(1f, 1f);
	private final IntervalUtil quick = new IntervalUtil(0.5f, 0.5f);

	@Override
	public boolean isDone() {
		return false;
	}

	@Override
	public boolean runWhilePaused() {
		return false;
	}

	@Override
	public void advance(float amount) {
		interval.advance(Global.getSector().getClock().convertToDays(amount));
		if (interval.intervalElapsed()) Fleets.advanceDay();
		quick.advance(amount);
		if (quick.intervalElapsed()) {
			Fleets.advanceCall();
			Fleets.advanceReturns();
		}
	}
}
