package playerhq.visual;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Items;

public class MarketPlaceSupport {

	public static final String AGORA = "playerhq_v_agora";
	public static final String EXCHANGE = "playerhq_v_exchange";
	public static final String INDUSTRY = "playerhq_v_marketplace";

	public static final float MAX_MERCHANT_BUDGET = 1000000f;
	public static final String EXTRA_BUDGET_KEY = "$playerhq_v_extra_merchant_budget";

	public static MarketPlaceStructure industry(MarketAPI market) {
		if (market == null) return null;
		com.fs.starfarer.api.campaign.econ.Industry ind = market.getIndustry(INDUSTRY);
		return ind instanceof MarketPlaceStructure ? (MarketPlaceStructure) ind : null;
	}

	public static float findsBonus(MarketAPI market) {
		MarketPlaceStructure s = industry(market);
		return s == null ? 0f : s.findsBonus();
	}

	public static float priceDiscount(MarketAPI market) {
		MarketPlaceStructure s = industry(market);
		return s == null ? 0f : s.priceDiscount();
	}

	public static boolean isBuilt(MarketAPI market) {
		return market != null && market.hasIndustry(INDUSTRY);
	}

	public static void addSubmarkets(MarketAPI market) {
		if (market == null) return;
		if (!market.hasSubmarket(AGORA)) market.addSubmarket(AGORA);
		if (!market.hasSubmarket(EXCHANGE)) market.addSubmarket(EXCHANGE);
	}

	public static void removeSubmarkets(MarketAPI market) {
		if (market == null) return;
		CargoAPI storage = Production.storage(market);
		if (market.hasSubmarket(AGORA)) {
			CargoAPI agora = market.getSubmarket(AGORA).getCargo();
			if (storage != null) {
				storage.addAll(agora);
				FleetDataAPI ships = agora.getMothballedShips();
				if (ships != null) {
					storage.initMothballedShips(com.fs.starfarer.api.impl.campaign.ids.Factions.PLAYER);
					for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships.getMembersListCopy())) {
						ships.removeFleetMember(m);
						storage.getMothballedShips().addFleetMember(m);
					}
				}
			}
			market.removeSubmarket(AGORA);
		}
		if (market.hasSubmarket(EXCHANGE)) market.removeSubmarket(EXCHANGE);
		market.getMemoryWithoutUpdate().unset(EXTRA_BUDGET_KEY);
	}

	public static boolean isDepositable(CargoStackAPI stack) {
		if (stack.isWeaponStack()) return true;
		if (stack.isFighterWingStack()) return true;
		if (stack.isSpecialStack()) {
			SpecialItemData data = stack.getSpecialDataIfSpecial();
			if (data == null) return false;
			String id = data.getId();
			return Items.TAG_MODSPEC.equals(id) || Items.SHIP_BP.equals(id)
					|| Items.WEAPON_BP.equals(id) || Items.FIGHTER_BP.equals(id);
		}
		return false;
	}

	public static float getTotalValue(CargoAPI cargo) {
		float total = 0f;
		for (CargoStackAPI stack : cargo.getStacksCopy()) {
			total += stack.getBaseValuePerUnit() * stack.getSize();
		}
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed != null) {
			for (FleetMemberAPI member : mothballed.getMembersListCopy()) {
				total += member.getBaseSellValue();
			}
		}
		return total;
	}

	public static void addExchangeSpend(MarketAPI market, float amountSpent) {
		if (market == null || amountSpent <= 0f) return;
		float current = market.getMemoryWithoutUpdate().getFloat(EXTRA_BUDGET_KEY);
		market.getMemoryWithoutUpdate().set(EXTRA_BUDGET_KEY, current + amountSpent);
	}

	public static String produceMonthly(MarketAPI market) {
		if (market == null || !market.hasSubmarket(AGORA)) return null;
		if (market.hasSubmarket(EXCHANGE)) {
			try {
				market.getSubmarket(EXCHANGE).getPlugin().updateCargoPrePlayerInteraction();
			} catch (Throwable t) {
				Global.getLogger(MarketPlaceSupport.class).warn("Exchange monthly restock failed", t);
			}
		}
		float income = collectMerchantIncome(market);
		String shipName = null;
		SubmarketAPI agora = market.getSubmarket(AGORA);
		FleetDataAPI mothballed = agora.getCargo().getMothballedShips();
		if (mothballed != null) {
			List<FleetMemberAPI> members = mothballed.getMembersListCopy();
			if (!members.isEmpty()) {
				FleetMemberAPI chosen = members.get((int) (Math.random() * members.size()));
				float credits = chosen.getBaseSellValue();
				shipName = chosen.getHullSpec() != null ? chosen.getHullSpec().getHullName() : "a ship";
				mothballed.removeFleetMember(chosen);
				CampaignFleetAPI pf = Global.getSector().getPlayerFleet();
				if (pf != null) pf.getCargo().getCredits().add(credits);
				income += credits;
			}
		}
		if (income <= 0f) return null;
		String out = "merchants paid " + com.fs.starfarer.api.util.Misc.getDGSCredits(income);
		if (shipName != null) out += " (including the sale of a " + shipName + ")";
		return out;
	}

	public static float collectMerchantIncome(MarketAPI market) {
		float extra = market.getMemoryWithoutUpdate().getFloat(EXTRA_BUDGET_KEY);
		market.getMemoryWithoutUpdate().unset(EXTRA_BUDGET_KEY);

		CargoAPI inventory = market.getSubmarket(AGORA).getCargo();
		if (inventory.isEmpty()) return 0f;

		float budget = (float) Math.random() * MAX_MERCHANT_BUDGET + extra;
		float spent = 0f;

		List<CargoStackAPI> stacks = new ArrayList<CargoStackAPI>(inventory.getStacksCopy());
		Collections.sort(stacks, new Comparator<CargoStackAPI>() {
			@Override
			public int compare(CargoStackAPI a, CargoStackAPI b) {
				return Float.compare(b.getBaseValuePerUnit(), a.getBaseValuePerUnit());
			}
		});

		for (CargoStackAPI stack : stacks) {
			float unitValue = stack.getBaseValuePerUnit();
			if (unitValue <= 0f) continue;
			float remainingBudget = budget - spent;
			if (remainingBudget <= 0f) break;
			float unitsAffordable = (float) Math.floor(remainingBudget / unitValue);
			float unitsToSell = Math.min(stack.getSize(), unitsAffordable);
			if (unitsToSell <= 0f) continue;
			inventory.removeItems(stack.getType(), stack.getData(), unitsToSell);
			spent += unitsToSell * unitValue;
		}

		if (spent <= 0f) return 0f;
		CampaignFleetAPI pf = Global.getSector().getPlayerFleet();
		if (pf != null) pf.getCargo().getCredits().add(spent);
		return spent;
	}
}
