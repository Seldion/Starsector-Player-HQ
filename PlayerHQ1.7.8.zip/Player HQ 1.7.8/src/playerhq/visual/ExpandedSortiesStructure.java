package playerhq.visual;

public class ExpandedSortiesStructure extends ModuleStructure {

	@Override
	public boolean isAvailableToBuild() {
		if (market == null || market.hasIndustry(getId())) return StarfarerRules.on() && super.isAvailableToBuild();
		return StarfarerRules.on() && Fleets.hqBuilt(market) && super.isAvailableToBuild();
	}

	@Override
	public String getUnavailableReason() {
		if (!Fleets.hqBuilt(market)) return "Requires a Fleet HQ";
		return super.getUnavailableReason();
	}

	@Override
	public boolean showWhenUnavailable() {
		if (market != null && !market.hasTag(TestIds.TAG_STATION)) return false;
		return StarfarerRules.on();
	}

	@Override
	public boolean isHidden() {
		return !StarfarerRules.on();
	}

	@Override
	public boolean canShutDown() {
		return Fleets.owned(FleetKind.PATROL) < 2 && super.canShutDown();
	}

	@Override
	public String getCanNotShutDownReason() {
		return Fleets.owned(FleetKind.PATROL) >= 2 ? "Disband the second Patrol Fleet first." : super.getCanNotShutDownReason();
	}
}
