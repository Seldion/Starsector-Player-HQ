package playerhq.visual;

import java.util.Map;

import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class StationAccessCondition extends BaseMarketConditionPlugin {

	public static final String ID = "playerhq_v_station_access";
	public static final String ICON = "graphics/icons/markets/station_access.png";

	@Override
	protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
		Map<String, Float> parts = AccessStructure.breakdown(market);
		float total = 0f;
		for (float v : parts.values()) total += v;
		tooltip.addPara("Accessibility: %s", 10f, Misc.getHighlightColor(), Math.round(total) + "%");
		for (Map.Entry<String, Float> e : parts.entrySet()) {
			tooltip.addPara("%s: %s", 3f, Misc.getHighlightColor(), e.getKey(), "+" + Math.round(e.getValue()) + "%");
		}
	}
}
