package playerhq.visual;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

public class StationFleet {

	public static final int DOCKED = 0;
	public static final int OUT = 1;
	public static final int REBUILD = 2;

	public static final int NONE = 0;
	public static final int CALL = 1;
	public static final int MEETING = 2;
	public static final int RETURN = 3;
	public static final int LOADING = 4;
	public static final int CHARTER = 5;

	public static final int STG_NONE = 0;
	public static final int STG_LOAD = 1;
	public static final int STG_OUT = 2;
	public static final int STG_WORK = 3;
	public static final int STG_DEFEND = 4;

	public FleetKind kind;
	public long paid = 0L;
	public int phase = NONE;
	public boolean resupply = false;
	public long launchStamp = 0L;

	// Courier Charter run (a logistics fleet working a charter line instead of answering a call).
	public int charterId = -1;
	public List<String> charterPlan;
	public List<playerhq.charter.CharterItem> charterNeeds;
	public List<FleetMemberAPI> charterShips;
	public String charterDest;
	public boolean charterDelivering = false;
	public boolean charterWaiting = false;
	public long charterWaitStamp = 0L;
	public CargoAPI hold;
	public CargoAPI pending;
	public float capCargo = 0f;
	public float capFuel = 0f;
	public float capCrew = 0f;
	public int state = DOCKED;
	public float days = 1f;
	public float outDays = 0f;
	public boolean homing = false;
	public List<String> ships = new ArrayList<String>();
	public CampaignFleetAPI fleet;
	public List<ShipVariantAPI> variants;
	public List<ShipVariantAPI> originals;
	public List<String> originalNames;
	public int crewPaid = 0;

	public int stage = STG_NONE;
	public float stageDays = 0f;
	public SectorEntityToken target;
	public MarketAPI targetMarket;
	public float load = 0f;
	public Map<String, Float> carried = new LinkedHashMap<String, Float>();
	public float usedCargo = 0f;
	public float usedFuel = 0f;
	public float usedCrew = 0f;
	public int finds = 0;
	public List<FleetMemberAPI> recovered;
	public boolean hasSpot = false;
	public float spotX = 0f;
	public float spotY = 0f;

	public StationFleet(FleetKind kind) {
		this.kind = kind;
	}
}
