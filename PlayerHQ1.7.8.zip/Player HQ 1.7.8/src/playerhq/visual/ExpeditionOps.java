package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;

public class ExpeditionOps {

	public static final float MAX_RANGE_LY = 10f;
	public static final int MAX_DAYS = 90;
	public static final int ROLL_INTERVAL = 10;

	public static PlanetAPI pickPlanet(SectorEntityToken station) {
		int bestTier = 0;
		float bestDistance = Float.MAX_VALUE;
		PlanetAPI best = null;
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			for (PlanetAPI p : system.getPlanets()) {
				if (p.isStar() || p.getMarket() == null) continue;
				int tier = ExpeditionLoot.ruinsTier(p.getMarket());
				if (tier <= 0) continue;
				float ly = Misc.getDistanceLY(station, p);
				if (ly > MAX_RANGE_LY) continue;
				if (tier > bestTier || (tier == bestTier && ly < bestDistance)) {
					bestTier = tier;
					bestDistance = ly;
					best = p;
				}
			}
		}
		return best;
	}

	public static boolean prepare(SectorEntityToken station, StationFleet f) {
		PlanetAPI planet = pickPlanet(station);
		if (planet == null) return false;
		f.target = planet;
		return true;
	}

	public static void launched(SectorEntityToken station, StationFleet f) {
		f.hold = Global.getFactory().createCargo(true);
		f.hold.initMothballedShips(Factions.PLAYER);
		f.stage = StationFleet.STG_OUT;
		f.stageDays = 0f;
		f.finds = 0;
		Fleets.travel(f.fleet, f.target, "Traveling to " + f.target.getName());
	}

	public static void advance(SectorEntityToken station, StationFleet f) {
		CampaignFleetAPI fleet = f.fleet;
		if (f.target == null) {
			Fleets.sendHome(station, f);
			return;
		}
		if (f.stage == StationFleet.STG_OUT) {
			if (Fleets.arrived(fleet, f.target)) {
				fleet.clearAssignments();
				fleet.setCircularOrbitPointingDown(f.target, (float) (Math.random() * 360f), f.target.getRadius() + 250f, MAX_DAYS * 2f);
				f.stage = StationFleet.STG_WORK;
				f.stageDays = 0f;
				return;
			}
			if (fleet.getCurrentAssignment() == null) Fleets.travel(fleet, f.target, "Traveling to " + f.target.getName());
			return;
		}
		if (f.stage != StationFleet.STG_WORK) {
			Fleets.sendHome(station, f);
			return;
		}
		f.stageDays += 1f;
		if (f.hold == null) f.hold = Global.getFactory().createCargo(true);
		if (Math.round(f.stageDays) % ROLL_INTERVAL == 0 && f.target instanceof PlanetAPI) {
			if (ExpeditionLoot.roll(f.hold, ((PlanetAPI) f.target).getMarket())) f.finds++;
		}
		if (f.stageDays >= MAX_DAYS || ExpeditionLoot.used(f.hold) >= f.capCargo) {
			f.stage = StationFleet.STG_NONE;
			Fleets.sendHome(station, f);
		}
	}

	public static void deliver(SectorEntityToken station, StationFleet f) {
		if (f.hold == null || station.getMarket() == null) return;
		CargoAPI finds = Fleets.finds(station.getMarket());
		finds.addAll(f.hold);
		if (f.hold.getMothballedShips() != null) {
			finds.initMothballedShips(Factions.PLAYER);
			for (FleetMemberAPI m : new java.util.ArrayList<FleetMemberAPI>(f.hold.getMothballedShips().getMembersListCopy())) {
				f.hold.getMothballedShips().removeFleetMember(m);
				finds.getMothballedShips().addFleetMember(m);
			}
		}
	}

	public static String status(StationFleet f) {
		String name = f.target != null ? f.target.getName() : "the ruins";
		if (f.stage == StationFleet.STG_OUT) return "Heading to " + name;
		if (f.stage == StationFleet.STG_WORK) return "Exploring " + name + ", day " + Math.round(f.stageDays) + " of " + MAX_DAYS + ", " + f.finds + " finds";
		return "Out exploring";
	}
}
