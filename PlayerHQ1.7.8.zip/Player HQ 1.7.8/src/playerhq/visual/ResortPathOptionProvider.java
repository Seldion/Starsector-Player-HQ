package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.Industry.IndustryTooltipMode;
import com.fs.starfarer.api.campaign.listeners.DialogCreatorUI;
import com.fs.starfarer.api.campaign.listeners.IndustryOptionProvider;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class ResortPathOptionProvider implements IndustryOptionProvider {

	public static final Object OPTION_ID = "playerhq_v_choose_path";

	@Override
	public List<IndustryOptionData> getIndustryOptions(Industry ind) {
		if (!(ind instanceof ResortIndustry) || !TestIds.INDUSTRY_RESORT.equals(ind.getId())) return null;
		if (ind.isBuilding() || ind.isUpgrading()) return null;
		List<IndustryOptionData> list = new ArrayList<IndustryOptionData>();
		IndustryOptionData data = new IndustryOptionData("Choose Upgrade Path", OPTION_ID, ind, this);
		data.color = Misc.getHighlightColor();
		data.enabled = true;
		list.add(data);
		return list;
	}

	@Override
	public void createTooltip(IndustryOptionData opt, TooltipMakerAPI tooltip, float width) {
		if (opt.id != OPTION_ID) return;
		tooltip.addPara("Upgrade this Resort into a Beach Resort or a Winter Resort.", 0f);
	}

	@Override
	public void optionSelected(IndustryOptionData opt, DialogCreatorUI ui) {
		if (opt.id != OPTION_ID) return;
		ui.showDialog(520f, 250f, new ResortPathDialog(opt.ind));
	}

	@Override
	public void addToIndustryTooltip(Industry ind, IndustryTooltipMode mode, TooltipMakerAPI tooltip, float width, boolean expanded) {
	}
}
