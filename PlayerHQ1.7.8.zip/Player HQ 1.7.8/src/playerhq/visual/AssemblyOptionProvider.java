package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.Industry.IndustryTooltipMode;
import com.fs.starfarer.api.campaign.listeners.DialogCreatorUI;
import com.fs.starfarer.api.campaign.listeners.IndustryOptionProvider;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class AssemblyOptionProvider implements IndustryOptionProvider {

	public static final Object OPTION_INJECT = "playerhq_v_assembly_inject";

	@Override
	public List<IndustryOptionData> getIndustryOptions(Industry ind) {
		if (!(ind instanceof AssemblyIndustry) || !StarfarerRules.on()) return null;
		if (ind.isBuilding() || ind.isUpgrading()) return null;
		List<IndustryOptionData> list = new ArrayList<IndustryOptionData>();
		IndustryOptionData inject = new IndustryOptionData("Inject Credits", OPTION_INJECT, ind, this);
		inject.color = Misc.getHighlightColor();
		inject.enabled = true;
		list.add(inject);
		return list;
	}

	@Override
	public void createTooltip(IndustryOptionData opt, TooltipMakerAPI tooltip, float width) {
		if (opt.id == OPTION_INJECT) {
			tooltip.addPara("Spend credits to fill the order pool directly, at %s credits for every 1 pool credit.", 0f, Misc.getHighlightColor(),
					"" + (int) AssemblyIndustry.CREDITS_PER_POOL_CREDIT);
		}
	}

	@Override
	public void optionSelected(IndustryOptionData opt, DialogCreatorUI ui) {
		if (!(opt.ind instanceof AssemblyIndustry)) return;
		if (opt.id == OPTION_INJECT) ui.showDialog(520f, 380f, new AssemblyDialog((AssemblyIndustry) opt.ind));
	}

	@Override
	public void addToIndustryTooltip(Industry ind, IndustryTooltipMode mode, TooltipMakerAPI tooltip, float width, boolean expanded) {
	}
}
