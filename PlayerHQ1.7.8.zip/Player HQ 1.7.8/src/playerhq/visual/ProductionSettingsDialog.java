package playerhq.visual;

import java.util.LinkedHashMap;
import java.util.Map;

import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class ProductionSettingsDialog implements CustomDialogDelegate {

	private final ManufactoriumIndustry industry;
	private final Map<String, ButtonAPI> boxes = new LinkedHashMap<String, ButtonAPI>();

	public ProductionSettingsDialog(ManufactoriumIndustry industry) {
		this.industry = industry;
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		float w = 500f;
		TooltipMakerAPI el = panel.createUIElement(w, 400f, false);
		el.addSectionHeading("Production Settings", Alignment.MID, 0f);
		el.addPara("Tick the products the Manufactorium should make each month.", Misc.getGrayColor(), 6f);
		for (ManufactoriumIndustry.Product p : ManufactoriumIndustry.PRODUCTS) {
			ButtonAPI b = el.addCheckbox(w - 20f, 24f, p.name, p.key, ButtonAPI.UICheckboxSize.SMALL, 4f);
			b.setChecked(industry.isEnabled(p.key));
			boxes.put(p.key, b);
		}
		panel.addUIElement(el);
	}

	@Override
	public boolean hasCancelButton() {
		return false;
	}

	@Override
	public String getConfirmText() {
		return "Close";
	}

	@Override
	public String getCancelText() {
		return "Cancel";
	}

	@Override
	public void customDialogConfirm() {
		for (Map.Entry<String, ButtonAPI> e : boxes.entrySet()) {
			industry.setEnabled(e.getKey(), e.getValue().isChecked());
		}
	}

	@Override
	public void customDialogCancel() {
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return new BaseCustomUIPanelPlugin() {
			@Override
			public void buttonPressed(Object buttonId) {
				if (!(buttonId instanceof String)) return;
				ButtonAPI b = boxes.get(buttonId);
				if (b != null) industry.setEnabled((String) buttonId, b.isChecked());
			}
		};
	}
}
