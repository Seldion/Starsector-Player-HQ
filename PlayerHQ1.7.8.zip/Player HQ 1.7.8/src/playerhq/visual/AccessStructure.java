package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class AccessStructure extends SlotIndustry {

	public static final String PUBLIC_SHUTTLES = "playerhq_v_public_shuttles";
	public static final String SPACE_ELEVATOR = "playerhq_v_space_elevator";

	public static final float BASE = 25f;
	public static final float SHUTTLES_BONUS = 25f;
	public static final float ELEVATOR_BONUS = 75f;
	public static final float SKILL_BONUS = 15f;
	public static final float SPOOL_BONUS = 15f;
	public static final float[] AI_BONUS = { 5f, 10f, 15f };

	public static float bonusFor(String id) {
		if (PUBLIC_SHUTTLES.equals(id)) return SHUTTLES_BONUS;
		if (SPACE_ELEVATOR.equals(id)) return ELEVATOR_BONUS;
		return 0f;
	}

	public static boolean hasSkill() {
		return Global.getSector().getPlayerStats() != null
				&& Global.getSector().getPlayerStats().getSkillLevel(Skills.INDUSTRIAL_PLANNING) > 0;
	}

	private static int tierOf(String coreId) {
		if (Commodities.GAMMA_CORE.equals(coreId)) return 0;
		if (Commodities.BETA_CORE.equals(coreId)) return 1;
		if (Commodities.ALPHA_CORE.equals(coreId)) return 2;
		return -1;
	}

	private boolean isElevator() {
		return SPACE_ELEVATOR.equals(getId());
	}

	public float extraBonus() {
		float b = 0f;
		int t = tierOf(getAICoreId());
		if (t >= 0) b += AI_BONUS[t];
		if (isElevator() && slotHas(0, Items.FULLERENE_SPOOL)) b += SPOOL_BONUS;
		return b;
	}

	public static float accessibility(MarketAPI market) {
		float a = BASE;
		if (market != null) {
			if (market.hasIndustry(SPACE_ELEVATOR)) a += ELEVATOR_BONUS;
			else if (market.hasIndustry(PUBLIC_SHUTTLES)) a += SHUTTLES_BONUS;
			for (String id : new String[] { PUBLIC_SHUTTLES, SPACE_ELEVATOR }) {
				Industry ind = market.getIndustry(id);
				if (ind instanceof AccessStructure && !(ind.isBuilding() && !ind.isUpgrading())) {
					a += ((AccessStructure) ind).extraBonus();
				}
			}
		}
		if (hasSkill()) a += SKILL_BONUS;
		return a;
	}

	public static boolean resortBuilt(MarketAPI market) {
		if (market == null) return false;
		for (String id : new String[] { TestIds.INDUSTRY_RESORT, TestIds.INDUSTRY_BEACH, TestIds.INDUSTRY_WINTER }) {
			Industry ind = market.getIndustry(id);
			if (ind != null && (!ind.isBuilding() || ind.isUpgrading())) return true;
		}
		return false;
	}

	@Override
	public boolean isAvailableToBuild() {
		if (!super.isAvailableToBuild()) return false;
		if (market == null || !PUBLIC_SHUTTLES.equals(getId()) || market.hasIndustry(getId())) return true;
		return resortBuilt(market);
	}

	@Override
	public boolean showWhenUnavailable() {
		if (!super.showWhenUnavailable()) return false;
		if (market == null || !PUBLIC_SHUTTLES.equals(getId()) || market.hasIndustry(getId())) return true;
		return resortBuilt(market);
	}

	@Override
	public String getUnavailableReason() {
		if (market != null && PUBLIC_SHUTTLES.equals(getId()) && !resortBuilt(market)) return "Requires a Resort.";
		return super.getUnavailableReason();
	}

	public static java.util.LinkedHashMap<String, Float> breakdown(MarketAPI market) {
		java.util.LinkedHashMap<String, Float> want = new java.util.LinkedHashMap<String, Float>();
		if (market == null) return want;
		want.put("Station", BASE);
		if (market.hasIndustry(SPACE_ELEVATOR)) want.put("Space Elevator", ELEVATOR_BONUS);
		else if (market.hasIndustry(PUBLIC_SHUTTLES)) want.put("Public Shuttles", SHUTTLES_BONUS);
		for (String id : new String[] { PUBLIC_SHUTTLES, SPACE_ELEVATOR }) {
			Industry ind = market.getIndustry(id);
			if (!(ind instanceof AccessStructure) || (ind.isBuilding() && !ind.isUpgrading())) continue;
			AccessStructure a = (AccessStructure) ind;
			int t = tierOf(a.getAICoreId());
			if (t >= 0) {
				want.put(Global.getSettings().getCommoditySpec(a.getAICoreId()).getName(), AI_BONUS[t]);
			}
			if (a.isElevator() && a.slotHas(0, Items.FULLERENE_SPOOL)) want.put("Fullerene Spool", SPOOL_BONUS);
		}
		if (hasSkill()) want.put("Industrial Planning", SKILL_BONUS);
		return want;
	}

	@Override
	protected String[] slotTitles() {
		return isElevator() ? new String[] { "Fullerene Spool" } : new String[0];
	}

	@Override
	protected String[][] slotAllowed() {
		return isElevator() ? new String[][] { { Items.FULLERENE_SPOOL } } : new String[0][];
	}

	@Override
	protected String slotEffectText(int slot, SpecialItemData data) {
		return "Improves accessibility";
	}

	@Override
	public boolean canInstallAICores() {
		return true;
	}

	@Override
	protected void applyAICoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void updateAICoreToSupplyAndDemandModifiers() {
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode) {
		if (coreId == null) {
			if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP) {
				tooltip.addPara("No AI core currently assigned. Installing one improves accessibility.", 0f);
			}
			return;
		}
		if (tierOf(coreId) < 0) return;
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(coreId);
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		text.addPara("%s: Improves accessibility.", 0f, Misc.getHighlightColor(), spec.getName());
		tooltip.addImageWithText(10f);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		addAICoreSection(tooltip, getAICoreId(), mode);
	}
}
