package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelAtEntity;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class MilitaryIndustry extends SlotIndustry implements MonthlyProducer {

	public static final float MAX_PERSONNEL = 5000f;
	public static final float CREW_PER_MONTH = 100f;
	public static final float MARINES_PER_MONTH = 50f;
	public static final float CREW_STIPEND = 0.5f;
	public static final float MARINE_STIPEND = 10f;
	public static final float RATE_ONE = 0.03f;
	public static final float DEFENSE_BASE = 0.05f;
	public static final float[] DEFENSE_CORE = { 0.01f, 0.05f, 0.10f };
	public static final float DEFENSE_REPLICATOR = 0.05f;
	public static final float SF_DEFENSE_BASE = 0.20f;
	public static final float[] SF_DEFENSE_CORE = { 0.10f, 0.15f, 0.20f };
	public static final float SF_DEFENSE_REPLICATOR = 0.20f;

	@Override
	protected String[] slotTitles() {
		return new String[] { "Combat Drone Replicator" };
	}

	@Override
	protected String[][] slotAllowed() {
		return new String[][] { { Items.DRONE_REPLICATOR } };
	}

	@Override
	protected String slotEffectText(int slot, SpecialItemData data) {
		return "Allows training of marines and improves colony defense.";
	}

	@Override
	public boolean canInstallAICores() {
		return true;
	}

	@Override
	protected void applyAICoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void updateAICoreToSupplyAndDemandModifiers() {
	}

	public float coreTrainingMult() {
		String id = getAICoreId();
		if (Commodities.GAMMA_CORE.equals(id)) return 2f;
		if (Commodities.BETA_CORE.equals(id)) return 3f;
		if (Commodities.ALPHA_CORE.equals(id)) return 4f;
		return 1f;
	}

	public boolean replicator() {
		return slotHas(0, Items.DRONE_REPLICATOR);
	}

	public float defenseMult() {
		boolean sf = StarfarerRules.on();
		float[] coreBonus = sf ? SF_DEFENSE_CORE : DEFENSE_CORE;
		float m = 1f + (sf ? SF_DEFENSE_BASE : DEFENSE_BASE);
		String core = getAICoreId();
		if (Commodities.GAMMA_CORE.equals(core)) m += coreBonus[0];
		else if (Commodities.BETA_CORE.equals(core)) m += coreBonus[1];
		else if (Commodities.ALPHA_CORE.equals(core)) m += coreBonus[2];
		if (replicator()) m += sf ? SF_DEFENSE_REPLICATOR : DEFENSE_REPLICATOR;
		return m;
	}

	public float trainingRatio() {
		float base = replicator() ? RATE_ONE : 0f;
		return base * coreTrainingMult();
	}

	@Override
	protected void applyIncomeAndUpkeep(float sizeMult) {
		getIncome().unmodify();
		getUpkeep().unmodify();
	}

	@Override
	public String produceMonthly() {
		SubmarketAPI sub = market.getSubmarket(Submarkets.SUBMARKET_STORAGE);
		if (sub == null) return null;
		CargoAPI storage = sub.getCargo();
		int crewAdd = (int) Math.min(CREW_PER_MONTH, Math.max(0f, MAX_PERSONNEL - storage.getCrew()));
		int marAdd = (int) Math.min(MARINES_PER_MONTH, Math.max(0f, MAX_PERSONNEL - storage.getMarines()));
		if (crewAdd > 0) storage.addCrew(crewAdd);
		if (marAdd > 0) storage.addMarines(marAdd);
		applyTraining(sub);
		if (crewAdd + marAdd <= 0) return null;
		return "welcomed a new batch of recruits";
	}

	private void applyTraining(SubmarketAPI sub) {
		float ratio = trainingRatio();
		if (ratio <= 0f) return;
		float marines = sub.getCargo().getMarines();
		if (marines <= 0f) return;
		SectorEntityToken station = market.getPrimaryEntity();
		if (station == null) return;
		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, sub, true);
		if (at == null) return;
		at.data.numMayHaveChanged(marines, true);
		at.data.addXP(ratio * marines);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode) {
		if (coreId == null) {
			if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP) {
				tooltip.addPara("No AI core currently assigned. Installing one improves training efficiency.", 0f);
			}
			return;
		}
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(coreId);
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		text.addPara("%s: Improves training efficiency.", 0f, Misc.getHighlightColor(), spec.getName());
		tooltip.addImageWithText(10f);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		addAICoreSection(tooltip, getAICoreId(), mode);
	}

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		if (mode == IndustryTooltipMode.ADD_INDUSTRY) return;
		tooltip.addPara("Recruits arrive in the station's storage each month. Their stipends are paid as part of the station upkeep.", 10f);
		tooltip.addPara("The marines in the station's storage also help defend the colonized planet the station orbits.", 3f);
		if (trainingRatio() > 0f) {
			tooltip.addPara("The station is training the marines it holds.", 3f);
		} else {
			tooltip.addPara("Install a Combat Drone Replicator to train marines.", Misc.getGrayColor(), 3f);
		}
		if (StarfarerRules.on()) {
			CargoAPI storage = Production.storage(market);
			tooltip.addPara("Each month: %s crew and %s marines arrive, up to %s each in storage.", 6f, Misc.getHighlightColor(),
					"" + (int) CREW_PER_MONTH, "" + (int) MARINES_PER_MONTH, "" + (int) MAX_PERSONNEL);
			if (storage != null) {
				tooltip.addPara("Currently in storage: %s crew and %s marines.", 3f, Misc.getHighlightColor(),
						"" + storage.getCrew(), "" + storage.getMarines());
			}
			tooltip.addPara("Colony defense multiplier: %sx.", 3f, Misc.getHighlightColor(), String.format("%.2f", defenseMult()));
			if (trainingRatio() > 0f) tooltip.addPara("Marine training speed: %sx.", 3f, Misc.getHighlightColor(), String.format("%.2f", trainingRatio() / RATE_ONE));
		}
	}
}
