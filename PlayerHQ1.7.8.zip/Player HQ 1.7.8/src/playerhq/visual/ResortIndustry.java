package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class ResortIndustry extends BaseIndustry {

	@Override
	public float getBuildTime() {
		return StarfarerRules.visualDays(getId(), super.getBuildTime());
	}

	@Override
	public void startBuilding() {
		super.startBuilding();
		buildTime = StarfarerRules.visualDays(getId(), buildTime);
	}

	@Override
	public void startUpgrading() {
		super.startUpgrading();
		buildTime = StarfarerRules.visualDays(getId(), buildTime);
	}

	public static final float[] BASE_INCOME_BY_SIZE = {
			8000f, 16000f, 28000f, 42000f, 62000f, 84000f, 108000f, 134000f, 166000f, 200000f
	};
	public static final String[] IMAGES = {
			"graphics/modules/recreational_hub.jpg",
			"graphics/modules/recreational_hub_2.jpg",
			"graphics/modules/recreational_hub_3.jpg",
			"graphics/modules/recreational_hub_4.jpg",
			"graphics/modules/recreational_hub_5.jpg",
			"graphics/modules/recreational_hub_6.jpg",
			"graphics/modules/recreational_hub_7.jpg"
	};
	public static final float ACCESSIBILITY = 0.25f;
	public static final float UNOWNED_UPKEEP = 20000f;
	public static final float[] AI_BONUS = { 0.05f, 0.10f, 0.15f };

	public String getUpgradeTargetId() {
		return upgradeId;
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		super.addPostDemandSection(tooltip, hasDemand, mode);
		if (mode != IndustryTooltipMode.ADD_INDUSTRY) return;
		String line = StarfarerRules.costLine(getId());
		if (line != null) tooltip.addPara(line, 10f);
	}

	@Override
	public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
		if (!forUpgrade) StarfarerRules.refund(market, getId(), isBuilding() ? 1f : StarfarerRules.REFUND_FRACTION);
		super.notifyBeingRemoved(mode, forUpgrade);
	}

	@Override
	public void apply() {
		super.apply(true);
	}

	protected int getImageOffset() {
		return 0;
	}

	@Override
	public String getCurrentImage() {
		if (market == null) return super.getCurrentImage();
		int n = IMAGES.length;
		int idx = Math.abs((market.getId().hashCode() + getImageOffset()) % n);
		return IMAGES[idx];
	}

	@Override
	public boolean isAvailableToBuild() {
		if (market != null && !market.hasTag(TestIds.TAG_STATION)) return false;
		if (market == null) return true;
		if (market.hasIndustry(getId())) return true;
		return !market.hasIndustry(TestIds.INDUSTRY_BEACH) && !market.hasIndustry(TestIds.INDUSTRY_WINTER)
				&& StarfarerRules.afford(market, getId());
	}

	@Override
	public String getUnavailableReason() {
		if (market != null && (market.hasIndustry(TestIds.INDUSTRY_BEACH) || market.hasIndustry(TestIds.INDUSTRY_WINTER))) {
			return "This station already has an upgraded resort.";
		}
		String lack = StarfarerRules.lacking(market, getId());
		return lack != null ? lack : "This station already has an upgraded resort.";
	}

	@Override
	public boolean showWhenUnavailable() {
		if (market != null && !market.hasTag(TestIds.TAG_STATION)) return false;
		if (market == null) return true;
		return !market.hasIndustry(TestIds.INDUSTRY_BEACH) && !market.hasIndustry(TestIds.INDUSTRY_WINTER);
	}

	@Override
	public float getBuildCost() {
		Float sf = StarfarerRules.credits(getId());
		if (sf != null) return sf;
		return 50000f;
	}

	protected MarketAPI getOrbitedMarket() {
		SectorEntityToken entity = market.getPrimaryEntity();
		if (entity == null) return null;
		SectorEntityToken focus = entity.getOrbitFocus();
		if (!(focus instanceof PlanetAPI)) return null;
		MarketAPI m = ((PlanetAPI) focus).getMarket();
		if (m == null || m == market || m.isPlanetConditionMarketOnly() || m.getSize() < 1) return null;
		return m;
	}

	public float holoBonus() {
		float bonus = 0.10f;
		MarketAPI orbit = market == null ? null : getOrbitedMarket();
		if (orbit != null) bonus = Math.max(bonus, orbit.getHazardValue() - 1f);
		return Math.min(bonus, 1f);
	}

	protected float getItemBonus() {
		SpecialItemData item = getSpecialItem();
		if (item == null || !Items.DEALMAKER_HOLOSUITE.equals(item.getId())) return 0f;
		return holoBonus();
	}

	private static int tierOf(String coreId) {
		if (Commodities.GAMMA_CORE.equals(coreId)) return 0;
		if (Commodities.BETA_CORE.equals(coreId)) return 1;
		if (Commodities.ALPHA_CORE.equals(coreId)) return 2;
		return -1;
	}

	@Override
	public boolean canInstallAICores() {
		return true;
	}

	@Override
	protected void applyAICoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void updateAICoreToSupplyAndDemandModifiers() {
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode) {
		if (coreId == null) {
			if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP) {
				tooltip.addPara("No AI core currently assigned. Installing one improves Resort income.", 0f);
			}
			return;
		}
		int t = tierOf(coreId);
		if (t < 0) return;
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(coreId);
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		text.addPara("%s: Improves Resort income.", 0f, Misc.getHighlightColor(), spec.getName());
		tooltip.addImageWithText(10f);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		addAICoreSection(tooltip, getAICoreId(), mode);
	}

	protected float getClimateBonus(MarketAPI orbit) {
		return 0f;
	}

	protected String getClimateText() {
		return null;
	}

	public float computeIncome() {
		if (market == null) return 0f;
		MarketAPI orbit = getOrbitedMarket();
		if (orbit == null) return 0f;

		int idx = Math.min(orbit.getSize(), BASE_INCOME_BY_SIZE.length) - 1;
		float base = BASE_INCOME_BY_SIZE[idx];
		float total = base;
		total += base * getClimateBonus(orbit);
		total += base * getItemBonus();
		int tier = tierOf(getAICoreId());
		if (tier >= 0) total += base * AI_BONUS[tier];
		return total * AccessStructure.accessibility(market) / 100f;
	}

	@Override
	protected void applyIncomeAndUpkeep(float sizeMult) {
		getIncome().unmodify();
		getUpkeep().unmodify();
	}

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		MarketAPI orbit = getOrbitedMarket();
		if (orbit == null) {
			tooltip.addPara("The station does not orbit a colonized planet, so the resort earns nothing.", Misc.getNegativeHighlightColor(), 10f);
		} else {
			tooltip.addPara("Income comes from %s, a size %s colony.", 10f, Misc.getHighlightColor(),
					orbit.getName(), String.valueOf(orbit.getSize()));
			if (StarfarerRules.on() && mode != IndustryTooltipMode.ADD_INDUSTRY) {
				tooltip.addPara("Currently generating %s credits a month, scaled by the station's accessibility of %s%%.", 3f, Misc.getHighlightColor(),
						"" + (int) computeIncome(), "" + Math.round(AccessStructure.accessibility(market)));
				if (getSpecialItem() == null) {
					tooltip.addPara("Installing VR Suites would raise income by %s%%.", 3f, Misc.getHighlightColor(), "" + Math.round(holoBonus() * 100f));
				}
			}

		}
	}

	@Override
	protected boolean addNonAICoreInstalledItems(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded) {
		SpecialItemData item = getSpecialItem();
		if (item == null) return false;
		SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec(item.getId());
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		float bonus = getItemBonus();
		text.addPara("%s. Increases income.", 0f,
				Misc.getHighlightColor(), spec.getName());
		tooltip.addImageWithText(10f);
		return true;
	}

	@Override
	public List<InstallableIndustryItemPlugin> getInstallableItems() {
		ArrayList<InstallableIndustryItemPlugin> list = new ArrayList<InstallableIndustryItemPlugin>();
		list.add(new ResortItemPlugin(this));
		return list;
	}

	@Override
	public boolean wantsToUseSpecialItem(SpecialItemData data) {
		return data != null && ResortItemPlugin.isResortItem(data.getId());
	}
}
