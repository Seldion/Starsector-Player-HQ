package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class AssemblyIndustry extends SlotIndustry implements MonthlyProducer {

	public static final float POOL_BASE_MAX = 500000f;
	public static final float POOL_MONTHLY_BASE = 10000f;
	public static final float CREDITS_PER_POOL_CREDIT = 10f;
	public static final float[] INJECT_TIERS = { 1000f, 5000f, 25000f, 100000f };
	public static final float[] NANO_CREDITS = { 7500f, 15000f };
	public static final float[] NANO_CAP = { 100000f, 250000f };
	public static final float[] AI_CREDITS = { 1000f, 1500f, 2500f };
	public static final float[] AI_CAP = { 30000f, 75000f, 125000f };
	public static final float COOLING_DISCOUNT = 0.15f;
	public static final float COOLING_CREDITS = 2500f;
	public static final float COOLING_CAP = 125000f;

	public static final float CORRUPTED_DISCOUNT = 0.10f;
	public static final float PRISTINE_DISCOUNT = 0.20f;

	public static final float[] AI_DISCOUNT = { 0.05f, 0.10f, 0.15f };

	protected float pool;

	@Override
	protected String[] slotTitles() {
		if (StarfarerRules.on()) return new String[] { "Nanoforge", "Cooling System" };
		return new String[] { "Nanoforge" };
	}

	@Override
	protected String[][] slotAllowed() {
		if (StarfarerRules.on()) {
			return new String[][] { { Items.PRISTINE_NANOFORGE, Items.CORRUPTED_NANOFORGE }, { Items.CRYOARITHMETIC_ENGINE } };
		}
		return new String[][] { { Items.PRISTINE_NANOFORGE, Items.CORRUPTED_NANOFORGE } };
	}

	@Override
	protected String slotEffectText(int slot, SpecialItemData data) {
		if (!StarfarerRules.on()) return "Costs lowered";
		if (slot == 1) {
			return "Costs lowered by 15%, " + (int) COOLING_CREDITS + " credits a month added to the order pool, and " + (int) COOLING_CAP + " more pool capacity.";
		}
		int t = Items.PRISTINE_NANOFORGE.equals(data.getId()) ? 1 : 0;
		return "Costs lowered by " + (int) ((t == 1 ? PRISTINE_DISCOUNT : CORRUPTED_DISCOUNT) * 100) + "%, " + (int) NANO_CREDITS[t]
				+ " credits a month added to the order pool, and " + (int) NANO_CAP[t] + " more pool capacity.";
	}

	@Override
	protected String slotMenuTitle(int slot, boolean installed) {
		if (!StarfarerRules.on()) return super.slotMenuTitle(slot, installed);
		if (slot == 0) return installed ? "Manage Forges..." : "Improve Forges";
		return installed ? "Manage Cooling System..." : "Install Cooling System";
	}

	@Override
	public boolean canInstallAICores() {
		return true;
	}

	public boolean cooling() {
		return StarfarerRules.on() && slotHas(1, Items.CRYOARITHMETIC_ENGINE);
	}

	public float pool() {
		return pool;
	}

	public float poolMax() {
		float max = POOL_BASE_MAX;
		int n = nanoTier();
		if (n > 0) max += NANO_CAP[n - 1];
		int a = aiTier();
		if (a >= 0) max += AI_CAP[a];
		if (cooling()) max += COOLING_CAP;
		return max;
	}

	public float monthlyGain() {
		float gain = POOL_MONTHLY_BASE;
		int n = nanoTier();
		if (n > 0) gain += NANO_CREDITS[n - 1];
		int a = aiTier();
		if (a >= 0) gain += AI_CREDITS[a];
		if (cooling()) gain += COOLING_CREDITS;
		return gain;
	}

	public void spendPool(float amount) {
		pool = Math.max(0f, pool - amount);
	}

	public float injectable(float requested) {
		return Math.max(0f, Math.min(requested, poolMax() - pool));
	}

	public float inject(float requested) {
		float actual = injectable(requested);
		if (actual <= 0f) return 0f;
		float cost = actual * CREDITS_PER_POOL_CREDIT;
		com.fs.starfarer.api.util.MutableValue credits = Global.getSector().getPlayerFleet().getCargo().getCredits();
		if (credits.get() < cost) return 0f;
		credits.subtract(cost);
		pool += actual;
		return actual;
	}

	@Override
	public String produceMonthly() {
		if (!StarfarerRules.on()) return null;
		float before = pool;
		pool = Math.min(poolMax(), pool + monthlyGain());
		if (pool <= before) return null;
		return "added " + (int) (pool - before) + " credits to the order pool";
	}

	@Override
	protected void applyAICoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void updateAICoreToSupplyAndDemandModifiers() {
	}

	private static int tierOf(String coreId) {
		if (Commodities.GAMMA_CORE.equals(coreId)) return 0;
		if (Commodities.BETA_CORE.equals(coreId)) return 1;
		if (Commodities.ALPHA_CORE.equals(coreId)) return 2;
		return -1;
	}

	public int aiTier() {
		return tierOf(getAICoreId());
	}

	public int nanoTier() {
		if (slotHas(0, Items.PRISTINE_NANOFORGE)) return 2;
		if (slotHas(0, Items.CORRUPTED_NANOFORGE)) return 1;
		return 0;
	}

	public float discount() {
		float d = 0f;
		int n = nanoTier();
		if (n == 2) d += PRISTINE_DISCOUNT;
		else if (n == 1) d += CORRUPTED_DISCOUNT;
		int a = aiTier();
		if (a >= 0) d += AI_DISCOUNT[a];
		if (cooling()) d += COOLING_DISCOUNT;
		return Math.min(1f, d);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode) {
		if (coreId == null) {
			if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP) {
				tooltip.addPara("No AI core currently assigned. Installing one lowers costs.", 0f);
			}
			return;
		}
		int t = tierOf(coreId);
		if (t < 0) return;
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(coreId);
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		if (StarfarerRules.on()) {
			text.addPara("%s: Costs lowered by %s%%, %s credits a month added to the order pool, and %s more pool capacity.", 0f, Misc.getHighlightColor(),
					spec.getName(), "" + (int) (AI_DISCOUNT[t] * 100), "" + (int) AI_CREDITS[t], "" + (int) AI_CAP[t]);
		} else {
			text.addPara("%s: Costs lowered.", 0f, Misc.getHighlightColor(), spec.getName());
		}
		tooltip.addImageWithText(10f);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		addAICoreSection(tooltip, getAICoreId(), mode);
	}

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		if (mode == IndustryTooltipMode.ADD_INDUSTRY) return;
		tooltip.addPara("Order ships, weapons and fighters from the station's main menu, hotkey %s.", 10f,
				Misc.getHighlightColor(), "O");
		if (!StarfarerRules.on()) return;
		tooltip.addPara("Order pool: %s / %s. Gains %s credits a month. Every order has to fit inside the pool and also costs credits.", 6f,
				Misc.getHighlightColor(), "" + (int) pool, "" + (int) poolMax(), "" + (int) monthlyGain());
		tooltip.addPara("Order costs are lowered by %s%%.", 3f, Misc.getHighlightColor(), "" + Math.round(discount() * 100f));
	}
}
