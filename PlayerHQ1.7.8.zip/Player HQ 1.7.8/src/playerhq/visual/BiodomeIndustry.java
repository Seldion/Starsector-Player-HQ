package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class BiodomeIndustry extends SlotIndustry implements MonthlyProducer {

	public static final float FOOD_BASE = 100f;
	public static final float ORGANICS_BASE = 50f;
	public static final float NANITES_FOOD = 250f;
	public static final float NANITES_ORGANICS = 150f;
	public static final float[] AI_BONUS = { 25f, 50f, 150f };

	@Override
	protected String[] slotTitles() {
		return new String[] { "Soil Nanites" };
	}

	@Override
	protected String[][] slotAllowed() {
		return new String[][] { { Items.SOIL_NANITES } };
	}

	@Override
	protected String slotEffectText(int slot, SpecialItemData data) {
		return "Improves Production";
	}

	@Override
	public boolean canInstallAICores() {
		return true;
	}

	@Override
	protected void applyAICoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void updateAICoreToSupplyAndDemandModifiers() {
	}

	private static int tierOf(String coreId) {
		if (Commodities.GAMMA_CORE.equals(coreId)) return 0;
		if (Commodities.BETA_CORE.equals(coreId)) return 1;
		if (Commodities.ALPHA_CORE.equals(coreId)) return 2;
		return -1;
	}

	private float aiBonus() {
		int t = tierOf(getAICoreId());
		return t < 0 ? 0f : AI_BONUS[t];
	}

	public float food() {
		return FOOD_BASE + (slotHas(0, Items.SOIL_NANITES) ? NANITES_FOOD : 0f) + aiBonus();
	}

	public float organics() {
		return ORGANICS_BASE + (slotHas(0, Items.SOIL_NANITES) ? NANITES_ORGANICS : 0f) + aiBonus();
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode) {
		if (coreId == null) {
			if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP) {
				tooltip.addPara("No AI core currently assigned. Installing one improves production.", 0f);
			}
			return;
		}
		int t = tierOf(coreId);
		if (t < 0) return;
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(coreId);
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		text.addPara("%s: Improves Production.", 0f, Misc.getHighlightColor(), spec.getName());
		tooltip.addImageWithText(10f);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		addAICoreSection(tooltip, getAICoreId(), mode);
	}

	@Override
	public String produceMonthly() {
		CargoAPI storage = Production.storage(market);
		if (storage == null) return null;
		float f = Production.addCapped(storage, Commodities.FOOD, food());
		float o = Production.addCapped(storage, Commodities.ORGANICS, organics());
		if (f + o <= 0f) return null;
		return "harvested a fresh crop";
	}

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		if (mode == IndustryTooltipMode.ADD_INDUSTRY) return;
		tooltip.addPara("The domes are growing food and organics, which are delivered to the station's storage each month.", 10f);
		if (!StarfarerRules.on()) return;
		tooltip.addPara("Expected monthly crop: %s food and %s organics.", 6f, Misc.getHighlightColor(), "" + (int) food(), "" + (int) organics());
		CargoAPI storage = Production.storage(market);
		if (storage == null) return;
		tooltip.addPara("Current storage: %s/%s food, %s/%s organics.", 3f, Misc.getHighlightColor(),
				"" + (int) storage.getCommodityQuantity(Commodities.FOOD), "" + (int) Production.cap(Commodities.FOOD),
				"" + (int) storage.getCommodityQuantity(Commodities.ORGANICS), "" + (int) Production.cap(Commodities.ORGANICS));
	}
}
