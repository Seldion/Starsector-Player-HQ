package playerhq.visual;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.ConstructionQueue;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.util.Misc;

public class StarfarerRules {

	public static final String PAID_KEY = "$playerhq_v_paid_resources";
	public static final float REFUND_FRACTION = 0.5f;
	public static final float BUILD_DAYS = 1f;

	public static float visualDays(String id, float easyDays) {
		return on() ? buildDays(id) : easyDays;
	}

	public static float buildDays(String id) {
		if ("playerhq_v_assembly".equals(id)) return 120f;
		if ("playerhq_v_manufactorium".equals(id)) return 90f;
		if ("playerhq_v_marketplace".equals(id) || "playerhq_v_beach_resort".equals(id) || "playerhq_v_winter_resort".equals(id) || "playerhq_v_expanded_sorties".equals(id)) return 30f;
		if ("playerhq_v_station_upkeep".equals(id)) return BUILD_DAYS;
		return 60f;
	}

	private static final String[] ITEMS = {
			Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES,
			Commodities.HEAVY_MACHINERY, Commodities.ORGANICS, Commodities.CREW, Commodities.MARINES };
	private static final String[] NAMES = { "metals", "transplutonics", "volatiles", "heavy machinery", "organics", "crew", "marines" };

	private static final Map<String, Float> CREDITS = new HashMap<String, Float>();

	static {
		CREDITS.put("playerhq_v_resort", 30000f);
		CREDITS.put("playerhq_v_beach_resort", 5500f);
		CREDITS.put("playerhq_v_winter_resort", 5500f);
		CREDITS.put("playerhq_v_mining_hub", 39000f);
		CREDITS.put("playerhq_v_manufactorium", 78000f);
		CREDITS.put("playerhq_v_biodome", 40000f);
		CREDITS.put("playerhq_v_assembly", 380000f);
		CREDITS.put("playerhq_v_military_ward", 20000f);
		CREDITS.put("playerhq_v_fleet_hq", 16000f);
		CREDITS.put("playerhq_v_expanded_sorties", 3500f);
		CREDITS.put("playerhq_v_academy", 25500f);
		CREDITS.put("playerhq_v_public_shuttles", 14500f);
		CREDITS.put("playerhq_v_space_elevator", 30000f);
		CREDITS.put("playerhq_v_marketplace", 10000f);
	}

	public static Float credits(String id) {
		return on() ? CREDITS.get(id) : null;
	}

	private static final Map<String, float[]> COSTS = new HashMap<String, float[]>();

	static {
		COSTS.put("playerhq_v_mining_hub", new float[] { 700f, 250f, 150f, 350f, 0f, 0f });
		COSTS.put("playerhq_v_manufactorium", new float[] { 1400f, 250f, 200f, 1200f, 0f, 0f });
		COSTS.put("playerhq_v_biodome", new float[] { 1300f, 0f, 0f, 100f, 2700f, 0f });
		COSTS.put("playerhq_v_assembly", new float[] { 5500f, 4250f, 1400f, 1700f, 0f, 0f });
		COSTS.put("playerhq_v_military_ward", new float[] { 700f, 250f, 0f, 60f, 0f, 0f });
		COSTS.put("playerhq_v_fleet_hq", new float[] { 850f, 80f, 50f, 0f, 0f, 100f });
		COSTS.put("playerhq_v_resort", new float[] { 1000f, 100f, 40f, 200f, 0f, 600f });
		COSTS.put("playerhq_v_beach_resort", new float[] { 0f, 0f, 0f, 0f, 650f, 0f });
		COSTS.put("playerhq_v_winter_resort", new float[] { 0f, 0f, 0f, 0f, 650f, 0f });
		COSTS.put("playerhq_v_public_shuttles", new float[] { 650f, 170f, 0f, 35f, 0f, 35f });
		COSTS.put("playerhq_v_space_elevator", new float[] { 1600f, 240f, 0f, 160f, 0f, 0f });
		COSTS.put("playerhq_v_marketplace", new float[] { 900f, 50f, 0f, 20f, 0f, 0f });
		COSTS.put("playerhq_v_expanded_sorties", new float[] { 50f, 20f, 0f, 40f, 0f, 100f });
		COSTS.put("playerhq_v_academy", new float[] { 700f, 230f, 60f, 0f, 0f, 230f, 30f });
	}

	public static boolean chosen() {
		return playerhq.mode.HQMode.isChosen();
	}

	public static boolean on() {
		if (Global.getSector() == null) return false;
		return playerhq.mode.HQMode.isChosen() && playerhq.mode.HQMode.isStarfarer();
	}

	private static float[] costs(String id) {
		return COSTS.get(id);
	}

	public static float[] totals() {
		float[] t = new float[ITEMS.length];
		for (float[] c : COSTS.values()) {
			for (int i = 0; i < c.length && i < t.length; i++) t[i] += c[i];
		}
		return t;
	}

	public static String[] itemIds() {
		return ITEMS;
	}

	public static float[] cost(String id) {
		return costs(id);
	}

	private static CargoAPI storage(MarketAPI market) {
		return Production.storage(market);
	}

	private static float have(MarketAPI market, String item) {
		float n = 0f;
		CargoAPI storage = storage(market);
		if (storage != null) n += Commodities.CREW.equals(item) ? storage.getCrew() : Commodities.MARINES.equals(item) ? storage.getMarines() : storage.getCommodityQuantity(item);
		if (!Commodities.CREW.equals(item) && !Commodities.MARINES.equals(item)) {
			CampaignFleetAPI player = Global.getSector().getPlayerFleet();
			if (player != null) n += player.getCargo().getCommodityQuantity(item);
		}
		return n;
	}

	public static String lacking(MarketAPI market, String id) {
		float[] c = costs(id);
		if (!on() || c == null) return null;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < ITEMS.length && i < c.length; i++) {
			if (c[i] <= 0f) continue;
			if (have(market, ITEMS[i]) < c[i]) {
				if (sb.length() > 0) sb.append(", ");
				sb.append((int) c[i]).append(" ").append(NAMES[i]);
			}
		}
		return sb.length() == 0 ? null : "Needs " + sb + " between your fleet and the station's storage.";
	}

	public static boolean afford(MarketAPI market, String id) {
		if (market != null && on()) {
			Set<String> paid = paid(market);
			if (paid.contains(id) || paid.contains("upg:" + id)) return true;
		}
		return lacking(market, id) == null;
	}

	public static String costLine(String id) {
		float[] c = costs(id);
		if (!on() || c == null) return null;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < ITEMS.length && i < c.length; i++) {
			if (c[i] <= 0f) continue;
			if (sb.length() > 0) sb.append(", ");
			sb.append((int) c[i]).append(" ").append(NAMES[i]);
		}
		return sb.length() == 0 ? null : "Also costs " + sb + ".";
	}

	public static void pay(MarketAPI market, String id) {
		float[] c = costs(id);
		if (c == null) return;
		CargoAPI storage = storage(market);
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		for (int i = 0; i < ITEMS.length && i < c.length; i++) {
			float need = c[i];
			if (need <= 0f) continue;
			if (Commodities.CREW.equals(ITEMS[i])) {
				if (storage != null) storage.removeCrew((int) Math.min(need, storage.getCrew()));
				continue;
			}
			if (Commodities.MARINES.equals(ITEMS[i])) {
				if (storage != null) storage.removeMarines((int) Math.min(need, storage.getMarines()));
				continue;
			}
			if (storage != null) {
				float take = Math.min(need, storage.getCommodityQuantity(ITEMS[i]));
				if (take > 0f) storage.removeCommodity(ITEMS[i], take);
				need -= take;
			}
			if (need > 0f && player != null) {
				player.getCargo().removeCommodity(ITEMS[i], Math.min(need, player.getCargo().getCommodityQuantity(ITEMS[i])));
			}
		}
	}

	public static void refund(MarketAPI market, String id, float fraction) {
		float[] c = costs(id);
		if (c == null || !on()) return;
		CargoAPI storage = storage(market);
		if (storage == null) return;
		for (int i = 0; i < ITEMS.length && i < c.length; i++) {
			if (c[i] <= 0f) continue;
			if (Commodities.CREW.equals(ITEMS[i])) {
				storage.addCrew((int) c[i]);
			} else if (Commodities.MARINES.equals(ITEMS[i])) {
				storage.addMarines((int) c[i]);
			} else {
				storage.addCommodity(ITEMS[i], c[i] * fraction);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private static Set<String> paid(MarketAPI market) {
		MemoryAPI m = market.getMemoryWithoutUpdate();
		Set<String> paid = (Set<String>) m.get(PAID_KEY);
		if (paid == null) {
			paid = new HashSet<String>();
			m.set(PAID_KEY, paid);
		}
		return paid;
	}

	private static String upgradeTarget(Industry ind) {
		if (ind instanceof ModuleStructure) return ((ModuleStructure) ind).getUpgradeTargetId();
		if (ind instanceof ResortIndustry) return ((ResortIndustry) ind).getUpgradeTargetId();
		return null;
	}

	public static void process(MarketAPI market) {
		if (!on() || market == null) return;
		Set<String> paid = paid(market);
		ConstructionQueue queue = market.getConstructionQueue();
		List<String> queued = new ArrayList<String>();
		if (queue != null) {
			for (ConstructionQueue.ConstructionQueueItem item : queue.getItems()) queued.add(item.id);
		}
		for (String id : queued) {
			if (costs(id) == null || paid.contains(id)) continue;
			if (afford(market, id)) {
				pay(market, id);
				paid.add(id);
			} else {
				queue.removeItem(id);
				Global.getSector().getCampaignUI().addMessage("The " + name(id) + " was removed from the queue. " + lacking(market, id),
						Misc.getNegativeHighlightColor());
			}
		}
		List<String> upgrading = new ArrayList<String>();
		for (Industry ind : new ArrayList<Industry>(market.getIndustries())) {
			if (!ind.isUpgrading()) continue;
			String up = upgradeTarget(ind);
			if (up == null || costs(up) == null) continue;
			upgrading.add(up);
			if (paid.contains("upg:" + up)) continue;
			if (afford(market, up)) {
				pay(market, up);
				paid.add("upg:" + up);
			} else {
				ind.cancelUpgrade();
				upgrading.remove(up);
				Global.getSector().getCampaignUI().addMessage("The " + name(up) + " upgrade was cancelled. " + lacking(market, up),
						Misc.getNegativeHighlightColor());
			}
		}
		for (String key : new ArrayList<String>(paid)) {
			if (key.startsWith("upg:")) {
				String id = key.substring(4);
				if (upgrading.contains(id)) continue;
				if (!market.hasIndustry(id)) refund(market, id, 1f);
				paid.remove(key);
			} else {
				if (queued.contains(key)) continue;
				if (!market.hasIndustry(key)) refund(market, key, 1f);
				paid.remove(key);
			}
		}
	}

	private static String name(String id) {
		try {
			return Global.getSettings().getIndustrySpec(id).getName();
		} catch (Throwable t) {
			return id;
		}
	}
}
