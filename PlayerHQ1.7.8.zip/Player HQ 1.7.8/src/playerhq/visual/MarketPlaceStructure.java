package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class MarketPlaceStructure extends SlotIndustry implements MonthlyProducer {

	public static final float HOLOSUITE_DISCOUNT = 0.15f;
	public static final float[] AI_BONUS = { 0.05f, 0.10f, 0.15f };

	@Override
	protected String[] slotTitles() {
		return new String[] { "Dealmaker Holosuite" };
	}

	@Override
	protected String[][] slotAllowed() {
		return new String[][] { { Items.DEALMAKER_HOLOSUITE } };
	}

	@Override
	protected String slotEffectText(int slot, SpecialItemData data) {
		return "Reducing prices";
	}

	public float priceDiscount() {
		return slotHas(0, Items.DEALMAKER_HOLOSUITE) ? HOLOSUITE_DISCOUNT : 0f;
	}

	private static int tierOf(String coreId) {
		if (Commodities.GAMMA_CORE.equals(coreId)) return 0;
		if (Commodities.BETA_CORE.equals(coreId)) return 1;
		if (Commodities.ALPHA_CORE.equals(coreId)) return 2;
		return -1;
	}

	public float findsBonus() {
		int t = tierOf(getAICoreId());
		return t < 0 ? 0f : AI_BONUS[t];
	}

	@Override
	public boolean canInstallAICores() {
		return true;
	}

	@Override
	protected void applyAICoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void updateAICoreToSupplyAndDemandModifiers() {
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode) {
		if (coreId == null) {
			if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP) {
				tooltip.addPara("No AI core currently assigned. Installing one improves the chances for better finds.", 0f);
			}
			return;
		}
		int t = tierOf(coreId);
		if (t < 0) return;
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(coreId);
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		text.addPara("%s: Improving chances for better finds.", 0f, Misc.getHighlightColor(), spec.getName());
		tooltip.addImageWithText(10f);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		addAICoreSection(tooltip, getAICoreId(), mode);
	}

	@Override
	public void apply() {
		super.apply();
		if (market != null && !isBuilding()) MarketPlaceSupport.addSubmarkets(market);
	}

	@Override
	public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
		super.notifyBeingRemoved(mode, forUpgrade);
		MarketPlaceSupport.removeSubmarkets(market);
	}

	@Override
	public String produceMonthly() {
		return MarketPlaceSupport.produceMonthly(market);
	}

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		tooltip.addPara("Adds an Agora and an Exchange to the station's inventory screen. Store weapons, fighter wings, blueprints and hull mods in the Agora and passing merchants buy them each month, priciest first, along with some of whatever you spent at the Exchange. One stored ship is also sold at random each month. The Exchange is a buy-only stock that restocks about once a month.", 10f);
		if (mode == IndustryTooltipMode.ADD_INDUSTRY) return;
		if (priceDiscount() > 0f) tooltip.addPara("The Holosuite is bringing Exchange prices down.", 3f);
		if (findsBonus() > 0f) tooltip.addPara("The AI core is improving the Exchange's chances for better finds.", 3f);
	}
}
