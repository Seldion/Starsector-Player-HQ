package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class AssemblyDialog implements CustomDialogDelegate {

	private static final String TIER = "tier:";

	private final AssemblyIndustry industry;
	private CustomPanelAPI panel;
	private CustomPanelAPI current;

	private final BaseCustomUIPanelPlugin handler = new BaseCustomUIPanelPlugin() {
		@Override
		public void buttonPressed(Object buttonId) {
			pressed(buttonId);
		}
	};

	public AssemblyDialog(AssemblyIndustry industry) {
		this.industry = industry;
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		this.panel = panel;
		show();
	}

	private void show() {
		if (current != null) {
			current.getPosition().inTL(-6000f, -6000f);
			panel.removeComponent(current);
		}
		float w = 500f;
		CustomPanelAPI view = panel.createCustomPanel(w, 340f, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI el = view.createUIElement(w, 340f, false);
		buildInject(el, w);
		view.addUIElement(el).inTL(0f, 0f);
		current = view;
		panel.addComponent(view).inTL(0f, 0f);
	}

	private void buildInject(TooltipMakerAPI el, float w) {
		el.addSectionHeading("Inject Credits", Alignment.MID, 0f);
		el.addPara("Order pool: %s / %s. Gains %s a month. Spend credits to add to it at %s credits for every 1 pool credit.", 6f,
				Misc.getHighlightColor(), "" + (int) industry.pool(), "" + (int) industry.poolMax(), "" + (int) industry.monthlyGain(),
				"" + (int) AssemblyIndustry.CREDITS_PER_POOL_CREDIT);
		float credits = Global.getSector().getPlayerFleet().getCargo().getCredits().get();
		for (int i = 0; i < AssemblyIndustry.INJECT_TIERS.length; i++) {
			float tier = AssemblyIndustry.INJECT_TIERS[i];
			float actual = industry.injectable(tier);
			float cost = actual * AssemblyIndustry.CREDITS_PER_POOL_CREDIT;
			ButtonAPI b = el.addButton("Inject " + (int) tier + " pool credits  (" + Misc.getDGSCredits(cost) + ")", TIER + i, w - 20f, 28f, 6f);
			b.setEnabled(actual > 0f && credits >= cost);
		}
	}

	private void pressed(Object buttonId) {
		if (!(buttonId instanceof String)) return;
		String id = (String) buttonId;
		if (id.startsWith(TIER)) {
			industry.inject(AssemblyIndustry.INJECT_TIERS[Integer.parseInt(id.substring(TIER.length()))]);
		}
		show();
	}

	@Override
	public boolean hasCancelButton() {
		return false;
	}

	@Override
	public String getConfirmText() {
		return "Close";
	}

	@Override
	public String getCancelText() {
		return "Cancel";
	}

	@Override
	public void customDialogConfirm() {
	}

	@Override
	public void customDialogCancel() {
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return handler;
	}
}
