package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.loading.IndustrySpecAPI;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class ResortPathDialog implements CustomDialogDelegate {

	private final Industry resort;
	private CustomDialogCallback callback;
	private final List<String> ids = new ArrayList<String>();

	public ResortPathDialog(Industry resort) {
		this.resort = resort;
		ids.add(TestIds.INDUSTRY_BEACH);
		ids.add(TestIds.INDUSTRY_WINTER);
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		this.callback = callback;
		float w = 500f;
		TooltipMakerAPI el = panel.createUIElement(w, 220f, false);
		el.addSectionHeading("Choose Upgrade Path", Alignment.MID, 0f);
		for (String id : ids) {
			Industry target = resort.getMarket().instantiateIndustry(id);
			boolean ok = target.isAvailableToBuild();
			String name = Global.getSettings().getIndustrySpec(id).getName();
			String text = name + "  (" + Misc.getDGSCredits(target.getBuildCost()) + ")";
			ButtonAPI b = el.addButton(text, id, w - 20f, 30f, 14f);
			b.setEnabled(ok);
			if (!ok) {
				el.addPara(target.getUnavailableReason(), Misc.getNegativeHighlightColor(), 3f);
			} else {
				el.addPara(Global.getSettings().getIndustrySpec(id).getDesc(), Misc.getGrayColor(), 3f);
			}
		}
		panel.addUIElement(el);
	}

	@Override
	public boolean hasCancelButton() {
		return true;
	}

	@Override
	public String getConfirmText() {
		return "Close";
	}

	@Override
	public String getCancelText() {
		return "Cancel";
	}

	@Override
	public void customDialogConfirm() {
	}

	@Override
	public void customDialogCancel() {
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return new BaseCustomUIPanelPlugin() {
			@Override
			public void buttonPressed(Object buttonId) {
				if (!(buttonId instanceof String) || !ids.contains(buttonId)) return;
				start((String) buttonId);
			}
		};
	}

	private void start(String id) {
		Industry target = resort.getMarket().instantiateIndustry(id);
		if (!target.isAvailableToBuild()) return;
		float cost = target.getBuildCost();
		com.fs.starfarer.api.util.MutableValue credits = Global.getSector().getPlayerFleet().getCargo().getCredits();
		if (credits.get() < cost) {
			Global.getSector().getCampaignUI().addMessage("Not enough credits for the " + target.getCurrentName() + " upgrade.");
			return;
		}
		credits.subtract(cost);
		IndustrySpecAPI spec = Global.getSettings().getIndustrySpec(TestIds.INDUSTRY_RESORT);
		spec.setUpgrade(id);
		resort.startUpgrading();
		spec.setUpgrade(null);
		if (callback != null) callback.dismissCustomDialog(0);
	}
}
