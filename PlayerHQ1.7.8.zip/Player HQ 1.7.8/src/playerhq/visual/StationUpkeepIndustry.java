package playerhq.visual;

import java.util.ArrayList;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Factions;

public class StationUpkeepIndustry extends BaseIndustry {

	public static final String ID = "playerhq_v_station_upkeep";
	public static final float MODULE_UPKEEP = 0.05f;

	@Override
	public void apply() {
		super.apply(true);
	}

	@Override
	public boolean isAvailableToBuild() {
		return false;
	}

	@Override
	public boolean showWhenUnavailable() {
		return false;
	}

	@Override
	public boolean isHidden() {
		return true;
	}

	@Override
	public float getBuildCost() {
		return 0f;
	}

	public static float moduleCosts(MarketAPI market) {
		float total = 0f;
		for (Industry ind : new ArrayList<Industry>(market.getIndustries())) {
			if (ind.isBuilding() && !ind.isUpgrading()) continue;
			String id = ind.getId();
			int guard = 0;
			while (id != null && guard++ < 6) {
				total += ModuleStructure.costOf(id);
				com.fs.starfarer.api.loading.IndustrySpecAPI spec = Global.getSettings().getIndustrySpec(id);
				id = spec == null ? null : spec.getDowngrade();
			}
		}
		return total * MODULE_UPKEEP;
	}

	public static float rent(MarketAPI market) {
		SectorEntityToken entity = market.getPrimaryEntity();
		if (entity == null) return 0f;
		SectorEntityToken focus = entity.getOrbitFocus();
		if (!(focus instanceof PlanetAPI)) return 0f;
		MarketAPI orbit = ((PlanetAPI) focus).getMarket();
		if (orbit == null || orbit == market || orbit.isPlanetConditionMarketOnly() || orbit.getSize() < 1) return 0f;
		return Factions.PLAYER.equals(orbit.getFactionId()) ? 0f : ResortIndustry.UNOWNED_UPKEEP;
	}

	public static float stipends(MarketAPI market) {
		if (!market.hasIndustry("playerhq_v_military_ward") && !market.hasIndustry("playerhq_v_fleet_hq")) return 0f;
		CargoAPI storage = Production.storage(market);
		if (storage == null) return 0f;
		return storage.getCrew() * MilitaryIndustry.CREW_STIPEND + storage.getMarines() * MilitaryIndustry.MARINE_STIPEND;
	}

	@Override
	protected void applyIncomeAndUpkeep(float sizeMult) {
		getIncome().unmodify();
		getUpkeep().unmodify();
		if (market == null) return;
		float earned = resortIncome(market) + TradeOps.income(market);
		if (earned > 0f) getIncome().modifyFlat("playerhq_v_station_income", earned, "Station income");
		float total = moduleCosts(market) + rent(market) + stipends(market);
		if (total > 0f) getUpkeep().modifyFlat("playerhq_v_station", total, "Station upkeep");
	}

	public static float resortIncome(MarketAPI market) {
		float total = 0f;
		for (Industry ind : new ArrayList<Industry>(market.getIndustries())) {
			if (!(ind instanceof ResortIndustry)) continue;
			if (ind.isBuilding() && !ind.isUpgrading()) continue;
			total += ((ResortIndustry) ind).computeIncome();
		}
		return total;
	}
}
