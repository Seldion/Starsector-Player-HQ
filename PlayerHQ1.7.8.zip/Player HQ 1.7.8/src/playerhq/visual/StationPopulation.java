package playerhq.visual;

import com.fs.starfarer.api.impl.campaign.econ.impl.PopulationAndInfrastructure;

public class StationPopulation extends PopulationAndInfrastructure {

	@Override
	public void apply() {
		super.apply();
		market.getStats().getDynamic().getMod(com.fs.starfarer.api.impl.campaign.ids.Stats.MAX_INDUSTRIES).unmodify();
	}

	@Override
	public void demand(String commodityId, int quantity) {
	}

	@Override
	public void demand(String commodityId, int quantity, String desc) {
	}

	@Override
	public void demand(int index, String commodityId, int quantity, String desc) {
	}

	@Override
	public void demand(String modId, String commodityId, int quantity, String desc) {
	}

	@Override
	public void supply(String commodityId, int quantity) {
	}

	@Override
	public void supply(String commodityId, int quantity, String desc) {
	}

	@Override
	public void supply(int index, String commodityId, int quantity, String desc) {
	}

	@Override
	public void supply(String modId, String commodityId, int quantity, String desc) {
	}
}
