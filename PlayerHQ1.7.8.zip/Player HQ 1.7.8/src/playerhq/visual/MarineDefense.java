package playerhq.visual;

import java.util.Random;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.Misc;

public class MarineDefense {

	public static final String DEFENSE_MOD_ID = "playerhq_v_station_marines";
	public static final String MULT_MOD_ID = "playerhq_v_station_military";
	public static final String NEXERELIN_MOD_ID = "nexerelin";

	public static final float MIN_RAID_CASUALTY_FRACTION = 0.05f;
	public static final float MAX_RAID_CASUALTY_FRACTION = 0.15f;

	private static final String KEY_MARKET = "$playerhq_v_marineDefenseMarket";
	private static final String KEY_MULT_MARKET = "$playerhq_v_defenseMultMarket";
	private static final String KEY_VALUE = "$playerhq_v_marineDefenseValue";
	private static final String KEY_RAID_TS = "$playerhq_v_marineDefenseRaidTs";

	private static final Random random = new Random();
	private static boolean nexFailed = false;
	private static java.lang.reflect.Method nexAdvance = null;

	public static MarketAPI defendedMarket(SectorEntityToken station) {
		MarketAPI own = station.getMarket();
		if (own == null || !(own.hasIndustry("playerhq_v_military_ward") || own.hasIndustry("playerhq_v_fleet_hq"))) return null;
		SectorEntityToken focus = station.getOrbitFocus();
		if (!(focus instanceof PlanetAPI)) return null;
		MarketAPI market = focus.getMarket();
		if (market == null || market.isPlanetConditionMarketOnly() || market.getSize() <= 0) return null;
		if (!market.isPlayerOwned()) return null;
		return market;
	}

	public static MarketAPI orbitedMarket(SectorEntityToken station) {
		SectorEntityToken focus = station.getOrbitFocus();
		if (!(focus instanceof PlanetAPI)) return null;
		MarketAPI market = focus.getMarket();
		if (market == null || market == station.getMarket() || market.isPlanetConditionMarketOnly() || market.getSize() <= 0) return null;
		return market;
	}

	private static MilitaryIndustry builtMilitary(MarketAPI own) {
		if (own == null) return null;
		for (String id : new String[] { "playerhq_v_fleet_hq", "playerhq_v_military_ward" }) {
			com.fs.starfarer.api.campaign.econ.Industry ind = own.getIndustry(id);
			if (ind instanceof MilitaryIndustry && !(ind.isBuilding() && !ind.isUpgrading())) return (MilitaryIndustry) ind;
		}
		return null;
	}

	private static void advanceMultiplier(SectorEntityToken station) {
		MemoryAPI stationMem = station.getMemoryWithoutUpdate();
		MilitaryIndustry military = builtMilitary(station.getMarket());
		MarketAPI target = military == null ? null : orbitedMarket(station);

		String previousId = stationMem.getString(KEY_MULT_MARKET);
		if (previousId != null && (target == null || !previousId.equals(target.getId()))) {
			MarketAPI previous = Global.getSector().getEconomy().getMarket(previousId);
			if (previous != null) {
				previous.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(MULT_MOD_ID);
			}
			stationMem.unset(KEY_MULT_MARKET);
		}
		if (target == null) return;
		com.fs.starfarer.api.combat.StatBonus defense = target.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD);
		float mult = military.defenseMult();
		com.fs.starfarer.api.combat.MutableStat.StatMod existing = defense.getMultBonus(MULT_MOD_ID);
		if (existing == null || Math.abs(existing.value - mult) > 0.0001f) {
			defense.modifyMult(MULT_MOD_ID, mult, military.getCurrentName() + " (Player HQ)");
		}
		stationMem.set(KEY_MULT_MARKET, target.getId());
	}

	public static void clear(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		for (String key : new String[] { KEY_MARKET, KEY_MULT_MARKET }) {
			String id = mem.getString(key);
			if (id == null) continue;
			MarketAPI m = Global.getSector().getEconomy().getMarket(id);
			if (m != null) {
				m.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(DEFENSE_MOD_ID);
				m.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(DEFENSE_MOD_ID);
				m.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(MULT_MOD_ID);
			}
			mem.unset(key);
		}
	}

	public static void advance(SectorEntityToken station) {
		MemoryAPI stationMem = station.getMemoryWithoutUpdate();
		advanceMultiplier(station);
		MarketAPI market = defendedMarket(station);

		String previousId = stationMem.getString(KEY_MARKET);
		if (previousId != null && (market == null || !previousId.equals(market.getId()))) {
			MarketAPI previous = Global.getSector().getEconomy().getMarket(previousId);
			if (previous != null) {
				previous.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(DEFENSE_MOD_ID);
				previous.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(DEFENSE_MOD_ID);
				previous.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(MULT_MOD_ID);
			}
			stationMem.unset(KEY_MARKET);
			stationMem.unset(KEY_VALUE);
			stationMem.unset(KEY_RAID_TS);
		}
		if (market == null) return;

		CargoAPI storage = Production.storage(station.getMarket());
		int stored = storage == null ? 0 : storage.getMarines();
		MilitaryIndustry military = null;
		for (String id : new String[] { "playerhq_v_fleet_hq", "playerhq_v_military_ward" }) {
			com.fs.starfarer.api.campaign.econ.Industry ind = station.getMarket().getIndustry(id);
			if (ind instanceof MilitaryIndustry && !(ind.isBuilding() && !ind.isUpgrading())) {
				military = (MilitaryIndustry) ind;
				break;
			}
		}
		int marines = military == null ? 0 : stored;
		int applied = stationMem.contains(KEY_VALUE) ? (int) stationMem.getLong(KEY_VALUE) : -1;
		if (applied != marines || (marines > 0 && !marketHasMod(market))) {
			if (marines > 0) {
				market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyFlat(
						DEFENSE_MOD_ID, marines, "Marines stationed at Player HQ");
			} else {
				market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(DEFENSE_MOD_ID);
			}
			stationMem.set(KEY_VALUE, (long) marines);
			stationMem.set(KEY_MARKET, market.getId());
		}

		long raidTs = market.getMemoryWithoutUpdate().contains(Misc.LAST_RAIDED_AT)
				? market.getMemoryWithoutUpdate().getLong(Misc.LAST_RAIDED_AT) : -1L;
		if (!stationMem.contains(KEY_RAID_TS)) {
			stationMem.set(KEY_RAID_TS, raidTs);
		} else if (stationMem.getLong(KEY_RAID_TS) != raidTs) {
			stationMem.set(KEY_RAID_TS, raidTs);
			if (raidTs != -1L) applyRaidCasualties(market, storage);
		}

		if (!nexFailed && Global.getSettings().getModManager().isModEnabled(NEXERELIN_MOD_ID)) {
			try {
				if (nexAdvance == null) {
					nexAdvance = Class.forName("playerhq.nex.NexMarineDefense").getMethod("advance",
							SectorEntityToken.class, MarketAPI.class, CargoAPI.class);
				}
				nexAdvance.invoke(null, station, market, storage);
			} catch (Throwable t) {
				nexFailed = true;
				Global.getLogger(MarineDefense.class).warn("Nexerelin marine defense support disabled", t);
			}
		}
	}

	private static boolean marketHasMod(MarketAPI market) {
		return market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).getFlatBonus(DEFENSE_MOD_ID) != null;
	}

	private static void applyRaidCasualties(MarketAPI market, CargoAPI storage) {
		if (storage == null) return;
		int marines = storage.getMarines();
		if (marines <= 0) return;
		float fraction = MIN_RAID_CASUALTY_FRACTION
				+ random.nextFloat() * (MAX_RAID_CASUALTY_FRACTION - MIN_RAID_CASUALTY_FRACTION);
		int lost = Math.max(1, Math.round(marines * fraction));
		lost = Math.min(lost, marines);
		storage.removeMarines(lost);
	}
}
