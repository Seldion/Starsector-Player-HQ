package playerhq.visual;

public interface MonthlyProducer {
	String produceMonthly();
}
