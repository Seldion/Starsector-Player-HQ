package playerhq.visual;

import java.util.HashSet;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.loading.IndustrySpecAPI;

import kaysaar.bmo.listeners.BuildingMenuListener;

public class BmoHideListener implements BuildingMenuListener {

	@Override
	public HashSet<String> addBuildingsToBeHidden(MarketAPI market) {
		HashSet<String> hidden = new HashSet<String>();
		if (market == null || !market.hasTag(TestIds.TAG_STATION)) return hidden;
		List<IndustrySpecAPI> specs = Global.getSettings().getAllIndustrySpecs();
		for (IndustrySpecAPI spec : specs) {
			String id = spec.getId();
			if (id == null) continue;
			if (id.startsWith("playerhq") || Industries.POPULATION.equals(id)) continue;
			hidden.add(id);
		}
		return hidden;
	}
}
