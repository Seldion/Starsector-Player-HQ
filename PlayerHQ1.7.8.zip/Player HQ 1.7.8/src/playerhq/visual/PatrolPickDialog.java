package playerhq.visual;

import java.util.Map;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;

public class PatrolPickDialog implements InteractionDialogPlugin {

	private static final String DONE = "playerhq_v_patrol_done";

	private final SectorEntityToken station;
	private InteractionDialogAPI dialog;

	public PatrolPickDialog(SectorEntityToken station) {
		this.station = station;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		dialog.setPromptText("Patrol Fleet");
		dialog.getOptionPanel().addOption("Cancel", DONE);
		dialog.setOptionOnEscape("Cancel", DONE);
		PatrolPick.open(dialog, station, new Runnable() {
			@Override
			public void run() {
				PatrolPickDialog.this.finish();
			}
		});
	}

	private void finish() {
		if (PatrolPick.lastBuilt) {
			dialog.dismiss();
			return;
		}
		dialog.getOptionPanel().clearOptions();
		dialog.getOptionPanel().addOption("Done", DONE);
		dialog.setOptionOnEscape("Done", DONE);
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (DONE.equals(optionData)) dialog.dismiss();
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
