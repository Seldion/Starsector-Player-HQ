package playerhq.visual;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainPlugin;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidBeltTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class MiningOps {

	public static final float THRESHOLD = 10000f;
	public static final float CAP = 20000f;
	public static final float DAILY_DIVISOR = 3f;
	public static final float MAX_LY = 10f;
	public static final float BELT_MIN_STAR_DISTANCE = 3000f;
	public static final float LASER_POWER = 5f;
	public static final float HAMMER_POWER = 20f;
	public static final float POD_POWER = 20f;
	public static final String ACTIVE_KEY = "$playerhq_v_mining_active_";

	public static final String[] IDS = { Commodities.ORE, Commodities.RARE_ORE, Commodities.VOLATILES, Commodities.ORGANICS };

	private static final String[][] CONDITIONS = {
			{ Conditions.ORE_SPARSE, Conditions.ORE_MODERATE, Conditions.ORE_ABUNDANT, Conditions.ORE_RICH, Conditions.ORE_ULTRARICH },
			{ Conditions.RARE_ORE_SPARSE, Conditions.RARE_ORE_MODERATE, Conditions.RARE_ORE_ABUNDANT, Conditions.RARE_ORE_RICH, Conditions.RARE_ORE_ULTRARICH },
			{ Conditions.VOLATILES_TRACE, Conditions.VOLATILES_DIFFUSE, Conditions.VOLATILES_ABUNDANT, Conditions.VOLATILES_PLENTIFUL },
			{ Conditions.ORGANICS_TRACE, Conditions.ORGANICS_COMMON, Conditions.ORGANICS_ABUNDANT, Conditions.ORGANICS_PLENTIFUL },
	};

	public static final float LASER_COST = 100f;
	public static final float HAMMER_COST = 150f;
	public static final float POD_COST = 1500f;

	private static float[] gear(ShipHullSpecAPI h) {
		float lasers = 0f;
		float hammers = 0f;
		for (WeaponSlotAPI slot : h.getAllWeaponSlotsCopy()) {
			if (slot.isDecorative() || slot.isSystemSlot() || slot.isBuiltIn() || slot.isHidden() && !slot.isWeaponSlot()) continue;
			if (slot.isStationModule()) continue;
			if (slot.getSlotSize() != WeaponSize.SMALL) continue;
			WeaponType type = slot.getWeaponType();
			if (type == WeaponType.LAUNCH_BAY || type == WeaponType.DECORATIVE || type == WeaponType.SYSTEM
					|| type == WeaponType.BUILT_IN || type == WeaponType.STATION_MODULE) continue;
			if (type == WeaponType.MISSILE) hammers++;
			else lasers++;
		}
		return new float[] { lasers, hammers, h.getFighterBays() };
	}

	public static float gearCost(ShipHullSpecAPI h) {
		float[] g = gear(h);
		return g[0] * LASER_COST + g[1] * HAMMER_COST + g[2] * POD_COST;
	}

	public static float power(StationFleet f) {
		float total = 0f;
		for (String id : f.ships) {
			String hullId = id.endsWith("_Hull") ? id.substring(0, id.length() - 5) : id;
			ShipHullSpecAPI h;
			try {
				h = Global.getSettings().getHullSpec(hullId);
			} catch (Throwable t) {
				continue;
			}
			if (h == null) continue;
			float[] g = gear(h);
			total += g[0] * LASER_POWER + g[1] * HAMMER_POWER + g[2] * POD_POWER;
		}
		return total;
	}

	public static boolean active(SectorEntityToken station, String id) {
		return station.getMemoryWithoutUpdate().getBoolean(ACTIVE_KEY + id);
	}

	public static void updateGate(SectorEntityToken station) {
		CargoAPI storage = Fleets.storage(station);
		if (storage == null) return;
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		for (String id : IDS) {
			float qty = storage.getCommodityQuantity(id);
			boolean on = mem.getBoolean(ACTIVE_KEY + id);
			if (!on && qty < THRESHOLD) on = true;
			else if (on && qty >= CAP) on = false;
			mem.set(ACTIVE_KEY + id, on);
		}
	}

	private static boolean open(SectorEntityToken station, CargoAPI storage, String id) {
		return active(station, id) && storage.getCommodityQuantity(id) < CAP;
	}

	private static boolean hasAny(SectorEntityToken station) {
		CargoAPI storage = Fleets.storage(station);
		if (storage == null) return false;
		for (String id : IDS) if (open(station, storage, id)) return true;
		return false;
	}

	private static boolean has(MarketAPI market, String[] conditions) {
		if (market == null) return false;
		for (String c : conditions) if (market.hasCondition(c)) return true;
		return false;
	}

	static boolean[] flags(SectorEntityToken e) {
		if (e instanceof PlanetAPI) {
			MarketAPI m = ((PlanetAPI) e).getMarket();
			return new boolean[] { has(m, CONDITIONS[0]), has(m, CONDITIONS[1]), has(m, CONDITIONS[2]), has(m, CONDITIONS[3]) };
		}
		return new boolean[] { true, true, true, false };
	}

	private static List<SectorEntityToken> belts(StarSystemAPI system) {
		List<SectorEntityToken> out = new ArrayList<SectorEntityToken>();
		if (system == null) return out;
		List<PlanetAPI> stars = new ArrayList<PlanetAPI>();
		for (PlanetAPI p : system.getPlanets()) if (p.isStar()) stars.add(p);
		for (Object o : system.getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) o;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if (!(plugin instanceof AsteroidBeltTerrainPlugin) && !(plugin instanceof AsteroidFieldTerrainPlugin)) continue;
			boolean close = false;
			for (PlanetAPI star : stars) {
				if (Misc.getDistance(terrain, star) < BELT_MIN_STAR_DISTANCE) {
					close = true;
					break;
				}
			}
			if (!close) out.add(terrain);
		}
		return out;
	}

	private static List<SectorEntityToken> homeTargets(SectorEntityToken station) {
		List<SectorEntityToken> out = new ArrayList<SectorEntityToken>();
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return out;
		SectorEntityToken focus = station.getOrbitFocus();
		for (PlanetAPI p : system.getPlanets()) {
			if (p.isStar() || p == focus) continue;
			out.add(p);
		}
		if (focus == null || focus instanceof PlanetAPI) out.addAll(belts(system));
		return out;
	}

	private static List<SectorEntityToken> outsideTargets(SectorEntityToken station) {
		List<SectorEntityToken> out = new ArrayList<SectorEntityToken>();
		StarSystemAPI home = station.getStarSystem();
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			if (system == null || system == home) continue;
			if (system.hasTag(Tags.THEME_HIDDEN)) continue;
			if (Misc.getDistanceLY(station.getLocationInHyperspace(), system.getLocation()) > MAX_LY) continue;
			if (!TradeOps.safe(system)) continue;
			for (PlanetAPI p : system.getPlanets()) {
				if (p.isStar()) continue;
				boolean[] fl = flags(p);
				if (fl[0] || fl[1] || fl[2] || fl[3]) out.add(p);
			}
		}
		return out;
	}

	private static float weight(SectorEntityToken station, CargoAPI storage, SectorEntityToken e) {
		boolean[] fl = flags(e);
		float w = 0f;
		for (int i = 0; i < IDS.length; i++) {
			if (!fl[i] || !open(station, storage, IDS[i])) continue;
			w = Math.max(w, Math.max(1f, CAP - storage.getCommodityQuantity(IDS[i])));
		}
		if (w > 0f && e.getStarSystem() != null && e.getStarSystem() != station.getStarSystem()) {
			float ly = Misc.getDistanceLY(station.getLocationInHyperspace(), e.getStarSystem().getLocation());
			w = w / (1f + 0.25f * ly);
		}
		return w;
	}

	private static SectorEntityToken pick(SectorEntityToken station) {
		CargoAPI storage = Fleets.storage(station);
		if (storage == null) return null;
		WeightedRandomPicker<SectorEntityToken> picker = new WeightedRandomPicker<SectorEntityToken>();
		for (SectorEntityToken e : homeTargets(station)) {
			float w = weight(station, storage, e);
			if (w > 0f) picker.add(e, w);
		}
		if (picker.isEmpty()) {
			for (SectorEntityToken e : outsideTargets(station)) {
				float w = weight(station, storage, e);
				if (w > 0f) picker.add(e, w);
			}
		}
		return picker.isEmpty() ? null : picker.pick();
	}

	public static boolean prepare(SectorEntityToken station, StationFleet f) {
		updateGate(station);
		if (!hasAny(station)) return false;
		if (power(f) <= 0f || f.capCargo <= 0f) return false;
		SectorEntityToken target = pick(station);
		if (target == null) return false;
		f.target = target;
		f.hasSpot = false;
		if (target instanceof CampaignTerrainAPI) {
			CampaignTerrainPlugin plugin = ((CampaignTerrainAPI) target).getPlugin();
			if (!(plugin instanceof AsteroidFieldTerrainPlugin) && plugin instanceof BaseRingTerrain) {
				BaseRingTerrain.RingParams rp = ((BaseRingTerrain) plugin).getRingParams();
				if (rp != null && rp.relatedEntity != null) {
					float angle = (float) (Math.random() * 360f);
					Vector2f c = rp.relatedEntity.getLocation();
					f.spotX = c.x + (float) Math.cos(Math.toRadians(angle)) * rp.middleRadius;
					f.spotY = c.y + (float) Math.sin(Math.toRadians(angle)) * rp.middleRadius;
					f.hasSpot = true;
				}
			}
		}
		return true;
	}

	private static SectorEntityToken goal(StationFleet f) {
		if (f.hasSpot && f.target.getContainingLocation() != null) return f.target.getContainingLocation().createToken(f.spotX, f.spotY);
		return f.target;
	}

	private static String targetName(StationFleet f) {
		if (f.target instanceof PlanetAPI) return f.target.getName();
		return "an asteroid field";
	}

	public static void launched(SectorEntityToken station, StationFleet f) {
		f.stage = StationFleet.STG_OUT;
		f.load = 0f;
		f.carried = new LinkedHashMap<String, Float>();
		Fleets.travel(f.fleet, goal(f), "Traveling to mine " + targetName(f));
	}

	public static void advance(SectorEntityToken station, StationFleet f) {
		CampaignFleetAPI fleet = f.fleet;
		if (f.target == null) {
			Fleets.sendHome(station, f);
			return;
		}
		if (f.stage == StationFleet.STG_OUT) {
			SectorEntityToken goal = goal(f);
			if (Fleets.arrived(fleet, goal)) {
				fleet.clearAssignments();
				float radius = f.target instanceof PlanetAPI ? f.target.getRadius() + 250f : 200f;
				fleet.setCircularOrbitPointingDown(goal, (float) (Math.random() * 360f), radius, 120f);
				f.stage = StationFleet.STG_WORK;
				return;
			}
			if (fleet.getCurrentAssignment() == null) Fleets.travel(fleet, goal, "Traveling to mine " + targetName(f));
			return;
		}
		if (f.stage != StationFleet.STG_WORK) {
			Fleets.sendHome(station, f);
			return;
		}
		float perResource = power(f) / DAILY_DIVISOR;
		CargoAPI storage = Fleets.storage(station);
		boolean[] fl = flags(f.target);
		boolean gathered = false;
		for (int i = 0; i < IDS.length; i++) {
			if (!fl[i] || perResource <= 0f) continue;
			Float have = f.carried.get(IDS[i]);
			float carried = have != null ? have : 0f;
			float stored = storage != null ? storage.getCommodityQuantity(IDS[i]) : 0f;
			if (stored + carried >= CAP) continue;
			f.carried.put(IDS[i], carried + perResource);
			f.load += perResource;
			gathered = true;
		}
		if (!gathered || f.load >= f.capCargo || perResource <= 0f) {
			f.stage = StationFleet.STG_NONE;
			Fleets.sendHome(station, f);
		}
	}

	public static void deliver(SectorEntityToken station, StationFleet f) {
		CargoAPI storage = Fleets.storage(station);
		if (storage == null || f.carried == null) return;
		for (Map.Entry<String, Float> e : f.carried.entrySet()) {
			float amount = e.getValue() != null ? e.getValue() : 0f;
			if (amount <= 0f) continue;
			storage.addCommodity(e.getKey(), amount);
		}
	}

	public static String status(StationFleet f) {
		String load = " (hold " + Math.round(f.load) + " / " + Math.round(f.capCargo) + ")";
		if (f.stage == StationFleet.STG_OUT && f.target != null) return "Heading to mine " + targetName(f);
		if (f.stage == StationFleet.STG_WORK && f.target != null) return "Mining at " + targetName(f) + load;
		return "Out mining" + load;
	}
}
