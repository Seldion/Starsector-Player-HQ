package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.Industry.IndustryTooltipMode;
import com.fs.starfarer.api.campaign.listeners.DialogCreatorUI;
import com.fs.starfarer.api.campaign.listeners.IndustryOptionProvider;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class ManufactoriumOptionProvider implements IndustryOptionProvider {

	public static final Object OPTION_ID = "playerhq_v_production_settings";

	@Override
	public List<IndustryOptionData> getIndustryOptions(Industry ind) {
		if (!(ind instanceof ManufactoriumIndustry)) return null;
		if (ind.isBuilding() || ind.isUpgrading()) return null;
		List<IndustryOptionData> list = new ArrayList<IndustryOptionData>();
		IndustryOptionData data = new IndustryOptionData("Production Settings", OPTION_ID, ind, this);
		data.color = Misc.getHighlightColor();
		data.enabled = true;
		list.add(data);
		return list;
	}

	@Override
	public void createTooltip(IndustryOptionData opt, TooltipMakerAPI tooltip, float width) {
		if (opt.id != OPTION_ID) return;
		tooltip.addPara("Choose which products the Manufactorium makes each month.", 0f);
	}

	@Override
	public void optionSelected(IndustryOptionData opt, DialogCreatorUI ui) {
		if (opt.id != OPTION_ID) return;
		ui.showDialog(520f, 440f, new ProductionSettingsDialog((ManufactoriumIndustry) opt.ind));
	}

	@Override
	public void addToIndustryTooltip(Industry ind, IndustryTooltipMode mode, TooltipMakerAPI tooltip, float width, boolean expanded) {
	}
}
