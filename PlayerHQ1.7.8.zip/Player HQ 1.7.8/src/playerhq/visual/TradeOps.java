package playerhq.visual;

import java.util.HashSet;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.intel.raid.RaidIntel;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.util.Misc;

public class TradeOps {

	public static final float SURPLUS_THRESHOLD = 8000f;
	public static final float SALE_FRACTION = 0.5f;
	public static final int LOAD_DAYS = 2;
	public static final String INCOME_KEY = "$playerhq_v_tradeIncome";

	static boolean tradeable(String id) {
		return id != null && !Commodities.FUEL.equals(id);
	}

	static Set<String> idsIn(CargoAPI cargo) {
		Set<String> ids = new HashSet<String>();
		if (cargo == null) return ids;
		for (CargoStackAPI stack : cargo.getStacksCopy()) {
			if (stack == null || stack.isNull() || !stack.isResourceStack()) continue;
			if (tradeable(stack.getCommodityId())) ids.add(stack.getCommodityId());
		}
		return ids;
	}

	static float surplus(CargoAPI storage, String id) {
		return Math.max(0f, storage.getCommodityQuantity(id) - SURPLUS_THRESHOLD);
	}

	static float space(String id) {
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(id);
		return spec != null ? spec.getCargoSpace() : 0f;
	}

	static float surplusSpace(CargoAPI storage) {
		if (storage == null) return 0f;
		float total = 0f;
		for (String id : idsIn(storage)) total += surplus(storage, id) * space(id);
		return total;
	}

	public static float used(CargoAPI hold) {
		if (hold == null) return 0f;
		hold.updateSpaceUsed();
		return hold.getSpaceUsed();
	}

	public static boolean prepare(SectorEntityToken station, StationFleet f) {
		if (f.capCargo <= 0f) return false;
		return surplusSpace(Fleets.storage(station)) >= f.capCargo;
	}

	public static void launched(SectorEntityToken station, StationFleet f) {
		CargoAPI storage = Fleets.storage(station);
		f.hold = Global.getFactory().createCargo(true);
		float loaded = 0f;
		for (String id : idsIn(storage)) {
			if (loaded >= f.capCargo) break;
			float units = surplus(storage, id);
			if (units <= 0f) continue;
			float per = space(id);
			if (per > 0f) units = Math.min(units, (f.capCargo - loaded) / per);
			if (units <= 0f) continue;
			storage.removeCommodity(id, units);
			f.hold.addCommodity(id, units);
			loaded += units * per;
		}
		f.stage = StationFleet.STG_LOAD;
		f.stageDays = 0f;
		f.fleet.clearAssignments();
		f.fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, station, 10f, "Loading cargo at " + station.getName());
	}

	public static boolean safe(StarSystemAPI system) {
		if (system == null) return false;
		FactionAPI player = Global.getSector().getPlayerFaction();
		for (MarketAPI market : Misc.getMarketsInLocation(system)) {
			if (market == null) continue;
			if (market.getFaction() != null && market.getFaction().isHostileTo(player)) return false;
			if (market.hasCondition(Conditions.PIRATE_ACTIVITY)) return false;
		}
		for (IntelInfoPlugin intel : Global.getSector().getIntelManager().getIntel(RaidIntel.class)) {
			if (!(intel instanceof RaidIntel)) continue;
			RaidIntel raid = (RaidIntel) intel;
			if (raid.getSystem() != system) continue;
			if (raid.getFaction() != null && raid.getFaction().isHostileTo(player)) return false;
		}
		return true;
	}

	private static MarketAPI pickMarket(Set<String> ids) {
		FactionAPI player = Global.getSector().getPlayerFaction();
		MarketAPI best = null;
		float bestStock = Float.MAX_VALUE;
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (market == null || market.isHidden() || market.isPlayerOwned()) continue;
			if (market.getPrimaryEntity() == null || market.getStarSystem() == null) continue;
			if (market.getFaction() != null && market.getFaction().isHostileTo(player)) continue;
			if (!safe(market.getStarSystem())) continue;
			float stock = 0f;
			for (String id : ids) {
				CommodityOnMarketAPI data = market.getCommodityData(id);
				if (data != null) stock += data.getStockpile();
			}
			if (stock < bestStock) {
				bestStock = stock;
				best = market;
			}
		}
		return best;
	}

	private static float sell(CargoAPI hold, MarketAPI market) {
		if (hold == null) return 0f;
		float proceeds = 0f;
		for (CargoStackAPI stack : new java.util.ArrayList<CargoStackAPI>(hold.getStacksCopy())) {
			if (stack == null || stack.isNull() || !stack.isResourceStack()) continue;
			String id = stack.getCommodityId();
			if (!tradeable(id)) continue;
			float qty = stack.getSize();
			if (qty <= 0f) continue;
			proceeds += market != null ? market.getDemandPrice(id, qty, true) : stack.getBaseValuePerUnit() * qty;
			hold.removeCommodity(id, qty);
		}
		return proceeds * SALE_FRACTION;
	}

	public static void advance(SectorEntityToken station, StationFleet f) {
		CampaignFleetAPI fleet = f.fleet;
		if (f.stage == StationFleet.STG_LOAD) {
			f.stageDays += 1f;
			if (f.stageDays < LOAD_DAYS) return;
			MarketAPI market = pickMarket(idsIn(f.hold));
			if (market == null) return;
			f.targetMarket = market;
			f.target = market.getPrimaryEntity();
			f.stage = StationFleet.STG_OUT;
			Fleets.travel(fleet, f.target, "Traveling to " + f.target.getName());
			return;
		}
		if (f.stage == StationFleet.STG_OUT) {
			if (f.target == null) {
				Fleets.sendHome(station, f);
				return;
			}
			if (Fleets.arrived(fleet, f.target)) {
				float proceeds = sell(f.hold, f.targetMarket);
				if (proceeds > 0f) {
					addProceeds(station, proceeds);
				}
				// The Shopping List: pick up anything on it that this market has, then bring it home.
				if (f.hold != null) {
					playerhq.shopping.ShoppingListEngine.Result bought = playerhq.shopping.ShoppingListEngine.autoBuyAtMarket(station, f.hold, f.targetMarket, f.capCargo);
					if (Fleets.isText(station)) playerhq.modules.MilitaryWardModule.logTraderBought(station, bought);
				}
				f.stage = StationFleet.STG_NONE;
				Fleets.sendHome(station, f);
				return;
			}
			if (fleet.getCurrentAssignment() == null) Fleets.travel(fleet, f.target, "Traveling to " + f.target.getName());
			return;
		}
		Fleets.sendHome(station, f);
	}

	public static void addProceeds(SectorEntityToken station, float amount) {
		if (Fleets.isText(station)) {
			Global.getSector().getPlayerFleet().getCargo().getCredits().add(amount);
			playerhq.modules.MilitaryWardModule.logTraderEarned(station, amount);
			return;
		}
		float prev = station.getMemoryWithoutUpdate().contains(INCOME_KEY) ? station.getMemoryWithoutUpdate().getFloat(INCOME_KEY) : 0f;
		station.getMemoryWithoutUpdate().set(INCOME_KEY, prev + amount);
		if (station.getMarket() != null && !Fleets.isText(station)) station.getMarket().reapplyIndustries();
	}

	public static float income(MarketAPI market) {
		if (market == null || market.getPrimaryEntity() == null) return 0f;
		if (!market.getPrimaryEntity().getMemoryWithoutUpdate().contains(INCOME_KEY)) return 0f;
		return market.getPrimaryEntity().getMemoryWithoutUpdate().getFloat(INCOME_KEY);
	}

	public static void resetIncome() {
		SectorEntityToken station = Fleets.station();
		if (station == null) return;
		station.getMemoryWithoutUpdate().unset(INCOME_KEY);
		if (station.getMarket() != null && !Fleets.isText(station)) station.getMarket().reapplyIndustries();
	}

	public static String status(StationFleet f) {
		if (f.stage == StationFleet.STG_LOAD) return "Loading cargo at the station";
		if (f.stage == StationFleet.STG_OUT && f.target != null) return "Heading to " + f.target.getName() + " to sell";
		return "Out on a trade run";
	}
}
