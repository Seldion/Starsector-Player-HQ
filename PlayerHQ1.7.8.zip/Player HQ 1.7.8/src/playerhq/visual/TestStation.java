package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainPlugin;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidBeltTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.deciv.DecivTracker;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.util.Misc;

public class TestStation {

	public static final float PLANET_RANGE = 1500f;

	public static final String NEX_UNINVADABLE_KEY = "$nex_uninvadable";

	public static SectorEntityToken find() {
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			for (SectorEntityToken e : system.getAllEntities()) {
				if (e.hasTag(TestIds.TAG_STATION)) return e;
			}
		}
		return null;
	}

	public static PlanetAPI closestPlanet(CampaignFleetAPI fleet) {
		StarSystemAPI system = fleet.getStarSystem();
		if (system == null || fleet.isInHyperspace() || fleet.isInHyperspaceTransition()) return null;
		PlanetAPI best = null;
		float bestDist = Float.MAX_VALUE;
		for (PlanetAPI p : system.getPlanets()) {
			if (p.isStar()) continue;
			float d = Misc.getDistance(fleet, p);
			if (d < bestDist) {
				best = p;
				bestDist = d;
			}
		}
		if (best == null || bestDist > PLANET_RANGE) return null;
		return best;
	}

	public static final float MIN_JUMP_POINT_DISTANCE = 300f;

	private static CampaignTerrainAPI beltTerrain(CampaignFleetAPI fleet) {
		StarSystemAPI system = fleet.getStarSystem();
		if (system == null || fleet.isInHyperspace() || fleet.isInHyperspaceTransition()) return null;
		for (Object object : system.getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) object;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if ((plugin instanceof AsteroidBeltTerrainPlugin || plugin instanceof AsteroidFieldTerrainPlugin)
					&& plugin.containsEntity(fleet)) {
				return terrain;
			}
		}
		return null;
	}

	private static boolean tooCloseToJumpPoint(CampaignFleetAPI fleet) {
		StarSystemAPI system = fleet.getStarSystem();
		if (system == null) return false;
		for (Object object : system.getEntities(JumpPointAPI.class)) {
			if (Misc.getDistance(fleet, (JumpPointAPI) object) < MIN_JUMP_POINT_DISTANCE) return true;
		}
		return false;
	}

	public static boolean canBuildHere(CampaignFleetAPI fleet) {
		if (find() != null) return false;
		if (closestPlanet(fleet) != null) return true;
		return beltTerrain(fleet) != null && !tooCloseToJumpPoint(fleet);
	}

	private static void placeInBelt(SectorEntityToken station, CampaignFleetAPI fleet, CampaignTerrainAPI terrain) {
		CampaignTerrainPlugin plugin = terrain.getPlugin();
		if (plugin instanceof AsteroidFieldTerrainPlugin) {
			OrbitAPI orbit = terrain.getOrbit();
			if (orbit != null && orbit.getFocus() != null) {
				station.setCircularOrbitWithSpin(orbit.getFocus(),
						Misc.getAngleInDegrees(orbit.getFocus().getLocation(), fleet.getLocation()),
						Misc.getDistance(fleet, orbit.getFocus()), orbit.getOrbitalPeriod(), 5f, 10f);
				return;
			}
			station.setCircularOrbitWithSpin(terrain,
					Misc.getAngleInDegrees(terrain.getLocation(), fleet.getLocation()),
					Misc.getDistance(fleet, terrain), 40f, 5f, 10f);
			return;
		}
		SectorEntityToken focus = terrain.getOrbitFocus();
		if (focus != null) {
			float radius = Misc.getDistance(focus, fleet);
			float days = Math.max(radius / 10f, 20f);
			if (plugin instanceof AsteroidBeltTerrainPlugin && ((AsteroidBeltTerrainPlugin) plugin).params != null) {
				days = (((AsteroidBeltTerrainPlugin) plugin).params.minOrbitDays
						+ ((AsteroidBeltTerrainPlugin) plugin).params.maxOrbitDays) / 2f;
			}
			station.setCircularOrbitPointingDown(focus, Misc.getAngleInDegrees(focus.getLocation(), fleet.getLocation()),
					radius, days);
			return;
		}
		station.setLocation(fleet.getLocation().x, fleet.getLocation().y);
	}

	public static SectorEntityToken build(CampaignFleetAPI fleet) {
		return build(fleet, playerhq.Ids.STATION_ENTITY_EASY);
	}

	public static SectorEntityToken build(CampaignFleetAPI fleet, String entityId) {
		if (!canBuildHere(fleet)) return null;
		PlanetAPI planet = closestPlanet(fleet);
		CampaignTerrainAPI belt = planet == null ? beltTerrain(fleet) : null;

		StarSystemAPI system = fleet.getStarSystem();
		String uid = Misc.genUID();
		SectorEntityToken station = system.addCustomEntity("playerhq_v_station_" + uid, "Player HQ",
				entityId, Factions.PLAYER);
		if (planet != null) {
			float angle = Misc.getAngleInDegrees(planet.getLocation(), fleet.getLocation());
			station.setCircularOrbitPointingDown(planet, angle, planet.getRadius() + 300f, 30f);
		} else {
			placeInBelt(station, fleet, belt);
		}
		station.addTag(TestIds.TAG_STATION);
		station.setCustomDescriptionId(playerhq.Ids.STATION_DESCRIPTION_ID);

		MarketAPI market = Global.getFactory().createMarket("playerhq_v_market_" + uid, "Player HQ", 3);
		market.setFactionId(Factions.PLAYER);
		market.setPrimaryEntity(station);
		market.setPlayerOwned(true);
		market.addCondition(Conditions.ABANDONED_STATION);
		market.addCondition(StationAccessCondition.ID);
		market.addIndustry(Industries.POPULATION);
		market.getIndustry(Industries.POPULATION).setHidden(true);
		quietPopulation(market);
		market.setHidden(true);
		market.setPlanetConditionMarketOnly(false);
		market.setEconGroup(market.getId());
		market.getMemoryWithoutUpdate().set(DecivTracker.NO_DECIV_KEY, true);
		market.getMemoryWithoutUpdate().set(NEX_UNINVADABLE_KEY, true);
		market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
		market.addSubmarket(Submarkets.LOCAL_RESOURCES);
		market.addSubmarket(Submarkets.SUBMARKET_STORAGE);
		StoragePlugin storage = (StoragePlugin) market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getPlugin();
		storage.setPlayerPaidToUnlock(true);
		market.setInvalidMissionTarget(true);
		market.addTag(Tags.MARKET_NO_OFFICER_SPAWN);
		market.addTag("market_no_industries_allowed");
		market.addTag(TestIds.TAG_STATION);

		station.setMarket(market);
		Global.getSector().getEconomy().addMarket(market, false);
		return station;
	}

	private static void quietPopulation(MarketAPI market) {
		market.getIncomeMult().modifyMult("playerhq_v_station_only", 0f, "Player HQ station");
		market.getUpkeepMult().modifyMult("playerhq_v_station_only", 0f, "Player HQ station");
		com.fs.starfarer.api.campaign.econ.Industry pop = market.getIndustry(Industries.POPULATION);
		java.util.List<com.fs.starfarer.api.campaign.econ.Industry> list = market.getIndustries();
		int index = list.indexOf(pop);
		try {
			StationPopulation replacement = new StationPopulation();
			replacement.init(Industries.POPULATION, market);
			replacement.setHidden(true);
			pop.unapply();
			list.set(index, replacement);
			if (!(market.getIndustry(Industries.POPULATION) instanceof StationPopulation)) {
				list.set(index, pop);
				clearMaps(pop);
			}
		} catch (Throwable t) {
			Global.getLogger(TestStation.class).warn("Could not replace the station population industry", t);
			try {
				if (index >= 0 && list.get(index) != pop) list.set(index, pop);
			} catch (Throwable ignored) {
			}
			clearMaps(pop);
		}
	}

	private static void clearMaps(com.fs.starfarer.api.campaign.econ.Industry ind) {
		for (String name : new String[] { "demand", "supply" }) {
			try {
				java.lang.reflect.Field f = com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry.class.getDeclaredField(name);
				f.setAccessible(true);
				Object map = f.get(ind);
				if (map instanceof java.util.Map) ((java.util.Map) map).clear();
			} catch (Throwable ignored) {
			}
		}
	}

	public static int moduleCount() {
		int n = 0;
		for (MarketAPI m : staleMarkets()) {
			for (com.fs.starfarer.api.campaign.econ.Industry ind : m.getIndustries()) {
				String id = ind.getId();
				if (id != null && id.startsWith("playerhq_v_") && !StationUpkeepIndustry.ID.equals(id)) n++;
			}
			if (m.getConstructionQueue() != null) n += m.getConstructionQueue().getItems().size();
		}
		return n;
	}

	public static java.util.List<MarketAPI> staleMarkets() {
		java.util.List<MarketAPI> list = new java.util.ArrayList<MarketAPI>();
		for (MarketAPI m : Global.getSector().getEconomy().getMarketsCopy()) {
			if (m.getId() != null && m.getId().startsWith("playerhq_v_market_")) list.add(m);
		}
		return list;
	}

	private static int jettison(MarketAPI market, com.fs.starfarer.api.campaign.LocationAPI loc,
			org.lwjgl.util.vector.Vector2f where) {
		com.fs.starfarer.api.campaign.CargoAPI storage = Production.storage(market);
		if (storage == null) return 0;
		int ships = 0;
		float scrapValue = 0f;
		com.fs.starfarer.api.campaign.FleetDataAPI data = storage.getMothballedShips();
		if (data != null) {
			for (com.fs.starfarer.api.fleet.FleetMemberAPI m : new java.util.ArrayList<com.fs.starfarer.api.fleet.FleetMemberAPI>(data.getMembersListCopy())) {
				scrapValue += m.getBaseValue() * SCRAP_FRACTION;
				data.removeFleetMember(m);
				ships++;
			}
		}
		if (scrapValue > 0f) {
			storage.addCommodity(com.fs.starfarer.api.impl.campaign.ids.Commodities.METALS,
					(float) Math.floor(scrapValue * 0.7f / price(com.fs.starfarer.api.impl.campaign.ids.Commodities.METALS)));
			storage.addCommodity(com.fs.starfarer.api.impl.campaign.ids.Commodities.RARE_METALS,
					(float) Math.floor(scrapValue * 0.2f / price(com.fs.starfarer.api.impl.campaign.ids.Commodities.RARE_METALS)));
			storage.addCommodity(com.fs.starfarer.api.impl.campaign.ids.Commodities.HEAVY_MACHINERY,
					(float) Math.floor(scrapValue * 0.1f / price(com.fs.starfarer.api.impl.campaign.ids.Commodities.HEAVY_MACHINERY)));
		}
		if (loc != null && where != null && !storage.isEmpty()) {
			com.fs.starfarer.api.campaign.CustomCampaignEntityAPI pods = Misc.addCargoPods(loc, where);
			pods.getCargo().addAll(storage, false);
		}
		storage.clear();
		return ships;
	}

	private static float price(String commodityId) {
		float p = Global.getSettings().getCommoditySpec(commodityId).getBasePrice();
		return p <= 0f ? 1f : p;
	}

	public static final float SCRAP_FRACTION = 0.5f;

	public static int remove() {
		int ships = 0;
		SectorEntityToken existing = find();
		if (existing != null) MarineDefense.clear(existing);
		for (MarketAPI m : staleMarkets()) {
			com.fs.starfarer.api.campaign.LocationAPI loc = null;
			org.lwjgl.util.vector.Vector2f where = null;
			SectorEntityToken e = m.getPrimaryEntity();
			if (e != null && e.getContainingLocation() != null) {
				loc = e.getContainingLocation();
				where = e.getLocation();
			} else {
				CampaignFleetAPI pf = Global.getSector().getPlayerFleet();
				if (pf != null && pf.getContainingLocation() != null) {
					loc = pf.getContainingLocation();
					where = pf.getLocation();
				}
			}
			ships += jettison(m, loc, where);
		}
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			for (SectorEntityToken e : new java.util.ArrayList<SectorEntityToken>(system.getAllEntities())) {
				if (e.hasTag(TestIds.TAG_STATION)) system.removeEntity(e);
			}
		}
		for (MarketAPI m : staleMarkets()) {
			Global.getSector().getEconomy().removeMarket(m);
		}
		return ships;
	}
}
