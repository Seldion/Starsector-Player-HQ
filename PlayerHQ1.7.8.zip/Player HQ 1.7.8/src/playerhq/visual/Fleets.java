package playerhq.visual;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.ai.FleetAssignmentDataAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.characters.SkillSpecAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI.ShipTypeHints;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.util.Misc;

public class Fleets {

	public static final String KEY = "$playerhq_v_fleets";
	public static final float DOCK_DAYS = 7f;
	public static final float REBUILD_DAYS = 30f;
	public static final float RELAUNCH_DAYS = 7f;

	private static float patrolReplaceDays(StationFleet f) {
		float total = 0f;
		if (f.variants != null && !f.variants.isEmpty()) {
			for (ShipVariantAPI v : f.variants) total += replaceDays(v.getHullSpec());
		} else {
			for (String id : f.ships) {
				try {
					total += replaceDays(Global.getSettings().getHullSpec(id.endsWith("_Hull") ? id.substring(0, id.length() - 5) : id));
				} catch (Throwable t) {
				}
			}
		}
		return total > 0f ? total : REBUILD_DAYS;
	}

	private static float replaceDays(ShipHullSpecAPI h) {
		if (h == null) return 0f;
		switch (h.getHullSize()) {
		case FRIGATE: return 3f;
		case DESTROYER: return 6f;
		case CRUISER: return 10f;
		case CAPITAL_SHIP: return 16f;
		default: return 0f;
		}
	}
	public static final float PATROL_DAYS = 90f;
	public static final int PATROL_SIZE = 30;
	public static final long PATROL_COST = 1000000L;
	public static final float ARRIVAL_RANGE = 300f;
	public static final float MEET_RANGE = 250f;
	public static final float LOAD_DAYS = 1f;
	public static final float COOLDOWN_DAYS = 3f;
	public static final float RETARGET_RANGE = 150f;
	public static final float SELL_RETURN = 0.5f;
	public static final String CALL_KEY = "$playerhq_v_callFleet";

	private static final Random RANDOM = new Random();

	public static final String STATION_REF = "$playerhq_v_stationRef";
	public static final String FINDS_ID = "playerhq_v_expedition_finds";

	public static SectorEntityToken station() {
		Object o = Global.getSector().getMemoryWithoutUpdate().get(STATION_REF);
		if (o instanceof SectorEntityToken && ((SectorEntityToken) o).isAlive()
				&& ((SectorEntityToken) o).getContainingLocation() != null) return (SectorEntityToken) o;
		SectorEntityToken found = TestStation.find();
		if (found == null) found = playerhq.util.PlayerHQUtils.findFirstEntityWithTagAnywhere(playerhq.Ids.TAG_STATION);
		if (found != null) Global.getSector().getMemoryWithoutUpdate().set(STATION_REF, found);
		return found;
	}

	public static boolean isText(SectorEntityToken station) {
		return station != null && !station.hasTag(TestIds.TAG_STATION);
	}

	@SuppressWarnings("unchecked")
	public static List<StationFleet> list() {
		SectorEntityToken station = station();
		if (station == null) return new ArrayList<StationFleet>();
		Object o = station.getMemoryWithoutUpdate().get(KEY);
		if (o instanceof List) return (List<StationFleet>) o;
		List<StationFleet> list = new ArrayList<StationFleet>();
		station.getMemoryWithoutUpdate().set(KEY, list);
		return list;
	}

	public static int owned(FleetKind kind) {
		int n = 0;
		for (StationFleet f : list()) if (f.kind == kind) n++;
		return n;
	}

	public static boolean sortiesBuilt() {
		SectorEntityToken station = station();
		if (station == null || station.getMarket() == null) return false;
		if (isText(station)) return playerhq.modules.StationItemsModule.hasExpandedSortiesInstalled(station);
		Industry ind = station.getMarket().getIndustry("playerhq_v_expanded_sorties");
		return ind != null && !ind.isBuilding();
	}

	public static boolean hqBuilt(MarketAPI market) {
		if (market == null) return false;
		if (isText(market.getPrimaryEntity())) return playerhq.modules.MilitaryWardModule.hasFleetHQBuilt(market.getPrimaryEntity());
		for (Industry ind : market.getIndustries()) {
			if (ind instanceof FleetHqIndustry && !ind.isBuilding()) return true;
		}
		return false;
	}

	private static ShipHullSpecAPI hull(String id, String name) {
		try {
			ShipHullSpecAPI h = Global.getSettings().getHullSpec(id);
			if (h != null) return h;
		} catch (Throwable t) {
		}
		for (ShipHullSpecAPI h : Global.getSettings().getAllShipHullSpecs()) {
			if (!h.isDHull() && name.equalsIgnoreCase(h.getHullName())) return h;
		}
		return null;
	}

	private static ShipHullSpecAPI specOf(String id) {
		try {
			ShipVariantAPI v = Global.getSettings().getVariant(id);
			if (v != null) return v.getHullSpec();
		} catch (Throwable t) {
		}
		try {
			return Global.getSettings().getHullSpec(id.endsWith("_Hull") ? id.substring(0, id.length() - 5) : id);
		} catch (Throwable t) {
			return null;
		}
	}

	private static FleetMemberAPI member(String id) {
		try {
			return Global.getFactory().createFleetMember(FleetMemberType.SHIP, id);
		} catch (Throwable t) {
			String hullId = id.endsWith("_Hull") ? id.substring(0, id.length() - 5) : id;
			ShipHullSpecAPI h = Global.getSettings().getHullSpec(hullId);
			return Global.getFactory().createFleetMember(FleetMemberType.SHIP,
					Global.getSettings().createEmptyVariant(hullId + "_playerhq_v", h));
		}
	}

	public static List<String> roll(FleetKind kind) {
		return kind.fixed() ? fixedShips(kind) : rollPatrol();
	}

	private static List<String> fixedShips(FleetKind kind) {
		List<String> ships = new ArrayList<String>();
		for (String[] part : kind.parts()) {
			ShipHullSpecAPI h = hull(part[0], part[1]);
			if (h == null) continue;
			int count = Integer.parseInt(part[2]);
			for (int i = 0; i < count; i++) ships.add(h.getHullId() + "_Hull");
		}
		return ships;
	}

	private static void group(Map<String, List<String>> map, ShipHullSpecAPI h, String variantId) {
		List<String> l = map.get(h.getHullId());
		if (l == null) {
			l = new ArrayList<String>();
			map.put(h.getHullId(), l);
		}
		l.add(variantId);
	}

	private static String pick(Map<String, List<String>> map) {
		if (map.isEmpty()) return null;
		List<List<String>> all = new ArrayList<List<String>>(map.values());
		List<String> variants = all.get(RANDOM.nextInt(all.size()));
		return variants.get(RANDOM.nextInt(variants.size()));
	}

	private static List<String> rollPatrol() {
		Set<String> known = Global.getSector().getPlayerFaction().getKnownShips();
		Map<String, List<String>> capital = new HashMap<String, List<String>>();
		Map<String, List<String>> cruiser = new HashMap<String, List<String>>();
		Map<String, List<String>> destroyer = new HashMap<String, List<String>>();
		Map<String, List<String>> frigate = new HashMap<String, List<String>>();
		for (String id : Global.getSettings().getAllVariantIds()) {
			if (id.endsWith("_Hull")) continue;
			ShipVariantAPI v;
			try {
				v = Global.getSettings().getVariant(id);
			} catch (Throwable t) {
				continue;
			}
			if (v == null) continue;
			ShipHullSpecAPI h = v.getHullSpec();
			if (h == null || !known.contains(h.getHullId())) continue;
			if (h.isDHull() || h.isCivilianNonCarrier()) continue;
			if (h.getHints().contains(ShipTypeHints.STATION) || h.getHints().contains(ShipTypeHints.MODULE)) continue;
			HullSize size = h.getHullSize();
			if (size == HullSize.CAPITAL_SHIP) group(capital, h, id);
			else if (size == HullSize.CRUISER) group(cruiser, h, id);
			else if (size == HullSize.DESTROYER) group(destroyer, h, id);
			else if (size == HullSize.FRIGATE) group(frigate, h, id);
		}
		List<String> ships = new ArrayList<String>();
		String cap = pick(capital);
		if (cap != null) ships.add(cap);
		int cruisers = 6;
		for (int i = 0; i < cruisers; i++) {
			String s = pick(cruiser);
			if (s != null) ships.add(s);
		}
		if (destroyer.isEmpty() && frigate.isEmpty()) return ships;
		while (ships.size() < PATROL_SIZE) {
			Map<String, List<String>> pool = destroyer.isEmpty() ? frigate : frigate.isEmpty() ? destroyer
					: (RANDOM.nextBoolean() ? destroyer : frigate);
			ships.add(pick(pool));
		}
		return ships;
	}

	private static float crewPrice() {
		return Global.getSettings().getCommoditySpec(Commodities.CREW).getBasePrice();
	}

	public static long cost(FleetKind kind, List<String> ships) {
		if (!kind.fixed()) return PATROL_COST;
		float crew = crewPrice();
		float total = 0f;
		for (String id : ships) {
			ShipHullSpecAPI h = specOf(id);
			if (h == null) continue;
			total += h.getBaseValue() + h.getMinCrew() * crew;
			if (kind == FleetKind.MINING) total += MiningOps.gearCost(h);
		}
		return Math.round(total);
	}

	public static String buy(FleetKind kind) {
		SectorEntityToken station = station();
		if (station == null || !hqBuilt(station.getMarket())) return "The station needs a Fleet HQ first.";
		if (kind == FleetKind.PATROL && StarfarerRules.on()) return "Choose the Patrol Fleet's ships from the station's main menu (Patrol Fleet).";
		if (owned(kind) >= kind.limit()) return "You already own the most " + kind.label + "s allowed.";
		List<String> ships = roll(kind);
		if (ships.isEmpty()) return kind.fixed() ? "The hulls for this fleet could not be found." : "You do not know any blueprints suitable for a patrol.";
		long cost = cost(kind, ships);
		com.fs.starfarer.api.util.MutableValue credits = Global.getSector().getPlayerFleet().getCargo().getCredits();
		if (credits.get() < cost) return "Not enough credits for the " + kind.label + ".";
		credits.subtract(cost);
		StationFleet f = new StationFleet(kind);
		f.paid = cost;
		f.days = 0f;
		f.ships = ships;
		capacities(f);
		list().add(f);
		return null;
	}

	public static long refund(StationFleet f) {
		if (f.variants != null) return f.paid;
		return Math.round(f.paid * SELL_RETURN);
	}

	public static void refill(StationFleet f) {
		if (f.variants != null) {
			f.ships = new ArrayList<String>();
			for (ShipVariantAPI v : f.variants) f.ships.add(v.getHullSpec().getHullId() + "_Hull");
		} else {
			f.ships = roll(f.kind);
		}
	}

	public static void sell(StationFleet f) {
		long back = refund(f);
		if (f.fleet != null && f.fleet.isAlive()) f.fleet.despawn();
		f.fleet = null;
		f.hold = null;
		clearCall(f);
		CharterRuns.release(f, true);
		list().remove(f);
		if (f.variants != null) PatrolPick.returnOriginals(f);
		Global.getSector().getPlayerFleet().getCargo().getCredits().add(back);
	}

	public static void disbandAll() {
		for (StationFleet f : new ArrayList<StationFleet>(list())) sell(f);
	}

	private static void clearCall(StationFleet f) {
		Object o = Global.getSector().getMemoryWithoutUpdate().get(CALL_KEY);
		if (o == f) Global.getSector().getMemoryWithoutUpdate().unset(CALL_KEY);
	}

	public static void advanceDay() {
		SectorEntityToken station = station();
		if (station == null) return;
		maintainFinds(station);
		Object o = station.getMemoryWithoutUpdate().get(KEY);
		if (!(o instanceof List) || ((List<?>) o).isEmpty()) return;
		List<StationFleet> list = list();
		if (!hqBuilt(station.getMarket())) {
			for (StationFleet f : list) {
				if (f.fleet != null && f.fleet.isAlive()) f.fleet.despawn();
			}
			list.clear();
			Global.getSector().getMemoryWithoutUpdate().unset(CALL_KEY);
			return;
		}
		for (StationFleet f : new ArrayList<StationFleet>(list)) step(station, f);
		CharterRuns.dispatchAvailable(station);
	}

	public static CargoAPI finds(MarketAPI market) {
		if (market == null) return null;
		if (isText(market.getPrimaryEntity())) return playerhq.modules.MilitaryWardModule.getExpeditionFindsCargo(market.getPrimaryEntity());
		if (!market.hasSubmarket(FINDS_ID)) market.addSubmarket(FINDS_ID);
		CargoAPI cargo = market.getSubmarket(FINDS_ID).getCargo();
		cargo.initMothballedShips(Factions.PLAYER);
		return cargo;
	}

	private static void maintainFinds(SectorEntityToken station) {
		MarketAPI market = station.getMarket();
		if (market == null || isText(station)) return;
		if (hqBuilt(market)) {
			finds(market);
			return;
		}
		if (!market.hasSubmarket(FINDS_ID)) return;
		CargoAPI stored = market.getSubmarket(FINDS_ID).getCargo();
		CargoAPI storage = storage(station);
		if (storage != null) {
			storage.addAll(stored);
			if (stored.getMothballedShips() != null) {
				storage.initMothballedShips(Factions.PLAYER);
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(stored.getMothballedShips().getMembersListCopy())) {
					stored.getMothballedShips().removeFleetMember(m);
					storage.getMothballedShips().addFleetMember(m);
				}
			}
		}
		market.removeSubmarket(FINDS_ID);
	}

	public static void capacities(StationFleet f) {
		float cargo = 0f;
		float fuel = 0f;
		float crew = 0f;
		for (String id : f.ships) {
			ShipHullSpecAPI h = specOf(id);
			if (h == null) continue;
			cargo += h.getCargo();
			fuel += h.getFuel();
			crew += h.getMaxCrew();
		}
		f.capCargo = cargo;
		f.capFuel = fuel;
		f.capCrew = crew;
	}

	public static float[] capacities(List<String> ships) {
		StationFleet f = new StationFleet(FleetKind.LOGISTICS);
		f.ships = ships;
		capacities(f);
		return new float[] { f.capCargo, f.capFuel, f.capCrew };
	}

	static boolean arrived(CampaignFleetAPI fleet, SectorEntityToken target) {
		if (fleet == null || target == null) return false;
		if (fleet.getContainingLocation() != target.getContainingLocation()) return false;
		if (Misc.getDistance(fleet, target) <= target.getRadius() + ARRIVAL_RANGE) return true;
		return fleet.getCurrentAssignment() == null;
	}

	static void travel(CampaignFleetAPI fleet, SectorEntityToken target, String text) {
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, target, 999f, text);
	}

	static void sendHome(SectorEntityToken station, StationFleet f) {
		f.homing = true;
		if (f.fleet != null && f.fleet.isAlive()) {
			f.fleet.setOrbit(null);
			assign(station, f);
		}
	}

	private static void returnStep(SectorEntityToken station, StationFleet f) {
		CampaignFleetAPI fleet = f.fleet;
		if (arrived(fleet, station)) {
			fleet.despawn();
			deliver(station, f);
			f.fleet = null;
			f.state = StationFleet.DOCKED;
			f.days = f.kind.logistics() ? COOLDOWN_DAYS : f.kind == FleetKind.PATROL ? DOCK_DAYS : f.kind == FleetKind.SALVAGE ? SalvageOps.COOLDOWN_DAYS : 0f;
			f.outDays = 0f;
			f.homing = false;
			f.phase = StationFleet.NONE;
			f.stage = StationFleet.STG_NONE;
			refill(f);
			capacities(f);
			return;
		}
		if (fleet.getCurrentAssignment() == null) assign(station, f);
	}

	public static void advanceReturns() {
		CharterRuns.advance();
		SectorEntityToken station = station();
		if (station == null) return;
		Object o = station.getMemoryWithoutUpdate().get(KEY);
		if (!(o instanceof List) || ((List<?>) o).isEmpty()) return;
		for (StationFleet f : new ArrayList<StationFleet>(list())) {
			if (!f.kind.logistics() || f.state != StationFleet.OUT || !f.homing) continue;
			if (f.fleet == null || !f.fleet.isAlive() || f.fleet.getBattle() != null) continue;
			returnStep(station, f);
		}
	}

	public static void deposit(StationFleet f) {
		CargoAPI storage = storage();
		if (storage != null && f.pending != null) storage.addAll(f.pending);
		f.pending = null;
	}

	private static void step(SectorEntityToken station, StationFleet f) {
		if (f.state == StationFleet.DOCKED) {
			if (f.kind.logistics()) {
				if (f.days > 0f) f.days -= 1f;
				return;
			}
			if (f.kind == FleetKind.PATROL) {
				f.days -= 1f;
				if (f.days <= 0f) launch(station, f);
				return;
			}
			if (f.kind == FleetKind.SALVAGE && f.days > 0f) {
				f.days -= 1f;
				return;
			}
			launch(station, f);
			return;
		}
		if (f.state == StationFleet.REBUILD) {
			f.days -= 1f;
			if (f.days <= 0f) {
				refill(f);
				capacities(f);
				f.state = StationFleet.DOCKED;
				f.days = f.kind == FleetKind.PATROL ? 1f : 0f;
			}
			return;
		}
		CampaignFleetAPI fleet = f.fleet;
		if (fleet == null || !fleet.isAlive() || fleet.getFleetData().getMembersListCopy().isEmpty()) {
			if (fleet != null && fleet.isAlive()) fleet.despawn();
			f.fleet = null;
			f.hold = null;
			f.recovered = null;
			f.carried = new LinkedHashMap<String, Float>();
			f.load = 0f;
			f.stage = StationFleet.STG_NONE;
			CharterRuns.release(f, false);
			f.phase = StationFleet.NONE;
			clearCall(f);
			f.state = StationFleet.REBUILD;
			f.days = StarfarerRules.on() ? (f.kind == FleetKind.PATROL ? patrolReplaceDays(f) : RELAUNCH_DAYS) : REBUILD_DAYS;
			f.homing = false;
			return;
		}
		if (fleet.getBattle() != null) return;
		if (f.kind.logistics() && !f.homing) return;
		if (f.homing) {
			returnStep(station, f);
			return;
		}
		f.outDays += 1f;
		if (f.kind == FleetKind.TRADE) TradeOps.advance(station, f);
		else if (f.kind == FleetKind.MINING) MiningOps.advance(station, f);
		else if (f.kind == FleetKind.EXPEDITION) ExpeditionOps.advance(station, f);
		else if (f.kind == FleetKind.SALVAGE) SalvageOps.advance(station, f);
		else if (f.kind == FleetKind.PATROL) PatrolOps.advance(station, f);
	}

	private static void launch(SectorEntityToken station, StationFleet f) {
		if (f.ships.isEmpty()) refill(f);
		capacities(f);
		f.stage = StationFleet.STG_NONE;
		f.stageDays = 0f;
		f.target = null;
		f.targetMarket = null;
		f.load = 0f;
		f.carried = new LinkedHashMap<String, Float>();
		f.hold = null;
		f.finds = 0;
		boolean ok = true;
		if (f.kind == FleetKind.TRADE) ok = TradeOps.prepare(station, f);
		else if (f.kind == FleetKind.MINING) ok = MiningOps.prepare(station, f);
		else if (f.kind == FleetKind.EXPEDITION) ok = ExpeditionOps.prepare(station, f);
		else if (f.kind == FleetKind.SALVAGE) ok = SalvageOps.prepare(station, f);
		if (!ok) {
			if (f.kind == FleetKind.PATROL) f.days = DOCK_DAYS;
			return;
		}
		CampaignFleetAPI fleet = build(station, f);
		if (fleet == null) {
			f.days = DOCK_DAYS;
			return;
		}
		f.fleet = fleet;
		f.state = StationFleet.OUT;
		f.outDays = 0f;
		f.homing = false;
		if (f.kind == FleetKind.TRADE) TradeOps.launched(station, f);
		else if (f.kind == FleetKind.MINING) MiningOps.launched(station, f);
		else if (f.kind == FleetKind.EXPEDITION) ExpeditionOps.launched(station, f);
		else if (f.kind == FleetKind.SALVAGE) SalvageOps.launched(station, f);
		else PatrolOps.launched(station, f);
	}

	static CampaignFleetAPI build(SectorEntityToken station, StationFleet f) {
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return null;
		if (f.ships.isEmpty()) refill(f);
		if (f.ships.isEmpty()) return null;
		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER, f.kind.label, false);
		List<FleetMemberAPI> members = new ArrayList<FleetMemberAPI>();
		FleetMemberAPI flagship = null;
		List<String> ids = f.ships;
		int total = f.variants != null ? f.variants.size() : ids.size();
		for (int idx = 0; idx < total; idx++) {
			FleetMemberAPI m;
			try {
				m = f.variants != null ? Global.getFactory().createFleetMember(FleetMemberType.SHIP, f.variants.get(idx).clone()) : member(ids.get(idx));
			} catch (Throwable t) {
				Global.getLogger(Fleets.class).warn("Could not create a fleet member", t);
				continue;
			}
			if (StarfarerRules.on() && f.kind != FleetKind.PATROL) outfit(m, f.kind == FleetKind.MINING);
			fleet.getFleetData().addFleetMember(m);
			members.add(m);
			if (flagship == null || m.getHullSpec().getHullSize().ordinal() > flagship.getHullSpec().getHullSize().ordinal()) flagship = m;
		}
		if (members.isEmpty()) return null;
		fleet.getFleetData().setFlagship(flagship);
		if (f.kind != FleetKind.PATROL) {
			if (StarfarerRules.on()) fleet.addTag("playerhq_v_stationfleet");
			fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_MAKE_NON_HOSTILE, true);
			fleet.getMemoryWithoutUpdate().set(MemFlags.FLEET_IGNORED_BY_OTHER_FLEETS, true);
			fleet.getMemoryWithoutUpdate().set(MemFlags.FLEET_IGNORES_OTHER_FLEETS, true);
			fleet.setNoEngaging(400f);
		}
		try {
			fleet.getFleetData().setSyncNeeded();
			fleet.getFleetData().syncIfNeeded();
		} catch (Throwable t) {
		}
		float crew = 0f;
		for (FleetMemberAPI m : members) {
			crew += m.getHullSpec().getMaxCrew();
			m.getStats().getSuppliesPerMonth().modifyMult("playerhq_v_fleet", 0f, "Station fleet");
			if (m.getRepairTracker() != null) {
				m.getRepairTracker().setMothballed(false);
				m.getRepairTracker().setCrashMothballed(false);
				m.updateStats();
				m.getRepairTracker().setCR(m.getRepairTracker().getMaxCR());
			}
		}
		fleet.getCargo().addCrew(Math.min(Math.round(crew), fleet.getCargo().getFreeCrewSpace()));
		float space = fleet.getCargo().getSpaceLeft();
		if (space > 0f) fleet.getCargo().addSupplies(space);
		int fuel = fleet.getCargo().getFreeFuelSpace();
		if (fuel > 0) fleet.getCargo().addFuel(fuel);
		if (f.kind == FleetKind.PATROL) {
			if (academyBuilt()) addAcademyOfficers(fleet, members, flagship);
			else addCaptains(fleet, members, flagship);
		}
		system.addEntity(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);
		return fleet;
	}

	private static PersonAPI officer(boolean leader, int skillCount, List<String> combat, List<String> leadership, FleetMemberAPI m) {
		if (m.getVariant().hasHullMod(HullMods.AUTOMATED)) {
			return Misc.getAICoreOfficerPlugin(Commodities.ALPHA_CORE).createPerson(Commodities.ALPHA_CORE, Factions.PLAYER, RANDOM);
		}
		PersonAPI p = Global.getSector().getFaction(Factions.PLAYER).createRandomPerson();
		MutableCharacterStatsAPI stats = p.getStats();
		stats.setSkipRefresh(true);
		stats.setLevel(skillCount + 5);
		for (String id : combat) stats.setSkillLevel(id, 2f);
		if (leader) for (String id : leadership) stats.setSkillLevel(id, 2f);
		stats.setSkipRefresh(false);
		stats.refreshCharacterStatsEffects();
		p.setPersonality(Personalities.STEADY);
		p.setRankId(leader ? Ranks.SPACE_ADMIRAL : Ranks.SPACE_COMMANDER);
		p.setPostId(leader ? Ranks.POST_FLEET_COMMANDER : Ranks.POST_OFFICER);
		return p;
	}

	private static void addCaptains(CampaignFleetAPI fleet, List<FleetMemberAPI> members, FleetMemberAPI flagship) {
		List<String> combat = new ArrayList<String>();
		List<String> leadership = new ArrayList<String>();
		for (String id : Global.getSettings().getSkillIds()) {
			SkillSpecAPI spec = Global.getSettings().getSkillSpec(id);
			if (spec == null || spec.isAptitudeEffect() || spec.isAdminSkill()) continue;
			if (spec.isCombatOfficerSkill()) combat.add(id);
			else if ("leadership".equals(spec.getGoverningAptitudeId())) leadership.add(id);
		}
		int count = combat.size() + leadership.size();
		for (FleetMemberAPI m : members) {
			try {
				boolean leader = m == flagship;
				PersonAPI p = officer(leader, count, combat, leadership, m);
				m.setCaptain(p);
				if (leader) fleet.setCommander(p);
			} catch (Throwable t) {
				Global.getLogger(Fleets.class).warn("Could not add a captain", t);
			}
		}
	}

	private static final String[] FLEET_MOD_NAMES = { "augmenteddrivefield", "efficiencyoverhaul" };

	private static String norm(String name) {
		return name == null ? "" : name.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]", "");
	}

	private static String modIdByName(String wanted) {
		for (com.fs.starfarer.api.loading.HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
			if (wanted.equals(norm(spec.getDisplayName())) || wanted.equals(norm(spec.getId()))) return spec.getId();
		}
		return null;
	}

	private static String roleModId(FleetMemberAPI m) {
		ShipHullSpecAPI h = m.getHullSpec();
		String design = h.getDesignation() == null ? "" : h.getDesignation().toLowerCase(java.util.Locale.ROOT);
		if (h.getHints().contains(ShipTypeHints.TANKER) || design.contains("tanker")) return modIdByName("auxiliaryfueltanks");
		if (h.getHints().contains(ShipTypeHints.TRANSPORT) || design.contains("transport")) return modIdByName("additionalberthing");
		if (h.getHints().contains(ShipTypeHints.FREIGHTER) || design.contains("freighter")) return modIdByName("expandedcargoholds");
		return null;
	}

	private static void outfit(FleetMemberAPI m, boolean mining) {
		try {
			ShipVariantAPI v = m.getVariant().clone();
			v.setSource(com.fs.starfarer.api.loading.VariantSource.REFIT);
			boolean changed = false;
			List<String> wanted = new ArrayList<String>();
			for (String name : FLEET_MOD_NAMES) {
				String id = modIdByName(name);
				if (id != null) wanted.add(id);
			}
			String role = roleModId(m);
			if (role != null) wanted.add(role);
			for (String id : wanted) {
				if (v.hasHullMod(id)) continue;
				v.addPermaMod(id, true);
				changed = true;
			}
			if (mining) {
				com.fs.starfarer.api.loading.WeaponSpecAPI laser = null;
				com.fs.starfarer.api.loading.WeaponSpecAPI blaster = null;
				try {
					laser = Global.getSettings().getWeaponSpec("mininglaser");
				} catch (Throwable t) {
				}
				try {
					blaster = Global.getSettings().getWeaponSpec("hammer");
				} catch (Throwable t) {
				}
				for (com.fs.starfarer.api.loading.WeaponSlotAPI slot : v.getHullSpec().getAllWeaponSlotsCopy()) {
					if (slot.isDecorative() || slot.isSystemSlot() || slot.isBuiltIn() || slot.isStationModule() || slot.isHidden()) continue;
					if (slot.getSlotSize() != com.fs.starfarer.api.combat.WeaponAPI.WeaponSize.SMALL) continue;
					com.fs.starfarer.api.combat.WeaponAPI.WeaponType type = slot.getWeaponType();
					if (type == com.fs.starfarer.api.combat.WeaponAPI.WeaponType.LAUNCH_BAY || type == com.fs.starfarer.api.combat.WeaponAPI.WeaponType.DECORATIVE
							|| type == com.fs.starfarer.api.combat.WeaponAPI.WeaponType.SYSTEM || type == com.fs.starfarer.api.combat.WeaponAPI.WeaponType.BUILT_IN
							|| type == com.fs.starfarer.api.combat.WeaponAPI.WeaponType.STATION_MODULE) continue;
					String weaponId = v.getWeaponId(slot.getId());
					if (weaponId != null && !weaponId.isEmpty()) continue;
					com.fs.starfarer.api.loading.WeaponSpecAPI pick = type == com.fs.starfarer.api.combat.WeaponAPI.WeaponType.MISSILE ? blaster : laser;
					if (pick == null) continue;
					v.addWeapon(slot.getId(), pick.getWeaponId());
					changed = true;
				}
				String pod = null;
				try {
					pod = Global.getSettings().getFighterWingSpec("mining_drone_wing").getId();
				} catch (Throwable t) {
				}
				if (pod != null) {
					for (int i = 0; i < v.getHullSpec().getFighterBays(); i++) {
						if (v.getHullSpec().isBuiltInWing(i)) continue;
						String wing = v.getWingId(i);
						if (wing != null && !wing.isEmpty()) continue;
						v.setWingId(i, pod);
						changed = true;
					}
				}
			}
			if (changed) {
				v.getWeaponGroups().clear();
				v.autoGenerateWeaponGroups();
				m.setVariant(v, false, true);
				m.updateStats();
			}
		} catch (Throwable t) {
			Global.getLogger(Fleets.class).warn("Could not outfit a ship", t);
		}
	}

	private static PersonAPI skilledOfficer(boolean leader, List<String> combat, int normal, int elite, String[] leadership) {
		PersonAPI p = Global.getSector().getFaction(Factions.PLAYER).createRandomPerson();
		MutableCharacterStatsAPI stats = p.getStats();
		List<String> pool = new ArrayList<String>(combat);
		java.util.Collections.shuffle(pool, RANDOM);
		stats.setSkipRefresh(true);
		int total = 0;
		for (int i = 0; i < normal + elite && i < pool.size(); i++) {
			stats.setSkillLevel(pool.get(i), i < elite ? 2f : 1f);
			total++;
		}
		if (leadership != null) {
			for (String id : leadership) {
				stats.setSkillLevel(id, 1f);
				total++;
			}
		}
		stats.setLevel(Math.max(1, total));
		stats.setSkipRefresh(false);
		stats.refreshCharacterStatsEffects();
		p.setPersonality(Personalities.STEADY);
		p.setRankId(leader ? Ranks.SPACE_ADMIRAL : Ranks.SPACE_COMMANDER);
		p.setPostId(leader ? Ranks.POST_FLEET_COMMANDER : Ranks.POST_OFFICER);
		return p;
	}

	private static int academyTier() {
		SectorEntityToken station = station();
		if (station == null || station.getMarket() == null || isText(station)) return 0;
		Industry ind = station.getMarket().getIndustry(AcademyStructure.ID);
		return ind instanceof AcademyStructure ? ((AcademyStructure) ind).tier() : 0;
	}

	private static boolean academyBuilt() {
		SectorEntityToken station = station();
		if (isText(station)) return playerhq.modules.StationItemsModule.hasAcademyInstalled(station);
		Industry ind = station == null || station.getMarket() == null ? null : station.getMarket().getIndustry(AcademyStructure.ID);
		return ind != null && !ind.isBuilding();
	}

	private static void addAcademyOfficers(CampaignFleetAPI fleet, List<FleetMemberAPI> members, FleetMemberAPI flagship) {
		List<String> combat = new ArrayList<String>();
		for (String id : Global.getSettings().getSkillIds()) {
			SkillSpecAPI spec = Global.getSettings().getSkillSpec(id);
			if (spec == null || spec.isAptitudeEffect() || spec.isAdminSkill()) continue;
			if (spec.isCombatOfficerSkill()) combat.add(id);
		}
		int tier = academyTier();
		for (FleetMemberAPI m : members) {
			try {
				boolean leader = m == flagship;
				PersonAPI p = null;
				if (m.getVariant().hasHullMod(HullMods.AUTOMATED)) {
					p = Misc.getAICoreOfficerPlugin(Commodities.ALPHA_CORE).createPerson(Commodities.ALPHA_CORE, Factions.PLAYER, RANDOM);
				} else {
					HullSize size = m.getHullSpec().getHullSize();
					int normal = AcademyStructure.normal(size, tier);
					int elite = AcademyStructure.elite(size, tier);
					if (normal + elite > 0) {
						p = skilledOfficer(leader, combat, normal, elite, size == HullSize.CAPITAL_SHIP ? AcademyStructure.leadership(tier) : null);
					}
				}
				if (p == null) continue;
				m.setCaptain(p);
				if (leader) fleet.setCommander(p);
			} catch (Throwable t) {
				Global.getLogger(Fleets.class).warn("Could not add an officer", t);
			}
		}
	}

	static CargoAPI storage(SectorEntityToken station) {
		MarketAPI market = station.getMarket();
		if (market == null || market.getSubmarket(Submarkets.SUBMARKET_STORAGE) == null) return null;
		return market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
	}

	public static CargoAPI storage() {
		SectorEntityToken station = station();
		return station == null ? null : storage(station);
	}

	private static void deliver(SectorEntityToken station, StationFleet f) {
		CargoAPI storage = storage(station);
		if (f.kind == FleetKind.EXPEDITION) ExpeditionOps.deliver(station, f);
		else if (f.kind == FleetKind.MINING) MiningOps.deliver(station, f);
		else if (f.kind == FleetKind.SALVAGE) SalvageOps.deliver(station, f);
		else if (storage != null && f.hold != null) {
			storage.addAll(f.hold);
			if (f.hold.getMothballedShips() != null && !f.hold.getMothballedShips().getMembersListCopy().isEmpty()) {
				storage.initMothballedShips(com.fs.starfarer.api.impl.campaign.ids.Factions.PLAYER);
				for (com.fs.starfarer.api.fleet.FleetMemberAPI ship : f.hold.getMothballedShips().getMembersListCopy()) {
					f.hold.getMothballedShips().removeFleetMember(ship);
					storage.getMothballedShips().addFleetMember(ship);
				}
			}
		}
		f.hold = null;
		f.load = 0f;
		f.carried = new LinkedHashMap<String, Float>();
		f.usedCargo = 0f;
		f.usedFuel = 0f;
		f.usedCrew = 0f;
		f.pending = null;
	}

	public static int ownedCount(FleetKind kind) {
		int n = 0;
		for (StationFleet f : list()) {
			if (f.kind == kind) n++;
		}
		return n;
	}

	/** "2 Mining, 1 Trade, 3 Logistics" -- the fleets the station owns, for the Status Report. */
	public static String ownedSummary() {
		StringBuilder sb = new StringBuilder();
		for (FleetKind kind : FleetKind.values()) {
			int n = 0;
			for (StationFleet f : list()) {
				if (f.kind == kind) n++;
			}
			if (n <= 0) continue;
			if (sb.length() > 0) sb.append(", ");
			sb.append(n).append(" ").append(kind.label.replace(" Fleet", ""));
		}
		return sb.length() == 0 ? null : sb.toString();
	}

	public static StationFleet ready() {
		return ready(null);
	}

	public static StationFleet ready(FleetKind kind) {
		for (StationFleet f : list()) {
			if (f.kind.logistics() && (kind == null || f.kind == kind) && f.state == StationFleet.DOCKED && f.days <= 0f) return f;
		}
		return null;
	}

	public static boolean callBusy() {
		for (StationFleet f : list()) {
			if (f.kind.logistics() && (f.phase == StationFleet.CALL || f.phase == StationFleet.MEETING || f.phase == StationFleet.LOADING)) return true;
		}
		return false;
	}

	public static int readyCount() {
		return readyCount(null);
	}

	public static int readyCount(FleetKind kind) {
		int n = 0;
		for (StationFleet f : list()) {
			if (f.kind.logistics() && (kind == null || f.kind == kind) && f.state == StationFleet.DOCKED && f.days <= 0f) n++;
		}
		return n;
	}

	public static final int CALL_CHARGES = 2;

	public static int callsOut() {
		int n = 0;
		for (StationFleet f : list()) {
			if (!f.kind.logistics() || f.state != StationFleet.OUT) continue;
			if (f.phase == StationFleet.CALL || f.phase == StationFleet.MEETING || f.phase == StationFleet.LOADING || f.phase == StationFleet.RETURN) n++;
		}
		return n;
	}

	public static int chargesLeft() {
		return Math.max(0, CALL_CHARGES - callsOut());
	}

	public static boolean canCall() {
		return ready() != null && !callBusy() && chargesLeft() > 0;
	}

	public static boolean call() {
		return call(null);
	}

	public static boolean call(FleetKind kind) {
		return call(kind, false);
	}

	public static boolean call(FleetKind kind, boolean resupply) {
		SectorEntityToken station = station();
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		StationFleet f = ready(kind);
		if (station == null || player == null || f == null || callBusy() || chargesLeft() <= 0) return false;
		capacities(f);
		CampaignFleetAPI fleet = build(station, f);
		if (fleet == null) return false;
		fleet.getMemoryWithoutUpdate().set(MemFlags.DO_NOT_TRY_TO_AVOID_NEARBY_FLEETS, true);
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_FLEET_DO_NOT_GET_SIDETRACKED, true);
		fleet.getStats().getFleetwideMaxBurnMod().modifyPercent("playerhq_v_rush", 100f, "Rush");
		f.fleet = fleet;
		f.state = StationFleet.OUT;
		f.phase = StationFleet.LOADING;
		f.launchStamp = Global.getSector().getClock().getTimestamp();
		f.resupply = resupply;
		f.homing = false;
		f.outDays = 0f;
		f.usedCargo = 0f;
		f.usedFuel = 0f;
		f.usedCrew = 0f;
		Global.getSector().getMemoryWithoutUpdate().set(CALL_KEY, f);
		// Orbit the station for a day, as if loading, before heading out to the player.
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, station, LOAD_DAYS + 1f, "Loading at " + station.getName());
		return true;
	}

	private static void rushTowardsPlayer(CampaignFleetAPI fleet, CampaignFleetAPI player) {
		FleetAssignmentDataAPI current = fleet.getCurrentAssignment();
		if (fleet.getContainingLocation() != player.getContainingLocation()) {
			if (current == null || current.getAssignment() != FleetAssignment.INTERCEPT || current.getTarget() != player) {
				fleet.clearAssignments();
				fleet.addAssignment(FleetAssignment.INTERCEPT, player, 100f, "Heading to your fleet");
			}
			return;
		}
		boolean needsNewTarget = current == null
				|| current.getAssignment() != FleetAssignment.GO_TO_LOCATION
				|| current.getTarget() == null
				|| Misc.getDistance(fleet, current.getTarget()) <= RETARGET_RANGE;
		if (!needsNewTarget) return;
		SectorEntityToken spot = fleet.getContainingLocation().createToken(player.getLocation().x, player.getLocation().y);
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, spot, 100f, "Heading to your fleet");
	}

	public static void advanceCall() {
		Object o = Global.getSector().getMemoryWithoutUpdate().get(CALL_KEY);
		if (!(o instanceof StationFleet)) return;
		StationFleet f = (StationFleet) o;
		boolean dialogUp = Global.getSector().getCampaignUI().isShowingDialog()
				|| Global.getSector().getCampaignUI().getCurrentInteractionDialog() != null;
		if (f.phase == StationFleet.MEETING) {
			if (!dialogUp) f.phase = StationFleet.CALL;
			return;
		}
		if (f.phase == StationFleet.LOADING) {
			if (f.fleet == null || !f.fleet.isAlive()) return;
			if (Global.getSector().getClock().getElapsedDaysSince(f.launchStamp) >= LOAD_DAYS) {
				f.phase = StationFleet.CALL;
				f.fleet.clearAssignments();
			}
			return;
		}
		if (f.phase != StationFleet.CALL) {
			Global.getSector().getMemoryWithoutUpdate().unset(CALL_KEY);
			return;
		}
		CampaignFleetAPI fleet = f.fleet;
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (fleet == null || !fleet.isAlive() || player == null) return;
		boolean near = fleet.getContainingLocation() == player.getContainingLocation()
				&& Misc.getDistance(fleet, player) <= MEET_RANGE;
		if (!near) {
			rushTowardsPlayer(fleet, player);
			return;
		}
		if (dialogUp || player.getBattle() != null) return;
		fleet.clearAssignments();
		f.phase = StationFleet.MEETING;
		com.fs.starfarer.api.campaign.InteractionDialogPlugin meeting = f.resupply
				? new playerhq.abilities.ResupplyMeetingDialogPlugin(storage(station()), f.capCargo, f.capFuel, f.capCrew, new Runnable() {
					@Override
					public void run() {
						finishMeeting(f);
					}
				})
				: new playerhq.abilities.CourierPickupTransferDialogPlugin(station(), fleet, new Runnable() {
					@Override
					public void run() {
						finishMeeting(f);
					}
				});
		if (!Global.getSector().getCampaignUI().showInteractionDialog(meeting, player)) {
			f.phase = StationFleet.CALL;
		}
	}

	public static void finishMeeting(StationFleet f) {
		SectorEntityToken station = station();
		f.phase = StationFleet.RETURN;
		f.homing = true;
		clearCall(f);
		if (station != null && f.fleet != null && f.fleet.isAlive()) assign(station, f);
	}

	static void assign(SectorEntityToken station, StationFleet f) {
		CampaignFleetAPI fleet = f.fleet;
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, 60f, "Returning to " + station.getName());
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_FLEET_DO_NOT_GET_SIDETRACKED, true);
	}

	private static String num(float v) {
		return String.format("%,d", Math.round(v));
	}

	public static String holdLine(StationFleet f) {
		capacities(f);
		if (f.kind.logistics()) {
			return "Hold: " + num(f.capCargo) + " cargo, " + num(f.capFuel) + " fuel, " + num(f.capCrew) + " crew";
		}
		if (f.kind == FleetKind.TRADE || f.kind == FleetKind.EXPEDITION) {
			float used = 0f;
			if (f.hold != null) used = f.kind == FleetKind.EXPEDITION ? ExpeditionLoot.used(f.hold) : TradeOps.used(f.hold);
			return "Hold: " + num(used) + " / " + num(f.capCargo) + " cargo";
		}
		if (f.kind == FleetKind.MINING) {
			return "Hold: " + num(f.load) + " / " + num(f.capCargo) + " cargo, mining power " + num(MiningOps.power(f)) + " per day";
		}
		return null;
	}

	public static String holdLine(FleetKind kind, List<String> ships) {
		StationFleet f = new StationFleet(kind);
		f.ships = ships;
		capacities(f);
		if (kind.logistics()) {
			return "Hold: " + num(f.capCargo) + " cargo, " + num(f.capFuel) + " fuel, " + num(f.capCrew) + " crew";
		}
		if (kind == FleetKind.MINING) {
			return "Hold: " + num(f.capCargo) + " cargo, mining power " + num(MiningOps.power(f)) + " per day";
		}
		if (kind == FleetKind.TRADE || kind == FleetKind.EXPEDITION) return "Hold: " + num(f.capCargo) + " cargo";
		return null;
	}

	public static String status(StationFleet f) {
		if (f.state == StationFleet.OUT) {
			if (f.phase == StationFleet.CHARTER) return CharterRuns.status(f);
			if (f.phase == StationFleet.LOADING) return "Loading at the station";
			if (f.phase == StationFleet.CALL) return "On its way to you";
			if (f.phase == StationFleet.MEETING) return "Meeting you";
			if (f.phase == StationFleet.RETURN) return "Returning to the station";
			if (f.homing) return "Returning to the station";
			if (f.kind == FleetKind.TRADE) return TradeOps.status(f);
			if (f.kind == FleetKind.MINING) return MiningOps.status(f);
			if (f.kind == FleetKind.EXPEDITION) return ExpeditionOps.status(f);
			if (f.kind == FleetKind.SALVAGE) return SalvageOps.status(f);
			if (f.kind == FleetKind.PATROL) return PatrolOps.status(f);
			return "Out on a trip";
		}
		if (f.state == StationFleet.REBUILD) return "Being rebuilt, ready in " + Math.max(1, Math.round(f.days)) + " days";
		if (f.kind.logistics()) return f.days > 0f ? "Docked, ready in " + Math.max(1, Math.round(f.days)) + " days" : "Docked, ready to be called";
		if (f.kind == FleetKind.PATROL) return "Docked, launching in " + Math.max(1, Math.round(f.days)) + " days";
		if (f.kind == FleetKind.TRADE) return "Docked, waiting for enough surplus stock to fill the hold";
		if (f.kind == FleetKind.MINING) return "Docked, waiting for a resource to drop below 10,000";
		if (f.kind == FleetKind.SALVAGE) return "Docked, waiting for something to salvage";
		return "Docked, waiting for a ruins site within 10 light years";
	}
}
