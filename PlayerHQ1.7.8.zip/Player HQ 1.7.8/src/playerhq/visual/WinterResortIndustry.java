package playerhq.visual;

import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;

public class WinterResortIndustry extends ResortIndustry {

	@Override
	public boolean isAvailableToBuild() {
		if (market != null && !market.hasTag(TestIds.TAG_STATION)) return false;
		if (market == null) return false;
		if (market.hasIndustry(getId())) return true;
		if (market.getConstructionQueue() != null && market.getConstructionQueue().hasItem(getId())) return true;
		if (market.getConstructionQueue() != null && market.getConstructionQueue().hasItem(TestIds.INDUSTRY_BEACH)) return false;
		if (!market.hasIndustry(TestIds.INDUSTRY_RESORT) || market.hasIndustry(TestIds.INDUSTRY_BEACH)) return false;
		if (!StarfarerRules.afford(market, getId())) return false;
		if (!TestIds.REQUIREMENTS) return true;
		if (market.getSubmarket(Submarkets.SUBMARKET_STORAGE) == null) return false;
		CargoAPI cargo = market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null)) >= 1f;
	}

	@Override
	public String getUnavailableReason() {
		if (market != null && !market.hasIndustry(TestIds.INDUSTRY_RESORT)) return "Requires a Resort to upgrade.";
		if (market != null && market.hasIndustry(TestIds.INDUSTRY_BEACH)) return "This resort is already a Beach Resort.";
		String lack = StarfarerRules.lacking(market, getId());
		return lack != null ? lack : "Requires a Cryoarithmetic Engine in the station's storage.";
	}

	@Override
	protected int getImageOffset() {
		return 2;
	}

	@Override
	public float getBuildCost() {
		Float sf = StarfarerRules.credits(getId());
		if (sf != null) return sf;
		return 25000f;
	}

	@Override
	public boolean showWhenUnavailable() {
		if (market != null && !market.hasTag(TestIds.TAG_STATION)) return false;
		return market != null && market.hasIndustry(TestIds.INDUSTRY_RESORT);
	}

	@Override
	protected float getClimateBonus(MarketAPI orbit) {
		if (orbit == null) return 0.10f;
		if (orbit.hasCondition(Conditions.VERY_HOT)) return 0.30f;
		if (orbit.hasCondition(Conditions.HOT)) return 0.20f;
		return 0.10f;
	}

	@Override
	protected String getClimateText() {
		return "Winter Resort";
	}

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		super.addPostDescriptionSection(tooltip, mode);
		if (TestIds.REQUIREMENTS && ReqText.isBuildMode(mode)) {
			ReqText.addItem(tooltip, market, Items.CRYOARITHMETIC_ENGINE, 1, "Cryoarithmetic Engine");
		}
	}
}
