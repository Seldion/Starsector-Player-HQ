package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.util.IntervalUtil;

public class MonthlyScript implements EveryFrameScript {

	private static final String KEY = "$playerhq_v_lastMonth";

	private final IntervalUtil interval = new IntervalUtil(0.5f, 1f);

	@Override
	public boolean isDone() {
		return false;
	}

	@Override
	public boolean runWhilePaused() {
		return false;
	}

	@Override
	public void advance(float amount) {
		interval.advance(Global.getSector().getClock().convertToDays(amount));
		if (!interval.intervalElapsed()) return;
		ensureReport(TestStation.find());
		int now = Global.getSector().getClock().getCycle() * 12 + Global.getSector().getClock().getMonth();
		Object last = Global.getSector().getMemoryWithoutUpdate().get(KEY);
		Global.getSector().getMemoryWithoutUpdate().set(KEY, now);
		if (!(last instanceof Integer)) return;
		if ((Integer) last == now) return;
		run(true);
		TradeOps.resetIncome();
	}

	public static void run(boolean announce) {
		SectorEntityToken station = TestStation.find();
		if (station == null || station.getMarket() == null) return;
		MarketAPI market = station.getMarket();
		List<String> lines = new ArrayList<String>();
		for (Industry ind : new ArrayList<Industry>(market.getIndustries())) {
			if (!(ind instanceof MonthlyProducer)) continue;
			if (ind.isBuilding() || ind.isDisrupted()) continue;
			String s = ((MonthlyProducer) ind).produceMonthly();
			if (s != null) lines.add(ind.getCurrentName() + " " + s);
		}
		float sales = TradeOps.income(market);
		if (announce && sales > 0f) lines.add("Trade Fleet sales brought in " + (int) sales + " credits");
		if (announce) playerhq.PlayerHQMonthlyReportIntel.reportVisual(station, lines);
	}

	/** Old saves and fresh builds: make sure the Status Report exists in the Intel screen. */
	static void ensureReport(SectorEntityToken station) {
		playerhq.PlayerHQMonthlyReportIntel.ensureCreated(station);
	}
}
