package playerhq.visual;

import java.awt.Color;

import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.Industry.IndustryTooltipMode;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class ReqText {

	public static boolean isBuildMode(IndustryTooltipMode mode) {
		return mode == IndustryTooltipMode.ADD_INDUSTRY || mode == IndustryTooltipMode.UPGRADE;
	}

	public static CargoAPI storage(MarketAPI market) {
		if (market == null || market.getSubmarket(Submarkets.SUBMARKET_STORAGE) == null) return null;
		return market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
	}

	public static void addCommodity(TooltipMakerAPI tooltip, MarketAPI market, String commodityId, float needed, String name) {
		CargoAPI cargo = storage(market);
		float have = cargo == null ? 0f : cargo.getCommodityQuantity(commodityId);
		add(tooltip, (int) needed + " " + name, (int) have, have >= needed);
	}

	public static void addItem(TooltipMakerAPI tooltip, MarketAPI market, String itemId, int needed, String name) {
		CargoAPI cargo = storage(market);
		float have = cargo == null ? 0f : cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(itemId, null));
		add(tooltip, needed + " " + name, (int) have, have >= needed);
	}

	private static void add(TooltipMakerAPI tooltip, String need, int have, boolean ok) {
		Color c = ok ? Misc.getPositiveHighlightColor() : Misc.getNegativeHighlightColor();
		tooltip.addPara("Also requires %s in the station's storage. You have %s.", 10f, Misc.getTextColor(), c, need, String.valueOf(have));
	}
}
