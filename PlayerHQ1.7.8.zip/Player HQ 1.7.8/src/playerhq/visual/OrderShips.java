package playerhq.visual;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCustomProductionPickerDelegateImpl;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionProductionAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.ListMap;
import com.fs.starfarer.api.util.Misc;

public class OrderShips {

	public static final String ASSEMBLY = "playerhq_v_assembly";

	public static AssemblyIndustry assembly(SectorEntityToken station) {
		if (station == null || station.getMarket() == null) return null;
		Industry ind = station.getMarket().getIndustry(ASSEMBLY);
		if (!(ind instanceof AssemblyIndustry)) return null;
		if (ind.isBuilding() || ind.isUpgrading()) return null;
		return (AssemblyIndustry) ind;
	}

	public static String firstVariantId(String hullId) {
		if (hullId == null) return null;
		try {
			String bareId = hullId + "_Hull";
			if (Global.getSettings().getVariant(bareId) != null) return bareId;
		} catch (Throwable t) {
		}
		ListMap<String> variantsByHull = Global.getSettings().getHullIdToVariantListMap();
		List<String> variants = variantsByHull.get(hullId);
		if (variants == null || variants.isEmpty()) return null;
		for (String variantId : variants) {
			try {
				com.fs.starfarer.api.combat.ShipVariantAPI variant = Global.getSettings().getVariant(variantId);
				if (variant == null) continue;
				if (!variant.getSMods().isEmpty() || !variant.getPermaMods().isEmpty()) continue;
				return variantId;
			} catch (Throwable t) {
			}
		}
		return variants.get(0);
	}

	public static class Picker extends BaseCustomProductionPickerDelegateImpl {

		private final SectorEntityToken station;
		private final TextPanelAPI text;

		public Picker(SectorEntityToken station, TextPanelAPI text) {
			this.station = station;
			this.text = text;
		}

		private float mult() {
			AssemblyIndustry a = assembly(station);
			return a == null ? 1f : 1f - a.discount();
		}

		@Override
		public Set<String> getAvailableShipHulls() {
			return new LinkedHashSet<String>(Global.getSector().getPlayerFaction().getKnownShips());
		}

		@Override
		public Set<String> getAvailableWeapons() {
			return new LinkedHashSet<String>(Global.getSector().getPlayerFaction().getKnownWeapons());
		}

		@Override
		public Set<String> getAvailableFighters() {
			return new LinkedHashSet<String>(Global.getSector().getPlayerFaction().getKnownFighters());
		}

		@Override
		public float getCostMult() {
			return mult();
		}

		@Override
		public float getMaximumValue() {
			CampaignFleetAPI pf = Global.getSector().getPlayerFleet();
			float credits = pf == null ? 0f : pf.getCargo().getCredits().get();
			AssemblyIndustry a = assembly(station);
			if (StarfarerRules.on() && a != null) return Math.min(credits, a.pool());
			return credits;
		}

		@Override
		public void notifyProductionSelected(FactionProductionAPI production) {
			CampaignFleetAPI pf = Global.getSector().getPlayerFleet();
			MarketAPI market = station.getMarket();
			CargoAPI storage = Production.storage(market);
			if (pf == null || storage == null || assembly(station) == null) {
				text.addPara("The Strategic Assembly is not available.");
				return;
			}
			float m = mult();
			float total = 0f;
			for (FactionProductionAPI.ItemInProductionAPI item : production.getCurrent()) {
				total += unitCost(item, m) * item.getQuantity();
			}
			if (total > pf.getCargo().getCredits().get()) {
				text.addPara("The order could not be completed: you do not have enough credits.");
				return;
			}
			AssemblyIndustry asm = assembly(station);
			if (StarfarerRules.on() && asm != null && total > asm.pool()) {
				text.addPara("The order could not be completed: the order pool only holds " + Misc.getDGSCredits(asm.pool()) + ".");
				return;
			}
			int built = 0;
			for (FactionProductionAPI.ItemInProductionAPI item : production.getCurrent()) {
				FactionProductionAPI.ProductionItemType type = item.getType();
				for (int i = 0; i < item.getQuantity(); i++) {
					if (deliver(storage, type, item.getSpecId())) built++;
				}
			}
			if (built > 0) {
				pf.getCargo().getCredits().subtract(total);
				if (StarfarerRules.on() && asm != null) asm.spendPool(total);
				text.addPara("Order complete: " + built + " item(s) delivered to the station's storage for "
						+ Misc.getDGSCredits(total) + " credits.");
			} else {
				text.addPara("The order could not be completed.");
			}
		}

		private float unitCost(FactionProductionAPI.ItemInProductionAPI item, float m) {
			FactionProductionAPI.ProductionItemType type = item.getType();
			float base = 0f;
			if (type == FactionProductionAPI.ProductionItemType.SHIP) {
				ShipHullSpecAPI h = Global.getSettings().getHullSpec(item.getSpecId());
				if (h != null) base = h.getBaseValue();
			} else if (type == FactionProductionAPI.ProductionItemType.FIGHTER) {
				FighterWingSpecAPI w = Global.getSettings().getFighterWingSpec(item.getSpecId());
				if (w != null) base = w.getBaseValue();
			} else if (type == FactionProductionAPI.ProductionItemType.WEAPON) {
				WeaponSpecAPI w = Global.getSettings().getWeaponSpec(item.getSpecId());
				if (w != null) base = w.getBaseValue();
			}
			return base * m;
		}

		private boolean deliver(CargoAPI storage, FactionProductionAPI.ProductionItemType type, String id) {
			if (type == FactionProductionAPI.ProductionItemType.SHIP) {
				String variantId = firstVariantId(id);
				if (variantId == null) return false;
				storage.addMothballedShip(FleetMemberType.SHIP, variantId, null);
				return true;
			} else if (type == FactionProductionAPI.ProductionItemType.FIGHTER) {
				storage.addFighters(id, 1);
				return true;
			} else if (type == FactionProductionAPI.ProductionItemType.WEAPON) {
				storage.addWeapons(id, 1);
				return true;
			}
			return false;
		}
	}
}
