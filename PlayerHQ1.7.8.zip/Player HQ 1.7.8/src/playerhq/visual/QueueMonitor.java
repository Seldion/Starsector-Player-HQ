package playerhq.visual;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MutableCommodityQuantity;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.ConstructionQueue;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;

public class QueueMonitor implements EveryFrameScript {

	public static final String PAID_KEY = "$playerhq_v_paid_queue";
	public static final float FOUNDRY_METALS = 100f;

	private final IntervalUtil interval = new IntervalUtil(1f, 2f);

	@Override
	public boolean isDone() {
		return false;
	}

	@Override
	public boolean runWhilePaused() {
		return true;
	}

	@Override
	public void advance(float amount) {
		interval.advance(amount);
		if (!interval.intervalElapsed()) return;

		SectorEntityToken core = TestStation.find();
		if (core != null && core.getMarket() != null) {
			Industry pop = core.getMarket().getIndustry(com.fs.starfarer.api.impl.campaign.ids.Industries.POPULATION);
			if (pop != null && !pop.isHidden()) pop.setHidden(true);
			if (!core.getMarket().hasTag("market_no_industries_allowed")) core.getMarket().addTag("market_no_industries_allowed");
			if (core.getMarket().isImmigrationIncentivesOn()) core.getMarket().setImmigrationIncentivesOn(false);
			core.getMarket().getStats().getDynamic().getMod("max_market_size").modifyFlat("playerhq_v_nogrowth",
					core.getMarket().getSize() - com.fs.starfarer.api.util.Misc.MAX_COLONY_SIZE, "Player HQ station");
			enforceAllowedStructures(core.getMarket());
			migrate(core.getMarket());
			ensureStockpile(core.getMarket());
			ensureStationUpkeep(core.getMarket());
			StarfarerRules.process(core.getMarket());
syncMarketPlace(core.getMarket());
			MarineDefense.advance(core);
			swapResort(core.getMarket(), TestIds.INDUSTRY_BEACH);
			swapResort(core.getMarket(), TestIds.INDUSTRY_WINTER);
			keepOrder(core.getMarket());
		}
		if (!TestIds.REQUIREMENTS) return;
		SectorEntityToken station = TestStation.find();
		if (station == null || station.getMarket() == null) return;
		MarketAPI market = station.getMarket();
		if (market.getSubmarket(Submarkets.SUBMARKET_STORAGE) == null) return;
		CargoAPI cargo = market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		MemoryAPI mem = market.getMemoryWithoutUpdate();
		Set<String> paid = (Set<String>) mem.get(PAID_KEY);
		if (paid == null) {
			paid = new HashSet<String>();
			mem.set(PAID_KEY, paid);
		}

		ConstructionQueue queue = market.getConstructionQueue();
		List<String> queued = new ArrayList<String>();
		if (queue != null) {
			for (ConstructionQueue.ConstructionQueueItem item : queue.getItems()) {
				queued.add(item.id);
			}
		}

		for (String id : queued) {
			if (paid.contains(id)) continue;
			if (TestIds.INDUSTRY_FOUNDRY.equals(id)) {
				if (cargo.getCommodityQuantity(Commodities.METALS) >= FOUNDRY_METALS) {
					cargo.removeCommodity(Commodities.METALS, FOUNDRY_METALS);
					paid.add(id);
				}
			} else if (TestIds.INDUSTRY_BEACH.equals(id) || TestIds.INDUSTRY_WINTER.equals(id)) {
				SpecialItemData need = new SpecialItemData(itemFor(id), null);
				if (cargo.getQuantity(CargoItemType.SPECIAL, need) >= 1f) {
					cargo.removeItems(CargoItemType.SPECIAL, need, 1f);
					paid.add(id);
				}
			}
		}

		Industry resort = market.getIndustry(TestIds.INDUSTRY_RESORT);
		String upgrading = null;
		if (resort instanceof ResortIndustry && resort.isUpgrading()) {
			upgrading = ((ResortIndustry) resort).getUpgradeTargetId();
		}
		if (upgrading != null && !paid.contains("upg:" + upgrading)) {
			SpecialItemData need = new SpecialItemData(itemFor(upgrading), null);
			if (cargo.getQuantity(CargoItemType.SPECIAL, need) >= 1f) {
				cargo.removeItems(CargoItemType.SPECIAL, need, 1f);
				paid.add("upg:" + upgrading);
			} else {
				resort.cancelUpgrade();
			}
		}
		for (String key : new ArrayList<String>(paid)) {
			if (!key.startsWith("upg:")) continue;
			String id = key.substring(4);
			if (id.equals(upgrading)) continue;
			if (!market.hasIndustry(id)) {
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemFor(id), null), 1f);
			}
			paid.remove(key);
		}

		for (String id : new ArrayList<String>(paid)) {
			if (id.startsWith("upg:")) continue;
			if (queued.contains(id)) continue;
			if (!market.hasIndustry(id)) {
				if (TestIds.INDUSTRY_FOUNDRY.equals(id)) {
					cargo.addCommodity(Commodities.METALS, FOUNDRY_METALS);
				} else {
					cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemFor(id), null), 1f);
				}
			}
			paid.remove(id);
		}

	}

	private static String itemFor(String id) {
		return TestIds.INDUSTRY_BEACH.equals(id) ? Items.ORBITAL_FUSION_LAMP : Items.CRYOARITHMETIC_ENGINE;
	}

	private static final String ORDER_KEY = "$playerhq_v_order";
	private static final String[][] TOP = {
		{ "playerhq_v_fleet_hq", "playerhq_v_military_ward" },
		{ "playerhq_v_assembly" },
		{ "playerhq_v_manufactorium" }
	};

	private void keepOrder(MarketAPI market) {
		List<Industry> list = market.getIndustries();
		MemoryAPI mem = market.getMemoryWithoutUpdate();
		List<String> saved = (List<String>) mem.get(ORDER_KEY);
		if (saved == null) saved = new ArrayList<String>();
		Set<String> now = new HashSet<String>();
		for (Industry i : list) now.add(i.getId());
		List<String> next = new ArrayList<String>();
		next.addAll(saved);
		for (Industry i : list) {
			String id = i.getId();
			if (next.contains(id)) continue;
			int at = next.size();
			try {
				String from = Global.getSettings().getIndustrySpec(id).getDowngrade();
				if (from != null && next.contains(from)) at = next.indexOf(from) + 1;
			} catch (Throwable t) {
			}
			next.add(at, id);
		}
		for (java.util.Iterator<String> it = next.iterator(); it.hasNext();) if (!now.contains(it.next())) it.remove();
		final List<String> order = new ArrayList<String>();
		for (String[] group : TOP) {
			for (String id : group) if (now.contains(id)) order.add(id);
		}
		for (String id : next) if (now.contains(id) && !order.contains(id)) order.add(id);
		boolean same = list.size() == order.size();
		for (int i = 0; same && i < list.size(); i++) if (!list.get(i).getId().equals(order.get(i))) same = false;
		if (!same) {
			try {
				java.util.Collections.sort(list, new java.util.Comparator<Industry>() {
					public int compare(Industry a, Industry b) {
						return order.indexOf(a.getId()) - order.indexOf(b.getId());
					}
				});
			} catch (Throwable t) {
				Global.getLogger(QueueMonitor.class).warn("Could not reorder structures", t);
			}
		}
		if (!next.equals(saved)) mem.set(ORDER_KEY, next);
	}

	private void swapResort(MarketAPI market, String upgradeId) {
		Industry upgrade = market.getIndustry(upgradeId);
		Industry resort = market.getIndustry(TestIds.INDUSTRY_RESORT);
		if (upgrade == null || resort == null) return;
		if (upgrade.isBuilding() || upgrade.isUpgrading()) return;
		SpecialItemData item = resort.getSpecialItem();
		resort.setSpecialItem(null);
		String core = resort.getAICoreId();
		if (core != null && upgrade.getAICoreId() == null) {
			upgrade.setAICoreId(core);
			resort.setAICoreId(null);
		}
		market.removeIndustry(TestIds.INDUSTRY_RESORT, null, true);
		if (item != null && upgrade.getSpecialItem() == null) upgrade.setSpecialItem(item);
	}

	private static final String[][] EXPECTED = {
		{ "playerhq_v_mining_hub", "playerhq.visual.MiningHubIndustry" },
		{ "playerhq_v_manufactorium", "playerhq.visual.ManufactoriumIndustry" },
		{ "playerhq_v_biodome", "playerhq.visual.BiodomeIndustry" },
		{ "playerhq_v_assembly", "playerhq.visual.AssemblyIndustry" },
		{ "playerhq_v_military_ward", "playerhq.visual.MilitaryIndustry" },
		{ "playerhq_v_fleet_hq", "playerhq.visual.FleetHqIndustry" },
		{ "playerhq_v_marketplace", "playerhq.visual.MarketPlaceStructure" },
		{ "playerhq_v_public_shuttles", "playerhq.visual.AccessStructure" },
		{ "playerhq_v_space_elevator", "playerhq.visual.AccessStructure" }
	};

	private void ensureStationUpkeep(MarketAPI market) {
		if (!market.hasIndustry(StationUpkeepIndustry.ID)) market.addIndustry(StationUpkeepIndustry.ID);
	}

	private void ensureStockpile(MarketAPI market) {
		if (!market.hasSubmarket(Submarkets.LOCAL_RESOURCES)) market.addSubmarket(Submarkets.LOCAL_RESOURCES);
	}

	private void syncMarketPlace(MarketAPI market) {
		Industry mp = market.getIndustry(MarketPlaceSupport.INDUSTRY);
		boolean built = mp != null && !mp.isBuilding();
		if (built) {
			MarketPlaceSupport.addSubmarkets(market);
		} else if (mp == null && (market.hasSubmarket(MarketPlaceSupport.AGORA) || market.hasSubmarket(MarketPlaceSupport.EXCHANGE))) {
			MarketPlaceSupport.removeSubmarkets(market);
		}
	}

	private static boolean isPlayerHQStructure(String id) {
		return id != null && (id.startsWith("playerhq") || Industries.POPULATION.equals(id));
	}

	private static boolean isHiddenUtilityIndustry(String id) {
		try {
			return Global.getSettings().getIndustrySpec(id).hasTag("do_not_show_in_build_dialog");
		} catch (Throwable t) {
			return false;
		}
	}

	private static final String ENFORCED_WARNED_KEY = "$playerhq_v_enforcedWarned";

	@SuppressWarnings("unchecked")
	private static Set<String> enforcedWarned(MarketAPI market) {
		MemoryAPI mem = market.getMemoryWithoutUpdate();
		Set<String> warned = (Set<String>) mem.get(ENFORCED_WARNED_KEY);
		if (warned == null) {
			warned = new HashSet<String>();
			mem.set(ENFORCED_WARNED_KEY, warned);
		}
		return warned;
	}

	private void enforceAllowedStructures(MarketAPI market) {
		ConstructionQueue queue = market.getConstructionQueue();
		if (queue != null) {
			for (ConstructionQueue.ConstructionQueueItem item : new ArrayList<ConstructionQueue.ConstructionQueueItem>(queue.getItems())) {
				if (isPlayerHQStructure(item.id)) continue;
				if (isHiddenUtilityIndustry(item.id)) continue;
				String name = item.id;
				try {
					name = Global.getSettings().getIndustrySpec(item.id).getName();
				} catch (Throwable t) {
				}
				queue.removeItem(item.id);
				CampaignFleetAPI pf = Global.getSector().getPlayerFleet();
				if (pf != null && item.cost > 0) pf.getCargo().getCredits().add(item.cost);
				Global.getSector().getCampaignUI().addMessage("The Player HQ can only build its own structures. Construction of "
						+ name + " was cancelled and " + Misc.getDGSCredits(item.cost) + " refunded.",
						Misc.getNegativeHighlightColor());
			}
		}
		Set<String> warned = enforcedWarned(market);
		for (Industry ind : new ArrayList<Industry>(market.getIndustries())) {
			String id = ind.getId();
			if (isPlayerHQStructure(id)) continue;
			if (isHiddenUtilityIndustry(id)) continue;
			if (StationUpkeepIndustry.ID.equals(id)) continue;
			if (ind.isBuilding() || ind.isUpgrading()) continue;
			String name = ind.getCurrentName();
			market.removeIndustry(id, null, true);
			if (warned.add(id)) {
				Global.getSector().getCampaignUI().addMessage("The Player HQ can only build its own structures. "
						+ name + " was removed.",
						Misc.getNegativeHighlightColor());
			}
		}
	}

	private void migrate(com.fs.starfarer.api.campaign.econ.MarketAPI market) {
		for (String[] e : EXPECTED) {
			Industry ind = market.getIndustry(e[0]);
			if (ind == null || ind.isBuilding() || ind.isUpgrading()) continue;
			if (ind.getClass().getName().equals(e[1])) continue;
			market.removeIndustry(e[0], null, true);
			market.addIndustry(e[0]);
		}
	}
}
