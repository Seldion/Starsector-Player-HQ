package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.Industry.IndustryTooltipMode;
import com.fs.starfarer.api.campaign.listeners.DialogCreatorUI;
import com.fs.starfarer.api.campaign.listeners.IndustryOptionProvider;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class FleetHqOptionProvider implements IndustryOptionProvider {

	public static final Object OPTION_ID = "playerhq_v_buy_fleet";

	@Override
	public List<IndustryOptionData> getIndustryOptions(Industry ind) {
		if (!(ind instanceof FleetHqIndustry)) return null;
		if (ind.isBuilding() || ind.isUpgrading()) return null;
		List<IndustryOptionData> list = new ArrayList<IndustryOptionData>();
		IndustryOptionData data = new IndustryOptionData("Manage Fleet", OPTION_ID, ind, this);
		data.color = Misc.getHighlightColor();
		data.enabled = true;
		list.add(data);
		return list;
	}

	@Override
	public void createTooltip(IndustryOptionData opt, TooltipMakerAPI tooltip, float width) {
		if (opt.id != OPTION_ID) return;
		tooltip.addPara("Manage station fleets: buy four Transport Fleets, two each of the Trade, Mining, Expedition and Salvage Fleets, and a Patrol Fleet. " + (StarfarerRules.on() ? "The Patrol Fleet is built from ships you pick, and a second one needs Expanded Sorties." : "The Patrol Fleet is built from random ships you know."), 0f);
	}

	@Override
	public void optionSelected(IndustryOptionData opt, DialogCreatorUI ui) {
		if (opt.id != OPTION_ID) return;
		ui.showDialog(580f, 520f, new BuyFleetDialog());
	}

	@Override
	public void addToIndustryTooltip(Industry ind, IndustryTooltipMode mode, TooltipMakerAPI tooltip, float width, boolean expanded) {
	}
}
