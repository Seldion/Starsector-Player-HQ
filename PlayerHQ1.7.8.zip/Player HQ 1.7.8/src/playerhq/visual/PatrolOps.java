package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;

public class PatrolOps {

	public static final int PATROL_DAYS = 90;
	public static final float LEG_DAYS = 6f;
	public static final float THREAT_RANGE = 4000f;
	public static final float DEFEND_DAYS = 8f;

	public static void launched(SectorEntityToken station, StationFleet f) {
		f.stage = StationFleet.STG_WORK;
		f.stageDays = 0f;
		f.fleet.clearAssignments();
		leg(station, f);
	}

	private static boolean friendly(MarketAPI market) {
		if (market == null || market.isHidden() || market.getPrimaryEntity() == null) return false;
		return market.getFaction() == null || !market.getFaction().isHostileTo(Factions.PLAYER);
	}

	private static void leg(SectorEntityToken station, StationFleet f) {
		StarSystemAPI system = station.getStarSystem();
		List<SectorEntityToken> options = new ArrayList<SectorEntityToken>();
		options.add(station);
		if (system != null) {
			for (MarketAPI market : Misc.getMarketsInLocation(system)) {
				if (friendly(market) && market.getPrimaryEntity() != station) options.add(market.getPrimaryEntity());
			}
			options.addAll(system.getJumpPoints());
		}
		SectorEntityToken target = options.get((int) (Math.random() * options.size()));
		f.fleet.addAssignment(FleetAssignment.ORBIT_AGGRESSIVE, target, LEG_DAYS, "Patrolling near " + target.getName());
	}

	private static SectorEntityToken threatened(SectorEntityToken station) {
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return null;
		List<SectorEntityToken> colonies = new ArrayList<SectorEntityToken>();
		for (MarketAPI market : Misc.getMarketsInLocation(system)) {
			if (friendly(market)) colonies.add(market.getPrimaryEntity());
		}
		if (colonies.isEmpty()) return null;
		for (CampaignFleetAPI other : system.getFleets()) {
			if (other.getBattle() == null || other.getFaction() == null) continue;
			if (!other.getFaction().isHostileTo(Factions.PLAYER)) continue;
			for (SectorEntityToken colony : colonies) {
				if (Misc.getDistance(other, colony) <= THREAT_RANGE) return colony;
			}
		}
		return null;
	}

	public static void advance(SectorEntityToken station, StationFleet f) {
		CampaignFleetAPI fleet = f.fleet;
		if (f.outDays >= PATROL_DAYS) {
			Fleets.sendHome(station, f);
			return;
		}
		if (f.stage == StationFleet.STG_DEFEND) {
			f.stageDays -= 1f;
			if (f.stageDays <= 0f) {
				f.stage = StationFleet.STG_WORK;
				fleet.clearAssignments();
				leg(station, f);
			}
			return;
		}
		SectorEntityToken colony = threatened(station);
		if (colony != null) {
			fleet.clearAssignments();
			fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, colony, 5f, "Responding to an attack near " + colony.getName());
			fleet.addAssignment(FleetAssignment.DEFEND_LOCATION, colony, DEFEND_DAYS, "Defending " + colony.getName());
			f.stage = StationFleet.STG_DEFEND;
			f.stageDays = DEFEND_DAYS;
			return;
		}
		if (fleet.getCurrentAssignment() == null) leg(station, f);
	}

	public static String status(StationFleet f) {
		if (f.stage == StationFleet.STG_DEFEND) return "Defending a colony, day " + Math.round(f.outDays) + " of " + PATROL_DAYS;
		return "Patrolling, day " + Math.round(f.outDays) + " of " + PATROL_DAYS;
	}
}
