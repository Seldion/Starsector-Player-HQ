package playerhq.visual;

import com.fs.starfarer.api.ui.TooltipMakerAPI;

public class FleetHqIndustry extends MilitaryIndustry {

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		super.addPostDescriptionSection(tooltip, mode);
		tooltip.addPara("Keeps everything the Military Paradigm does and adds the station fleets. Right-click the Fleet HQ to buy fleets: " + "four Transport Fleets, two each of the Trade, Mining, Expedition and Salvage Fleets, and a Patrol Fleet. " + (StarfarerRules.on() ? "The Patrol Fleet is built from ships you pick, and a second one needs Expanded Sorties." : "The Patrol Fleet is built from random ships you know."), 3f);
		if (mode == IndustryTooltipMode.ADD_INDUSTRY) return;
		StringBuilder sb = new StringBuilder();
		for (FleetKind k : FleetKind.values()) {
			if (k.limit() <= 0) continue;
			if (sb.length() > 0) sb.append(", ");
			sb.append(k.label).append(" ").append(Fleets.owned(k)).append("/").append(k.limit());
		}
		tooltip.addPara("Fleets owned: %s.", 3f, com.fs.starfarer.api.util.Misc.getHighlightColor(), sb.toString());
	}

	@Override
	public boolean canShutDown() {
		return Fleets.list().isEmpty() && super.canShutDown();
	}

	@Override
	public String getCanNotShutDownReason() {
		return Fleets.list().isEmpty() ? super.getCanNotShutDownReason() : "Sell or disband every fleet first";
	}
}
