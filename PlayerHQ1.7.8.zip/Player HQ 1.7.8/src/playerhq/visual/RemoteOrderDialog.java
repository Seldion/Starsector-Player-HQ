package playerhq.visual;

import java.util.Map;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;

/** Order Production from the Intel report in Visual mode: opens the Strategic Assembly's order picker from anywhere. */
public class RemoteOrderDialog implements InteractionDialogPlugin {

	private static final String DONE = "playerhq_v_remote_order_done";

	private final SectorEntityToken station;
	private InteractionDialogAPI dialog;
	private boolean unavailable = false;
	private boolean pickerRequested = false;

	public RemoteOrderDialog(SectorEntityToken station) {
		this.station = station;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		if (station == null || !station.isAlive() || OrderShips.assembly(station) == null) {
			dialog.getTextPanel().addPara("The Strategic Assembly is not available.");
			unavailable = true;
		}
		dialog.getOptionPanel().addOption("Done", DONE);
		dialog.setOptionOnEscape("Done", DONE);
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		dialog.dismiss();
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) {
		if (unavailable || pickerRequested) return;
		pickerRequested = true;
		dialog.showCustomProductionPicker(new OrderShips.Picker(station, dialog.getTextPanel()));
	}

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
