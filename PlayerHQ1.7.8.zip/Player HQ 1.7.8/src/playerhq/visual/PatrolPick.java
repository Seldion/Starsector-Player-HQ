package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FleetMemberPickerListener;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.Misc;

public class PatrolPick {

	public static final int CRUISERS = 4;
	public static final int DESTROYERS = 6;
	public static final int FRIGATES = 12;

	public static boolean hasHq(SectorEntityToken station) {
		return station != null && station.getMarket() != null && Fleets.hqBuilt(station.getMarket());
	}

	private static boolean automatedBlocked(FleetMemberAPI m) {
		if (m.getVariant() == null || !m.getVariant().hasHullMod(HullMods.AUTOMATED)) return false;
		return Global.getSector().getPlayerStats().getSkillLevel(Skills.AUTOMATED_SHIPS) <= 0f;
	}

	private static boolean warship(FleetMemberAPI m) {
		if (m.getHullSpec() == null || automatedBlocked(m)) return false;
		ShipHullSpecAPI spec = m.getHullSpec();
		if (spec.isCarrier()) return !m.isStation();
		if (spec.isCivilianNonCarrier()) return false;
		if (spec.isPhase() || spec.getHints().contains(ShipHullSpecAPI.ShipTypeHints.PHASE)) return false;
		return !m.isStation();
	}

	private static void addFrom(CargoAPI cargo, String factionId, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI data = cargo.getMothballedShips();
		if (data == null) return;
		for (FleetMemberAPI m : data.getMembersListCopy()) if (warship(m)) out.add(m);
	}

	public static List<FleetMemberAPI> candidates(SectorEntityToken station, CampaignFleetAPI player) {
		List<FleetMemberAPI> out = new ArrayList<FleetMemberAPI>();
		for (FleetMemberAPI m : player.getFleetData().getMembersListCopy()) {
			if (!m.isFlagship() && warship(m)) out.add(m);
		}
		addFrom(player.getCargo(), player.getFaction().getId(), out);
		addFrom(Production.storage(station.getMarket()), player.getFaction().getId(), out);
		java.util.Collections.sort(out, new java.util.Comparator<FleetMemberAPI>() {
			@Override
			public int compare(FleetMemberAPI a, FleetMemberAPI b) {
				return b.getHullSpec().getHullSize().ordinal() - a.getHullSpec().getHullSize().ordinal();
			}
		});
		return out;
	}

	public static boolean valid(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.size() != 4) return false;
		int cap = 0, cru = 0, des = 0, fri = 0;
		for (FleetMemberAPI m : chosen) {
			HullSize s = m.getHullSpec().getHullSize();
			if (s == HullSize.CAPITAL_SHIP) cap++;
			else if (s == HullSize.CRUISER) cru++;
			else if (s == HullSize.DESTROYER) des++;
			else if (s == HullSize.FRIGATE) fri++;
		}
		return cap == 1 && cru == 1 && des == 1 && fri == 1;
	}

	public static int copies(HullSize size) {
		if (size == HullSize.CRUISER) return CRUISERS - 1;
		if (size == HullSize.DESTROYER) return DESTROYERS - 1;
		if (size == HullSize.FRIGATE) return FRIGATES - 1;
		return 0;
	}

	private static long copyCost(ShipVariantAPI v) {
		float total = v.getHullSpec().getBaseValue();
		List<String> slots = v.getNonBuiltInWeaponSlots();
		if (slots != null) {
			for (String slot : slots) {
				WeaponSpecAPI w = v.getWeaponSpec(slot);
				if (w != null) total += w.getBaseValue();
			}
		}
		List<String> wings = v.getNonBuiltInWings();
		if (wings != null) {
			for (String id : wings) {
				if (id == null || id.isEmpty()) continue;
				FighterWingSpecAPI wing = Global.getSettings().getFighterWingSpec(id);
				if (wing != null) total += wing.getBaseValue();
			}
		}
		return Math.round(total);
	}

	public static long credits(List<FleetMemberAPI> chosen) {
		long total = 0L;
		for (FleetMemberAPI m : chosen) total += copyCost(m.getVariant()) * copies(m.getHullSpec().getHullSize());
		return total;
	}

	public static int crew(List<FleetMemberAPI> chosen) {
		int total = 0;
		for (FleetMemberAPI m : chosen) {
			total += Math.round(m.getMinCrew()) * (1 + copies(m.getHullSpec().getHullSize()));
		}
		return total;
	}

	public static boolean lastBuilt = false;

	public static void open(final InteractionDialogAPI dialog, final SectorEntityToken station, final Runnable done) {
		final CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (!hasHq(station)) {
			dialog.getTextPanel().addPara("The station needs a Fleet HQ first.");
			done.run();
			return;
		}
		if (Fleets.owned(FleetKind.PATROL) >= FleetKind.PATROL.limit()) {
			dialog.getTextPanel().addPara("You already own the most Patrol Fleets allowed.");
			done.run();
			return;
		}
		lastBuilt = false;
		step(dialog, station, player, new ArrayList<FleetMemberAPI>(), done);
	}

	public static void defer(final Runnable task) {
		Global.getSector().addTransientScript(new com.fs.starfarer.api.EveryFrameScript() {
			private boolean ran = false;

			@Override
			public boolean isDone() {
				return ran;
			}

			@Override
			public boolean runWhilePaused() {
				return true;
			}

			@Override
			public void advance(float amount) {
				if (ran) return;
				ran = true;
				task.run();
			}
		});
	}

	private static final HullSize[] STEP_SIZES = { HullSize.CAPITAL_SHIP, HullSize.CRUISER, HullSize.DESTROYER, HullSize.FRIGATE };
	private static final String[] STEP_NAMES = { "Capital", "Cruiser", "Destroyer", "Frigate" };

	private static void step(final InteractionDialogAPI dialog, final SectorEntityToken station, final CampaignFleetAPI player,
			final List<FleetMemberAPI> chosen, final Runnable done) {
		final int index = chosen.size();
		if (index >= STEP_SIZES.length) {
			String error = buy(station, player, chosen);
			lastBuilt = error == null;
			dialog.getTextPanel().addPara(error != null ? error
					: "Patrol Fleet built. The rest of the fleet is filled in with copies of the ships you supplied.");
			done.run();
			return;
		}
		List<FleetMemberAPI> pool = new ArrayList<FleetMemberAPI>();
		for (FleetMemberAPI m : candidates(station, player)) {
			if (m.getHullSpec().getHullSize() == STEP_SIZES[index]) pool.add(m);
		}
		if (pool.isEmpty()) {
			dialog.getTextPanel().addPara("You have no suitable " + STEP_NAMES[index] + " (Warship or Carrier hull) in your fleet, cargo or the station's storage.");
			done.run();
			return;
		}
		dialog.showFleetMemberPickerDialog("Choose a " + STEP_NAMES[index] + " (" + (index + 1) + " of 4)",
				"Confirm", "Cancel", 4, 6, 64f, true, true, pool, new FleetMemberPickerListener() {
					@Override
					public void pickedFleetMembers(List<FleetMemberAPI> members) {
						if (members == null || members.size() != 1) {
							dialog.getTextPanel().addPara("Pick exactly one " + STEP_NAMES[index] + ".");
							defer(new Runnable() {
								@Override
								public void run() {
									step(dialog, station, player, chosen, done);
								}
							});
							return;
						}
						chosen.add(members.get(0));
						defer(new Runnable() {
							@Override
							public void run() {
								step(dialog, station, player, chosen, done);
							}
						});
					}

					@Override
					public void cancelledFleetMemberPicking() {
						dialog.getTextPanel().addPara("Patrol Fleet cancelled.");
						done.run();
					}
				});
	}

	private static void removeFrom(SectorEntityToken station, CampaignFleetAPI player, FleetMemberAPI m) {
		if (player.getFleetData().getMembersListCopy().contains(m)) {
			player.getFleetData().removeFleetMember(m);
			player.getFleetData().ensureHasFlagship();
			return;
		}
		CargoAPI cargo = player.getCargo();
		cargo.initMothballedShips(player.getFaction().getId());
		if (cargo.getMothballedShips() != null && cargo.getMothballedShips().getMembersListCopy().contains(m)) {
			cargo.getMothballedShips().removeFleetMember(m);
			return;
		}
		CargoAPI storage = Production.storage(station.getMarket());
		if (storage != null && storage.getMothballedShips() != null) storage.getMothballedShips().removeFleetMember(m);
	}

	public static String buy(SectorEntityToken station, CampaignFleetAPI player, List<FleetMemberAPI> chosen) {
		long credits = credits(chosen);
		int crew = crew(chosen);
		CargoAPI storage = Production.storage(station.getMarket());
		int stationCrew = storage == null ? 0 : storage.getCrew();
		int fleetCrew = player.getCargo().getCrew();
		if (player.getCargo().getCredits().get() < credits) return "Not enough credits for the copies: " + Misc.getDGSCredits(credits) + ".";
		if (stationCrew + fleetCrew < crew) return "Crewing the fleet takes " + crew + " crew, and only " + (stationCrew + fleetCrew) + " is available.";

		List<ShipVariantAPI> variants = new ArrayList<ShipVariantAPI>();
		List<FleetMemberAPI> originals = new ArrayList<FleetMemberAPI>();
		for (FleetMemberAPI m : chosen) {
			ShipVariantAPI v = m.getVariant().clone();
			variants.add(v);
			for (int i = 0; i < copies(m.getHullSpec().getHullSize()); i++) variants.add(v.clone());
			originals.add(m);
		}
		player.getCargo().getCredits().subtract(credits);
		int fromStation = Math.min(stationCrew, crew);
		if (storage != null && fromStation > 0) storage.removeCrew(fromStation);
		if (crew - fromStation > 0) player.getCargo().removeCrew(crew - fromStation);
		for (FleetMemberAPI m : chosen) {
			m.setCaptain(null);
			removeFrom(station, player, m);
		}
		StationFleet f = new StationFleet(FleetKind.PATROL);
		f.paid = credits;
		f.crewPaid = crew;
		f.days = 0f;
		f.variants = variants;
		f.originals = new ArrayList<ShipVariantAPI>();
		for (FleetMemberAPI m : originals) f.originals.add(m.getVariant().clone());
		f.originalNames = new ArrayList<String>();
		for (FleetMemberAPI m : originals) f.originalNames.add(m.getShipName());
		Fleets.refill(f);
		Fleets.capacities(f);
		Fleets.list().add(f);
		return null;
	}

	public static void returnOriginals(StationFleet f) {
		SectorEntityToken station = Fleets.station();
		if (station == null || f.originals == null) return;
		CargoAPI storage = Production.storage(station.getMarket());
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (storage == null) return;
		storage.initMothballedShips(player.getFaction().getId());
		for (int i = 0; i < f.originals.size(); i++) {
			FleetMemberAPI m = Global.getFactory().createFleetMember(FleetMemberType.SHIP, f.originals.get(i).clone());
			if (f.originalNames != null && i < f.originalNames.size() && f.originalNames.get(i) != null) m.setShipName(f.originalNames.get(i));
			m.setCaptain(null);
			storage.getMothballedShips().addFleetMember(m);
		}
		if (f.crewPaid > 0) storage.addCrew(f.crewPaid);
	}
}
