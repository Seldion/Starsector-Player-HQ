package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class AcademyStructure extends ModuleStructure {

	public static final String ID = "playerhq_v_academy";

	private static final int[][] NORMAL = { { 4, 5, 6, 7 }, { 2, 3, 4, 5 }, { 0, 2, 3, 4 }, { 0, 0, 2, 3 } };
	private static final int[][] ELITE = { { 1, 2, 3, 4 }, { 0, 1, 2, 3 }, { 0, 0, 1, 2 }, { 0, 0, 0, 1 } };
	private static final String[] LEADERSHIP = { "support_doctrine", "crew_training", "wolfpack_tactics", "tactical_drills" };
	private static final String[] LEADERSHIP_NAMES = { "Support Doctrine", "Crew Training", "Wolfpack Tactics", "Tactical Drills" };
	private static final String[] SIZES = { "Capital", "Cruisers", "Destroyers", "Frigates" };

	@Override
	public boolean isAvailableToBuild() {
		if (market == null || market.hasIndustry(getId())) return super.isAvailableToBuild();
		return Fleets.hqBuilt(market) && super.isAvailableToBuild();
	}

	@Override
	public String getUnavailableReason() {
		if (!Fleets.hqBuilt(market)) return "Requires a Fleet HQ";
		return super.getUnavailableReason();
	}

	@Override
	public boolean showWhenUnavailable() {
		if (market != null && !market.hasTag(TestIds.TAG_STATION)) return false;
		return true;
	}

	@Override
	public boolean canInstallAICores() {
		return true;
	}

	@Override
	protected void applyAICoreModifiers() {
	}

	@Override
	protected void applyNoAICoreModifiers() {
	}

	@Override
	protected void updateAICoreToSupplyAndDemandModifiers() {
	}

	public static int sizeIndex(HullSize size) {
		if (size == HullSize.CAPITAL_SHIP) return 0;
		if (size == HullSize.CRUISER) return 1;
		if (size == HullSize.DESTROYER) return 2;
		return 3;
	}

	public int tier() {
		String id = getAICoreId();
		if (Commodities.GAMMA_CORE.equals(id)) return 1;
		if (Commodities.BETA_CORE.equals(id)) return 2;
		if (Commodities.ALPHA_CORE.equals(id)) return 3;
		return 0;
	}

	public static int normal(HullSize size, int tier) {
		return NORMAL[sizeIndex(size)][tier];
	}

	public static int elite(HullSize size, int tier) {
		return ELITE[sizeIndex(size)][tier];
	}

	public static String[] leadership(int tier) {
		String[] out = new String[tier + 1];
		for (int i = 0; i < out.length; i++) out[i] = LEADERSHIP[i];
		return out;
	}

	public int normalSkills(HullSize size) {
		return normal(size, tier());
	}

	public int eliteSkills(HullSize size) {
		return elite(size, tier());
	}

	public String[] leadershipSkills() {
		return leadership(tier());
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode) {
		if (coreId == null) {
			if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP) {
				tooltip.addPara("No AI core currently assigned. Installing one trains more officers with more skills.", 0f);
			}
			return;
		}
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(coreId);
		TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
		text.addPara("%s: More officers with more skills.", 0f, Misc.getHighlightColor(), spec.getName());
		tooltip.addImageWithText(10f);
	}

	@Override
	public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		addAICoreSection(tooltip, getAICoreId(), mode);
	}

	@Override
	protected void addPostDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode) {
		if (mode == IndustryTooltipMode.ADD_INDUSTRY) return;
		tooltip.addPara("Officers are picked at random each time a Patrol Fleet launches.", 10f);
		HullSize[] sizes = { HullSize.CAPITAL_SHIP, HullSize.CRUISER, HullSize.DESTROYER, HullSize.FRIGATE };
		for (int i = 0; i < sizes.length; i++) {
			int n = normalSkills(sizes[i]);
			int e = eliteSkills(sizes[i]);
			if (n + e <= 0) continue;
			tooltip.addPara(SIZES[i] + ": %s combat skills and %s elite.", 3f, Misc.getHighlightColor(), "" + n, "" + e);
		}
		StringBuilder sb = new StringBuilder();
		String[] lead = leadershipSkills();
		for (int i = 0; i < lead.length; i++) {
			if (i > 0) sb.append(", ");
			sb.append(LEADERSHIP_NAMES[i]);
		}
		tooltip.addPara("The capital's officer also has: %s.", 3f, Misc.getHighlightColor(), sb.toString());
	}
}
