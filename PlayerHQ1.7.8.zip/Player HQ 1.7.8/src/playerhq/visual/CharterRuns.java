package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;

import playerhq.charter.CharterItem;
import playerhq.charter.CourierCharterData;
import playerhq.charter.CourierCharterState;
import playerhq.charter.CourierRequest;
import playerhq.modules.CourierCharterEngine;
import playerhq.modules.MilitaryWardModule;

/**
 * Courier Charters for the Visual style: a free Transport Fleet works a charter line, collecting from
 * the pickup location and delivering to the drop-off location, then heads home. Same rules as the
 * Text style's Courier Bays (CourierCharterEngine), but run on StationFleet.
 */
public class CharterRuns {

	public static final float LOAD_DAYS = 1f;
	public static final float UNLOAD_DAYS = 1f;
	public static final int MAX_SHIPS_PER_TRIP = CourierCharterEngine.MAX_SHIPS_PER_TRIP;

	public static String status(StationFleet f) {
		String name = f.target != null ? f.target.getName() : "its next stop";
		if (f.charterWaiting) {
			float left = (f.charterDelivering ? UNLOAD_DAYS : LOAD_DAYS) - Global.getSector().getClock().getElapsedDaysSince(f.charterWaitStamp);
			int days = Math.max(1, (int) Math.ceil(left));
			return (f.charterDelivering ? "Unloading cargo at " : "Loading cargo at ") + name + ", done in " + days + (days == 1 ? " day" : " days");
		}
		return f.charterDelivering ? "Heading to " + name + " to deliver goods" : "Heading to " + name + " to collect cargo";
	}

	private static boolean isHq(SectorEntityToken station, SectorEntityToken target) {
		if (target == null) return false;
		if (target == station) return true;
		return target.getMarket() != null && station.getMarket() != null && target.getMarket() == station.getMarket();
	}

	public static void dispatchAvailable(SectorEntityToken station) {
		if (station == null || !playerhq.charter.CharterAccess.available(station)) return;
		CourierCharterState state = CourierCharterData.getState();
		for (CourierRequest r : new ArrayList<CourierRequest>(state.requests)) {
			if (r.inTransit) continue;
			if (r.suspended) {
				r.status = "Suspended";
				continue;
			}
			MarketAPI source = CourierCharterData.getMarket(r.sourceMarketId);
			MarketAPI dest = CourierCharterData.getMarket(r.destMarketId);
			if (r.sourceMarketId == null) {
				r.status = "Choose a pickup location";
				continue;
			}
			if (!CourierCharterData.isUsableMarket(source, station) || !CourierCharterData.isUsableMarket(dest, station)) {
				r.status = "Location is not available";
				continue;
			}
			if (!r.hasAnything()) {
				r.status = "No items chosen yet";
				continue;
			}
			List<CharterItem> movable = CourierCharterEngine.computeMovable(station, r, dest, source);
			if (movable.isEmpty()) {
				r.status = "Nothing to move right now";
				continue;
			}
			StationFleet f = Fleets.ready(FleetKind.LOGISTICS);
			if (f == null) {
				r.status = "Waiting for a free Transport Fleet";
				continue;
			}
			if (!launch(station, r, f, dest, source, movable)) {
				r.status = "Could not launch a Transport Fleet";
			}
		}
	}

	private static boolean launch(SectorEntityToken station, CourierRequest r, StationFleet f, MarketAPI dest, MarketAPI source,
			List<CharterItem> needs) {
		Fleets.capacities(f);
		CampaignFleetAPI fleet = Fleets.build(station, f);
		if (fleet == null) return false;
		fleet.getMemoryWithoutUpdate().set(MemFlags.DO_NOT_TRY_TO_AVOID_NEARBY_FLEETS, true);
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_FLEET_DO_NOT_GET_SIDETRACKED, true);
		f.fleet = fleet;
		f.state = StationFleet.OUT;
		f.phase = StationFleet.CHARTER;
		f.homing = false;
		f.outDays = 0f;
		f.resupply = false;
		f.hold = Global.getFactory().createCargo(true);
		f.charterId = r.id;
		f.charterPlan = new ArrayList<String>();
		f.charterPlan.add(source.getId());
		f.charterNeeds = needs;
		f.charterShips = new ArrayList<FleetMemberAPI>();
		f.charterDest = dest.getId();
		f.charterDelivering = false;
		f.charterWaiting = false;
		f.target = source.getPrimaryEntity();
		Fleets.travel(fleet, f.target, "Collecting cargo at " + f.target.getName());
		r.inTransit = true;
		r.status = "Transport Fleet dispatched";
		return true;
	}

	public static void advance() {
		SectorEntityToken station = Fleets.station();
		if (station == null) return;
		for (StationFleet f : new ArrayList<StationFleet>(Fleets.list())) {
			if (f.phase != StationFleet.CHARTER || f.fleet == null || !f.fleet.isAlive()) continue;
			if (f.fleet.getBattle() != null) continue;
			step(station, f);
		}
	}

	private static void step(SectorEntityToken station, StationFleet f) {
		CampaignFleetAPI fleet = f.fleet;
		SectorEntityToken target = f.target;
		if (target == null) {
			if (f.charterDelivering) {
				finish(station, f);
				return;
			}
			if (f.charterPlan != null && !f.charterPlan.isEmpty()) f.charterPlan.remove(0);
			routeToNextStop(station, f);
			return;
		}

		if (f.charterWaiting) {
			float need = f.charterDelivering ? UNLOAD_DAYS : LOAD_DAYS;
			if (Global.getSector().getClock().getElapsedDaysSince(f.charterWaitStamp) < need) return;
			f.charterWaiting = false;
			arrivedAndDone(station, f, target);
			return;
		}

		if (!Fleets.arrived(fleet, target)) return;
		if (!isHq(station, target)) {
			fleet.clearAssignments();
			fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, target, 4f,
					(f.charterDelivering ? "Unloading cargo at " : "Loading cargo at ") + target.getName());
			f.charterWaitStamp = Global.getSector().getClock().getTimestamp();
			f.charterWaiting = true;
			return;
		}
		arrivedAndDone(station, f, target);
	}

	private static void arrivedAndDone(SectorEntityToken station, StationFleet f, SectorEntityToken target) {
		if (f.charterDelivering) {
			deliver(f, target.getMarket());
			finish(station, f);
			dispatchAvailable(station);
			return;
		}
		loadAt(f, target.getMarket());
		if (f.charterPlan != null && !f.charterPlan.isEmpty()) f.charterPlan.remove(0);
		routeToNextStop(station, f);
	}

	private static void routeToNextStop(SectorEntityToken station, StationFleet f) {
		SectorEntityToken next = null;
		while (f.charterPlan != null && !f.charterPlan.isEmpty()) {
			MarketAPI m = CourierCharterData.getMarket(f.charterPlan.get(0));
			if (m != null && m.getPrimaryEntity() != null) {
				next = m.getPrimaryEntity();
				break;
			}
			f.charterPlan.remove(0);
		}
		String label = "Collecting cargo at ";
		f.charterDelivering = false;
		if (next == null) {
			MarketAPI dest = CourierCharterData.getMarket(f.charterDest);
			if (dest == null || dest.getPrimaryEntity() == null) {
				finish(station, f);
				return;
			}
			next = dest.getPrimaryEntity();
			f.charterDelivering = true;
			label = "Delivering cargo to ";
		}
		f.charterWaiting = false;
		f.target = next;
		Fleets.travel(f.fleet, next, label + next.getName());
	}

	private static void loadAt(StationFleet f, MarketAPI market) {
		if (market == null) return;
		SubmarketAPI sub = MilitaryWardModule.getCourierTargetStorage(market);
		if (sub == null || sub.getCargo() == null) return;
		CargoAPI source = sub.getCargo();
		List<CharterItem> needs = f.charterNeeds;
		CargoAPI hold = f.hold;
		if (needs == null || hold == null) return;

		hold.updateSpaceUsed();
		float spaceLeft = Math.max(0f, f.capCargo - hold.getSpaceUsed());
		int personnelLeft = (int) Math.max(0f, f.capCrew - hold.getTotalPersonnel());
		float fuelRoom = Math.max(0f, f.capFuel - hold.getFuel());
		for (CharterItem item : needs) {
			if (item == null || item.amount <= 0) continue;

			if (item.isShip()) {
				if (f.charterShips == null || source.getMothballedShips() == null) continue;
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(source.getMothballedShips().getMembersListCopy())) {
					if (item.amount <= 0 || f.charterShips.size() >= MAX_SHIPS_PER_TRIP) break;
					if (!item.id.equals(m.getHullId())) continue;
					source.getMothballedShips().removeFleetMember(m);
					f.charterShips.add(m);
					item.amount--;
				}
				continue;
			}

			CargoAPI.CargoItemType type = item.cargoType();
			if (type == null) continue;
			Object data = CourierCharterEngine.dataFor(source, item);
			float avail = CourierCharterEngine.countIn(source, item);
			float want = Math.min(item.amount, (float) Math.floor(avail));
			if (want <= 0f) continue;

			CargoAPI probe = Global.getFactory().createCargo(true);
			probe.addItems(type, data, 1f);
			List<CargoStackAPI> probeStacks = probe.getStacksCopy();
			if (probeStacks.isEmpty()) continue;
			CargoStackAPI ps = probeStacks.get(0);

			float units;
			if (ps.isFuelStack()) {
				units = Math.min(want, fuelRoom);
				fuelRoom -= (float) Math.floor(units);
			} else if (ps.isPersonnelStack()) {
				units = Math.min(want, personnelLeft);
				personnelLeft -= (int) Math.floor(units);
			} else {
				float perUnit = ps.getCargoSpacePerUnit();
				units = perUnit > 0f ? Math.min(want, (float) Math.floor(spaceLeft / perUnit)) : want;
				spaceLeft -= units * Math.max(0f, perUnit);
			}
			units = (float) Math.floor(units);
			if (units <= 0f) continue;

			source.removeItems(type, data, units);
			hold.addItems(type, data, units);
			item.amount -= (int) units;
		}
	}

	private static void deliver(StationFleet f, MarketAPI dest) {
		if (dest == null) return;
		SectorEntityToken station = Fleets.station();
		SubmarketAPI sub = MilitaryWardModule.getCourierTargetStorage(dest);
		if (sub == null || sub.getCargo() == null) return;
		CargoAPI destCargo = sub.getCargo();
		boolean useStockpile = MilitaryWardModule.isStockpileDestination(station, dest);
		if (f.hold != null) {
			for (CargoStackAPI stack : new ArrayList<CargoStackAPI>(f.hold.getStacksCopy())) {
				if (stack == null || stack.isNull()) continue;
				float units = stack.getSize();
				if (units <= 0f) continue;
				f.hold.removeItems(stack.getType(), stack.getData(), units);
				MilitaryWardModule.deliverToColony(dest, useStockpile, destCargo, stack.getType(), stack.getData(), units);
			}
		}
		if (f.charterShips != null && !f.charterShips.isEmpty()) {
			destCargo.initMothballedShips(Factions.PLAYER);
			if (destCargo.getMothballedShips() != null) {
				for (FleetMemberAPI m : f.charterShips) destCargo.getMothballedShips().addFleetMember(m);
				f.charterShips.clear();
			}
		}
		CourierRequest r = CourierCharterData.findRequest(f.charterId);
		if (r != null) {
			r.runs++;
			r.inTransit = false;
			r.status = "Delivered, checking again when a Transport Fleet is free";
		}
		f.charterId = -1;
	}

	/** The run is over: send the fleet home. Anything it still holds goes into the station's storage when it docks. */
	private static void finish(SectorEntityToken station, StationFleet f) {
		release(f, true);
		f.phase = StationFleet.NONE;
		Fleets.sendHome(station, f);
	}

	/**
	 * Clears the run's bookkeeping. keepShips: carried ships are put in the station's storage (recalled);
	 * otherwise they were lost with the fleet.
	 */
	static void release(StationFleet f, boolean keepShips) {
		if (f.charterId < 0 && f.charterShips == null && f.charterPlan == null) return;
		if (keepShips && f.charterShips != null && !f.charterShips.isEmpty()) {
			CargoAPI hq = Fleets.storage();
			if (hq != null) {
				hq.initMothballedShips(Factions.PLAYER);
				if (hq.getMothballedShips() != null) {
					for (FleetMemberAPI m : f.charterShips) hq.getMothballedShips().addFleetMember(m);
				}
			}
		}
		if (f.charterId >= 0) {
			CourierRequest r = CourierCharterData.findRequest(f.charterId);
			if (r != null && r.inTransit) {
				r.inTransit = false;
				r.status = keepShips ? "Transport Fleet recalled" : "Transport Fleet was lost";
			}
		}
		f.charterId = -1;
		f.charterPlan = null;
		f.charterNeeds = null;
		f.charterShips = null;
		f.charterDest = null;
		f.charterDelivering = false;
		f.charterWaiting = false;
	}
}
