package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class CallFleetAbility extends BaseDurationAbility {

	public static final String ID = "playerhq_v_call_fleet";

	@Override
	public boolean isUsable() {
		if (Fleets.station() == null || !Fleets.canCall()) return false;
		return super.isUsable();
	}

	@Override
	protected void activateImpl() {
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (player == null) return;
		Global.getSector().getCampaignUI().showInteractionDialog(new CallFleetDialog(), player);
	}

	@Override
	public boolean hasTooltip() {
		return true;
	}

	@Override
	public boolean isTooltipExpandable() {
		return false;
	}

	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
		tooltip.addTitle("Call Fleet");
		tooltip.addPara("Resupply - a Transport Fleet loads up at the station for a day, then comes to your location carrying Supplies, Fuel and Crew from the station's storage, up to what its holds can carry.", 10f,
				Misc.getHighlightColor(), "Resupply");
		tooltip.addPara("Transport - a Transport Fleet loads up at the station for a day, then comes to your location and takes the cargo, fuel and crew you hand over back to the station's storage.", 6f,
				Misc.getHighlightColor(), "Transport");
		tooltip.addPara("Two charges: only two fleets can be called out at once, and only one can be on its way to you at a time. A fleet that has been to you and is heading back "
				+ "can be followed by another call, and a fleet that gets home is ready again after %s days. Calls left: %s of %s.", 6f,
				Misc.getHighlightColor(), "" + (int) Fleets.COOLDOWN_DAYS, "" + Fleets.chargesLeft(), "" + Fleets.CALL_CHARGES);
		if (Fleets.station() == null) {
			tooltip.addPara("Requires a Player HQ station.", Misc.getNegativeHighlightColor(), 10f);
		} else if (Fleets.callBusy()) {
			tooltip.addPara("A fleet is already on its way to you.", Misc.getNegativeHighlightColor(), 10f);
		} else if (Fleets.chargesLeft() <= 0) {
			tooltip.addPara("Both calls are out. Wait for a fleet to get back.", Misc.getNegativeHighlightColor(), 10f);
		} else if (Fleets.ready() == null) {
			tooltip.addPara("No fleet is ready. Buy one at the Fleet HQ, or wait for one to get back.", Misc.getNegativeHighlightColor(), 10f);
		} else {
			tooltip.addPara("Transport Fleets ready: %s", 10f, Misc.getHighlightColor(), "" + Fleets.readyCount());
		}
	}

	@Override
	protected void applyEffect(float amount, float level) { }

	@Override
	protected void deactivateImpl() { }

	@Override
	protected void cleanupImpl() { }
}
