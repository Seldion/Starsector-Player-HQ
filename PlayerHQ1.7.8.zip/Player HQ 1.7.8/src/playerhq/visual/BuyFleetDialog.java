package playerhq.visual;

import java.util.EnumMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CampaignUIAPI;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class BuyFleetDialog implements CustomDialogDelegate {

	private static final String SELL = "sell:";

	private final Map<FleetKind, Long> costs = new EnumMap<FleetKind, Long>(FleetKind.class);
	private final Map<FleetKind, LabelAPI> owned = new EnumMap<FleetKind, LabelAPI>(FleetKind.class);
	private final Map<FleetKind, ButtonAPI> buy = new EnumMap<FleetKind, ButtonAPI>(FleetKind.class);
	private final Map<FleetKind, ButtonAPI> sell = new EnumMap<FleetKind, ButtonAPI>(FleetKind.class);

	private final com.fs.starfarer.api.campaign.InteractionDialogAPI host;

	public BuyFleetDialog() {
		this(null);
	}

	public BuyFleetDialog(com.fs.starfarer.api.campaign.InteractionDialogAPI host) {
		this.host = host;
	}

	private void showDialog(final com.fs.starfarer.api.campaign.InteractionDialogPlugin plugin, final SectorEntityToken station, String failure) {
		callback.dismissCustomDialog(0);
		if (host != null) {
			host.dismiss();
			PatrolPick.defer(new Runnable() {
				@Override
				public void run() {
					Global.getSector().getCampaignUI().showInteractionDialog(plugin, station);
				}
			});
			return;
		}
		boolean shown = Global.getSector().getCampaignUI().showInteractionDialogFromCargo(plugin, station,
				new CampaignUIAPI.DismissDialogDelegate() {
					@Override
					public void dialogDismissed() {
					}
				});
		if (!shown) Global.getSector().getCampaignUI().addMessage(failure, Misc.getNegativeHighlightColor());
	}

	private CustomPanelAPI panel;
	private CustomDialogCallback callback;
	private float width;
	private float height;

	private final BaseCustomUIPanelPlugin handler = new BaseCustomUIPanelPlugin() {
		@Override
		public void buttonPressed(Object buttonId) {
			pressed(buttonId);
		}
	};

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		this.panel = panel;
		this.callback = callback;
		this.width = panel.getPosition().getWidth();
		this.height = panel.getPosition().getHeight();
		showMain();
	}

	private void showMain() {
		costs.clear();
		owned.clear();
		buy.clear();
		sell.clear();
		float w = width;
		float h = height;
		TooltipMakerAPI el = panel.createUIElement(w, h, true);
		el.addSectionHeading("Manage Fleet", Alignment.MID, 0f);
		el.addPara("Fleets are paid for once, hulls and crew, and run on their own. A lost fleet is rebuilt for free. Selling a fleet returns half of what you paid.", Misc.getGrayColor(), 6f);
		for (FleetKind kind : FleetKind.values()) {
			if (kind.limit() <= 0) continue;
			boolean picker = kind == FleetKind.PATROL && StarfarerRules.on();
			long cost = kind.fixed() ? Fleets.cost(kind, Fleets.roll(kind)) : Fleets.PATROL_COST;
			costs.put(kind, cost);
			el.addSectionHeading(kind.label, Alignment.MID, 10f);
			el.addPara(kind.blurb(), 4f);
			if (picker) {
				el.addPara("You choose its ships: 1 Capital, 1 Cruiser, 1 Destroyer and 1 Frigate. Copies of them fill out the fleet and are paid for in credits. "
						+ "Disbanding it returns the full price and your ships.", 3f);
			} else {
				el.addPara("Cost: %s", 3f, Misc.getHighlightColor(), Misc.getDGSCredits(cost));
			}
			owned.put(kind, el.addPara("", Misc.getGrayColor(), 3f));
			float rowW = w - 30f;
			float half = (rowW - 6f) / 2f;
			CustomPanelAPI row = panel.createCustomPanel(rowW, 28f, handler);
			TooltipMakerAPI left = row.createUIElement(half, 28f, false);
			buy.put(kind, left.addButton(picker ? "Build" : "Buy", kind.name(), half, 28f, 0f));
			row.addUIElement(left).inTL(0f, 0f);
			TooltipMakerAPI right = row.createUIElement(half, 28f, false);
			sell.put(kind, right.addButton(picker ? "Disband" : "Sell", SELL + kind.name(), half, 28f, 0f));
			row.addUIElement(right).inTL(half + 6f, 0f);
			el.addCustom(row, 6f);
		}
		panel.addUIElement(el).inTL(0f, 0f);
		update();
	}

	private StationFleet last(FleetKind kind) {
		StationFleet found = null;
		for (StationFleet f : Fleets.list()) if (f.kind == kind) found = f;
		return found;
	}

	private void update() {
		float credits = Global.getSector().getPlayerFleet().getCargo().getCredits().get();
		for (FleetKind kind : FleetKind.values()) {
			if (!buy.containsKey(kind)) continue;
			int count = Fleets.owned(kind);
			owned.get(kind).setText("Owned: " + count + " / " + kind.limit());
			boolean picker = kind == FleetKind.PATROL && StarfarerRules.on();
			buy.get(kind).setEnabled(picker ? count < kind.limit() : count < kind.limit() && credits >= costs.get(kind));
			StationFleet f = last(kind);
			sell.get(kind).setEnabled(f != null);
			String verb = kind == FleetKind.PATROL && StarfarerRules.on() ? "Disband" : "Sell";
			sell.get(kind).setText(f == null ? verb : verb + "  (" + Misc.getDGSCredits(Fleets.refund(f)) + ")");
		}
	}

	private void pressed(Object buttonId) {
		if (!(buttonId instanceof String)) return;
		String id = (String) buttonId;
		if (id.startsWith(SELL)) {
			FleetKind kind;
			try {
				kind = FleetKind.valueOf(id.substring(SELL.length()));
			} catch (IllegalArgumentException e) {
				return;
			}
			StationFleet f = last(kind);
			if (f == null) return;
			if (kind == FleetKind.PATROL && StarfarerRules.on()) {
				openDisband(kind);
				return;
			}
			boolean disband = kind == FleetKind.PATROL && StarfarerRules.on();
			String text = disband ? "Disbanded the " + kind.label + ". " + Misc.getDGSCredits(Fleets.refund(f)) + " refunded and your ships returned to the station's storage."
					: "Sold a " + kind.label + " for " + Misc.getDGSCredits(Fleets.refund(f)) + ".";
			Fleets.sell(f);
			update();
			return;
		}
		FleetKind kind;
		try {
			kind = FleetKind.valueOf(id);
		} catch (IllegalArgumentException e) {
			return;
		}
		if (kind == FleetKind.PATROL && StarfarerRules.on()) {
			openPicker();
			return;
		}
		String error = Fleets.buy(kind);
		if (error != null) {
			Global.getSector().getCampaignUI().addMessage(error, Misc.getNegativeHighlightColor());
			return;
		}
		update();
	}

	private void openDisband(FleetKind kind) {
		SectorEntityToken station = Fleets.station();
		if (station == null) return;
		showDialog(new Disband(kind), station, "The disband window could not be opened here.");
	}

	public static class Disband implements com.fs.starfarer.api.campaign.InteractionDialogPlugin {

		private static final String CANCEL = "playerhq_v_disband_cancel";
		private static final String YES = "playerhq_v_disband_yes";

		private final FleetKind kind;
		private com.fs.starfarer.api.campaign.InteractionDialogAPI dialog;
		private StationFleet picked;

		public Disband(FleetKind kind) {
			this.kind = kind;
		}

		@Override
		public void init(com.fs.starfarer.api.campaign.InteractionDialogAPI dialog) {
			this.dialog = dialog;
			list();
		}

		private boolean returns() {
			return kind == FleetKind.PATROL && StarfarerRules.on();
		}

		private void list() {
			picked = null;
			dialog.getOptionPanel().clearOptions();
			dialog.setPromptText((returns() ? "Disband " : "Sell ") + kind.label);
			dialog.getTextPanel().addPara("Choose the " + kind.label + " to " + (returns() ? "disband." : "sell."));
			int n = 0;
			for (StationFleet f : Fleets.list()) {
				if (f.kind != kind) continue;
				n++;
				String lead = f.originalNames != null && !f.originalNames.isEmpty() && f.originalNames.get(0) != null ? " led by " + f.originalNames.get(0) : "";
				dialog.getOptionPanel().addOption(kind.label + " " + n + lead + " - " + Fleets.status(f), f);
			}
			dialog.getOptionPanel().addOption("Cancel", CANCEL);
			dialog.setOptionOnEscape("Cancel", CANCEL);
		}

		@Override
		public void optionSelected(String optionText, Object optionData) {
			if (CANCEL.equals(optionData)) {
				dialog.dismiss();
				return;
			}
			if (optionData instanceof StationFleet) {
				picked = (StationFleet) optionData;
				dialog.getOptionPanel().clearOptions();
				dialog.getTextPanel().addPara(returns()
						? "Disband this " + kind.label + "? " + Misc.getDGSCredits(Fleets.refund(picked)) + " is refunded and your ships go back to the station's storage."
						: "Sell this " + kind.label + " for " + Misc.getDGSCredits(Fleets.refund(picked)) + "?");
				dialog.getOptionPanel().addOption(returns() ? "Yes, disband it" : "Yes, sell it", YES);
				dialog.getOptionPanel().addOption("No, go back", CANCEL + "_back");
				dialog.setOptionOnEscape("No, go back", CANCEL + "_back");
				return;
			}
			if ((CANCEL + "_back").equals(optionData)) {
				list();
				return;
			}
			if (YES.equals(optionData) && picked != null && Fleets.list().contains(picked)) {
				String text = returns() ? "Disbanded the " + kind.label + ". " + Misc.getDGSCredits(Fleets.refund(picked)) + " refunded and your ships returned to the station's storage."
						: "Sold a " + kind.label + " for " + Misc.getDGSCredits(Fleets.refund(picked)) + ".";
				Fleets.sell(picked);
			}
			dialog.dismiss();
		}

		@Override
		public void optionMousedOver(String optionText, Object optionData) { }

		@Override
		public void advance(float amount) { }

		@Override
		public void backFromEngagement(com.fs.starfarer.api.combat.EngagementResultAPI battleResult) { }

		@Override
		public Object getContext() {
			return null;
		}

		@Override
		public java.util.Map<String, com.fs.starfarer.api.campaign.rules.MemoryAPI> getMemoryMap() {
			return null;
		}
	}

	private void openPicker() {
		SectorEntityToken station = Fleets.station();
		if (station == null || !PatrolPick.hasHq(station)) {
			Global.getSector().getCampaignUI().addMessage("The station needs a Fleet HQ first.", Misc.getNegativeHighlightColor());
			return;
		}
		showDialog(new PatrolPickDialog(station), station, "The ship picker could not be opened here. Use Patrol Fleet on the station's main menu.");
	}

	@Override
	public boolean hasCancelButton() {
		return false;
	}

	@Override
	public String getConfirmText() {
		return "Close";
	}

	@Override
	public String getCancelText() {
		return "Cancel";
	}

	@Override
	public void customDialogConfirm() {
	}

	@Override
	public void customDialogCancel() {
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return handler;
	}
}
