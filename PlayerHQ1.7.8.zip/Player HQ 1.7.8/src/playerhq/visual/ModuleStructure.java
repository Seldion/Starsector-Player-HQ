package playerhq.visual;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.ui.TooltipMakerAPI;

public class ModuleStructure extends BaseIndustry {

	@Override
	public float getBuildTime() {
		return StarfarerRules.visualDays(getId(), super.getBuildTime());
	}

	@Override
	public void startBuilding() {
		super.startBuilding();
		buildTime = StarfarerRules.visualDays(getId(), buildTime);
	}

	@Override
	public void startUpgrading() {
		super.startUpgrading();
		buildTime = StarfarerRules.visualDays(getId(), buildTime);
	}

	private static final Map<String, Float> COSTS = new HashMap<String, Float>();

	static {
		COSTS.put("playerhq_v_mining_hub", 25000f);
		COSTS.put("playerhq_v_manufactorium", 75000f);
		COSTS.put("playerhq_v_biodome", 25000f);
		COSTS.put("playerhq_v_assembly", 75000f);
		COSTS.put("playerhq_v_military_ward", 50000f);
		COSTS.put("playerhq_v_fleet_hq", 50000f);
		COSTS.put("playerhq_v_expanded_sorties", 40000f);
		COSTS.put("playerhq_v_academy", 50000f);
		COSTS.put("playerhq_v_public_shuttles", 50000f);
		COSTS.put("playerhq_v_space_elevator", 50000f);
		COSTS.put("playerhq_v_marketplace", 25000f);
		COSTS.put("playerhq_v_resort", 50000f);
		COSTS.put("playerhq_v_beach_resort", 25000f);
		COSTS.put("playerhq_v_winter_resort", 25000f);
	}

	public static float costOf(String id) {
		Float c = COSTS.get(id);
		return c == null ? 0f : c;
	}

	@Override
	public void apply() {
		super.apply(true);
	}

	protected boolean replacedByUpgrade() {
		if (market == null) return false;
		String up = getSpec().getUpgrade();
		return up != null && market.hasIndustry(up);
	}

	public String getUpgradeTargetId() {
		return upgradeId;
	}

	@Override
	public boolean isAvailableToBuild() {
		if (market != null && !market.hasTag(TestIds.TAG_STATION)) return false;
		if (replacedByUpgrade()) return false;
		if (market == null || market.hasIndustry(getId())) return true;
		return StarfarerRules.afford(market, getId());
	}

	@Override
	public String getUnavailableReason() {
		String lack = StarfarerRules.lacking(market, getId());
		return lack != null ? lack : super.getUnavailableReason();
	}

	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		super.addPostDemandSection(tooltip, hasDemand, mode);
		if (mode != IndustryTooltipMode.ADD_INDUSTRY) return;
		String line = StarfarerRules.costLine(getId());
		if (line != null) tooltip.addPara(line, 10f);
	}

	@Override
	public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
		if (!forUpgrade) StarfarerRules.refund(market, getId(), isBuilding() ? 1f : StarfarerRules.REFUND_FRACTION);
		super.notifyBeingRemoved(mode, forUpgrade);
	}

	@Override
	public boolean canInstallAICores() {
		return false;
	}

	@Override
	public boolean showWhenUnavailable() {
		if (market != null && !market.hasTag(TestIds.TAG_STATION)) return false;
		return !replacedByUpgrade();
	}

	@Override
	public float getBuildCost() {
		Float sf = StarfarerRules.credits(getId());
		if (sf != null) return sf;
		Float c = COSTS.get(getId());
		return c == null ? 0f : c;
	}
}
