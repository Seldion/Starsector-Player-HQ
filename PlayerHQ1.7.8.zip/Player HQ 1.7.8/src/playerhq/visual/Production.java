package playerhq.visual;

import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;

public class Production {

	public static final float RAW_CAP = 20000f;
	public static final float DEFAULT_CAP = 15000f;

	public static CargoAPI storage(MarketAPI market) {
		if (market == null) return null;
		SubmarketAPI s = market.getSubmarket(Submarkets.SUBMARKET_STORAGE);
		return s == null ? null : s.getCargo();
	}

	public static float cap(String id) {
		if (Commodities.ORE.equals(id) || Commodities.RARE_ORE.equals(id) || Commodities.ORGANICS.equals(id)
				|| Commodities.FOOD.equals(id) || Commodities.VOLATILES.equals(id) || Commodities.METALS.equals(id)
				|| Commodities.RARE_METALS.equals(id)) {
			return RAW_CAP;
		}
		return DEFAULT_CAP;
	}

	public static float addCapped(CargoAPI storage, String id, float amount) {
		if (storage == null || amount <= 0f) return 0f;
		float space = cap(id) - storage.getCommodityQuantity(id);
		if (space <= 0f) return 0f;
		float toAdd = Math.min(amount, space);
		storage.addCommodity(id, toAdd);
		return toAdd;
	}

	public static float convert(CargoAPI storage, String[] inputs, float[] perBatch, String output,
			float outPerBatch, float maxOutput) {
		if (storage == null) return 0f;
		float maxOut = maxOutput;
		for (int i = 0; i < inputs.length; i++) {
			float avail = storage.getCommodityQuantity(inputs[i]);
			float o = avail / perBatch[i] * outPerBatch;
			if (o < maxOut) maxOut = o;
		}
		float space = cap(output) - storage.getCommodityQuantity(output);
		if (space < maxOut) maxOut = space;
		int out = (int) Math.floor(maxOut);
		while (out > 0) {
			boolean ok = true;
			for (int i = 0; i < inputs.length; i++) {
				float need = (float) Math.ceil(out / outPerBatch * perBatch[i]);
				if (need > storage.getCommodityQuantity(inputs[i])) {
					ok = false;
					break;
				}
			}
			if (ok) break;
			out--;
		}
		if (out <= 0) return 0f;
		for (int i = 0; i < inputs.length; i++) {
			float need = (float) Math.ceil(out / outPerBatch * perBatch[i]);
			storage.removeCommodity(inputs[i], need);
		}
		storage.addCommodity(output, out);
		return out;
	}
}
