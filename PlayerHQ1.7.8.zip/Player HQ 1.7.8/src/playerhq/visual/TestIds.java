package playerhq.visual;

public class TestIds {
	public static final String ABILITY = "playerhq_v_construct";
	public static final String ENTITY = "playerhq_v_station_hightech";
	public static final String ENTITY_LOWTECH = "playerhq_v_station_lowtech";
	public static final String ENTITY_HIGHTECH = "playerhq_v_station_hightech_sf";
	public static final String TAG_STATION = "playerhq_v_station";
	public static final String INDUSTRY_RESORT = "playerhq_v_resort";
	public static final String INDUSTRY_BEACH = "playerhq_v_beach_resort";
	public static final String INDUSTRY_WINTER = "playerhq_v_winter_resort";
	public static final String INDUSTRY_FOUNDRY = "playerhq_v_foundry";
	public static final boolean REQUIREMENTS = false;
	public static final String MOD_STAT_SOURCE = "playerhq_v";
}
