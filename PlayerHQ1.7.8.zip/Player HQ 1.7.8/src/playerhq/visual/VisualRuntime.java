package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;

public class VisualRuntime {

	public static void ensureStationTags() {
		SectorEntityToken station = TestStation.find();
		if (station == null) return;
		station.addTag(TestIds.TAG_STATION);
		MarketAPI market = station.getMarket();
		if (market == null) return;
		market.addTag(Tags.MARKET_NO_OFFICER_SPAWN);
		market.addTag("market_no_industries_allowed");
		market.addTag(TestIds.TAG_STATION);
	}

	public static void ensureBmoIntegration() {
		try {
			Class.forName("kaysaar.bmo.listeners.BuildingMenuListener");
		} catch (Throwable t) {
			return;
		}
		try {
			Global.getSector().getListenerManager().addListener(new BmoHideListener(), true);
		} catch (Throwable t) {
			Global.getLogger(VisualRuntime.class).warn("Could not register Building Menu Overhaul integration", t);
		}
	}

	public static void loadTextures() {
		try {
			Global.getSettings().loadTexture("graphics/stations/player_hq_interaction.jpg");
			Global.getSettings().loadTexture(StationAccessCondition.ICON);
		} catch (Exception e) {
			Global.getLogger(VisualRuntime.class).warn("Could not load " + StationAccessCondition.ICON, e);
		}
		for (String path : ResortIndustry.IMAGES) {
			try {
				Global.getSettings().loadTexture(path);
			} catch (Exception e) {
				Global.getLogger(VisualRuntime.class).warn("Could not load " + path, e);
			}
		}
	}

	public static void installFleets() {
		if (!Global.getSector().hasTransientScript(FleetsScript.class)) Global.getSector().addTransientScript(new FleetsScript());
	}

	public static void install() {
		ensureStationTags();
		ensureBmoIntegration();
		Global.getSector().addTransientScript(new QueueMonitor());
		Global.getSector().addTransientScript(new MonthlyScript());
		installFleets();
		for (String id : new String[] { "playerhq_v_fleet_hq", "playerhq_v_space_elevator", "playerhq_v_beach_resort", "playerhq_v_winter_resort" }) {
			Global.getSector().getPlayerFaction().addKnownIndustry(id);
		}
		HostileGuard.install();
		Global.getSector().getListenerManager().addListener(new ResortPathOptionProvider(), true);
		Global.getSector().getListenerManager().addListener(new ManufactoriumOptionProvider(), true);
		Global.getSector().getListenerManager().addListener(new FleetHqOptionProvider(), true);
		Global.getSector().getListenerManager().addListener(new AssemblyOptionProvider(), true);
		Global.getSector().getListenerManager().addListener(new DowngradeOptionProvider(), true);
	}
}
