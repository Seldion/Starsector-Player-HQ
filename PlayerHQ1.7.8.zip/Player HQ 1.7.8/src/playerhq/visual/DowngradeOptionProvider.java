package playerhq.visual;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.Industry.IndustryTooltipMode;
import com.fs.starfarer.api.campaign.listeners.DialogCreatorUI;
import com.fs.starfarer.api.campaign.listeners.IndustryOptionProvider;
import com.fs.starfarer.api.loading.IndustrySpecAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class DowngradeOptionProvider implements IndustryOptionProvider {

	public static final Object OPTION_ID = "playerhq_v_downgrade";

	private static final List<String> IDS = Arrays.asList(
			"playerhq_v_fleet_hq", "playerhq_v_space_elevator", TestIds.INDUSTRY_BEACH, TestIds.INDUSTRY_WINTER);

	private static String targetName(Industry ind) {
		String target = ind.getSpec().getDowngrade();
		IndustrySpecAPI spec = target == null ? null : Global.getSettings().getIndustrySpec(target);
		return spec == null ? null : spec.getName();
	}

	@Override
	public List<IndustryOptionData> getIndustryOptions(Industry ind) {
		if (!IDS.contains(ind.getId())) return null;
		if (ind.isBuilding() || ind.isUpgrading()) return null;
		if (targetName(ind) == null) return null;
		List<IndustryOptionData> list = new ArrayList<IndustryOptionData>();
		IndustryOptionData data = new IndustryOptionData("Downgrade", OPTION_ID, ind, this);
		data.color = Misc.getHighlightColor();
		data.enabled = !(ind instanceof FleetHqIndustry) || Fleets.list().isEmpty();
		list.add(data);
		return list;
	}

	@Override
	public void createTooltip(IndustryOptionData opt, TooltipMakerAPI tooltip, float width) {
		if (opt.id != OPTION_ID) return;
		if (!opt.enabled) {
			tooltip.addPara("Sell or disband every fleet first", Misc.getNegativeHighlightColor(), 0f);
			return;
		}
		tooltip.addPara("Go back to the %s. The bonuses of this upgrade are lost.", 0f, Misc.getHighlightColor(), targetName(opt.ind));
	}

	@Override
	public void optionSelected(IndustryOptionData opt, DialogCreatorUI ui) {
		if (opt.id != OPTION_ID) return;
		ui.showDialog(480f, 190f, new Confirm(opt.ind));
	}

	@Override
	public void addToIndustryTooltip(Industry ind, IndustryTooltipMode mode, TooltipMakerAPI tooltip, float width, boolean expanded) {
	}

	private static class Confirm implements CustomDialogDelegate {
		private final Industry ind;

		Confirm(Industry ind) {
			this.ind = ind;
		}

		@Override
		public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
			TooltipMakerAPI el = panel.createUIElement(440f, 130f, false);
			el.addPara("Downgrade the %s back to the %s? The bonuses of the upgrade are lost and its build cost is not refunded.",
					10f, Misc.getHighlightColor(), ind.getCurrentName(), targetName(ind));
			panel.addUIElement(el);
		}

		@Override
		public boolean hasCancelButton() {
			return true;
		}

		@Override
		public String getConfirmText() {
			return "Downgrade";
		}

		@Override
		public String getCancelText() {
			return "Cancel";
		}

		@Override
		public void customDialogConfirm() {
			if (ind.getMarket() != null && ind.getMarket().hasIndustry(ind.getId())
					&& !ind.isBuilding() && !ind.isUpgrading()) {
				ind.downgrade();
			}
		}

		@Override
		public void customDialogCancel() {
		}

		@Override
		public CustomUIPanelPlugin getCustomPanelPlugin() {
			return new BaseCustomUIPanelPlugin();
		}
	}
}
