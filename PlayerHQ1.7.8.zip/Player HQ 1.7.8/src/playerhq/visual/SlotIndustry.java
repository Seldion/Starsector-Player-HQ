package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin.InstallableItemDescriptionMode;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseInstallableIndustryItemPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public abstract class SlotIndustry extends ModuleStructure {

	protected SpecialItemData[] slots;

	protected abstract String[] slotTitles();

	protected abstract String[][] slotAllowed();

	protected String slotEffectText(int slot, SpecialItemData data) {
		return "";
	}

	protected String slotMenuTitle(int slot, boolean installed) {
		return (installed ? "Manage " : "Install ") + slotTitles()[slot] + "...";
	}

	protected String slotUninstallText(int slot) {
		return "Uninstall " + slotTitles()[slot];
	}

	protected SpecialItemData[] slots() {
		int n = slotTitles().length;
		if (slots == null) {
			slots = new SpecialItemData[n];
		} else if (slots.length != n) {
			SpecialItemData[] fresh = new SpecialItemData[n];
			CargoAPI storage = Production.storage(market);
			for (int i = 0; i < slots.length; i++) {
				if (slots[i] == null) continue;
				boolean placed = false;
				for (int j = 0; j < n && !placed; j++) {
					if (fresh[j] == null && allowedIn(j, slots[i].getId())) {
						fresh[j] = slots[i];
						placed = true;
					}
				}
				if (!placed && storage != null) {
					storage.addItems(CargoItemType.SPECIAL, slots[i], 1);
				}
			}
			slots = fresh;
		}
		return slots;
	}

	public SpecialItemData slotItem(int slot) {
		return slots()[slot];
	}

	public boolean slotHas(int slot, String itemId) {
		SpecialItemData d = slots()[slot];
		return d != null && itemId.equals(d.getId());
	}

	public boolean allowedIn(int slot, String id) {
		if (id == null) return false;
		for (String s : slotAllowed()[slot]) if (s.equals(id)) return true;
		return false;
	}

	@Override
	public List<InstallableIndustryItemPlugin> getInstallableItems() {
		ArrayList<InstallableIndustryItemPlugin> list = new ArrayList<InstallableIndustryItemPlugin>();
		for (int i = 0; i < slotTitles().length; i++) list.add(new SlotPlugin(this, i));
		return list;
	}

	@Override
	public List<SpecialItemData> getVisibleInstalledItems() {
		ArrayList<SpecialItemData> list = new ArrayList<SpecialItemData>();
		for (SpecialItemData d : slots()) if (d != null) list.add(d);
		return list;
	}

	@Override
	public boolean wantsToUseSpecialItem(SpecialItemData data) {
		if (data == null) return false;
		for (int i = 0; i < slotTitles().length; i++) if (allowedIn(i, data.getId())) return true;
		return false;
	}

	@Override
	protected boolean addNonAICoreInstalledItems(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded) {
		boolean any = false;
		for (int i = 0; i < slotTitles().length; i++) {
			SpecialItemData d = slots()[i];
			if (d == null) continue;
			SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec(d.getId());
			TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48f);
			text.addPara("%s installed. %s", 0f, Misc.getHighlightColor(), spec.getName(), slotEffectText(i, d));
			tooltip.addImageWithText(any ? 5f : 10f);
			any = true;
		}
		return any;
	}

	@Override
	public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
		if (!forUpgrade) {
			CargoAPI storage = Production.storage(market);
			if (storage != null) {
				for (int i = 0; i < slotTitles().length; i++) {
					if (slots()[i] != null) {
						storage.addItems(CargoItemType.SPECIAL, slots()[i], 1);
						slots()[i] = null;
					}
				}
			}
		}
		super.notifyBeingRemoved(mode, forUpgrade);
	}

	@Override
	protected void upgradeFinished(Industry previous) {
		super.upgradeFinished(previous);
		if (previous instanceof SlotIndustry) {
			SpecialItemData[] prev = ((SlotIndustry) previous).slots();
			SpecialItemData[] mine = slots();
			for (int i = 0; i < Math.min(prev.length, mine.length); i++) mine[i] = prev[i];
			CargoAPI storage = Production.storage(market);
			for (int i = mine.length; i < prev.length; i++) {
				if (prev[i] != null && storage != null) storage.addItems(CargoItemType.SPECIAL, prev[i], 1);
			}
		}
	}

	public static class SlotPlugin extends BaseInstallableIndustryItemPlugin {
		protected SlotIndustry industry;
		protected int slot;

		public SlotPlugin(SlotIndustry industry, int slot) {
			this.industry = industry;
			this.slot = slot;
		}

		@Override
		public SpecialItemData getCurrentlyInstalledItemData() {
			return industry.slots()[slot];
		}

		@Override
		public void setCurrentlyInstalledItemData(SpecialItemData data) {
			industry.slots()[slot] = data;
		}

		@Override
		public String getMenuItemTitle() {
			return industry.slotMenuTitle(slot, getCurrentlyInstalledItemData() != null);
		}

		@Override
		public String getUninstallButtonText() {
			return industry.slotUninstallText(slot);
		}

		@Override
		public String getNoItemCurrentlyInstalledText() {
			return "No " + industry.slotTitles()[slot] + " currently installed";
		}

		@Override
		public String getNoItemsAvailableText() {
			return "No suitable items available";
		}

		@Override
		public String getNoItemsAvailableTextRemote() {
			return "No suitable items available in storage";
		}

		@Override
		public String getSelectItemToAssignToIndustryText() {
			return "Select " + industry.slotTitles()[slot] + " to install in " + industry.getCurrentName();
		}

		@Override
		public boolean isInstallableItem(CargoStackAPI stack) {
			if (!stack.isSpecialStack()) return false;
			SpecialItemData data = stack.getSpecialDataIfSpecial();
			return data != null && industry.allowedIn(slot, data.getId());
		}

		@Override
		public boolean canBeInstalled(SpecialItemData data) {
			return data != null && industry.allowedIn(slot, data.getId());
		}

		@Override
		public boolean hasMenuItemTooltip() {
			return true;
		}

		@Override
		public boolean isMenuItemTooltipExpandable() {
			return false;
		}

		@Override
		public float getMenuItemTooltipWidth() {
			return 400f;
		}

		@Override
		public void createMenuItemTooltip(TooltipMakerAPI tooltip, boolean expanded) {
			tooltip.addPara("Slot for a " + industry.slotTitles()[slot] + ".", 0f);
			SpecialItemData data = getCurrentlyInstalledItemData();
			if (data == null) {
				tooltip.addPara(getNoItemCurrentlyInstalledText() + ".", Misc.getGrayColor(), 10f);
			} else {
				tooltip.addPara("Installed: %s", 10f, Misc.getHighlightColor(),
						Global.getSettings().getSpecialItemSpec(data.getId()).getName());
			}
		}

		@Override
		public void addItemDescription(TooltipMakerAPI text, SpecialItemData data, InstallableItemDescriptionMode mode) {
			if (data == null) return;
			String t = industry.slotEffectText(slot, data);
			if (t != null && t.length() > 0) text.addPara(t, 10f);
		}
	}
}
