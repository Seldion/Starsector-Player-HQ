package playerhq.visual;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin.InstallableItemDescriptionMode;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseInstallableIndustryItemPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class ResortItemPlugin extends BaseInstallableIndustryItemPlugin {

	protected Industry industry;

	public ResortItemPlugin(Industry industry) {
		this.industry = industry;
	}

	public static boolean isResortItem(String id) {
		return Items.DEALMAKER_HOLOSUITE.equals(id);
	}

	@Override
	public SpecialItemData getCurrentlyInstalledItemData() {
		return industry.getSpecialItem();
	}

	@Override
	public void setCurrentlyInstalledItemData(SpecialItemData data) {
		industry.setSpecialItem(data);
	}

	@Override
	public String getMenuItemTitle() {
		return getCurrentlyInstalledItemData() == null ? "Install VR Suites" : "Manage VR Suites...";
	}

	@Override
	public String getUninstallButtonText() {
		return "Uninstall VR Suites";
	}

	@Override
	public String getNoItemCurrentlyInstalledText() {
		return "No item currently installed";
	}

	@Override
	public String getNoItemsAvailableText() {
		return "No suitable items available";
	}

	@Override
	public String getNoItemsAvailableTextRemote() {
		return "No suitable items available in storage";
	}

	@Override
	public String getSelectItemToAssignToIndustryText() {
		return "Select VR Suites to install for " + industry.getCurrentName();
	}

	@Override
	public boolean isInstallableItem(CargoStackAPI stack) {
		if (!stack.isSpecialStack()) return false;
		SpecialItemData data = stack.getSpecialDataIfSpecial();
		return data != null && isResortItem(data.getId());
	}

	@Override
	public boolean canBeInstalled(SpecialItemData data) {
		return data != null && isResortItem(data.getId());
	}

	@Override
	public boolean hasMenuItemTooltip() {
		return true;
	}

	@Override
	public boolean isMenuItemTooltipExpandable() {
		return false;
	}

	@Override
	public float getMenuItemTooltipWidth() {
		return 400f;
	}

	@Override
	public void createMenuItemTooltip(TooltipMakerAPI tooltip, boolean expanded) {
		tooltip.addPara("A Dealmaker Holosuite can be installed here to raise the resort's income.", 0f);
		SpecialItemData data = industry.getSpecialItem();
		if (data == null) {
			tooltip.addPara(getNoItemCurrentlyInstalledText() + ".", Misc.getGrayColor(), 10f);
		} else {
			tooltip.addPara("Installed: %s", 10f, Misc.getHighlightColor(),
					Global.getSettings().getSpecialItemSpec(data.getId()).getName());
		}
	}

	@Override
	public void addItemDescription(TooltipMakerAPI text, SpecialItemData data, InstallableItemDescriptionMode mode) {
		if (data == null) return;
		String id = data.getId();
		if (Items.DEALMAKER_HOLOSUITE.equals(id)) {
			text.addPara("Increases income.", 10f);
		}
	}
}
