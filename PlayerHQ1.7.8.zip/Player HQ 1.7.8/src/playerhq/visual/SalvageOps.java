package playerhq.visual;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainPlugin;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.FleetEncounterContext;
import com.fs.starfarer.api.impl.campaign.RepairGantry;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.procgen.SalvageEntityGenDataSpec;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageEntityGeneratorOld;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageEntity;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin;
import com.fs.starfarer.api.util.Misc;

public class SalvageOps {

	public static final int MAX_SHIPS = 10;
	public static final int WRECK_DAYS = 1;
	public static final int DEBRIS_DAYS = 2;
	public static final float FULL_FRACTION = 0.97f;
	public static final float MIN_DENSITY = 0.2f;
	public static final float ORBIT_RADIUS = 200f;
	public static final float COOLDOWN_DAYS = 4f;

	private static boolean wreck(SectorEntityToken e) {
		return e != null && e.getCustomPlugin() instanceof DerelictShipEntityPlugin;
	}

	private static DebrisFieldTerrainPlugin debrisPlugin(SectorEntityToken e) {
		if (!(e instanceof CampaignTerrainAPI)) return null;
		CampaignTerrainPlugin plugin = ((CampaignTerrainAPI) e).getPlugin();
		return (plugin instanceof DebrisFieldTerrainPlugin) ? (DebrisFieldTerrainPlugin) plugin : null;
	}

	private static boolean guarded(SectorEntityToken e) {
		MemoryAPI mem = e.getMemoryWithoutUpdate();
		if (mem.getBoolean("$hasDefenders") || mem.contains("$defenderFleet") || mem.contains(MemFlags.SALVAGE_DEFENDER_OVERRIDE)) return true;
		try {
			SalvageEntityGenDataSpec spec = SalvageEntityGeneratorOld.getSalvageSpec(e.getCustomEntityType());
			if (spec != null && spec.getProbDefenders() > 0f) return true;
		} catch (Throwable t) {
		}
		return false;
	}

	private static boolean usableWreck(SectorEntityToken e) {
		if (!wreck(e) || !e.isAlive() || e.isExpired()) return false;
		if (guarded(e)) return false;
		Object special = e.getMemoryWithoutUpdate().get(MemFlags.SALVAGE_SPECIAL_DATA);
		return special == null || special instanceof ShipRecoverySpecial.ShipRecoverySpecialData;
	}

	private static boolean boardable(ShipRecoverySpecial.PerShipData data) {
		if (data == null) return false;
		try {
			ShipVariantAPI variant = data.variant != null ? data.variant
					: (data.variantId != null ? Global.getSettings().getVariant(data.variantId) : null);
			if (variant == null || variant.getHullSpec() == null) return false;
			if (variant.hasTag(Tags.VARIANT_UNBOARDABLE)) return false;
			return !Misc.isUnboardable(variant.getHullSpec());
		} catch (Throwable t) {
			return false;
		}
	}

	private static List<ShipRecoverySpecial.PerShipData> recoverable(SectorEntityToken e) {
		List<ShipRecoverySpecial.PerShipData> ships = new ArrayList<ShipRecoverySpecial.PerShipData>();
		if (!usableWreck(e) || e.hasTag(Tags.UNRECOVERABLE)) return ships;
		Object special = e.getMemoryWithoutUpdate().get(MemFlags.SALVAGE_SPECIAL_DATA);
		if (special instanceof ShipRecoverySpecial.ShipRecoverySpecialData) {
			for (ShipRecoverySpecial.PerShipData data : ((ShipRecoverySpecial.ShipRecoverySpecialData) special).ships) {
				if (boardable(data)) ships.add(data);
			}
		}
		return ships;
	}

	private static int wreckShipCount(SectorEntityToken e) {
		Object special = e.getMemoryWithoutUpdate().get(MemFlags.SALVAGE_SPECIAL_DATA);
		if (special instanceof ShipRecoverySpecial.ShipRecoverySpecialData) {
			return ((ShipRecoverySpecial.ShipRecoverySpecialData) special).ships.size();
		}
		return 1;
	}

	private static boolean hasDrops(SectorEntityToken e) {
		return (e.getDropValue() != null && !e.getDropValue().isEmpty())
				|| (e.getDropRandom() != null && !e.getDropRandom().isEmpty());
	}

	private static boolean usableDebris(SectorEntityToken e) {
		DebrisFieldTerrainPlugin debris = debrisPlugin(e);
		if (debris == null || !e.isAlive() || e.isExpired()) return false;
		DebrisFieldTerrainPlugin.DebrisFieldParams params = debris.getParams();
		if (params == null || params.baseDensity <= 0f) return false;
		if (params.defenderProb > 0f) return false;
		return params.density / params.baseDensity >= MIN_DENSITY;
	}

	private static boolean valid(SectorEntityToken e, int slotsLeft) {
		if (e == null || !e.isAlive()) return false;
		if (wreck(e)) {
			if (!usableWreck(e)) return false;
			List<ShipRecoverySpecial.PerShipData> ships = recoverable(e);
			if (ships.size() > slotsLeft) return false;
			return !ships.isEmpty() || hasDrops(e);
		}
		return usableDebris(e);
	}

	private static SectorEntityToken pickNearest(SectorEntityToken from, int slotsLeft) {
		Vector2f fromHyper = from.getLocationInHyperspace();
		SectorEntityToken best = null;
		float bestKey = Float.MAX_VALUE;
		for (LocationAPI loc : Global.getSector().getAllLocations()) {
			if (loc == null) continue;
			for (SectorEntityToken e : loc.getAllEntities()) {
				if (!wreck(e) && !(e instanceof CampaignTerrainAPI)) continue;
				if (!valid(e, slotsLeft)) continue;
				float key = Misc.getDistance(fromHyper, e.getLocationInHyperspace());
				if (from.getContainingLocation() == loc) key += 0.1f * Misc.getDistance(from.getLocation(), e.getLocation());
				else key += 0.1f * e.getLocation().length();
				if (key < bestKey) {
					bestKey = key;
					best = e;
				}
			}
		}
		return best;
	}

	private static String describe(SectorEntityToken target) {
		if (target == null) return "its target";
		String where = (target.getContainingLocation() instanceof StarSystemAPI)
				? "the " + ((StarSystemAPI) target.getContainingLocation()).getBaseName() + " system" : "hyperspace";
		return (wreck(target) ? "a derelict ship in " : "a debris field in ") + where;
	}

	private static List<FleetMemberAPI> recovered(StationFleet f) {
		if (f.recovered == null) f.recovered = new ArrayList<FleetMemberAPI>();
		return f.recovered;
	}

	private static int slotsLeft(StationFleet f) {
		return MAX_SHIPS - recovered(f).size();
	}

	private static boolean full(StationFleet f) {
		if (recovered(f).size() >= MAX_SHIPS) return true;
		if (f.capCargo <= 0f || f.hold == null) return true;
		f.hold.updateSpaceUsed();
		return f.hold.getSpaceUsed() >= f.capCargo * FULL_FRACTION;
	}

	public static boolean prepare(SectorEntityToken station, StationFleet f) {
		SectorEntityToken target = pickNearest(station, MAX_SHIPS);
		if (target == null) return false;
		f.target = target;
		return true;
	}

	public static void launched(SectorEntityToken station, StationFleet f) {
		f.hold = Global.getFactory().createCargo(true);
		f.recovered = new ArrayList<FleetMemberAPI>();
		f.stage = StationFleet.STG_OUT;
		f.stageDays = 0f;
		Fleets.travel(f.fleet, f.target, "Traveling to salvage " + describe(f.target));
	}

	private static void next(SectorEntityToken station, StationFleet f) {
		SectorEntityToken next = full(f) ? null : pickNearest(f.fleet, slotsLeft(f));
		if (next == null) {
			f.stage = StationFleet.STG_NONE;
			f.target = null;
			Fleets.sendHome(station, f);
			return;
		}
		f.target = next;
		f.stage = StationFleet.STG_OUT;
		f.fleet.setOrbit(null);
		Fleets.travel(f.fleet, next, "Traveling to salvage " + describe(next));
	}

	public static void advance(SectorEntityToken station, StationFleet f) {
		CampaignFleetAPI fleet = f.fleet;
		if (f.stage == StationFleet.STG_OUT) {
			if (!valid(f.target, slotsLeft(f))) {
				next(station, f);
				return;
			}
			if (Fleets.arrived(fleet, f.target)) {
				fleet.clearAssignments();
				fleet.setCircularOrbitPointingDown(f.target, (float) (Math.random() * 360f), ORBIT_RADIUS, 60f);
				f.stage = StationFleet.STG_WORK;
				f.stageDays = wreck(f.target) ? WRECK_DAYS : DEBRIS_DAYS;
				return;
			}
			if (fleet.getCurrentAssignment() == null) Fleets.travel(fleet, f.target, "Traveling to salvage " + describe(f.target));
			return;
		}
		if (f.stage != StationFleet.STG_WORK) {
			Fleets.sendHome(station, f);
			return;
		}
		f.stageDays -= 1f;
		if (f.stageDays > 0f) return;
		if (valid(f.target, slotsLeft(f))) {
			try {
				if (wreck(f.target)) recoverWreck(f, f.target);
				else salvageDebris(f, f.target);
			} catch (Throwable t) {
				Global.getLogger(SalvageOps.class).warn("The Salvage Fleet failed on a target", t);
				if (wreck(f.target)) Misc.fadeAndExpire(f.target, 1f);
			}
		}
		next(station, f);
	}

	private static void recoverWreck(StationFleet f, SectorEntityToken wreck) {
		List<ShipRecoverySpecial.PerShipData> ships = recoverable(wreck);
		List<FleetMemberAPI> recovered = recovered(f);
		java.util.Random random = new java.util.Random();
		int here = 0;
		for (ShipRecoverySpecial.PerShipData data : ships) {
			if (recovered.size() >= MAX_SHIPS) break;
			FleetMemberAPI member = buildShip(data, random);
			if (member != null) {
				recovered.add(member);
				here++;
			}
		}
		if (here < wreckShipCount(wreck)) addLoot(f, wreck, 1f);
		Misc.fadeAndExpire(wreck, 1f);
	}

	private static FleetMemberAPI buildShip(ShipRecoverySpecial.PerShipData data, java.util.Random random) {
		if (data == null || (data.variantId == null && data.variant == null)) return null;
		FleetMemberAPI member;
		try {
			member = data.variantId != null
					? Global.getFactory().createFleetMember(FleetMemberType.SHIP, data.variantId)
					: Global.getFactory().createFleetMember(FleetMemberType.SHIP, data.variant);
		} catch (Throwable t) {
			return null;
		}
		if (Misc.isUnboardable(member)) return null;
		if (data.shipName != null) member.setShipName(data.shipName);

		ShipRecoverySpecial.ShipCondition condition = data.condition != null ? data.condition : ShipRecoverySpecial.ShipCondition.AVERAGE;
		int dmods;
		float hull;
		float retain;
		switch (condition) {
		case PRISTINE: dmods = 0; hull = 1f; retain = 1f; break;
		case GOOD: dmods = 1; hull = 0.6f + random.nextFloat() * 0.2f; retain = 0.67f; break;
		case AVERAGE: dmods = 1 + random.nextInt(2); hull = 0.4f + random.nextFloat() * 0.2f; retain = 0.5f; break;
		case BATTERED: dmods = 2 + random.nextInt(2); hull = 0.2f + random.nextFloat() * 0.2f; retain = 0.33f; break;
		default: dmods = 3 + random.nextInt(2); hull = random.nextFloat() * 0.1f; retain = 0.2f; break;
		}

		member.getStatus().setHullFraction(hull);
		member.getRepairTracker().setCR(0f);

		ShipVariantAPI variant = member.getVariant().clone();
		variant.setOriginalVariant(null);
		dmods = Math.max(0, dmods - DModManager.getNumDMods(variant));
		if (dmods > 0 && data.addDmods) DModManager.setDHull(variant);
		member.setVariant(variant, false, true);
		if (dmods > 0 && data.addDmods) DModManager.addDMods(member, true, dmods, random);

		if (data.pruneWeapons) {
			FleetEncounterContext.prepareShipForRecovery(member, false, false, false, retain, retain, random);
			member.getVariant().autoGenerateWeaponGroups();
		}
		return member;
	}

	private static float skillBonus(CampaignFleetAPI player) {
		float bonus = 0f;
		for (com.fs.starfarer.api.combat.MutableStat.StatMod mod : player.getStats().getDynamic()
				.getStat(Stats.SALVAGE_VALUE_MULT_FLEET_INCLUDES_RARE).getFlatMods().values()) {
			bonus += mod.value;
		}
		for (com.fs.starfarer.api.combat.MutableStat.StatMod mod : player.getStats().getDynamic()
				.getStat(Stats.SALVAGE_VALUE_MULT_FLEET_NOT_RARE).getFlatMods().values()) {
			bonus += mod.value;
		}
		return bonus;
	}

	private static void salvageDebris(StationFleet f, SectorEntityToken field) {
		DebrisFieldTerrainPlugin debris = debrisPlugin(field);
		if (debris == null) return;
		DebrisFieldTerrainPlugin.DebrisFieldParams params = debris.getParams();
		float overallMult = params.baseDensity > 0f ? params.density / params.baseDensity : 0f;
		if (overallMult < 0.01f) overallMult = 0.01f;
		addLoot(f, field, overallMult);
		params.density -= overallMult;
		if (params.density < 0f) params.density = 0f;
		debris.setScavenged(true);
	}

	private static void addLoot(StationFleet f, SectorEntityToken source, float overallMult) {
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		float gantryBonus = RepairGantry.getAdjustedGantryModifier(f.fleet, null, 0f);
		float valueMult = 1f + gantryBonus + (player != null ? skillBonus(player) : 0f);
		float rareMult = player != null ? player.getStats().getDynamic().getValue(Stats.SALVAGE_VALUE_MULT_FLEET_INCLUDES_RARE) : 1f;
		float fuelMult = player != null ? player.getStats().getDynamic().getValue(Stats.FUEL_SALVAGE_VALUE_MULT_FLEET) : 1f;

		CargoAPI loot = SalvageEntity.generateSalvage(new java.util.Random(), valueMult, rareMult, overallMult, fuelMult,
				new ArrayList<SalvageEntityGenDataSpec.DropData>(source.getDropValue()),
				new ArrayList<SalvageEntityGenDataSpec.DropData>(source.getDropRandom()));
		if (loot == null || loot.isEmpty()) return;
		float fuelRoom = Math.max(0f, f.capFuel - f.hold.getFuel());
		if (loot.getFuel() > fuelRoom) loot.removeFuel(loot.getFuel() - fuelRoom);
		f.hold.addAll(loot);
	}

	public static void deliver(SectorEntityToken station, StationFleet f) {
		CargoAPI storage = Fleets.storage(station);
		if (storage == null) return;
		if (f.hold != null) storage.addAll(f.hold);
		List<FleetMemberAPI> ships = recovered(f);
		if (!ships.isEmpty()) {
			storage.initMothballedShips(Factions.PLAYER);
			for (FleetMemberAPI m : ships) storage.getMothballedShips().addFleetMember(m);
		}
		f.recovered = null;
	}

	public static String status(StationFleet f) {
		String progress = " (" + recovered(f).size() + "/" + MAX_SHIPS + " ships recovered)";
		if (f.stage == StationFleet.STG_WORK) return "Salvaging " + describe(f.target) + progress;
		if (f.stage == StationFleet.STG_OUT) return "Heading to " + describe(f.target) + progress;
		return "Out salvaging" + progress;
	}
}
