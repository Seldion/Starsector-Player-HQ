package playerhq.visual;

public enum FleetKind {

	LOGISTICS("Transport Fleet", 4, "Called to you with Supplies, Fuel and Crew, or to carry cargo back to the station. Also works Courier Charters.",
			new String[][] { { "colossus", "Colossus", "3" }, { "nebula", "Nebula", "3" }, { "phaeton", "Phaeton", "3" } }),
	TRADE("Trade Fleet", 2, "A fleet that sells surplus resources.",
			new String[][] { { "colossus", "Colossus", "6" }, { "phaeton", "Phaeton", "2" } }),
	MINING("Mining Fleet", 2, "A fleet that mines from astral bodies and belts.",
			new String[][] { { "colossus", "Colossus", "6" }, { "phaeton", "Phaeton", "2" }, { "drover", "Drover", "2" } }),
	EXPEDITION("Expedition Fleet", 2, "A fleet that goes out into the unknown and explores bringing back goodies.",
			new String[][] { { "buffalo", "Buffalo", "2" }, { "phaeton", "Phaeton", "2" }, { "nebula", "Nebula", "2" } }),
	SALVAGE("Salvage Fleet", 2, "A fleet that salvages derelict ships and debris fields.",
			new String[][] { { "colossus", "Colossus", "4" }, { "crig", "Salvage Rig", "4" }, { "phaeton", "Phaeton", "2" } }),
	PATROL("Patrol Fleet", 1, "Your standard combat patrol fleet.",
			null);

	public final String label;
	public final int max;
	public final String blurb;
	public final String[][] parts;

	FleetKind(String label, int max, String blurb, String[][] parts) {
		this.label = label;
		this.max = max;
		this.blurb = blurb;
		this.parts = parts;
	}

	public String blurb() {
		return blurb;
	}

	public boolean logistics() {
		return this == LOGISTICS;
	}

	public int limit() {
		if (this == PATROL) return StarfarerRules.on() && Fleets.sortiesBuilt() ? 2 : 1;
		return max;
	}

	public String[][] parts() {
		if (this == LOGISTICS && StarfarerRules.on()) {
			return new String[][] { { "atlas", "Atlas", "3" }, { "starliner", "Starliner", "3" }, { "prometheus", "Prometheus", "2" } };
		}
		return parts;
	}

	public boolean fixed() {
		return parts != null;
	}

	public String composition() {
		String[][] p = parts();
		if (p == null) return "Random ships from known blueprints";
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < p.length; i++) {
			if (i > 0) sb.append(", ");
			sb.append(p[i][2]).append(" ").append(p[i][1]);
		}
		return sb.toString();
	}
}
