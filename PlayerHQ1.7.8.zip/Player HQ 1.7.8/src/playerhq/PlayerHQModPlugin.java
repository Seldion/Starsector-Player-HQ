package playerhq;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;

import playerhq.util.PlayerHQUtils;

import java.util.List;

public class PlayerHQModPlugin extends BaseModPlugin {

	@Override
	public void onApplicationLoad() throws Exception {
		Global.getSettings().loadTexture(PlayerHQMonthlyReportIntel.ICON_PATH);
		playerhq.visual.VisualRuntime.loadTextures();
	}

	@Override
	public void onGameLoad(boolean newGame) {
		playerhq.mode.HQMode.migrateOldSaves();
		grantAbilityIfMissing(Ids.ABILITY_CONSTRUCT);
		boolean visual = playerhq.mode.HQMode.isChosen() && playerhq.mode.HQMode.isColony();
		if (visual) {
			playerhq.visual.VisualRuntime.install();
		}
		playerhq.abilities.CallAbilityGrant.install();
		PlayerHQItemDescriptions.apply();
		if (visual) return;
		if (playerhq.mode.HQMode.isChosen()) playerhq.visual.VisualRuntime.installFleets();

		com.fs.starfarer.api.campaign.SectorEntityToken station = PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
		if (station != null && station.getMarket() != null) {
			playerhq.modules.MilitaryWardModule.ensureExpeditionFindsSubmarket(station);
		}
	}

	@Override
	public void beforeGameSave() {
		if (playerhq.mode.HQMode.isChosen() && playerhq.mode.HQMode.isColony()) playerhq.visual.HostileGuard.beforeSave();
	}

	@Override
	public void afterGameSave() {
		if (playerhq.mode.HQMode.isChosen() && playerhq.mode.HQMode.isColony()) playerhq.visual.HostileGuard.afterSave();
	}

	@Override
	public void onGameSaveFailed() {
		if (playerhq.mode.HQMode.isChosen() && playerhq.mode.HQMode.isColony()) playerhq.visual.HostileGuard.afterSave();
	}

	private void grantAbilityIfMissing(String abilityId) {
		MutableCharacterStatsAPI stats = Global.getSector().getPlayerStats();
		if (stats == null) return;

		List<String> granted = stats.getGrantedAbilityIds();
		if (!granted.contains(abilityId)) {
			granted.add(abilityId);
		}
	}
}
