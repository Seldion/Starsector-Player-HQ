package playerhq.modules;

import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

import playerhq.charter.CharterItem;
import playerhq.charter.CourierRequest;

import java.util.ArrayList;
import java.util.List;

public class CourierCharterEngine {
	public static final int MAX_SHIPS_PER_TRIP = 10;

	private static String key(String type, String id, String data) {
		return type + "|" + id + "|" + (data == null ? "" : data);
	}

	public static List<CharterItem> computeMovable(SectorEntityToken station, CourierRequest r, MarketAPI dest, MarketAPI source) {
		List<CharterItem> movable = new ArrayList<CharterItem>();
		SubmarketAPI sourceSub = MilitaryWardModule.getCourierTargetStorage(source);
		if (sourceSub == null || sourceSub.getCargo() == null) return movable;
		CargoAPI sourceCargo = sourceSub.getCargo();
		SubmarketAPI destSub = MilitaryWardModule.getCourierTargetStorage(dest);
		CargoAPI destCargo = destSub != null ? destSub.getCargo() : null;
		List<String> seen = new ArrayList<String>();
		boolean stockpileDest = MilitaryWardModule.isStockpileDestination(station, dest);

		for (CharterItem item : r.items) {
			if (item == null || item.amount <= 0) continue;
			seen.add(key(item.type, item.id, item.data));
			int need = item.amount;
			float haveAtDest = destCargo != null ? countIn(destCargo, item) : 0f;
			if (stockpileDest) haveAtDest += MilitaryWardModule.getStockpiledAmount(dest, item.cargoType(), item.cargoData());
			if (destCargo != null || stockpileDest) need = Math.max(0, item.amount - (int) haveAtDest);
			if (need <= 0) continue;
			int available = (int) Math.floor(countIn(sourceCargo, item));
			int take = Math.min(need, available);
			if (take <= 0) continue;
			CharterItem copy = item.copy();
			copy.amount = take;
			movable.add(copy);
		}

		if (r.allWeapons || r.allWings || r.allSpecials || r.allResources || r.allHullmods) {
			List<CharterItem> all = new ArrayList<CharterItem>();
			for (CargoStackAPI stack : sourceCargo.getStacksCopy()) {
				if (stack == null || stack.isNull()) continue;
				CargoAPI.CargoItemType type = stack.getType();
				boolean modspec = false;
				if (type == CargoAPI.CargoItemType.SPECIAL) {
					SpecialItemData msd = stack.getSpecialDataIfSpecial();
					modspec = msd != null && "modspec".equals(msd.getId());
				}
				boolean take = (r.allWeapons && type == CargoAPI.CargoItemType.WEAPONS)
						|| (r.allWings && type == CargoAPI.CargoItemType.FIGHTER_CHIP)
						|| (r.allResources && type == CargoAPI.CargoItemType.RESOURCES)
						|| (r.allSpecials && type == CargoAPI.CargoItemType.SPECIAL && !modspec)
						|| (r.allHullmods && type == CargoAPI.CargoItemType.SPECIAL && modspec);
				if (!take) continue;
				int amount = (int) stack.getSize();
				if (amount <= 0) continue;
				String id;
				String data = null;
				if (type == CargoAPI.CargoItemType.SPECIAL) {
					SpecialItemData sd = stack.getSpecialDataIfSpecial();
					if (sd == null) continue;
					id = sd.getId();
					data = sd.getData();
				} else {
					if (stack.getData() == null) continue;
					id = String.valueOf(stack.getData());
				}
				String k = key(type.name(), id, data);
				if (seen.contains(k)) continue;
				CharterItem existing = null;
				for (CharterItem a : all) {
					if (key(a.type, a.id, a.data).equals(k)) {
						existing = a;
						break;
					}
				}
				if (existing != null) existing.amount += amount;
				else all.add(new CharterItem(type.name(), id, data, stack.getDisplayName(), amount));
			}
			movable.addAll(all);
		}
		if (r.allShips && sourceCargo.getMothballedShips() != null) {
			List<CharterItem> ships = new ArrayList<CharterItem>();
			for (FleetMemberAPI m : sourceCargo.getMothballedShips().getMembersListCopy()) {
				if (m == null || m.getHullId() == null) continue;
				if (seen.contains(key(CharterItem.SHIP, m.getHullId(), null))) continue;
				CharterItem existing = null;
				for (CharterItem a : ships) {
					if (a.id.equals(m.getHullId())) {
						existing = a;
						break;
					}
				}
				if (existing != null) existing.amount++;
				else ships.add(new CharterItem(CharterItem.SHIP, m.getHullId(), null, m.getHullSpec().getHullName(), 1));
			}
			movable.addAll(ships);
		}
		return movable;
	}

	public static Object dataFor(CargoAPI cargo, CharterItem item) {
		if (!CargoAPI.CargoItemType.SPECIAL.name().equals(item.type)) return item.cargoData();
		for (CargoStackAPI stack : cargo.getStacksCopy()) {
			if (stack == null || stack.isNull() || !stack.isSpecialStack()) continue;
			SpecialItemData sd = stack.getSpecialDataIfSpecial();
			if (sd == null || !item.id.equals(sd.getId())) continue;
			if (item.data == null ? sd.getData() == null : item.data.equals(sd.getData())) return sd;
		}
		return item.cargoData();
	}

	public static float countIn(CargoAPI cargo, CharterItem item) {
		if (cargo == null || item == null) return 0f;
		if (item.isShip()) {
			int n = 0;
			if (cargo.getMothballedShips() != null) {
				for (FleetMemberAPI m : cargo.getMothballedShips().getMembersListCopy()) {
					if (item.id.equals(m.getHullId())) n++;
				}
			}
			return n;
		}
		CargoAPI.CargoItemType type = item.cargoType();
		if (type == null) return 0f;
		if (type == CargoAPI.CargoItemType.SPECIAL) {
			float n = 0f;
			for (CargoStackAPI stack : cargo.getStacksCopy()) {
				if (stack == null || stack.isNull() || !stack.isSpecialStack()) continue;
				SpecialItemData sd = stack.getSpecialDataIfSpecial();
				if (sd == null || !item.id.equals(sd.getId())) continue;
				if (item.data == null ? sd.getData() == null : item.data.equals(sd.getData())) n += stack.getSize();
			}
			return n;
		}
		try {
			return cargo.getQuantity(type, item.cargoData());
		} catch (Throwable t) {
			return 0f;
		}
	}
}
