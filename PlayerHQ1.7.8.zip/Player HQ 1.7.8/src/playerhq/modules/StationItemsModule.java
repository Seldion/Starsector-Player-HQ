package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.mode.EasyRules;
import playerhq.util.PlayerHQUtils;

public class StationItemsModule {

	public static final String SPACE_ELEVATOR_MEMORY_KEY = "$playerhq_stationitem_spaceelevator";
	public static final String PUBLIC_SHUTTLES_MEMORY_KEY = "$playerhq_stationitem_publicshuttles";
	public static final String EXPANDED_SORTIES_MEMORY_KEY = "$playerhq_stationitem_expandedsorties";
	public static final String ACADEMY_MEMORY_KEY = "$playerhq_stationitem_academy";

	public static final float BASE_ACCESSIBILITY = 25f;
	public static final float SPACE_ELEVATOR_ACCESSIBILITY_BONUS = 50f;
	public static final float PUBLIC_SHUTTLES_ACCESSIBILITY_BONUS = 25f;

	public static final float INDUSTRIAL_PLANNING_ACCESSIBILITY_BONUS = 15f;

	public static final float SPACE_ELEVATOR_CREDIT_COST = 25000f;
	public static final float SPACE_ELEVATOR_METALS_COST = 1000f;
	public static final float SPACE_ELEVATOR_TRANSPLUTONICS_COST = 150f;
	public static final float SPACE_ELEVATOR_HEAVY_MACHINERY_COST = 100f;

	public static final float PUBLIC_SHUTTLES_CREDIT_COST = 10000f;
	public static final float PUBLIC_SHUTTLES_METALS_COST = 1000f;
	public static final float PUBLIC_SHUTTLES_TRANSPLUTONICS_COST = 250f;
	public static final float PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST = 50f;
	public static final int PUBLIC_SHUTTLES_CREW_COST = 50;

	public static final float EXPANDED_SORTIES_CREDIT_COST = 40000f;
	public static final float EXPANDED_SORTIES_METALS_COST = 200f;
	public static final float EXPANDED_SORTIES_TRANSPLUTONICS_COST = 100f;
	public static final float EXPANDED_SORTIES_HEAVY_MACHINERY_COST = 400f;
	public static final int EXPANDED_SORTIES_CREW_COST = 500;

	public static final float ACADEMY_CREDIT_COST = 25500f;
	public static final float ACADEMY_METALS_COST = 700f;
	public static final float ACADEMY_TRANSPLUTONICS_COST = 230f;
	public static final float ACADEMY_VOLATILES_COST = 60f;
	public static final float ACADEMY_MARINES_COST = 30f;
	public static final int ACADEMY_CREW_COST = 230;

	public static float getAccessibility(SectorEntityToken station) {
		float accessibility = BASE_ACCESSIBILITY;
		if (EasyRules.on()) {
			if (hasSpaceElevatorInstalled(station)) accessibility += EasyRules.ELEVATOR_ACCESS_BONUS;
			if (hasPublicShuttlesInstalled(station)) accessibility += EasyRules.SHUTTLES_ACCESS_BONUS;
			accessibility += EasyRules.accessExtra(station);
			if (hasIndustrialPlanningSkill()) accessibility += INDUSTRIAL_PLANNING_ACCESSIBILITY_BONUS;
			return accessibility;
		}
		if (hasSpaceElevatorInstalled(station)) accessibility += SPACE_ELEVATOR_ACCESSIBILITY_BONUS;
		if (hasPublicShuttlesInstalled(station)) accessibility += PUBLIC_SHUTTLES_ACCESSIBILITY_BONUS;
		if (hasIndustrialPlanningSkill()) accessibility += INDUSTRIAL_PLANNING_ACCESSIBILITY_BONUS;
		return accessibility;
	}

	public static float getAccessibilityMultiplier(SectorEntityToken station) {
		return getAccessibility(station) / 100f;
	}

	public static boolean hasIndustrialPlanningSkill() {
		return Global.getSector().getPlayerStats() != null
				&& Global.getSector().getPlayerStats().getSkillLevel(Skills.INDUSTRIAL_PLANNING) > 0;
	}

	public static boolean hasSpaceElevatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(SPACE_ELEVATOR_MEMORY_KEY);
	}

	public static boolean hasSpoolInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(EasyRules.SPOOL_KEY);
	}

	public static boolean hasSpoolAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.FULLERENE_SPOOL);
	}

	public static void installSpool(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (hasSpoolInstalled(station) || !hasSpoolAvailable(station, playerFleet)) return;
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.FULLERENE_SPOOL, 1);
		station.getMemoryWithoutUpdate().set(EasyRules.SPOOL_KEY, true);
	}

	public static void uninstallSpool(SectorEntityToken station) {
		if (!hasSpoolInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.FULLERENE_SPOOL, 1);
		station.getMemoryWithoutUpdate().unset(EasyRules.SPOOL_KEY);
	}

	public static boolean hasSpaceElevatorCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) {
			return !hasSpaceElevatorInstalled(station) && EasyRules.canAfford(playerFleet, EasyRules.PRICE_MEDIUM);
		}
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.FULLERENE_SPOOL)
				&& playerFleet.getCargo().getCredits().get() >= SPACE_ELEVATOR_CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= SPACE_ELEVATOR_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= SPACE_ELEVATOR_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= SPACE_ELEVATOR_HEAVY_MACHINERY_COST;
	}

	public static void installSpaceElevator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSpaceElevatorCost(station, playerFleet)) return;
		if (EasyRules.on()) {
			EasyRules.pay(playerFleet, EasyRules.PRICE_MEDIUM);
			station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, true);
			return;
		}
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.FULLERENE_SPOOL, 1);
		playerFleet.getCargo().getCredits().subtract(SPACE_ELEVATOR_CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, SPACE_ELEVATOR_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, SPACE_ELEVATOR_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, SPACE_ELEVATOR_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, true);
	}

	public static void refundSpaceElevator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSpaceElevatorInstalled(station)) return;
		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_MEDIUM);
			if (hasSpoolInstalled(station)) {
				playerFleet.getCargo().addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FULLERENE_SPOOL, null), 1);
				station.getMemoryWithoutUpdate().unset(EasyRules.SPOOL_KEY);
			}
			if (!hasPublicShuttlesInstalled(station)) EasyRules.returnCore(station, EasyRules.MOD_ACCESS, playerFleet.getCargo());
			station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, false);
			return;
		}
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FULLERENE_SPOOL, null), 1);
		cargo.addCommodity(Commodities.METALS, SPACE_ELEVATOR_METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, SPACE_ELEVATOR_TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, SPACE_ELEVATOR_HEAVY_MACHINERY_COST * fraction);
		station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, false);
	}

	public static void uninstallSpaceElevator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSpaceElevatorInstalled(station)) return;
		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_MEDIUM);
			uninstallSpool(station);
			if (!hasPublicShuttlesInstalled(station)) EasyRules.removeCore(station, EasyRules.MOD_ACCESS);
			station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, false);
			return;
		}
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FULLERENE_SPOOL, null), 1);
			storage.addCommodity(Commodities.METALS, SPACE_ELEVATOR_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, SPACE_ELEVATOR_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.HEAVY_MACHINERY, SPACE_ELEVATOR_HEAVY_MACHINERY_COST * fraction);
		}
		station.getMemoryWithoutUpdate().set(SPACE_ELEVATOR_MEMORY_KEY, false);
	}

	public static boolean hasPublicShuttlesInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(PUBLIC_SHUTTLES_MEMORY_KEY);
	}

	public static boolean hasPublicShuttlesCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) return EasyRules.canAfford(playerFleet, EasyRules.PRICE_MEDIUM);
		return playerFleet.getCargo().getCredits().get() >= PUBLIC_SHUTTLES_CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= PUBLIC_SHUTTLES_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= PUBLIC_SHUTTLES_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST
				&& PlayerHQUtils.getStationCrew(station) >= PUBLIC_SHUTTLES_CREW_COST;
	}

	public static void installPublicShuttles(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasPublicShuttlesCost(station, playerFleet)) return;
		if (EasyRules.on()) {
			EasyRules.pay(playerFleet, EasyRules.PRICE_MEDIUM);
			station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, true);
			return;
		}
		playerFleet.getCargo().getCredits().subtract(PUBLIC_SHUTTLES_CREDIT_COST);
		PlayerHQUtils.removeStationCrew(station, PUBLIC_SHUTTLES_CREW_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, PUBLIC_SHUTTLES_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, PUBLIC_SHUTTLES_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, true);
	}

	public static void refundPublicShuttles(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasPublicShuttlesInstalled(station)) return;
		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_MEDIUM);
			if (!hasSpaceElevatorInstalled(station)) EasyRules.returnCore(station, EasyRules.MOD_ACCESS, playerFleet.getCargo());
			station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, false);
			return;
		}
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.addCommodity(Commodities.METALS, PUBLIC_SHUTTLES_METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, PUBLIC_SHUTTLES_TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST * fraction);
		cargo.addCrew(PUBLIC_SHUTTLES_CREW_COST);
		station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, false);
	}

	public static void uninstallPublicShuttles(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasPublicShuttlesInstalled(station)) return;
		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_MEDIUM);
			if (!hasSpaceElevatorInstalled(station)) EasyRules.removeCore(station, EasyRules.MOD_ACCESS);
			station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, false);
			return;
		}
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(Commodities.METALS, PUBLIC_SHUTTLES_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, PUBLIC_SHUTTLES_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.HEAVY_MACHINERY, PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST * fraction);
			storage.addCrew(PUBLIC_SHUTTLES_CREW_COST);
		}
		station.getMemoryWithoutUpdate().set(PUBLIC_SHUTTLES_MEMORY_KEY, false);
	}

	public static boolean hasExpandedSortiesInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(EXPANDED_SORTIES_MEMORY_KEY);
	}

	public static boolean hasExpandedSortiesCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= EXPANDED_SORTIES_CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= EXPANDED_SORTIES_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= EXPANDED_SORTIES_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= EXPANDED_SORTIES_HEAVY_MACHINERY_COST
				&& PlayerHQUtils.getStationCrew(station) >= EXPANDED_SORTIES_CREW_COST;
	}

	public static void installExpandedSorties(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (hasExpandedSortiesInstalled(station) || !hasExpandedSortiesCost(station, playerFleet)) return;
		playerFleet.getCargo().getCredits().subtract(EXPANDED_SORTIES_CREDIT_COST);
		PlayerHQUtils.removeStationCrew(station, EXPANDED_SORTIES_CREW_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, EXPANDED_SORTIES_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, EXPANDED_SORTIES_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, EXPANDED_SORTIES_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(EXPANDED_SORTIES_MEMORY_KEY, true);
	}

	public static void refundExpandedSorties(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasExpandedSortiesInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.addCommodity(Commodities.METALS, EXPANDED_SORTIES_METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, EXPANDED_SORTIES_TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, EXPANDED_SORTIES_HEAVY_MACHINERY_COST * fraction);
		cargo.addCrew(EXPANDED_SORTIES_CREW_COST);
		station.getMemoryWithoutUpdate().set(EXPANDED_SORTIES_MEMORY_KEY, false);
	}

	public static void uninstallExpandedSorties(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasExpandedSortiesInstalled(station)) return;
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(Commodities.METALS, EXPANDED_SORTIES_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, EXPANDED_SORTIES_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.HEAVY_MACHINERY, EXPANDED_SORTIES_HEAVY_MACHINERY_COST * fraction);
			storage.addCrew(EXPANDED_SORTIES_CREW_COST);
		}
		station.getMemoryWithoutUpdate().set(EXPANDED_SORTIES_MEMORY_KEY, false);
	}

	public static boolean hasAcademyInstalled(SectorEntityToken station) {
		return station != null && station.getMemoryWithoutUpdate().getBoolean(ACADEMY_MEMORY_KEY);
	}

	public static boolean hasAcademyCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!MilitaryWardModule.hasFleetHQBuilt(station)) return false;
		if (EasyRules.on()) return EasyRules.canAfford(playerFleet, EasyRules.PRICE_ACADEMY);
		return playerFleet.getCargo().getCredits().get() >= ACADEMY_CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= ACADEMY_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= ACADEMY_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= ACADEMY_VOLATILES_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.MARINES) >= ACADEMY_MARINES_COST
				&& PlayerHQUtils.getStationCrew(station) >= ACADEMY_CREW_COST;
	}

	public static void installAcademy(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (hasAcademyInstalled(station) || !hasAcademyCost(station, playerFleet)) return;
		if (EasyRules.on()) {
			EasyRules.pay(playerFleet, EasyRules.PRICE_ACADEMY);
			station.getMemoryWithoutUpdate().set(ACADEMY_MEMORY_KEY, true);
			return;
		}
		playerFleet.getCargo().getCredits().subtract(ACADEMY_CREDIT_COST);
		PlayerHQUtils.removeStationCrew(station, ACADEMY_CREW_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, ACADEMY_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, ACADEMY_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, ACADEMY_VOLATILES_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.MARINES, ACADEMY_MARINES_COST);
		station.getMemoryWithoutUpdate().set(ACADEMY_MEMORY_KEY, true);
	}

	public static void refundAcademy(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasAcademyInstalled(station)) return;
		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_ACADEMY);
			station.getMemoryWithoutUpdate().set(ACADEMY_MEMORY_KEY, false);
			return;
		}
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		CargoAPI cargo = playerFleet.getCargo();
		cargo.getCredits().add(ACADEMY_CREDIT_COST * fraction);
		cargo.addCommodity(Commodities.METALS, ACADEMY_METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, ACADEMY_TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, ACADEMY_VOLATILES_COST * fraction);
		cargo.addCommodity(Commodities.MARINES, ACADEMY_MARINES_COST);
		cargo.addCrew(ACADEMY_CREW_COST);
		station.getMemoryWithoutUpdate().set(ACADEMY_MEMORY_KEY, false);
	}

	public static void uninstallAcademy(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasAcademyInstalled(station)) return;
		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_ACADEMY);
			station.getMemoryWithoutUpdate().set(ACADEMY_MEMORY_KEY, false);
			return;
		}
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		playerFleet.getCargo().getCredits().add(ACADEMY_CREDIT_COST * fraction);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(Commodities.METALS, ACADEMY_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, ACADEMY_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.VOLATILES, ACADEMY_VOLATILES_COST * fraction);
			storage.addCommodity(Commodities.MARINES, ACADEMY_MARINES_COST);
			storage.addCrew(ACADEMY_CREW_COST);
		}
		station.getMemoryWithoutUpdate().set(ACADEMY_MEMORY_KEY, false);
	}

}
