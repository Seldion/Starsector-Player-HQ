package playerhq;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import org.lwjgl.input.Keyboard;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.IntelUIAPI;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.HydroponicsHubModule.HydroponicsResult;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.IndustrialHubModule.IndustrialHubResult;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.MiningHangarModule.MiningResult;
import playerhq.modules.RecreationalHubModule;
import playerhq.util.PlayerHQUtils;

public class PlayerHQMonthlyReportIntel extends BaseIntelPlugin {

	public static final String ICON_PATH = "graphics/icons/intel/playerhq_report.png";

	private static final String BUTTON_ORDER_PRODUCTION = "playerhq_intel_order_production";
	private static final String BUTTON_SHOPPING_LIST = "playerhq_intel_shopping_list";
	private static final String BUTTON_COURIER = "playerhq_intel_courier";

	private SectorEntityToken station;

	private MiningResult mining;
	private IndustrialHubResult industrial;
	private HydroponicsResult hydroponics;
	private float recreationIncome;
	private float marketPlaceIncome;
	private float upkeepCharged;
	private List<String> deliveredShips = new ArrayList<String>();
	private List<String> deliveredWeapons = new ArrayList<String>();
	private List<String> deliveredWings = new ArrayList<String>();
	private String soldShipName;
	private float shipSaleIncome;
	private float traderEarned;
	private List<String> traderBought = new ArrayList<String>();
	private List<String> visualLines = new ArrayList<String>();

	/** Visual style: the structures' monthly production lines for the report. */
	public static void reportVisual(SectorEntityToken station, List<String> lines) {
		if (station == null) return;
		PlayerHQMonthlyReportIntel intel = (PlayerHQMonthlyReportIntel)
				Global.getSector().getIntelManager().getFirstIntel(PlayerHQMonthlyReportIntel.class);
		boolean isNew = intel == null;
		if (isNew) intel = new PlayerHQMonthlyReportIntel();
		intel.station = station;
		intel.visualLines = lines != null ? new ArrayList<String>(lines) : new ArrayList<String>();
		if (isNew) {
			Global.getSector().getIntelManager().addIntel(intel);
		} else {
			intel.sendUpdateIfPlayerHasIntel(null, false);
		}
	}

	public static void report(SectorEntityToken station, MiningResult mining, IndustrialHubResult industrial,
			HydroponicsResult hydroponics, float recreationIncome, float marketPlaceIncome, float upkeepCharged,
			List<String> deliveredShips, List<String> deliveredWeapons, List<String> deliveredWings,
			String soldShipName, float shipSaleIncome,
			float traderEarned, List<String> traderBought) {
		if (station == null) return;

		PlayerHQMonthlyReportIntel intel = (PlayerHQMonthlyReportIntel)
				Global.getSector().getIntelManager().getFirstIntel(PlayerHQMonthlyReportIntel.class);
		boolean isNew = intel == null;
		if (isNew) {
			intel = new PlayerHQMonthlyReportIntel();
		}

		intel.station = station;
		intel.mining = mining;
		intel.industrial = industrial;
		intel.hydroponics = hydroponics;
		intel.recreationIncome = recreationIncome;
		intel.marketPlaceIncome = marketPlaceIncome;
		intel.upkeepCharged = upkeepCharged;
		intel.deliveredShips = deliveredShips != null ? deliveredShips : new ArrayList<String>();
		intel.deliveredWeapons = deliveredWeapons != null ? deliveredWeapons : new ArrayList<String>();
		intel.deliveredWings = deliveredWings != null ? deliveredWings : new ArrayList<String>();
		intel.soldShipName = soldShipName;
		intel.shipSaleIncome = shipSaleIncome;
		intel.traderEarned = traderEarned;
		intel.traderBought = traderBought != null ? traderBought : new ArrayList<String>();

		if (isNew) {
			Global.getSector().getIntelManager().addIntel(intel);
		} else {
			intel.sendUpdateIfPlayerHasIntel(null, false);
		}
	}

	public static void ensureCreated(SectorEntityToken station) {
		if (station == null) return;

		IntelInfoPlugin existing = Global.getSector().getIntelManager().getFirstIntel(PlayerHQMonthlyReportIntel.class);
		if (existing != null) return;

		PlayerHQMonthlyReportIntel intel = new PlayerHQMonthlyReportIntel();
		intel.station = station;
		Global.getSector().getIntelManager().addIntel(intel);
	}

	public static void removeIfPresent() {
		IntelInfoPlugin intel = Global.getSector().getIntelManager().getFirstIntel(PlayerHQMonthlyReportIntel.class);
		if (intel != null) {
			Global.getSector().getIntelManager().removeIntel(intel);
		}
	}

	@Override
	protected String getName() {
		return "Player HQ Status Report";
	}

	@Override
	public String getIcon() {
		return ICON_PATH;
	}

	@Override
	public boolean isPlayerVisible() {
		return !isHidden() && !isEnded();
	}

	@Override
	public Set<String> getIntelTags(SectorMapAPI map) {
		Set<String> tags = super.getIntelTags(map);
		tags.add("Personal");
		return tags;
	}

	@Override
	public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		float opad = 10f;
		info.addPara(getName(), opad);
		addLines(info, opad);
	}

	private void addLines(TooltipMakerAPI info, float pad) {
		Color h = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();
		Color headingText = Misc.getBasePlayerColor();
		Color headingBg = Misc.getDarkPlayerColor();

		if (station == null || !station.isAlive()) {
			info.addPara("The station no longer exists.", pad, bad);
			return;
		}

		info.addPara(PlayerHQUtils.getStationLocationSummary(station), pad, h);

		boolean visual = playerhq.mode.HQMode.isColony();

		info.addSectionHeading("Modules", headingText, headingBg, Alignment.MID, pad);
		if (visual) addVisualModulesSection(info, pad);
		else addFacilitiesSection(info, pad);

		info.addSectionHeading("Last Month's Production", headingText, headingBg, Alignment.MID, pad);
		if (visual) addVisualProductionSection(info, pad);
		else addProductionSection(info, pad);

		ButtonAPI orderButton = info.addButton("Order Production", BUTTON_ORDER_PRODUCTION, 220f, 24f, pad);
		orderButton.setEnabled(visual ? playerhq.visual.OrderShips.assembly(station) != null : AssemblyBayModule.isBuilt(station));
		orderButton.setShortcut(Keyboard.KEY_O, true);
		ButtonAPI shoppingButton = info.addButton("Shopping List", BUTTON_SHOPPING_LIST, 220f, 24f, 4f);
		shoppingButton.setEnabled(playerhq.shopping.ShoppingAccess.available(station));
		shoppingButton.setShortcut(Keyboard.KEY_S, true);
		ButtonAPI courierButton = info.addButton("Courier", BUTTON_COURIER, 220f, 24f, 4f);
		courierButton.setEnabled(playerhq.charter.CharterAccess.available(station));
		courierButton.setShortcut(Keyboard.KEY_C, true);
	}

	private void addVisualModulesSection(TooltipMakerAPI info, float pad) {
		boolean any = false;
		if (station.getMarket() != null) {
			for (com.fs.starfarer.api.campaign.econ.Industry ind : station.getMarket().getIndustries()) {
				String id = ind.getId();
				if (id == null || !id.startsWith("playerhq_v_") || playerhq.visual.StationUpkeepIndustry.ID.equals(id)) continue;
				if (ind.isHidden()) continue;
				String name = ind.getCurrentName();
				if (ind.isBuilding()) name += " (under construction)";
				TooltipMakerAPI row = info.beginImageWithText(ind.getCurrentImage(), 32f);
				row.addPara(name, Misc.getHighlightColor(), 0f);
				info.addImageWithText(pad * 0.5f);
				any = true;
			}
		}
		if (!any) {
			info.addPara("No modules have been built yet.", pad);
			return;
		}
		String fleets = playerhq.visual.Fleets.ownedSummary();
		if (fleets != null) info.addPara("Fleets: %s.", pad, Misc.getHighlightColor(), fleets);
	}

	private void addVisualProductionSection(TooltipMakerAPI info, float pad) {
		if (visualLines == null || visualLines.isEmpty()) {
			info.addPara("Nothing to report yet.", pad);
			return;
		}
		for (String line : visualLines) {
			info.addPara(line, pad);
		}
	}

	@Override
	public void buttonPressConfirmed(Object buttonId, IntelUIAPI ui) {
		if (BUTTON_ORDER_PRODUCTION.equals(buttonId)) {
			if (station != null && station.isAlive()) {
				if (playerhq.mode.HQMode.isColony()) ui.showDialog(station, new playerhq.visual.RemoteOrderDialog(station));
				else ui.showDialog(station, new PlayerHQRemoteProductionDialogPlugin(station));
			}
			return;
		}
		if (BUTTON_SHOPPING_LIST.equals(buttonId)) {
			if (station != null && station.isAlive()) {
				ui.showDialog(station, new PlayerHQRemoteShoppingDialogPlugin(station));
			}
			return;
		}
		if (BUTTON_COURIER.equals(buttonId)) {
			if (station != null && station.isAlive()) {
				ui.showDialog(station, new PlayerHQRemoteCharterDialogPlugin(station));
			}
			return;
		}
		super.buttonPressConfirmed(buttonId, ui);
	}

	private static class Facility {
		final String name;
		final String iconCommodityId;
		Facility(String name, String iconCommodityId) {
			this.name = name;
			this.iconCommodityId = iconCommodityId;
		}
	}

	private void addFacilitiesSection(TooltipMakerAPI info, float pad) {
		List<Facility> facilities = getBuiltFacilities(station);

		if (facilities.isEmpty()) {
			info.addPara("No modules have been built yet.", pad);
			return;
		}

		for (Facility facility : facilities) {
			TooltipMakerAPI row = info.beginImageWithText(commodityIcon(facility.iconCommodityId), 32f);
			row.addPara(facility.name, Misc.getHighlightColor(), 0f);
			info.addImageWithText(pad * 0.5f);
		}

		if (MilitaryWardModule.hasFleetHQBuilt(station)) {
			String fleets = playerhq.visual.Fleets.ownedSummary();
			info.addPara("Fleet HQ: %s.", pad, Misc.getHighlightColor(), fleets == null ? "no fleets yet" : fleets);
		}
	}

	private static List<Facility> getBuiltFacilities(SectorEntityToken station) {
		List<Facility> facilities = new ArrayList<Facility>();

		if (MiningHangarModule.isBuilt(station)) facilities.add(new Facility("Materials Acquisition Hub", Commodities.ORE));
		if (RecreationalHubModule.isBuilt(station)) facilities.add(new Facility("Resort", Commodities.LUXURY_GOODS));
		if (IndustrialHubModule.isBuilt(station)) facilities.add(new Facility("Manufactorium", Commodities.HEAVY_MACHINERY));
		if (HydroponicsHubModule.isBuilt(station)) facilities.add(new Facility("Bio-Dome", Commodities.FOOD));
		if (AssemblyBayModule.isBuilt(station)) facilities.add(new Facility("Strategic Assembly", Commodities.HAND_WEAPONS));
		if (MilitaryWardModule.isBuilt(station)) facilities.add(new Facility("Military Paradigm", Commodities.MARINES));
		if (MilitaryWardModule.hasFleetHQBuilt(station)) facilities.add(new Facility("Fleet HQ", Commodities.SUPPLIES));

		return facilities;
	}

	private void addProductionSection(TooltipMakerAPI info, float pad) {
		Color h = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();

		boolean anyProduction = false;

		if (mining != null) {
			anyProduction |= addQuantityRow(info, pad, Commodities.ORE, mining.ore);
			anyProduction |= addQuantityRow(info, pad, Commodities.RARE_ORE, mining.rareOre);
			anyProduction |= addQuantityRow(info, pad, Commodities.VOLATILES, mining.volatiles);
			anyProduction |= addQuantityRow(info, pad, Commodities.ORGANICS, mining.organics);
		}

		if (industrial != null) {
			anyProduction |= addQuantityRow(info, pad, Commodities.METALS, industrial.metals);
			anyProduction |= addQuantityRow(info, pad, Commodities.RARE_METALS, industrial.transplutonics);
			anyProduction |= addQuantityRow(info, pad, Commodities.HEAVY_MACHINERY, industrial.heavyMachinery);
			anyProduction |= addQuantityRow(info, pad, Commodities.SUPPLIES, industrial.supplies);
			anyProduction |= addQuantityRow(info, pad, Commodities.DRUGS, industrial.drugs);
			anyProduction |= addQuantityRow(info, pad, Commodities.ORGANS, industrial.organs);
			anyProduction |= addQuantityRow(info, pad, Commodities.DOMESTIC_GOODS, industrial.domesticGoods);
			anyProduction |= addQuantityRow(info, pad, Commodities.LUXURY_GOODS, industrial.luxuryGoods);
			anyProduction |= addQuantityRow(info, pad, Commodities.HAND_WEAPONS, industrial.heavyArmaments);
			anyProduction |= addQuantityRow(info, pad, Commodities.FUEL, industrial.fuel);
		}

		if (hydroponics != null) {
			anyProduction |= addQuantityRow(info, pad, Commodities.FOOD, hydroponics.food);
			anyProduction |= addQuantityRow(info, pad, Commodities.ORGANICS, hydroponics.organics);
		}

		if (recreationIncome > 0f) {
			info.addPara("Resort generated %s credits in income.", pad, h, fmt(recreationIncome));
			anyProduction = true;
		}

		if (marketPlaceIncome > 0f) {
			info.addPara("Agora merchants paid %s credits for stock.", pad, h, fmt(marketPlaceIncome));
			anyProduction = true;
		}

		if (soldShipName != null) {
			info.addPara("A ship stored in the Agora was sold off: %s (%s credits).", pad, h,
					soldShipName, fmt(shipSaleIncome));
			anyProduction = true;
		}

		if (!deliveredShips.isEmpty()) {
			info.addPara("Strategic Assembly completed %s: %s.", pad, h,
					deliveredShips.size() == 1 ? "1 ship" : deliveredShips.size() + " ships",
					String.join(", ", deliveredShips));
			anyProduction = true;
		}

		if (!deliveredWeapons.isEmpty()) {
			info.addPara("Strategic Assembly completed %s: %s.", pad, h,
					deliveredWeapons.size() == 1 ? "1 weapon batch" : deliveredWeapons.size() + " weapon batches",
					String.join(", ", deliveredWeapons));
			anyProduction = true;
		}

		if (deliveredWings != null && !deliveredWings.isEmpty()) {
			info.addPara("Strategic Assembly completed %s: %s.", pad, h,
					deliveredWings.size() == 1 ? "1 fighter wing" : deliveredWings.size() + " fighter wings",
					String.join(", ", deliveredWings));
			anyProduction = true;
		}

		if (traderEarned > 0f || (traderBought != null && !traderBought.isEmpty())) {
			if (traderBought != null && !traderBought.isEmpty()) {
				info.addPara("Trader: %s credits. Bought: %s.", pad, h, fmt(traderEarned), String.join(", ", traderBought));
			} else {
				info.addPara("Trader: %s credits.", pad, h, fmt(traderEarned));
			}
			anyProduction = true;
		}

		if (upkeepCharged > 0f) {
			info.addPara("Station upkeep cost %s credits.", pad, bad, fmt(upkeepCharged));
			anyProduction = true;
		}

		if (!anyProduction) {
			info.addPara("Nothing to report yet.", pad);
		}
	}

	private boolean addQuantityRow(TooltipMakerAPI info, float pad, String commodityId, float quantity) {
		if (quantity <= 0f) return false;

		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(commodityId);
		TooltipMakerAPI row = info.beginImageWithText(spec.getIconName(), 32f);
		row.addPara(fmt(quantity) + "x " + spec.getName(), Misc.getHighlightColor(), 0f);
		info.addImageWithText(pad * 0.5f);
		return true;
	}

	private static String commodityIcon(String commodityId) {
		return Global.getSettings().getCommoditySpec(commodityId).getIconName();
	}

	private static String fmt(float value) {
		return "" + (int) value;
	}
}
