package playerhq.shopping;

import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.Industry;

import playerhq.mode.HQMode;
import playerhq.modules.MarketPlaceModule;

/** Whether the Shopping List can be used: needs the Market Place, whatever the mode or style. */
public class ShoppingAccess {

	public static final String VISUAL_MARKET_PLACE = "playerhq_v_marketplace";

	public static boolean available(SectorEntityToken station) {
		if (station == null) return false;
		if (HQMode.isColony()) {
			if (station.getMarket() == null) return false;
			Industry ind = station.getMarket().getIndustry(VISUAL_MARKET_PLACE);
			return ind != null && !ind.isBuilding();
		}
		return MarketPlaceModule.isBuilt(station);
	}
}
