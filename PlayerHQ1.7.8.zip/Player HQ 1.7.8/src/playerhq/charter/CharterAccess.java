package playerhq.charter;

import com.fs.starfarer.api.campaign.SectorEntityToken;


/** Whether Courier Charters can be used: needs at least one Transport Fleet, whatever the mode or style. */
public class CharterAccess {

	public static boolean available(SectorEntityToken station) {
		if (station == null) return false;
		return playerhq.visual.Fleets.ownedCount(playerhq.visual.FleetKind.LOGISTICS) > 0;
	}
}
