package playerhq.modules;

import java.util.HashSet;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fs.starfarer.api.Global;

/**
 * A user (and mod) editable list of item ids that should never show up in the Exchange's random
 * restocks, on top of whatever tags a weapon/wing/hull mod/hull is already marked with (see the
 * filtering in {@link BlackMarketSubmarketPlugin}). Backed by {@code
 * data/config/playerhq_exchange_blacklist.csv} -- add a row with the offending id to keep it out,
 * whether it's a base-game item or something from another mod. Any other installed mod can also
 * ship its own copy of that same file (same path, same "id" column) and its rows get merged in
 * automatically, so mod authors can blacklist their own problem items without editing this one.
 */
public class ExchangeBlacklist {

	private static final String CSV_PATH = "data/config/playerhq_exchange_blacklist.csv";

	private static Set<String> blacklistedIds;

	public static boolean isBlacklisted(String id) {
		if (id == null) return false;
		return getBlacklistedIds().contains(id);
	}

	private static Set<String> getBlacklistedIds() {
		if (blacklistedIds == null) {
			blacklistedIds = loadBlacklistedIds();
		}
		return blacklistedIds;
	}

	private static Set<String> loadBlacklistedIds() {
		Set<String> ids = new HashSet<String>();
		try {
			JSONArray rows = Global.getSettings().getMergedSpreadsheetData("id", CSV_PATH);
			for (int i = 0; i < rows.length(); i++) {
				JSONObject row = rows.getJSONObject(i);
				String id = row.optString("id", "").trim();
				if (id.isEmpty() || id.startsWith("#")) continue;
				ids.add(id);
			}
		} catch (Exception e) {
			Global.getLogger(ExchangeBlacklist.class).error("Failed to load " + CSV_PATH, e);
		}
		return ids;
	}
}
