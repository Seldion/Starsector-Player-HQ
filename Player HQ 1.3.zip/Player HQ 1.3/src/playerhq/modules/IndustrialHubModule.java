package playerhq.modules;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class IndustrialHubModule {

	public static final String MEMORY_KEY = "$playerhq_module_industrial";
	public static final String NANOFORGE_MEMORY_KEY = "$playerhq_module_industrial_nanoforge";
	public static final String NANOFORGE_ITEM_KEY = "$playerhq_module_industrial_nanoforge_item";
	public static final String BIOFACTORY_MEMORY_KEY = "$playerhq_module_industrial_biofactory";
	public static final String CATALYTIC_CORE_MEMORY_KEY = "$playerhq_module_industrial_catalyticcore";
	public static final String SYNCHROTRON_CORE_MEMORY_KEY = "$playerhq_module_industrial_synchrotroncore";

	public static final float CREDIT_COST = 50000f;
	public static final float METALS_COST = 2000f;
	public static final float TRANSPLUTONICS_COST = 500f;
	public static final float VOLATILES_COST = 500f;
	public static final float HEAVY_MACHINERY_COST = 1000f;

	public static final float ORE_PER_METAL = 5f;
	public static final float RARE_ORE_PER_TRANSPLUTONIC = 5f;
	public static final float METALS_OUTPUT_PER_BATCH_BASE = 1f;
	public static final float TRANSPLUTONICS_OUTPUT_PER_BATCH_BASE = 1f;

	/**
	 * Catalytic Core: reduces the ore cost of refining metals and the rare ore cost of refining
	 * transplutonics, and boosts metals and transplutonics output per batch.
	 */
	public static final float CATALYTIC_CORE_ORE_REDUCTION = 2f;
	public static final float CATALYTIC_CORE_METAL_OUTPUT_BONUS = 2f;
	public static final float CATALYTIC_CORE_RARE_ORE_REDUCTION = 2f;
	public static final float CATALYTIC_CORE_TRANSPLUTONICS_OUTPUT_BONUS = 2f;

	/** Synchrotron Core: converts stored Volatiles into Fuel at this rate. */
	public static final float VOLATILES_PER_FUEL_BATCH = 1f;
	public static final float FUEL_PER_BATCH = 10f;

	public static final float HEAVY_MACHINERY_METALS_COST = 10f;
	public static final float HEAVY_MACHINERY_TRANSPLUTONICS_COST = 5f;
	public static final float HEAVY_MACHINERY_BATCH_OUTPUT = 10f;

	public static final float SUPPLIES_BATCH_ORGANICS_COST = 1f;
	public static final float SUPPLIES_BATCH_METALS_COST = 1f;
	public static final float SUPPLIES_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float SUPPLIES_BATCH_VOLATILES_COST = 1f;
	public static final float SUPPLIES_BATCH_FOOD_COST = 1f;
	public static final float SUPPLIES_BATCH_OUTPUT = 15f;

	public static final float HEAVY_ARMAMENTS_BATCH_METALS_COST = 10f;
	public static final float HEAVY_ARMAMENTS_BATCH_TRANSPLUTONICS_COST = 10f;
	public static final float HEAVY_ARMAMENTS_BATCH_VOLATILES_COST = 5f;
	public static final float HEAVY_ARMAMENTS_BATCH_OUTPUT = 10f;

	public static final float DRUGS_BATCH_ORGANICS_COST = 3f;
	public static final float DRUGS_BATCH_METALS_COST = 1f;
	public static final float DRUGS_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float DRUGS_BATCH_OUTPUT = 15f;

	public static final float ORGANS_BATCH_ORGANICS_COST = 10f;
	public static final float ORGANS_BATCH_OUTPUT = 5f;

	public static final float DOMESTIC_GOODS_BATCH_METALS_COST = 1f;
	public static final float DOMESTIC_GOODS_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float DOMESTIC_GOODS_BATCH_ORGANICS_COST = 1f;
	public static final float DOMESTIC_GOODS_BATCH_OUTPUT = 10f;

	public static final float LUXURY_GOODS_BATCH_METALS_COST = 2f;
	public static final float LUXURY_GOODS_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float LUXURY_GOODS_BATCH_ORGANICS_COST = 2f;
	public static final float LUXURY_GOODS_BATCH_DRUGS_COST = 1f;
	public static final float LUXURY_GOODS_BATCH_OUTPUT = 10f;

	public static final float MAX_STORED_RESOURCES = 10000f;

	/** Caps how much Ore/Rare Ore the Manufactorium can refine into Metals/Transplutonics in one month. */
	public static final float MAX_ORE_REFINED_PER_MONTH = 1000f;
	public static final float MAX_RARE_ORE_REFINED_PER_MONTH = 1000f;

	/** Caps how much of everything else the Manufactorium makes (Heavy Machinery, Supplies, and so on) in one month. */
	public static final float MAX_OUTPUT_PER_MONTH = 200f;

	public static final String IMAGE_PATH = "graphics/modules/industrial_hub.jpg";

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= VOLATILES_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, VOLATILES_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;

		CargoAPI cargo = playerFleet.getCargo();
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);

		if (hasNanoforgeInstalled(station)) {
			String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
			if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
		}
		if (hasBiofactoryInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.BIOFACTORY_EMBRYO, null), 1);
		}
		if (hasCatalyticCoreInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.CATALYTIC_CORE, null), 1);
		}
		if (hasSynchrotronCoreInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SYNCHROTRON, null), 1);
		}
	}

	public static boolean hasNanoforgeInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(NANOFORGE_MEMORY_KEY);
	}

	public static boolean hasNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CORRUPTED_NANOFORGE)
				|| PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	public static boolean hasCorruptedNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CORRUPTED_NANOFORGE);
	}

	public static boolean hasPristineNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	/** The player picks which tier to install -- unlike a straight availability auto-pick, this lets a Corrupted Nanoforge be chosen on purpose even when a Pristine one is also on hand. */
	public static void installCorruptedNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		installNanoforgeTier(station, playerFleet, Items.CORRUPTED_NANOFORGE);
	}

	public static void installPristineNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		installNanoforgeTier(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	private static void installNanoforgeTier(SectorEntityToken station, CampaignFleetAPI playerFleet, String itemId) {
		if (!PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, itemId)) return;

		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, itemId, 1);
		station.getMemoryWithoutUpdate().set(NANOFORGE_ITEM_KEY, itemId);
		station.getMemoryWithoutUpdate().set(NANOFORGE_MEMORY_KEY, true);
	}

	public static void uninstallNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasNanoforgeInstalled(station)) return;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
		PlayerHQUtils.addToStationInventory(station, itemId, 1);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_ITEM_KEY);
	}

	/** Null if no Nanoforge is installed. */
	public static String getInstalledNanoforgeId(SectorEntityToken station) {
		if (!hasNanoforgeInstalled(station)) return null;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		return itemId != null ? itemId : Items.CORRUPTED_NANOFORGE;
	}

	public static boolean isCorruptedNanoforgeInstalled(SectorEntityToken station) {
		return Items.CORRUPTED_NANOFORGE.equals(getInstalledNanoforgeId(station));
	}

	public static boolean isPristineNanoforgeInstalled(SectorEntityToken station) {
		return Items.PRISTINE_NANOFORGE.equals(getInstalledNanoforgeId(station));
	}

	/** A Corrupted Nanoforge doubles the resources the Domestic Goods/Luxury Goods/Heavy Armaments line needs for the same output; a Pristine one costs the normal amount. */
	public static final float CORRUPTED_NANOFORGE_RESOURCE_MULTIPLIER = 2f;

	private static float getNanoforgeResourceMultiplier(SectorEntityToken station) {
		return isCorruptedNanoforgeInstalled(station) ? CORRUPTED_NANOFORGE_RESOURCE_MULTIPLIER : 1f;
	}

	private static float[] scaled(float[] amounts, float multiplier) {
		if (multiplier == 1f) return amounts;
		float[] out = new float[amounts.length];
		for (int i = 0; i < amounts.length; i++) out[i] = amounts[i] * multiplier;
		return out;
	}

	public static boolean hasBiofactoryInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(BIOFACTORY_MEMORY_KEY);
	}

	public static boolean hasBiofactoryAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.BIOFACTORY_EMBRYO);
	}

	public static void installBiofactory(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.BIOFACTORY_EMBRYO, 1);
		station.getMemoryWithoutUpdate().set(BIOFACTORY_MEMORY_KEY, true);
	}

	public static void uninstallBiofactory(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasBiofactoryInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.BIOFACTORY_EMBRYO, 1);
		station.getMemoryWithoutUpdate().unset(BIOFACTORY_MEMORY_KEY);
	}

	public static boolean hasCatalyticCoreInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(CATALYTIC_CORE_MEMORY_KEY);
	}

	public static boolean hasCatalyticCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CATALYTIC_CORE);
	}

	public static void installCatalyticCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.CATALYTIC_CORE, 1);
		station.getMemoryWithoutUpdate().set(CATALYTIC_CORE_MEMORY_KEY, true);
	}

	public static void uninstallCatalyticCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasCatalyticCoreInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.CATALYTIC_CORE, 1);
		station.getMemoryWithoutUpdate().unset(CATALYTIC_CORE_MEMORY_KEY);
	}

	public static boolean hasSynchrotronCoreInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(SYNCHROTRON_CORE_MEMORY_KEY);
	}

	public static boolean hasSynchrotronCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.SYNCHROTRON);
	}

	public static void installSynchrotronCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.SYNCHROTRON, 1);
		station.getMemoryWithoutUpdate().set(SYNCHROTRON_CORE_MEMORY_KEY, true);
	}

	public static void uninstallSynchrotronCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSynchrotronCoreInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.SYNCHROTRON, 1);
		station.getMemoryWithoutUpdate().unset(SYNCHROTRON_CORE_MEMORY_KEY);
	}

	/** Dismantling requires every installed upgrade to be uninstalled first, same as the other modules. */
	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasNanoforgeInstalled(station) && !hasBiofactoryInstalled(station)
				&& !hasCatalyticCoreInstalled(station) && !hasSynchrotronCoreInstalled(station);
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet);
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	public static float getOrePerMetal(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station) ? ORE_PER_METAL - CATALYTIC_CORE_ORE_REDUCTION : ORE_PER_METAL;
	}

	public static float getRareOrePerTransplutonic(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station) ? RARE_ORE_PER_TRANSPLUTONIC - CATALYTIC_CORE_RARE_ORE_REDUCTION : RARE_ORE_PER_TRANSPLUTONIC;
	}

	public static float getMetalsOutputPerBatch(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station)
				? METALS_OUTPUT_PER_BATCH_BASE + CATALYTIC_CORE_METAL_OUTPUT_BONUS : METALS_OUTPUT_PER_BATCH_BASE;
	}

	public static float getTransplutonicsOutputPerBatch(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station)
				? TRANSPLUTONICS_OUTPUT_PER_BATCH_BASE + CATALYTIC_CORE_TRANSPLUTONICS_OUTPUT_BONUS : TRANSPLUTONICS_OUTPUT_PER_BATCH_BASE;
	}

	public static class IndustrialHubResult {
		public float metals;
		public float transplutonics;
		public float heavyMachinery;
		public float supplies;
		public float drugs;
		public float organs;
		public float domesticGoods;
		public float luxuryGoods;
		public float heavyArmaments;
		public float fuel;
	}

	/**
	 * @param maxBatchesThisRun a ceiling on how many batches this single call may process, on top of
	 * whatever the available inputs/output space would otherwise allow -- how {@link #MAX_ORE_REFINED_PER_MONTH}
	 * and {@link #MAX_OUTPUT_PER_MONTH} are enforced. Pass {@link Float#MAX_VALUE} for no extra cap.
	 */
	private static float convert(CargoAPI storage, String[] inputIds, float[] inputAmounts,
			String outputId, float outputAmount, float maxStorage, float maxBatchesThisRun) {
		float maxBatches = maxBatchesThisRun;
		for (int i = 0; i < inputIds.length; i++) {
			float available = storage.getCommodityQuantity(inputIds[i]);
			float batchesForInput = available / inputAmounts[i];
			if (batchesForInput < maxBatches) maxBatches = batchesForInput;
		}

		float space = maxStorage - storage.getCommodityQuantity(outputId);
		if (space <= 0f) return 0f;
		float batchesForOutput = space / outputAmount;
		if (batchesForOutput < maxBatches) maxBatches = batchesForOutput;

		float batches = (float) Math.floor(maxBatches);
		if (batches <= 0f) return 0f;

		for (int i = 0; i < inputIds.length; i++) {
			storage.removeCommodity(inputIds[i], batches * inputAmounts[i]);
		}
		storage.addCommodity(outputId, batches * outputAmount);
		return batches * outputAmount;
	}

	public static IndustrialHubResult process(SectorEntityToken station) {
		if (!isBuilt(station)) return new IndustrialHubResult();
		if (station.getMarket() == null) return new IndustrialHubResult();

		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
		return runConversions(storage, station);
	}

	/**
	 * A read-only preview of what {@link #process} would produce if the monthly tick ran right now --
	 * runs the exact same conversion chain, in the same order, but against a throwaway copy of the
	 * station's storage, so nothing is actually consumed or produced. Used for the "estimated next
	 * month" summary on the module's own detail screen. Since it's a preview of stock the player might
	 * still spend or add to before the tick actually runs, it's only ever an estimate.
	 */
	public static IndustrialHubResult previewMonthlyProduction(SectorEntityToken station) {
		if (!isBuilt(station)) return new IndustrialHubResult();
		if (station.getMarket() == null) return new IndustrialHubResult();

		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
		return runConversions(storage.createCopy(), station);
	}

	private static IndustrialHubResult runConversions(CargoAPI storage, SectorEntityToken station) {
		IndustrialHubResult result = new IndustrialHubResult();

		result.metals = convert(storage, new String[] { Commodities.ORE }, new float[] { getOrePerMetal(station) },
				Commodities.METALS, getMetalsOutputPerBatch(station), MAX_STORED_RESOURCES,
				MAX_ORE_REFINED_PER_MONTH / getOrePerMetal(station));
		result.transplutonics = convert(storage, new String[] { Commodities.RARE_ORE }, new float[] { getRareOrePerTransplutonic(station) },
				Commodities.RARE_METALS, getTransplutonicsOutputPerBatch(station), MAX_STORED_RESOURCES,
				MAX_RARE_ORE_REFINED_PER_MONTH / getRareOrePerTransplutonic(station));

		result.heavyMachinery = convert(storage,
				new String[] { Commodities.METALS, Commodities.RARE_METALS },
				new float[] { HEAVY_MACHINERY_METALS_COST, HEAVY_MACHINERY_TRANSPLUTONICS_COST },
				Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_BATCH_OUTPUT, MAX_STORED_RESOURCES,
				MAX_OUTPUT_PER_MONTH / HEAVY_MACHINERY_BATCH_OUTPUT);
		result.supplies = convert(storage,
				new String[] { Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES, Commodities.FOOD },
				new float[] { SUPPLIES_BATCH_ORGANICS_COST, SUPPLIES_BATCH_METALS_COST, SUPPLIES_BATCH_TRANSPLUTONICS_COST,
						SUPPLIES_BATCH_VOLATILES_COST, SUPPLIES_BATCH_FOOD_COST },
				Commodities.SUPPLIES, SUPPLIES_BATCH_OUTPUT, MAX_STORED_RESOURCES,
				MAX_OUTPUT_PER_MONTH / SUPPLIES_BATCH_OUTPUT);

		if (hasSynchrotronCoreInstalled(station)) {
			result.fuel = convert(storage, new String[] { Commodities.VOLATILES }, new float[] { VOLATILES_PER_FUEL_BATCH },
					Commodities.FUEL, FUEL_PER_BATCH, MAX_STORED_RESOURCES,
					MAX_OUTPUT_PER_MONTH / FUEL_PER_BATCH);
		}

		// Biofactory runs before the Nanoforge so freshly-produced drugs are available the
		// same month for the Nanoforge's Luxury Goods line, which consumes drugs as an input.
		if (hasBiofactoryInstalled(station)) {
			result.drugs = convert(storage,
					new String[] { Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS },
					new float[] { DRUGS_BATCH_ORGANICS_COST, DRUGS_BATCH_METALS_COST, DRUGS_BATCH_TRANSPLUTONICS_COST },
					Commodities.DRUGS, DRUGS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					MAX_OUTPUT_PER_MONTH / DRUGS_BATCH_OUTPUT);
			result.organs = convert(storage,
					new String[] { Commodities.ORGANICS }, new float[] { ORGANS_BATCH_ORGANICS_COST },
					Commodities.ORGANS, ORGANS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					MAX_OUTPUT_PER_MONTH / ORGANS_BATCH_OUTPUT);
		}

		if (hasNanoforgeInstalled(station)) {
			float nanoforgeMult = getNanoforgeResourceMultiplier(station);
			result.domesticGoods = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS },
					scaled(new float[] { DOMESTIC_GOODS_BATCH_METALS_COST, DOMESTIC_GOODS_BATCH_TRANSPLUTONICS_COST, DOMESTIC_GOODS_BATCH_ORGANICS_COST }, nanoforgeMult),
					Commodities.DOMESTIC_GOODS, DOMESTIC_GOODS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					MAX_OUTPUT_PER_MONTH / DOMESTIC_GOODS_BATCH_OUTPUT);
			result.luxuryGoods = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS, Commodities.DRUGS },
					scaled(new float[] { LUXURY_GOODS_BATCH_METALS_COST, LUXURY_GOODS_BATCH_TRANSPLUTONICS_COST,
							LUXURY_GOODS_BATCH_ORGANICS_COST, LUXURY_GOODS_BATCH_DRUGS_COST }, nanoforgeMult),
					Commodities.LUXURY_GOODS, LUXURY_GOODS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					MAX_OUTPUT_PER_MONTH / LUXURY_GOODS_BATCH_OUTPUT);
			result.heavyArmaments = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES },
					scaled(new float[] { HEAVY_ARMAMENTS_BATCH_METALS_COST, HEAVY_ARMAMENTS_BATCH_TRANSPLUTONICS_COST,
							HEAVY_ARMAMENTS_BATCH_VOLATILES_COST }, nanoforgeMult),
					Commodities.HAND_WEAPONS, HEAVY_ARMAMENTS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					MAX_OUTPUT_PER_MONTH / HEAVY_ARMAMENTS_BATCH_OUTPUT);
		}

		return result;
	}
}
