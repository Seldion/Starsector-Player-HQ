package playerhq.modules;

import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CoreUIAPI;
import com.fs.starfarer.api.campaign.SubmarketPlugin.TransferAction;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;

/**
 * Backs the Player HQ Market Place's own storage submarket, the Agora (see
 * {@code data/campaign/submarkets.csv}), opened through the same real vanilla trade screen as the
 * Exchange -- a free-transfer personal storage locker, restricted to weapons, fighter wings,
 * blueprints, and installable hull mods (see {@link MarketPlaceModule#isDepositable}), with no
 * tariff and no effect on the wider game economy. Items placed here aren't sold for credits by this
 * submarket itself -- that only ever happens through {@link MarketPlaceModule#collectMerchantIncome}'s
 * monthly sweep. This tab is the only way to move items in or out of that inventory.
 */
public class MarketPlaceStorageSubmarketPlugin extends BaseSubmarketPlugin {

	@Override
	public void init(SubmarketAPI submarket) {
		super.init(submarket);
	}

	@Override
	public String getName() {
		return "Agora";
	}

	/** Nothing to restock here -- this only ever holds what the player deposits themselves. */
	@Override
	public void updateCargoPrePlayerInteraction() {
	}

	/** Purely personal storage -- shouldn't nudge the wider game economy's supply/demand tracking. */
	@Override
	public boolean isParticipatesInEconomy() {
		return false;
	}

	/** No tariff -- it's the player's own station. */
	@Override
	public float getTariff() {
		return 0f;
	}

	/** Free to move items in and out, same as any personal storage. */
	@Override
	public boolean isFreeTransfer() {
		return true;
	}

	@Override
	public boolean isBlackMarket() {
		return false;
	}

	@Override
	public boolean isOpenMarket() {
		return false;
	}

	/** Always available, regardless of the trade mode the screen was opened in. */
	@Override
	public boolean isEnabled(CoreUIAPI ui) {
		return true;
	}

	/** Shows the running total value of everything currently stored here, in the tab's own tooltip/description. */
	@Override
	public String getTooltipAppendix(CoreUIAPI ui) {
		int total = (int) MarketPlaceModule.getTotalValue(getCargo());
		return "Total value of items stored: " + total + " credits.";
	}

	@Override
	public String getBuyVerb() {
		return "Take";
	}

	@Override
	public String getSellVerb() {
		return "Store";
	}

	/** Only weapons, fighter wings, blueprints, and installable hull mods can be stored here. */
	@Override
	public boolean isIllegalOnSubmarket(CargoStackAPI stack, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return !MarketPlaceModule.isDepositable(stack);
		}
		return false;
	}

	@Override
	public boolean isIllegalOnSubmarket(String commodityId, TransferAction action) {
		return false;
	}

	@Override
	public String getIllegalTransferText(CargoStackAPI stack, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "Only weapons, fighter wings, blueprints, and hull mods can be stored here";
		}
		return super.getIllegalTransferText(stack, action);
	}

	/** Ships belong in the station's own storage, not here. */
	@Override
	public boolean isIllegalOnSubmarket(FleetMemberAPI member, TransferAction action) {
		return action == TransferAction.PLAYER_SELL;
	}

	@Override
	public String getIllegalTransferText(FleetMemberAPI member, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "Ships can't be stored in the Agora";
		}
		return super.getIllegalTransferText(member, action);
	}
}
