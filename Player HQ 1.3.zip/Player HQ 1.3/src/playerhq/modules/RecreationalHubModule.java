package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class RecreationalHubModule {

	public static final String MEMORY_KEY = "$playerhq_module_recreation";
	public static final String HOLOSUITE_MEMORY_KEY = "$playerhq_module_recreation_holosuite";
	public static final String FUSION_LAMP_MEMORY_KEY = "$playerhq_module_recreation_fusionlamp";

	public static final float CREDIT_COST = 20000f;
	public static final float METALS_COST = 500f;
	public static final float TRANSPLUTONICS_COST = 50f;
	public static final float VOLATILES_COST = 20f;
	public static final float HEAVY_MACHINERY_COST = 200f;
	/** The Resort needs staffing -- unlike the resource costs above, Crew is drawn only from the station's own storage, never the fleet's. */
	public static final int CREW_COST = 500;

	// "Build Beach Resort" (the Orbital Fusion Lamp upgrade here) also costs organics on top of
	// consuming the Fusion Lamp item itself -- simulating actually landscaping a beach.
	public static final float BEACH_RESORT_ORGANICS_COST = 1000f;

	// Base income scales with colony size like demand for a limited-capacity venue: small
	// colonies barely use it, bigger colonies drive more demand, but growth tapers off in
	// the upper sizes so it never exceeds 100000 (a size 10+ colony caps out there).
	private static final float[] BASE_INCOME_BY_SIZE = {
			2000f, 6000f, 12000f, 20000f, 30000f, 42000f, 56000f, 70000f, 85000f, 100000f
	};

	public static final float HOLOSUITE_BONUS = 0.10f;
	public static final float FUSION_LAMP_BONUS = 0.10f;

	public static final String[] IMAGE_PATHS = {
			"graphics/modules/recreational_hub.jpg",
			"graphics/modules/recreational_hub_2.jpg",
			"graphics/modules/recreational_hub_3.jpg",
			"graphics/modules/recreational_hub_4.jpg",
			"graphics/modules/recreational_hub_5.jpg",
			"graphics/modules/recreational_hub_6.jpg",
			"graphics/modules/recreational_hub_7.jpg",
	};

	public static String getRandomImagePath() {
		int index = (int) (Math.random() * IMAGE_PATHS.length);
		if (index >= IMAGE_PATHS.length) index = IMAGE_PATHS.length - 1;
		return IMAGE_PATHS[index];
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean canBuild(SectorEntityToken station) {
		return ConstructPlayerHQAbility.isOrbitingColonizedPlanet(station);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= VOLATILES_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST
				&& PlayerHQUtils.getStationCrew(station) >= CREW_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, VOLATILES_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);
		// Crew is only ever drawn from the station's own storage, never the fleet's -- see getStationCrew().
		PlayerHQUtils.removeStationCrew(station, CREW_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!isBuilt(station)) return;

		CargoAPI cargo = playerFleet.getCargo();
		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);
		// Crew is refunded in full, not at the usual half rate -- the staff just walk off the station.
		cargo.addCrew(CREW_COST);

		if (hasHolosuiteInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
		}
		if (hasFusionLampInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null), 1);
			cargo.addCommodity(Commodities.ORGANICS, BEACH_RESORT_ORGANICS_COST * fraction);
		}
	}

	public static boolean hasHolosuiteInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasHolosuiteAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE);
	}

	public static void installHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().set(HOLOSUITE_MEMORY_KEY, true);
	}

	public static void uninstallHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasHolosuiteInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().unset(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasFusionLampInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(FUSION_LAMP_MEMORY_KEY);
	}

	public static boolean hasFusionLampInCargo(CargoAPI cargo) {
		return cargo.getQuantity(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null)) >= 1;
	}

	/** "Build Beach Resort" cost check: the Fusion Lamp item plus its organics cost. */
	public static boolean hasBeachResortCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.ORBITAL_FUSION_LAMP)
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ORGANICS) >= BEACH_RESORT_ORGANICS_COST;
	}

	public static void installFusionLamp(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.ORBITAL_FUSION_LAMP, 1);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.ORGANICS, BEACH_RESORT_ORGANICS_COST);
		station.getMemoryWithoutUpdate().set(FUSION_LAMP_MEMORY_KEY, true);
	}

	public static void uninstallFusionLamp(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasFusionLampInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.ORBITAL_FUSION_LAMP, 1);
		station.getMemoryWithoutUpdate().unset(FUSION_LAMP_MEMORY_KEY);
	}

	/** Dismantling requires every installed upgrade to be uninstalled first, same as the other modules. */
	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasHolosuiteInstalled(station) && !hasFusionLampInstalled(station);
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet);
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	private static int getColonySize(SectorEntityToken station) {
		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return 0;
		return market.getSize();
	}

	public static float getBaseIncome(SectorEntityToken station) {
		return getBaseIncomeForSize(getColonySize(station));
	}

	private static float getBaseIncomeForSize(int size) {
		if (size < 1) return 0f;
		int index = Math.min(size, BASE_INCOME_BY_SIZE.length) - 1;
		return BASE_INCOME_BY_SIZE[index];
	}

	/**
	 * Base income (no bonuses yet, since no station exists) for previewing what a Resort
	 * would earn if built in orbit of the given market.
	 */
	public static float getExpectedIncomeForMarket(MarketAPI market) {
		if (market == null) return 0f;
		return getBaseIncomeForSize(market.getSize());
	}

	public static float getIncomeMultiplier(SectorEntityToken station) {
		float mult = 1f;
		if (hasHolosuiteInstalled(station)) mult += HOLOSUITE_BONUS;
		if (hasFusionLampInstalled(station)) mult += FUSION_LAMP_BONUS;
		return mult;
	}

	public static float getFinalIncome(SectorEntityToken station) {
		float base = getBaseIncome(station);
		if (base <= 0f) return 0f;
		return base * getIncomeMultiplier(station) * StationItemsModule.getAccessibilityMultiplier(station);
	}

	public static float collectIncome(SectorEntityToken station) {
		if (!isBuilt(station)) return 0f;
		float income = getFinalIncome(station);
		if (income <= 0f) return 0f;

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return 0f;
		playerFleet.getCargo().getCredits().add(income);
		return income;
	}
}
