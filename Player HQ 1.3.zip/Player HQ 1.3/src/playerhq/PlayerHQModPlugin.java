package playerhq;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;

import java.util.List;

public class PlayerHQModPlugin extends BaseModPlugin {

	@Override
	public void onApplicationLoad() throws Exception {
		// Custom icons referenced by raw path (rather than a registered sprite id) need to be loaded
		// into the texture cache before anything tries to display them -- otherwise getSprite() on
		// that path quietly comes up empty and the icon just doesn't show.
		Global.getSettings().loadTexture(PlayerHQMonthlyReportIntel.ICON_PATH);
	}

	@Override
	public void onGameLoad(boolean newGame) {
		if (!Global.getSector().getListenerManager().hasListenerOfClass(PlayerHQIncomeReportListener.class)) {
			Global.getSector().getListenerManager().addListener(new PlayerHQIncomeReportListener(), true);
		}

		grantAbilityIfMissing(Ids.ABILITY_CONSTRUCT);
		grantAbilityIfMissing(Ids.ABILITY_CALL_RESUPPLY);
		PlayerHQItemDescriptions.apply();
	}

	/**
	 * "unlockedAtStart" in abilities.csv only grants an ability during new-game character
	 * creation, so a save that was already in progress when this mod was added (or when a new
	 * ability was added to it) never picks it up on its own. This runs on every load (new game
	 * or otherwise) and adds it if it's missing, so existing saves get the ability automatically
	 * instead of needing a console command.
	 */
	private void grantAbilityIfMissing(String abilityId) {
		MutableCharacterStatsAPI stats = Global.getSector().getPlayerStats();
		if (stats == null) return;

		List<String> granted = stats.getGrantedAbilityIds();
		if (!granted.contains(abilityId)) {
			granted.add(abilityId);
		}
	}
}
