package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.util.Misc;

import java.util.ArrayList;
import java.util.List;

public class PatrolCallEngine {

	public static final int PREP_DAYS = MilitaryWardModule.PATROL_FLEET_PERIODIC_RETURN_COOLDOWN_DAYS;
	public static final int ORBIT_DAYS = 1;
	public static final int ESCORT_DAYS = 30;
	public static final int FREIGHTERS_REQUIRED = 2;
	public static final int TANKERS_REQUIRED = 2;

	private static final float DURATION_CAP_DAYS = 999f;
	private static final float MEET_RANGE = 400f;
	private static final float ARRIVAL_RANGE = 300f;

	private static final String CALLED_KEY = "$playerhq_patrolcall_bays";
	private static final String STATE_KEY = "$playerhq_patrolcall_state";
	private static final String TIMER_KEY = "$playerhq_patrolcall_timer";
	private static final String ESCORT_KEY = "$playerhq_patrolcall_escort";
	private static final String LOGISTICS_KEY = "$playerhq_patrolcall_logistics";
	private static final String HOME_KEY = "$playerhq_patrolcall_home";
	private static final String ESCORT_DONE_KEY = "$playerhq_patrolcall_escortdone";
	private static final String LOGISTICS_DONE_KEY = "$playerhq_patrolcall_logisticsdone";
	private static final String REBUILD_KEY = "$playerhq_patrolcall_rebuild";
	private static final String LAST_COUNT_KEY = "$playerhq_patrolcall_lastcount";
	private static final String BATTLE_START_KEY = "$playerhq_patrolcall_battlestart";

	private static final String ST_GATHER = "gather";
	private static final String ST_PREP = "prep";
	private static final String ST_ORBIT = "orbit";
	private static final String ST_TRAVEL = "travel";
	private static final String ST_ESCORT = "escort";
	private static final String ST_RETURN = "return";

	@SuppressWarnings("unchecked")
	private static List<Integer> calledBays(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(CALLED_KEY);
		return (o instanceof List) ? (List<Integer>) o : null;
	}

	private static String state(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(STATE_KEY);
		return (o instanceof String) ? (String) o : null;
	}

	public static boolean isCallActive(SectorEntityToken station) {
		List<Integer> bays = calledBays(station);
		return bays != null && !bays.isEmpty();
	}

	public static boolean isBayCalled(SectorEntityToken station, int bayIndex) {
		List<Integer> bays = calledBays(station);
		return bays != null && bays.contains(Integer.valueOf(bayIndex));
	}

	public static boolean hasRequiredLogistics(SectorEntityToken station, int bayIndex) {
		return MilitaryWardModule.getPatrolFleetFreighterCount(station, bayIndex) >= FREIGHTERS_REQUIRED
				&& MilitaryWardModule.getPatrolFleetTankerCount(station, bayIndex) >= TANKERS_REQUIRED;
	}

	public static boolean canCall(SectorEntityToken station, int bayIndex) {
		return MilitaryWardModule.isPatrolFleetBayBuilt(station, bayIndex) && hasRequiredLogistics(station, bayIndex)
				&& !isBayCalled(station, bayIndex);
	}

	public static List<Integer> getEligibleBays(SectorEntityToken station) {
		List<Integer> result = new ArrayList<Integer>();
		if (isCallActive(station)) return result;
		for (int i = 0; i < MilitaryWardModule.MAX_PATROL_FLEET_BAYS; i++) {
			if (canCall(station, i)) result.add(i);
		}
		return result;
	}

	public static boolean call(SectorEntityToken station, List<Integer> bays) {
		if (station == null || bays == null || bays.isEmpty() || isCallActive(station)) return false;
		for (Integer b : bays) {
			if (b == null || !canCall(station, b)) return false;
		}
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(CALLED_KEY, new ArrayList<Integer>(bays));
		mem.set(STATE_KEY, ST_GATHER);
		mem.unset(TIMER_KEY);
		for (Integer b : bays) {
			mem.unset(MilitaryWardModule.bayKey(HOME_KEY, b));
			mem.unset(MilitaryWardModule.bayKey(ESCORT_DONE_KEY, b));
			mem.unset(MilitaryWardModule.bayKey(LOGISTICS_DONE_KEY, b));
			mem.set(MilitaryWardModule.bayKey(REBUILD_KEY, b), 0);
			MilitaryWardModule.beginPatrolCallReturn(station, b);
		}
		return true;
	}

	public static String statusText(SectorEntityToken station, int bayIndex) {
		if (!isBayCalled(station, bayIndex)) return null;
		String st = state(station);
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		if (ST_GATHER.equals(st)) {
			if (MilitaryWardModule.isPatrolFleetDeployed(station, bayIndex)) {
				return "heading back to the station to prepare for a long trip";
			}
			int days = Math.max(1, MilitaryWardModule.getPatrolFleetCooldownDaysLeft(station, bayIndex));
			return "getting fully operational before preparing for a long trip, ready in about " + days + " day"
					+ (days == 1 ? "" : "s");
		}
		if (ST_PREP.equals(st)) {
			int days = Math.max(1, mem.getInt(TIMER_KEY));
			return "Preping for long trip, ready in " + days + " day" + (days == 1 ? "" : "s");
		}
		if (ST_ORBIT.equals(st)) return "undocked and circling the station before heading out to you";
		if (ST_TRAVEL.equals(st)) {
			return mem.getBoolean(MilitaryWardModule.bayKey(HOME_KEY, bayIndex)) ? "heading back to the station"
					: "on its way to meet up with your fleet";
		}
		if (ST_ESCORT.equals(st)) {
			if (mem.getBoolean(MilitaryWardModule.bayKey(HOME_KEY, bayIndex))) return "heading back to the station";
			int days = Math.max(1, mem.getInt(TIMER_KEY));
			return "escorting your fleet, heads back to the station in " + days + " day" + (days == 1 ? "" : "s");
		}
		if (ST_RETURN.equals(st)) return "returning to the station";
		return null;
	}

	public static void onBayRemoved(SectorEntityToken station, int bayIndex) {
		if (!isBayCalled(station, bayIndex)) return;
		despawn(station, bayIndex);
		clearBay(station, bayIndex);
		List<Integer> bays = calledBays(station);
		if (bays != null) bays.remove(Integer.valueOf(bayIndex));
		if (bays == null || bays.isEmpty()) endCall(station);
	}

	private static void despawn(SectorEntityToken station, int bayIndex) {
		CampaignFleetAPI escort = fleet(station, ESCORT_KEY, bayIndex);
		CampaignFleetAPI logistics = fleet(station, LOGISTICS_KEY, bayIndex);
		if (escort != null && escort.isAlive()) escort.despawn();
		if (logistics != null && logistics.isAlive()) logistics.despawn();
	}

	private static void clearBay(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(MilitaryWardModule.bayKey(ESCORT_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(LOGISTICS_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(HOME_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(ESCORT_DONE_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(LOGISTICS_DONE_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(REBUILD_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(LAST_COUNT_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(BATTLE_START_KEY, bayIndex));
	}

	private static void endCall(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(CALLED_KEY);
		mem.unset(STATE_KEY);
		mem.unset(TIMER_KEY);
	}

	private static CampaignFleetAPI fleet(SectorEntityToken station, String key, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(MilitaryWardModule.bayKey(key, bayIndex));
	}

	private static boolean isGone(CampaignFleetAPI f) {
		return f == null || !f.isAlive() || f.getFleetData() == null || f.getFleetData().getMembersListCopy().isEmpty();
	}

	public static void advanceDaily(SectorEntityToken station) {
		List<Integer> bays = calledBays(station);
		if (bays == null) return;
		for (Integer b : new ArrayList<Integer>(bays)) {
			if (!MilitaryWardModule.isPatrolFleetBayBuilt(station, b)) {
				onBayRemoved(station, b);
			}
		}
		bays = calledBays(station);
		if (bays == null || bays.isEmpty()) {
			endCall(station);
			return;
		}

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		String st = state(station);
		if (st == null) {
			endCall(station);
			return;
		}

		if (ST_GATHER.equals(st)) {
			for (Integer b : bays) {
				if (!MilitaryWardModule.isPatrolBayDockedAndReady(station, b)) return;
			}
			mem.set(STATE_KEY, ST_PREP);
			mem.set(TIMER_KEY, PREP_DAYS);
			Global.getSector().getCampaignUI().addMessage(describe(bays) + (bays.size() == 1 ? " is" : " are")
					+ " fully operational and preparing for a long trip. Ready in " + PREP_DAYS + " days.");
			return;
		}

		if (ST_PREP.equals(st)) {
			int left = mem.getInt(TIMER_KEY) - 1;
			if (left > 0) {
				mem.set(TIMER_KEY, left);
				return;
			}
			if (!spawn(station, bays)) {
				for (Integer b : bays) clearBay(station, b);
				endCall(station);
				return;
			}
			mem.set(STATE_KEY, ST_ORBIT);
			mem.set(TIMER_KEY, ORBIT_DAYS);
			Global.getSector().getCampaignUI().addMessage(describe(bays) + " undocked and will head out to you after a day.");
			return;
		}

		topOff(station, bays);
		resolveLosses(station, bays);
		bays = calledBays(station);
		if (bays == null || bays.isEmpty()) {
			endCall(station);
			return;
		}

		if (ST_ORBIT.equals(st)) {
			int left = mem.getInt(TIMER_KEY) - 1;
			if (left > 0) {
				mem.set(TIMER_KEY, left);
				return;
			}
			mem.set(STATE_KEY, ST_TRAVEL);
			mem.unset(TIMER_KEY);
			Global.getSector().getCampaignUI().addMessage(describe(bays) + " heading out to meet up with you.");
			return;
		}

		if (ST_TRAVEL.equals(st)) {
			beginEscortIfMet(station, bays);
			return;
		}

		if (ST_ESCORT.equals(st)) {
			int left = mem.getInt(TIMER_KEY) - 1;
			if (left > 0) {
				mem.set(TIMER_KEY, left);
				return;
			}
			beginReturn(station, bays);
			return;
		}

		if (ST_RETURN.equals(st)) {
			checkArrivals(station, bays);
		}
	}

	public static void advanceRealtime(SectorEntityToken station) {
		List<Integer> bays = calledBays(station);
		if (bays == null) return;
		String st = state(station);
		if (!ST_TRAVEL.equals(st) && !ST_ESCORT.equals(st) && !ST_RETURN.equals(st)) return;
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (player == null) return;

		for (Integer b : bays) {
			boolean home = ST_RETURN.equals(st)
					|| station.getMemoryWithoutUpdate().getBoolean(MilitaryWardModule.bayKey(HOME_KEY, b));
			for (String key : new String[] { ESCORT_KEY, LOGISTICS_KEY }) {
				CampaignFleetAPI f = fleet(station, key, b);
				if (f == null || !f.isAlive()) continue;
				if (home) {
					ensureGoingHome(station, f);
				} else if (ST_TRAVEL.equals(st)) {
					MilitaryWardModule.rushTowardsPlayer(f, player, DURATION_CAP_DAYS);
				} else {
					keepWithPlayer(f, player);
				}
			}
		}
		for (Integer b : bays) watchForAttacks(station, b);
		if (ST_TRAVEL.equals(st)) beginEscortIfMet(station, bays);
		if (ST_RETURN.equals(st)) checkArrivals(station, bays);
	}

	private static int shipCount(CampaignFleetAPI f) {
		if (f == null || !f.isAlive() || f.getFleetData() == null) return 0;
		return f.getFleetData().getMembersListCopy().size();
	}

	private static void watchForAttacks(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		CampaignFleetAPI escort = fleet(station, ESCORT_KEY, bayIndex);
		CampaignFleetAPI logistics = fleet(station, LOGISTICS_KEY, bayIndex);
		boolean inBattle = (escort != null && escort.isAlive() && escort.getBattle() != null)
				|| (logistics != null && logistics.isAlive() && logistics.getBattle() != null);
		int count = shipCount(escort) + shipCount(logistics);
		String lastKey = MilitaryWardModule.bayKey(LAST_COUNT_KEY, bayIndex);
		String startKey = MilitaryWardModule.bayKey(BATTLE_START_KEY, bayIndex);
		boolean wasInBattle = mem.contains(startKey);

		if (inBattle && !wasInBattle) {
			mem.set(startKey, mem.contains(lastKey) ? mem.getInt(lastKey) : count);
			return;
		}
		if (!inBattle && wasInBattle) {
			int before = mem.getInt(startKey);
			mem.unset(startKey);
			boolean casualties = count < before;
			Global.getSector().getCampaignUI().addMessage("Patrol Fleet " + (bayIndex + 1) + " was attacked and suffered "
					+ (casualties ? "casualties." : "no casualties."),
					casualties ? Misc.getNegativeHighlightColor() : Misc.getTextColor());
		}
		if (!inBattle) mem.set(lastKey, count);
	}

	private static void beginEscortIfMet(SectorEntityToken station, List<Integer> bays) {
		if (!hasMetPlayer(station, bays)) return;
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(STATE_KEY, ST_ESCORT);
		mem.set(TIMER_KEY, ESCORT_DAYS);
		Global.getSector().getCampaignUI().addMessage(describe(bays) + " met up with your fleet and will escort you for "
				+ ESCORT_DAYS + " days.");
	}

	private static void keepWithPlayer(CampaignFleetAPI f, CampaignFleetAPI player) {
		if (f.getContainingLocation() != player.getContainingLocation()) {
			MilitaryWardModule.rushTowardsPlayer(f, player, DURATION_CAP_DAYS);
			return;
		}
		com.fs.starfarer.api.campaign.ai.FleetAssignmentDataAPI cur = f.getCurrentAssignment();
		if (cur == null || cur.getAssignment() != FleetAssignment.FOLLOW || cur.getTarget() != player) {
			f.clearAssignments();
			f.addAssignment(FleetAssignment.FOLLOW, player, DURATION_CAP_DAYS, "Escorting your fleet");
		}
	}

	private static void ensureGoingHome(SectorEntityToken station, CampaignFleetAPI f) {
		com.fs.starfarer.api.campaign.ai.FleetAssignmentDataAPI cur = f.getCurrentAssignment();
		if (cur == null || cur.getAssignment() != FleetAssignment.GO_TO_LOCATION || cur.getTarget() != station) {
			f.clearAssignments();
			f.addAssignment(FleetAssignment.GO_TO_LOCATION, station, DURATION_CAP_DAYS, "Returning to the station");
		}
	}

	private static boolean hasMetPlayer(SectorEntityToken station, List<Integer> bays) {
		CampaignFleetAPI player = Global.getSector().getPlayerFleet();
		if (player == null) return false;
		boolean any = false;
		for (Integer b : bays) {
			CampaignFleetAPI escort = fleet(station, ESCORT_KEY, b);
			if (escort == null || !escort.isAlive() || isGone(escort)) continue;
			any = true;
			if (escort.getContainingLocation() != player.getContainingLocation()) return false;
			if (Misc.getDistance(escort, player) > MEET_RANGE) return false;
		}
		return any;
	}

	private static String describe(List<Integer> bays) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < bays.size(); i++) {
			if (i > 0) sb.append(i == bays.size() - 1 ? " and " : ", ");
			sb.append("Patrol Fleet ").append(bays.get(i) + 1);
		}
		return sb.toString();
	}

	private static boolean spawn(SectorEntityToken station, List<Integer> bays) {
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return false;
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		for (Integer b : bays) {
			List<ShipVariantAPI> loadout = MilitaryWardModule.getPatrolFleetLoadout(station, b);
			List<ShipVariantAPI> logistics = MilitaryWardModule.getPatrolFleetLogistics(station, b);
			List<String> logisticNames = MilitaryWardModule.getPatrolFleetLogisticsNames(station, b);
			if (loadout == null || loadout.isEmpty() || logistics == null || logistics.isEmpty()) return false;

			CampaignFleetAPI escort = Global.getFactory().createEmptyFleet(Factions.PLAYER, "Patrol Fleet " + (b + 1), false);
			FleetMemberAPI flagship = null;
			for (ShipVariantAPI variant : loadout) {
				FleetMemberAPI member = MilitaryWardModule.buildFreshPatrolShip(variant);
				escort.getFleetData().addFleetMember(member);
				if (flagship == null || member.getHullSpec().getHullSize() == HullSize.CAPITAL_SHIP) flagship = member;
			}
			if (flagship != null) escort.getFleetData().setFlagship(flagship);
			MilitaryWardModule.injectFleetLogistics(escort, escort.getFleetData().getMembersListCopy(), true);
			escort.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_MAKE_AGGRESSIVE, true);
			system.addEntity(escort);
			MilitaryWardModule.refreshFleetCR(escort);
			escort.setLocation(station.getLocation().x, station.getLocation().y);
			escort.addAssignment(FleetAssignment.ORBIT_PASSIVE, station, DURATION_CAP_DAYS, "Preparing to depart");

			CampaignFleetAPI supply = Global.getFactory().createEmptyFleet(Factions.PLAYER, "Patrol Fleet " + (b + 1) + " Logistics", false);
			FleetMemberAPI first = null;
			for (int i = 0; i < logistics.size(); i++) {
				String name = (logisticNames != null && i < logisticNames.size()) ? logisticNames.get(i) : null;
				FleetMemberAPI member = MilitaryWardModule.buildReturnedPatrolShip(logistics.get(i), name);
				supply.getFleetData().addFleetMember(member);
				if (first == null) first = member;
			}
			if (first != null) supply.getFleetData().setFlagship(first);
			MilitaryWardModule.injectFleetLogistics(supply, supply.getFleetData().getMembersListCopy(), true);
			MilitaryWardModule.markAsNonInteractiveTraffic(supply, DURATION_CAP_DAYS * 2f);
			supply.getMemoryWithoutUpdate().set(MemFlags.DO_NOT_TRY_TO_AVOID_NEARBY_FLEETS, true);
			system.addEntity(supply);
			MilitaryWardModule.refreshFleetCR(supply);
			supply.setLocation(station.getLocation().x, station.getLocation().y);
			supply.addAssignment(FleetAssignment.ORBIT_PASSIVE, station, DURATION_CAP_DAYS, "Preparing to depart");

			mem.set(MilitaryWardModule.bayKey(ESCORT_KEY, b), escort);
			mem.set(MilitaryWardModule.bayKey(LOGISTICS_KEY, b), supply);
			mem.unset(MilitaryWardModule.bayKey(HOME_KEY, b));
			mem.unset(MilitaryWardModule.bayKey(ESCORT_DONE_KEY, b));
			mem.unset(MilitaryWardModule.bayKey(LOGISTICS_DONE_KEY, b));
			mem.set(MilitaryWardModule.bayKey(REBUILD_KEY, b), 0);
		}
		return true;
	}

	private static void topOff(SectorEntityToken station, List<Integer> bays) {
		for (Integer b : bays) {
			CampaignFleetAPI escort = fleet(station, ESCORT_KEY, b);
			CampaignFleetAPI logistics = fleet(station, LOGISTICS_KEY, b);
			if (escort != null && escort.isAlive()) MilitaryWardModule.topOffFleetSuppliesIfLow(escort, true);
			if (logistics != null && logistics.isAlive()) MilitaryWardModule.topOffFleetSuppliesIfLow(logistics, true);
		}
	}

	private static void resolveLosses(SectorEntityToken station, List<Integer> bays) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		for (Integer b : new ArrayList<Integer>(bays)) {
			if (!isBayCalled(station, b)) continue;
			String escortDone = MilitaryWardModule.bayKey(ESCORT_DONE_KEY, b);
			String logisticsDone = MilitaryWardModule.bayKey(LOGISTICS_DONE_KEY, b);
			CampaignFleetAPI escort = fleet(station, ESCORT_KEY, b);
			CampaignFleetAPI logistics = fleet(station, LOGISTICS_KEY, b);

			if (!mem.getBoolean(escortDone) && isGone(escort)) {
				if (escort != null && escort.isAlive()) escort.despawn();
				List<ShipVariantAPI> loadout = MilitaryWardModule.getPatrolFleetLoadout(station, b);
				addRebuild(mem, b, loadout != null
						? MilitaryWardModule.computeRebuildDaysForLosses(loadout, new ArrayList<FleetMemberAPI>()) : 0);
				mem.set(escortDone, true);
				Global.getSector().getCampaignUI().addMessage("Patrol Fleet " + (b + 1)
						+ " lost all of its combat ships. Its freighters and tankers are heading back to the station.",
						Misc.getNegativeHighlightColor());
				mem.set(MilitaryWardModule.bayKey(HOME_KEY, b), true);
			}
			if (!mem.getBoolean(logisticsDone) && isGone(logistics)) {
				if (logistics != null && logistics.isAlive()) logistics.despawn();
				List<ShipVariantAPI> full = MilitaryWardModule.getPatrolFleetLogistics(station, b);
				addRebuild(mem, b, full != null
						? MilitaryWardModule.computeRebuildDaysForLosses(full, new ArrayList<FleetMemberAPI>()) : 0);
				mem.set(logisticsDone, true);
			}
			if (mem.getBoolean(escortDone) && mem.getBoolean(logisticsDone)) finalizeBay(station, b);
		}
		List<Integer> remaining = calledBays(station);
		if (remaining == null || remaining.isEmpty()) endCall(station);
	}

	private static void addRebuild(MemoryAPI mem, int bayIndex, int days) {
		String key = MilitaryWardModule.bayKey(REBUILD_KEY, bayIndex);
		mem.set(key, mem.getInt(key) + Math.max(0, days));
	}

	private static void beginReturn(SectorEntityToken station, List<Integer> bays) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(STATE_KEY, ST_RETURN);
		mem.unset(TIMER_KEY);
		for (Integer b : bays) {
			CampaignFleetAPI escort = fleet(station, ESCORT_KEY, b);
			CampaignFleetAPI logistics = fleet(station, LOGISTICS_KEY, b);
			if (escort != null && escort.isAlive()) ensureGoingHome(station, escort);
			if (logistics != null && logistics.isAlive()) ensureGoingHome(station, logistics);
		}
		Global.getSector().getCampaignUI().addMessage(describe(bays) + " finished escorting you and " + (bays.size() == 1 ? "is" : "are")
				+ " heading back to the station.");
	}

	private static boolean arrived(CampaignFleetAPI f, SectorEntityToken station) {
		return f.getContainingLocation() == station.getContainingLocation()
				&& Misc.getDistance(f, station) <= ARRIVAL_RANGE + station.getRadius();
	}

	private static void checkArrivals(SectorEntityToken station, List<Integer> bays) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		for (Integer b : new ArrayList<Integer>(bays)) {
			if (!isBayCalled(station, b)) continue;
			CampaignFleetAPI escort = fleet(station, ESCORT_KEY, b);
			CampaignFleetAPI logistics = fleet(station, LOGISTICS_KEY, b);
			String escortDone = MilitaryWardModule.bayKey(ESCORT_DONE_KEY, b);
			String logisticsDone = MilitaryWardModule.bayKey(LOGISTICS_DONE_KEY, b);

			if (!mem.getBoolean(escortDone) && escort != null && escort.isAlive() && !isGone(escort)
					&& escort.getBattle() == null && arrived(escort, station)) {
				List<ShipVariantAPI> loadout = MilitaryWardModule.getPatrolFleetLoadout(station, b);
				List<FleetMemberAPI> survivors = escort.getFleetData().getMembersListCopy();
				addRebuild(mem, b, loadout != null ? MilitaryWardModule.computeRebuildDaysForLosses(loadout, survivors) : 0);
				escort.despawn();
				mem.set(escortDone, true);
			}
			if (!mem.getBoolean(logisticsDone) && logistics != null && logistics.isAlive() && !isGone(logistics)
					&& logistics.getBattle() == null && arrived(logistics, station)) {
				List<ShipVariantAPI> full = MilitaryWardModule.getPatrolFleetLogistics(station, b);
				List<FleetMemberAPI> survivors = logistics.getFleetData().getMembersListCopy();
				addRebuild(mem, b, full != null ? MilitaryWardModule.computeRebuildDaysForLosses(full, survivors) : 0);
				logistics.despawn();
				mem.set(logisticsDone, true);
			}
		}
		resolveLosses(station, bays);
	}

	private static void finalizeBay(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		int rebuild = mem.getInt(MilitaryWardModule.bayKey(REBUILD_KEY, bayIndex));
		int cooldown = rebuild + MilitaryWardModule.PATROL_FLEET_PERIODIC_RETURN_COOLDOWN_DAYS;
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex), cooldown);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.PATROL_FLEET_PERIODIC_RETURN_MEMORY_KEY, bayIndex), true);
		mem.unset(MilitaryWardModule.bayKey(MilitaryWardModule.PATROL_FLEET_WIPED_MEMORY_KEY, bayIndex));
		clearBay(station, bayIndex);
		List<Integer> bays = calledBays(station);
		if (bays != null) bays.remove(Integer.valueOf(bayIndex));
		Global.getSector().getCampaignUI().addMessage("Patrol Fleet " + (bayIndex + 1)
				+ " is back at the station and starting its maintenance. It redeploys in " + cooldown + " days.");
	}
}
