package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;

import playerhq.charter.CharterItem;
import playerhq.charter.CourierCharterData;
import playerhq.charter.CourierCharterState;
import playerhq.charter.CourierRequest;
import playerhq.util.PlayerHQUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CourierCharterEngine {

	public static final String STATE_PICKUP = "charter_pickup";
	public static final String STATE_DELIVER = "charter_deliver";

	private static final String ID_KEY = "$playerhq_charter_run_id";
	private static final String PLAN_KEY = "$playerhq_charter_run_plan";
	private static final String NEEDS_KEY = "$playerhq_charter_run_needs";
	private static final String SHIPS_KEY = "$playerhq_charter_run_ships";
	private static final String LOADED_KEY = "$playerhq_charter_run_loaded";
	private static final String DEST_KEY = "$playerhq_charter_run_dest";
	private static final String WAIT_KEY = "$playerhq_charter_run_wait";

	public static final float LOAD_DAYS = 1f;
	public static final float UNLOAD_DAYS = 1f;

	public static boolean isCharterState(String state) {
		return STATE_PICKUP.equals(state) || STATE_DELIVER.equals(state);
	}

	public static boolean isCharterRun(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().contains(MilitaryWardModule.bayKey(ID_KEY, bayIndex));
	}

	public static String statusText(SectorEntityToken station, int bayIndex, String state) {
		SectorEntityToken target = MilitaryWardModule.getCourierTargetEntity(station, bayIndex);
		String name = target != null ? target.getName() : "its next stop";
		Long started = waitStart(station, bayIndex);
		if (started != null) {
			boolean loading = STATE_PICKUP.equals(state);
			float left = (loading ? LOAD_DAYS : UNLOAD_DAYS) - Global.getSector().getClock().getElapsedDaysSince(started);
			int days = Math.max(1, (int) Math.ceil(left));
			return (loading ? "loading cargo at " : "unloading cargo at ") + name + ", done in " + days + (days == 1 ? " day" : " days");
		}
		if (STATE_PICKUP.equals(state)) return "heading to " + name + " to collect cargo";
		return "heading to " + name + " to deliver goods";
	}

	private static Long waitStart(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(MilitaryWardModule.bayKey(WAIT_KEY, bayIndex));
		return (o instanceof Long) ? (Long) o : null;
	}

	private static void clearWait(SectorEntityToken station, int bayIndex) {
		station.getMemoryWithoutUpdate().unset(MilitaryWardModule.bayKey(WAIT_KEY, bayIndex));
	}

	private static void beginWait(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, SectorEntityToken target, String label) {
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.ORBIT_PASSIVE, target, 4f, label + target.getName());
		station.getMemoryWithoutUpdate().set(MilitaryWardModule.bayKey(WAIT_KEY, bayIndex), Long.valueOf(Global.getSector().getClock().getTimestamp()));
	}

	private static boolean waitFinished(SectorEntityToken station, int bayIndex, float days) {
		Long started = waitStart(station, bayIndex);
		return started != null && Global.getSector().getClock().getElapsedDaysSince(started) >= days;
	}

	private static boolean isHq(SectorEntityToken station, SectorEntityToken target) {
		if (target == null) return false;
		if (target == station) return true;
		return target.getMarket() != null && station.getMarket() != null && target.getMarket() == station.getMarket();
	}

	public static void advanceDaily(SectorEntityToken station) {
		dispatchAvailable(station);
	}

	public static void dispatchAvailable(SectorEntityToken station) {
		CourierCharterState state = CourierCharterData.getState();
		for (CourierRequest r : new ArrayList<CourierRequest>(state.requests)) {
			if (r.inTransit) continue;
			if (r.suspended) {
				r.status = "Suspended";
				continue;
			}
			MarketAPI source = CourierCharterData.getMarket(r.sourceMarketId);
			MarketAPI dest = CourierCharterData.getMarket(r.destMarketId);
			if (r.sourceMarketId == null) {
				r.status = "Choose a pickup location";
				continue;
			}
			if (!CourierCharterData.isUsableMarket(source, station) || !CourierCharterData.isUsableMarket(dest, station)) {
				r.status = "Location is not available";
				continue;
			}
			if (!r.hasAnything()) {
				r.status = "No items chosen yet";
				continue;
			}
			List<CharterItem> movable = computeMovable(r, dest, source);
			if (movable.isEmpty()) {
				r.status = "Nothing to move right now";
				continue;
			}
			int bay = MilitaryWardModule.findIdleCourierBayIndex(station);
			if (bay < 0) {
				r.status = "Waiting for a free Courier Fleet";
				continue;
			}
			if (!launch(station, r, bay, dest, source, movable)) {
				r.status = "Could not launch a Courier Fleet";
			}
		}
	}

	private static String key(String type, String id, String data) {
		return type + "|" + id + "|" + (data == null ? "" : data);
	}

	private static List<CharterItem> computeMovable(CourierRequest r, MarketAPI dest, MarketAPI source) {
		List<CharterItem> movable = new ArrayList<CharterItem>();
		SubmarketAPI sourceSub = MilitaryWardModule.getCourierTargetStorage(source);
		if (sourceSub == null || sourceSub.getCargo() == null) return movable;
		CargoAPI sourceCargo = sourceSub.getCargo();
		SubmarketAPI destSub = MilitaryWardModule.getCourierTargetStorage(dest);
		CargoAPI destCargo = destSub != null ? destSub.getCargo() : null;
		List<String> seen = new ArrayList<String>();

		for (CharterItem item : r.items) {
			if (item == null || item.amount <= 0) continue;
			seen.add(key(item.type, item.id, item.data));
			int need = item.amount;
			if (destCargo != null) need = Math.max(0, item.amount - (int) countIn(destCargo, item));
			if (need <= 0) continue;
			int available = (int) Math.floor(countIn(sourceCargo, item));
			int take = Math.min(need, available);
			if (take <= 0) continue;
			CharterItem copy = item.copy();
			copy.amount = take;
			movable.add(copy);
		}

		if (r.allWeapons || r.allWings || r.allSpecials) {
			List<CharterItem> all = new ArrayList<CharterItem>();
			for (CargoStackAPI stack : sourceCargo.getStacksCopy()) {
				if (stack == null || stack.isNull()) continue;
				CargoAPI.CargoItemType type = stack.getType();
				boolean take = (r.allWeapons && type == CargoAPI.CargoItemType.WEAPONS)
						|| (r.allWings && type == CargoAPI.CargoItemType.FIGHTER_CHIP)
						|| (r.allSpecials && type == CargoAPI.CargoItemType.SPECIAL);
				if (!take) continue;
				int amount = (int) stack.getSize();
				if (amount <= 0) continue;
				String id;
				String data = null;
				if (type == CargoAPI.CargoItemType.SPECIAL) {
					SpecialItemData sd = stack.getSpecialDataIfSpecial();
					if (sd == null) continue;
					id = sd.getId();
					data = sd.getData();
				} else {
					if (stack.getData() == null) continue;
					id = String.valueOf(stack.getData());
				}
				String k = key(type.name(), id, data);
				if (seen.contains(k)) continue;
				CharterItem existing = null;
				for (CharterItem a : all) {
					if (key(a.type, a.id, a.data).equals(k)) {
						existing = a;
						break;
					}
				}
				if (existing != null) existing.amount += amount;
				else all.add(new CharterItem(type.name(), id, data, stack.getDisplayName(), amount));
			}
			movable.addAll(all);
		}
		return movable;
	}

	private static Object dataFor(CargoAPI cargo, CharterItem item) {
		if (!CargoAPI.CargoItemType.SPECIAL.name().equals(item.type)) return item.cargoData();
		for (CargoStackAPI stack : cargo.getStacksCopy()) {
			if (stack == null || stack.isNull() || !stack.isSpecialStack()) continue;
			SpecialItemData sd = stack.getSpecialDataIfSpecial();
			if (sd == null || !item.id.equals(sd.getId())) continue;
			if (item.data == null ? sd.getData() == null : item.data.equals(sd.getData())) return sd;
		}
		return item.cargoData();
	}

	private static float countIn(CargoAPI cargo, CharterItem item) {
		if (cargo == null || item == null) return 0f;
		if (item.isShip()) {
			int n = 0;
			if (cargo.getMothballedShips() != null) {
				for (FleetMemberAPI m : cargo.getMothballedShips().getMembersListCopy()) {
					if (item.id.equals(m.getHullId())) n++;
				}
			}
			return n;
		}
		CargoAPI.CargoItemType type = item.cargoType();
		if (type == null) return 0f;
		if (type == CargoAPI.CargoItemType.SPECIAL) {
			float n = 0f;
			for (CargoStackAPI stack : cargo.getStacksCopy()) {
				if (stack == null || stack.isNull() || !stack.isSpecialStack()) continue;
				SpecialItemData sd = stack.getSpecialDataIfSpecial();
				if (sd == null || !item.id.equals(sd.getId())) continue;
				if (item.data == null ? sd.getData() == null : item.data.equals(sd.getData())) n += stack.getSize();
			}
			return n;
		}
		try {
			return cargo.getQuantity(type, item.cargoData());
		} catch (Throwable t) {
			return 0f;
		}
	}

	private static boolean launch(SectorEntityToken station, CourierRequest r, int bayIndex, MarketAPI dest, MarketAPI source,
			List<CharterItem> needs) {
		List<FleetMemberAPI> ships = MilitaryWardModule.getCourierBayCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return false;
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return false;

		MilitaryWardModule.outfitFleetShips(station, ships, false);

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER, "Courier Fleet " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		MilitaryWardModule.markAsNonInteractiveTraffic(fleet, MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		try {
			fleet.getFleetData().setSyncNeeded();
			fleet.getFleetData().syncIfNeeded();
			fleet.getCargo().updateSpaceUsed();
		} catch (Throwable t) {
		}
		MilitaryWardModule.injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		MilitaryWardModule.refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);

		SectorEntityToken first = source.getPrimaryEntity();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, first, MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				"Collecting cargo at " + first.getName());

		List<String> planIds = new ArrayList<String>();
		planIds.add(source.getId());

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_HOLD_MEMORY_KEY, bayIndex), Global.getFactory().createCargo(true));
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex), first);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_SUPPLIES_TO_DELIVER_MEMORY_KEY, bayIndex), 0f);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_TOURING_MEMORY_KEY, bayIndex), true);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_STATE_MEMORY_KEY, bayIndex), STATE_PICKUP);
		mem.set(MilitaryWardModule.bayKey(ID_KEY, bayIndex), r.id);
		mem.set(MilitaryWardModule.bayKey(PLAN_KEY, bayIndex), planIds);
		mem.set(MilitaryWardModule.bayKey(NEEDS_KEY, bayIndex), needs);
		mem.set(MilitaryWardModule.bayKey(SHIPS_KEY, bayIndex), new ArrayList<FleetMemberAPI>());
		mem.set(MilitaryWardModule.bayKey(LOADED_KEY, bayIndex), Global.getFactory().createCargo(true));
		mem.set(MilitaryWardModule.bayKey(DEST_KEY, bayIndex), dest.getId());

		r.inTransit = true;
		r.status = "Courier Fleet " + (bayIndex + 1) + " dispatched";
		return true;
	}

	@SuppressWarnings("unchecked")
	private static <T> T get(SectorEntityToken station, String key, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(MilitaryWardModule.bayKey(key, bayIndex));
		return (T) o;
	}

	public static void advanceRealtime(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, String state) {
		SectorEntityToken target = MilitaryWardModule.getCourierTargetEntity(station, bayIndex);

		if (STATE_PICKUP.equals(state)) {
			if (target == null) {
				List<String> plan = get(station, PLAN_KEY, bayIndex);
				if (plan != null && !plan.isEmpty()) plan.remove(0);
				routeToNextStop(station, bayIndex, fleet);
				return;
			}
			if (waitStart(station, bayIndex) != null) {
				if (!waitFinished(station, bayIndex, LOAD_DAYS)) return;
				clearWait(station, bayIndex);
				loadAt(station, bayIndex, fleet, target.getMarket());
				List<String> donePlan = get(station, PLAN_KEY, bayIndex);
				if (donePlan != null && !donePlan.isEmpty()) donePlan.remove(0);
				routeToNextStop(station, bayIndex, fleet);
				return;
			}
			if (!MilitaryWardModule.courierHasArrived(fleet, target, MilitaryWardModule.COURIER_FLEET_ARRIVAL_RANGE,
					MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS)) return;
			if (!isHq(station, target)) {
				beginWait(station, bayIndex, fleet, target, "Loading cargo at ");
				return;
			}
			loadAt(station, bayIndex, fleet, target.getMarket());
			List<String> plan = get(station, PLAN_KEY, bayIndex);
			if (plan != null && !plan.isEmpty()) plan.remove(0);
			routeToNextStop(station, bayIndex, fleet);
			return;
		}

		if (STATE_DELIVER.equals(state)) {
			if (target == null) {
				startReturn(station, bayIndex, fleet);
				return;
			}
			if (waitStart(station, bayIndex) != null) {
				if (!waitFinished(station, bayIndex, UNLOAD_DAYS)) return;
				clearWait(station, bayIndex);
				deliver(station, bayIndex, fleet, target.getMarket());
				startReturn(station, bayIndex, fleet);
				dispatchAvailable(station);
				return;
			}
			if (!MilitaryWardModule.courierHasArrived(fleet, target, MilitaryWardModule.COURIER_FLEET_ARRIVAL_RANGE,
					MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS)) return;
			if (!isHq(station, target)) {
				beginWait(station, bayIndex, fleet, target, "Unloading cargo at ");
				return;
			}
			deliver(station, bayIndex, fleet, target.getMarket());
			startReturn(station, bayIndex, fleet);
			dispatchAvailable(station);
		}
	}

	private static void routeToNextStop(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		List<String> plan = get(station, PLAN_KEY, bayIndex);
		SectorEntityToken next = null;
		while (plan != null && !plan.isEmpty()) {
			MarketAPI m = CourierCharterData.getMarket(plan.get(0));
			if (m != null && m.getPrimaryEntity() != null) {
				next = m.getPrimaryEntity();
				break;
			}
			plan.remove(0);
		}
		String state = STATE_PICKUP;
		String label = "Collecting cargo at ";
		if (next == null) {
			String destId = get(station, DEST_KEY, bayIndex);
			MarketAPI dest = CourierCharterData.getMarket(destId);
			if (dest == null || dest.getPrimaryEntity() == null) {
				startReturn(station, bayIndex, fleet);
				return;
			}
			next = dest.getPrimaryEntity();
			state = STATE_DELIVER;
			label = "Delivering cargo to ";
		}
		clearWait(station, bayIndex);
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, next, MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				label + next.getName());
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex), next);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_STATE_MEMORY_KEY, bayIndex), state);
	}

	private static void startReturn(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		clearWait(station, bayIndex);
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				"Returning to the station");
		station.getMemoryWithoutUpdate().set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_STATE_MEMORY_KEY, bayIndex),
				MilitaryWardModule.COURIER_FLEET_STATE_RETURNING);
	}

	private static void loadAt(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, MarketAPI market) {
		if (market == null) return;
		SubmarketAPI sub = MilitaryWardModule.getCourierTargetStorage(market);
		if (sub == null || sub.getCargo() == null) return;
		CargoAPI source = sub.getCargo();
		List<CharterItem> needs = get(station, NEEDS_KEY, bayIndex);
		CargoAPI loaded = get(station, LOADED_KEY, bayIndex);
		List<FleetMemberAPI> carried = get(station, SHIPS_KEY, bayIndex);
		if (needs == null || loaded == null) return;

		CargoAPI fleetCargo = MilitaryWardModule.getCourierFleetHold(station, bayIndex);
		float spaceLeft = Math.max(0f, MilitaryWardModule.getFleetBaseCargoCapacity(fleet) - fleetCargo.getSpaceUsed());
		int personnelLeft = (int) Math.max(0f, fleet.getCargo().getMaxPersonnel() - fleetCargo.getTotalPersonnel());
		float fuelRoom = Math.max(0f, MilitaryWardModule.getFleetBaseFuelCapacity(fleet) - fleetCargo.getFuel());
		for (CharterItem item : needs) {
			if (item == null || item.amount <= 0) continue;

			if (item.isShip()) {
				if (carried == null || source.getMothballedShips() == null) continue;
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(source.getMothballedShips().getMembersListCopy())) {
					if (item.amount <= 0) break;
					if (!item.id.equals(m.getHullId())) continue;
					source.getMothballedShips().removeFleetMember(m);
					carried.add(m);
					item.amount--;
				}
				continue;
			}

			CargoAPI.CargoItemType type = item.cargoType();
			if (type == null) continue;
			Object data = dataFor(source, item);
			float avail = countIn(source, item);
			float want = Math.min(item.amount, (float) Math.floor(avail));
			if (want <= 0f) continue;

			CargoAPI probe = Global.getFactory().createCargo(true);
			probe.addItems(type, data, 1f);
			List<CargoStackAPI> probeStacks = probe.getStacksCopy();
			if (probeStacks.isEmpty()) continue;
			CargoStackAPI ps = probeStacks.get(0);

			float units;
			if (ps.isFuelStack()) {
				units = Math.min(want, fuelRoom);
				fuelRoom -= (float) Math.floor(units);
			} else if (ps.isPersonnelStack()) {
				units = Math.min(want, personnelLeft);
				personnelLeft -= (int) Math.floor(units);
			} else {
				float perUnit = ps.getCargoSpacePerUnit();
				units = perUnit > 0f ? Math.min(want, (float) Math.floor(spaceLeft / perUnit)) : want;
				spaceLeft -= units * Math.max(0f, perUnit);
			}
			units = (float) Math.floor(units);
			if (units <= 0f) continue;

			source.removeItems(type, data, units);
			fleetCargo.addItems(type, data, units);
			loaded.addItems(type, data, units);
			item.amount -= (int) units;
		}
	}

	private static void deliver(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, MarketAPI dest) {
		if (dest == null) return;
		SubmarketAPI sub = MilitaryWardModule.getCourierTargetStorage(dest);
		if (sub == null || sub.getCargo() == null) return;
		CargoAPI destCargo = sub.getCargo();
		CargoAPI loaded = get(station, LOADED_KEY, bayIndex);
		List<FleetMemberAPI> carried = get(station, SHIPS_KEY, bayIndex);
		Integer requestId = get(station, ID_KEY, bayIndex);

		StringBuilder summary = new StringBuilder();
		int kinds = 0;
		if (loaded != null) {
			CargoAPI fleetCargo = MilitaryWardModule.getCourierFleetHold(station, bayIndex);
			for (CargoStackAPI stack : new ArrayList<CargoStackAPI>(loaded.getStacksCopy())) {
				if (stack == null || stack.isNull()) continue;
				float inFleet = fleetCargo.getQuantity(stack.getType(), stack.getData());
				float units = Math.min(stack.getSize(), inFleet);
				if (units <= 0f) continue;
				fleetCargo.removeItems(stack.getType(), stack.getData(), units);
				destCargo.addItems(stack.getType(), stack.getData(), units);
				kinds++;
				if (kinds <= 6) {
					if (summary.length() > 0) summary.append(", ");
					summary.append((int) units).append(" ").append(stack.getDisplayName());
				}
			}
			loaded.clear();
		}
		if (carried != null && !carried.isEmpty()) {
			destCargo.initMothballedShips(Factions.PLAYER);
			if (destCargo.getMothballedShips() != null) {
				for (FleetMemberAPI m : carried) {
					destCargo.getMothballedShips().addFleetMember(m);
					kinds++;
					if (kinds <= 6) {
						if (summary.length() > 0) summary.append(", ");
						summary.append("1 ").append(m.getHullSpec().getHullName());
					}
				}
				carried.clear();
			}
		}
		if (kinds > 6) summary.append(" and more");

		CourierRequest r = requestId != null ? CourierCharterData.findRequest(requestId) : null;
		if (r != null) {
			r.runs++;
			r.inTransit = false;
			r.status = "Delivered, checking again when a Courier Fleet is free";
		}
		station.getMemoryWithoutUpdate().unset(MilitaryWardModule.bayKey(ID_KEY, bayIndex));
		if (summary.length() > 0) {
			Global.getSector().getCampaignUI().addMessage("Courier Fleet " + (bayIndex + 1) + " delivered to "
					+ dest.getName() + ": " + summary);
		}
	}

	public static void onRunEnded(SectorEntityToken station, int bayIndex, boolean keepShips) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		if (!mem.contains(MilitaryWardModule.bayKey(ID_KEY, bayIndex))
				&& !mem.contains(MilitaryWardModule.bayKey(SHIPS_KEY, bayIndex))) return;

		Integer requestId = get(station, ID_KEY, bayIndex);
		List<FleetMemberAPI> carried = get(station, SHIPS_KEY, bayIndex);
		if (keepShips && carried != null && !carried.isEmpty()) {
			CargoAPI hq = PlayerHQUtils.getStationStorageCargo(station);
			if (hq != null) {
				hq.initMothballedShips(Factions.PLAYER);
				if (hq.getMothballedShips() != null) {
					for (FleetMemberAPI m : carried) hq.getMothballedShips().addFleetMember(m);
				}
			}
		}
		if (requestId != null) {
			CourierRequest r = CourierCharterData.findRequest(requestId);
			if (r != null && r.inTransit) {
				r.inTransit = false;
				r.status = keepShips ? "Courier Fleet recalled" : "Courier Fleet was lost";
			}
		}
		mem.unset(MilitaryWardModule.bayKey(ID_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(PLAN_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(NEEDS_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(SHIPS_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(LOADED_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(DEST_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(WAIT_KEY, bayIndex));
	}
}
