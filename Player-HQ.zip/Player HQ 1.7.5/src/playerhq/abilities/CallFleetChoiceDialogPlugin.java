package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.PatrolCallEngine;
import playerhq.modules.PersonalCourierEngine;

import java.util.Map;

public class CallFleetChoiceDialogPlugin implements InteractionDialogPlugin {

	private static final String OPTION_RESUPPLY = "playerhq_call_fleet_resupply";
	private static final String OPTION_COURIER = "playerhq_call_fleet_courier";
	private static final String OPTION_PERSONAL = "playerhq_call_fleet_personal_courier";
	private static final String OPTION_CANCEL = "playerhq_call_fleet_cancel";
	private static final String OPTION_PATROL = "playerhq_call_fleet_patrol";
	private static final String OPTION_PATROL_BAY_PREFIX = "playerhq_call_fleet_patrol_bay_";
	private static final String OPTION_PATROL_BOTH = "playerhq_call_fleet_patrol_both";
	private static final String OPTION_PATROL_BACK = "playerhq_call_fleet_patrol_back";

	private final SectorEntityToken station;

	private InteractionDialogAPI dialog;

	public CallFleetChoiceDialogPlugin(SectorEntityToken station) {
		this.station = station;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		TextPanelAPI text = dialog.getTextPanel();
		OptionPanelAPI options = dialog.getOptionPanel();

		dialog.setPromptText("Call Fleet");
		text.addPara("Choose which fleet to call out to you.");

		boolean resupplyActive = MilitaryWardModule.isResupplyFleetActive(station);
		boolean resupplyReady = MilitaryWardModule.hasResupplyBayBuilt(station) && !resupplyActive;
		options.addOption("Resupply Fleet", OPTION_RESUPPLY, resupplyReady
				? "Brings Supplies, Fuel, and Crew from the Player HQ's storage for you to take."
				: resupplyActive
						? "Currently " + MilitaryWardModule.getResupplyFleetStatusText(station) + "."
						: "Requires a Resupply Bay to be crewed in the Player HQ's Fleet HQ.");
		options.setEnabled(OPTION_RESUPPLY, resupplyReady);

		boolean courierActive = MilitaryWardModule.isCourierPickupFleetActive(station);
		boolean courierReady = MilitaryWardModule.hasCourierBayAvailableForPickup(station) && !courierActive;
		options.addOption("Courier Fleet", OPTION_COURIER, courierReady
				? "Comes to escort you -- hand it cargo and it'll be deposited into the Player HQ's storage "
						+ "as soon as the window closes."
				: courierActive
						? "Currently " + MilitaryWardModule.getCourierPickupStatusText(station) + "."
						: "Requires a Courier Bay to be crewed and idle in the Player HQ's Fleet HQ.");
		options.setEnabled(OPTION_COURIER, courierReady);

		if (PersonalCourierEngine.isModPresent()) {
			boolean personalReady = PersonalCourierEngine.canCall(station);
			options.addOption("Personal Courier", OPTION_PERSONAL, personalReady
					? "Instantly summons a courier next to you. It has no capacity limit and deposits everything "
							+ "you hand over straight into the Player HQ's storage, then flies back. No cooldown."
					: PersonalCourierEngine.notReadyReason(station));
			options.setEnabled(OPTION_PERSONAL, personalReady);
		}

		boolean patrolReady = !PatrolCallEngine.getEligibleBays(station).isEmpty();
		options.addOption("Call Patrol Fleet", OPTION_PATROL, patrolReady
				? "Calls one or both of your Patrol Fleets. They return to the station, prepare for " + PatrolCallEngine.PREP_DAYS
						+ " days, then meet up with you and escort you for " + PatrolCallEngine.ESCORT_DAYS + " days."
				: PatrolCallEngine.isCallActive(station)
						? "Every Patrol Fleet that can be called is already out on a call."
						: "Requires a Patrol Fleet crewed with " + PatrolCallEngine.FREIGHTERS_REQUIRED + " Freighters and "
								+ PatrolCallEngine.TANKERS_REQUIRED + " Tankers.");
		options.setEnabled(OPTION_PATROL, patrolReady);

		options.addOption("Cancel", OPTION_CANCEL);
	}

	private void showPatrolChoices() {
		OptionPanelAPI options = dialog.getOptionPanel();
		TextPanelAPI text = dialog.getTextPanel();
		options.clearOptions();
		dialog.setPromptText("Call Patrol Fleet");
		text.addPara("Choose which Patrol Fleet to call. It returns to the station and spends " + PatrolCallEngine.PREP_DAYS
				+ " days preparing once it is fully operational, then meets up with you and escorts you for "
				+ PatrolCallEngine.ESCORT_DAYS + " days before heading back for maintenance. The whole fleet, "
				+ "including its freighters and tankers, travels together.");
		java.util.List<Integer> eligible = PatrolCallEngine.getEligibleBays(station);
		int built = 0;
		for (int bay = 0; bay < MilitaryWardModule.MAX_PATROL_FLEET_BAYS; bay++) {
			if (!MilitaryWardModule.isPatrolFleetBayBuilt(station, bay)) continue;
			built++;
			boolean ready = eligible.contains(Integer.valueOf(bay));
			String why = ready ? "Calls Patrol Fleet " + (bay + 1) + "." : PatrolCallEngine.notReadyReason(station, bay);
			options.addOption("Patrol Fleet " + (bay + 1), OPTION_PATROL_BAY_PREFIX + bay, why);
			options.setEnabled(OPTION_PATROL_BAY_PREFIX + bay, ready);
		}
		if (built > 1) {
			options.addOption("Both Patrol Fleets", OPTION_PATROL_BOTH, eligible.size() > 1
					? "Calls every Patrol Fleet that is ready, together."
					: "Only available when more than one Patrol Fleet is ready to be called.");
			options.setEnabled(OPTION_PATROL_BOTH, eligible.size() > 1);
		}
		options.addOption("Back", OPTION_PATROL_BACK);
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();

		if (OPTION_RESUPPLY.equals(optionData)) {
			if (MilitaryWardModule.dispatchResupplyFleet(station, playerFleet)) {
				Global.getSector().getCampaignUI().addMessage("The Resupply Fleet departs the Player HQ and starts "
						+ "heading your way.");
			}
			dialog.dismiss();
			return;
		}

		if (OPTION_PATROL.equals(optionData)) {
			showPatrolChoices();
			return;
		}

		if (OPTION_PATROL_BACK.equals(optionData)) {
			dialog.getOptionPanel().clearOptions();
			dialog.getTextPanel().clear();
			init(dialog);
			return;
		}

		if (OPTION_PATROL_BOTH.equals(optionData)) {
			if (PatrolCallEngine.call(station, PatrolCallEngine.getEligibleBays(station))) {
				Global.getSector().getCampaignUI().addMessage("Both Patrol Fleets are returning to the Player HQ to prepare "
						+ "for a long trip.");
			}
			dialog.dismiss();
			return;
		}

		if (optionData instanceof String && ((String) optionData).startsWith(OPTION_PATROL_BAY_PREFIX)) {
			try {
				int bay = Integer.parseInt(((String) optionData).substring(OPTION_PATROL_BAY_PREFIX.length()));
				java.util.List<Integer> one = new java.util.ArrayList<Integer>();
				one.add(bay);
				if (PatrolCallEngine.call(station, one)) {
					Global.getSector().getCampaignUI().addMessage("Patrol Fleet " + (bay + 1) + " is returning to the Player HQ "
							+ "to prepare for a long trip.");
				}
			} catch (NumberFormatException ignored) {
			}
			dialog.dismiss();
			return;
		}

		if (OPTION_PERSONAL.equals(optionData)) {
			if (PersonalCourierEngine.call(station, playerFleet)) {
				Global.getSector().getCampaignUI().addMessage("Your Personal Courier appears nearby and heads to your fleet.");
			}
			dialog.dismiss();
			return;
		}

		if (OPTION_COURIER.equals(optionData)) {
			if (MilitaryWardModule.dispatchCourierPickupFleet(station, playerFleet)) {
				Global.getSector().getCampaignUI().addMessage("The Courier Fleet departs the Player HQ and starts "
						+ "heading your way.");
			}
			dialog.dismiss();
			return;
		}

		dialog.dismissAsCancel();
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
