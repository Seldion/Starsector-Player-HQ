package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import playerhq.Ids;
import playerhq.modules.MilitaryWardModule;
import playerhq.util.PlayerHQUtils;

import java.awt.Color;

public class CallResupplyFleetAbility extends BaseDurationAbility {

	private static SectorEntityToken findStation() {
		return PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
	}

	private static boolean canCallResupply(SectorEntityToken station) {
		return MilitaryWardModule.hasResupplyBayBuilt(station) && !MilitaryWardModule.isResupplyFleetActive(station);
	}

	private static boolean canCallCourier(SectorEntityToken station) {
		return MilitaryWardModule.hasCourierBayAvailableForPickup(station) && !MilitaryWardModule.isCourierPickupFleetActive(station);
	}

	private static boolean canCallPersonal(SectorEntityToken station) {
		return playerhq.modules.PersonalCourierEngine.canCall(station);
	}

	private static boolean canCallPatrol(SectorEntityToken station) {
		return !playerhq.modules.PatrolCallEngine.getEligibleBays(station).isEmpty();
	}

	@Override
	public boolean isUsable() {
		SectorEntityToken station = findStation();
		if (station == null) return false;
		if (!canCallResupply(station) && !canCallCourier(station) && !canCallPatrol(station) && !canCallPersonal(station)) return false;
		return super.isUsable();
	}

	@Override
	protected void activateImpl() {
		SectorEntityToken station = findStation();
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (station == null || playerFleet == null) return;

		Global.getSector().getCampaignUI().showInteractionDialog(new CallFleetChoiceDialogPlugin(station), playerFleet);
	}

	@Override
	protected void applyEffect(float amount, float level) { }

	@Override
	protected void deactivateImpl() { }

	@Override
	protected void cleanupImpl() { }

	@Override
	public boolean hasTooltip() {
		return true;
	}

	@Override
	public boolean isTooltipExpandable() {
		return false;
	}

	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
		Color bad = Misc.getNegativeHighlightColor();
		float pad = 10f;

		tooltip.addTitle("Call Fleet");
		tooltip.addPara("Opens a menu to select a fleet to call.", pad);
		tooltip.addPara("Resupply Fleet - Calls a resupply fleet that will bring Supplies, Crew and Fuel to your "
				+ "location but only up to the amount in the station's inventory.", pad, Misc.getHighlightColor(),
				"Resupply Fleet");
		SectorEntityToken station = findStation();
		if (station != null && MilitaryWardModule.isResupplyFleetActive(station)) {
			String resupplyWhere = MilitaryWardModule.getResupplyFleetLocationText(station);
			if (resupplyWhere != null) {
				resupplyWhere = Character.toUpperCase(resupplyWhere.charAt(0)) + resupplyWhere.substring(1);
				tooltip.addPara("Supply Fleet Location: %s", pad, Misc.getHighlightColor(), resupplyWhere);
			}
		}
		tooltip.addPara("Courier Fleet - Calls a courier fleet to take items and ferry them to the HQ.", pad,
				Misc.getHighlightColor(), "Courier Fleet");

		if (station != null && MilitaryWardModule.isCourierPickupFleetActive(station)) {
			String where = MilitaryWardModule.getCourierPickupLocationText(station);
			if (where != null) {
				where = Character.toUpperCase(where.charAt(0)) + where.substring(1);
				tooltip.addPara("Courier's current location: %s", pad, Misc.getHighlightColor(), where);
			}
		}

		if (playerhq.modules.PersonalCourierEngine.isModPresent()) {
			tooltip.addPara("Personal Courier - Instantly summons a courier next to you that takes everything you hand "
					+ "over with no capacity limit and deposits it into the HQ's storage. No cooldown.", pad,
					Misc.getHighlightColor(), "Personal Courier");
			if (station != null && playerhq.modules.PersonalCourierEngine.isActive(station)) {
				String where = playerhq.modules.PersonalCourierEngine.getLocationText(station);
				if (where != null) {
					where = Character.toUpperCase(where.charAt(0)) + where.substring(1);
					tooltip.addPara("Personal Courier's current location: %s", pad, Misc.getHighlightColor(), where);
				}
			}
		}

		tooltip.addPara("Call Patrol Fleet - Calls one or both Patrol Fleets that have 2 Freighters and 2 Tankers. They return "
				+ "to the station, prepare for %s days, then meet up with you and escort you for %s days before going back "
				+ "for maintenance.", pad, Misc.getHighlightColor(),
				playerhq.modules.PatrolCallEngine.PREP_DAYS + "", playerhq.modules.PatrolCallEngine.ESCORT_DAYS + "");
		if (station != null && playerhq.modules.PatrolCallEngine.isCallActive(station)) {
			for (String line : playerhq.modules.PatrolCallEngine.getLocationLines(station)) {
				int split = line.indexOf(": ");
				tooltip.addPara(line.substring(0, split + 2) + "%s", pad, Misc.getHighlightColor(), line.substring(split + 2));
			}
		}

		tooltip.addPara("Fleets will launch from the station and travel to your location, this means it will take "
				+ "time for them to reach you and to get back to the station, resupply fleet will follow you for up "
				+ "to %s days but the courier will head back to the station the moment the transfer window is "
				+ "closed.", pad, Misc.getHighlightColor(), MilitaryWardModule.RESUPPLY_FLEET_FOLLOW_DAYS + "");

		if (station == null) {
			tooltip.addPara("Requires a Player HQ station to exist.", bad, pad);
		} else if (!canCallResupply(station) && !canCallCourier(station) && !canCallPatrol(station) && !canCallPersonal(station)) {
			tooltip.addPara("No fleet is currently available -- build a Resupply Bay, Courier Bay or a Patrol Fleet with "
					+ "2 Freighters and 2 Tankers in the Fleet HQ, or wait for the one you last called to finish its run.", bad, pad);
		}
	}
}
