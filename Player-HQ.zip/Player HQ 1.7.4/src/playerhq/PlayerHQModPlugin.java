package playerhq;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;

import playerhq.util.PlayerHQUtils;

import java.util.List;

public class PlayerHQModPlugin extends BaseModPlugin {

	@Override
	public void onApplicationLoad() throws Exception {
		Global.getSettings().loadTexture(PlayerHQMonthlyReportIntel.ICON_PATH);
	}

	@Override
	public void onGameLoad(boolean newGame) {
		if (!Global.getSector().getListenerManager().hasListenerOfClass(PlayerHQFleetLossListener.class)) {
			Global.getSector().getListenerManager().addListener(new PlayerHQFleetLossListener(), true);
		}

		grantAbilityIfMissing(Ids.ABILITY_CONSTRUCT);
		grantAbilityIfMissing(Ids.ABILITY_CALL_RESUPPLY);
		PlayerHQItemDescriptions.apply();

		com.fs.starfarer.api.campaign.SectorEntityToken station = PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
		if (station != null && station.getMarket() != null) {
			playerhq.modules.MilitaryWardModule.migrateLegacyPatrolBays(station);
			playerhq.modules.MilitaryWardModule.ensureExpeditionFindsSubmarket(station);
		}
	}

	private void grantAbilityIfMissing(String abilityId) {
		MutableCharacterStatsAPI stats = Global.getSector().getPlayerStats();
		if (stats == null) return;

		List<String> granted = stats.getGrantedAbilityIds();
		if (!granted.contains(abilityId)) {
			granted.add(abilityId);
		}
	}
}
