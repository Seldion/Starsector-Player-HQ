package playerhq.modules;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelAtEntity;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelData;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelRank;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.mode.EasyRules;
import playerhq.util.PlayerHQUtils;

public class MilitaryWardModule {

	public static final String MEMORY_KEY = "$playerhq_module_militaryward";
	public static final String HOLOSUITE_MEMORY_KEY = "$playerhq_module_militaryward_holosuite";
	public static final String DRONE_REPLICATOR_MEMORY_KEY = "$playerhq_module_militaryward_dronereplicator";
	public static final String AICORE_MEMORY_KEY = "$playerhq_module_militaryward_aicore";

	public static final float CREDIT_COST = 35000f;
	public static final float METALS_COST = 4000f;
	public static final float TRANSPLUTONICS_COST = 1500f;
	public static final float HEAVY_MACHINERY_COST = 300f;

	public static final float MAX_PERSONNEL = 5000f;

	public static final float CREW_PRODUCTION_PER_MONTH = 100f;
	public static final float MARINE_PRODUCTION_PER_MONTH = 50f;

	public static final float CREW_STIPEND_PER_UNIT = 0.5f;
	public static final float MARINE_STIPEND_PER_UNIT = 10f;

	public static final float TRAINING_RATE_HOLODECK_ONLY = 0.03f;
	public static final float TRAINING_RATE_DRONE_REPLICATOR_ONLY = 0.03f;
	public static final float TRAINING_RATE_BOTH = 0.08f;

	public static final float AI_CORE_COST = 1f;

	public static final float MILITARY_WARD_DEFENSE_BONUS = 0.50f;
	public static final float MILITARY_WARD_STABILITY_BONUS = 1f;
	public static final String MILITARY_WARD_BONUS_MARKET_MEMORY_KEY = "$playerhq_module_militaryward_bonus_market";
	private static final String MILITARY_WARD_DEFENSE_MOD_ID = "playerhq_militaryward_defense";
	private static final String MILITARY_WARD_STABILITY_MOD_ID = "playerhq_militaryward_stability";

	public static final String FLEET_HQ_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_hq";
	public static final float FLEET_HQ_CREDIT_COST = 10000f;
	public static final float FLEET_HQ_METALS_COST = 350f;
	public static final float FLEET_HQ_TRANSPLUTONICS_COST = 35f;
	public static final float FLEET_HQ_VOLATILES_COST = 20f;
	public static final int FLEET_HQ_CREW_COST = 50;

	public static final String[] IMAGE_PATHS = {
			"graphics/modules/military_ward.jpg",
			"graphics/modules/military_ward_2.jpg",
			"graphics/modules/military_ward_3.jpg",
			"graphics/modules/military_ward_4.jpg",
			"graphics/modules/military_ward_5.jpg",
			"graphics/modules/military_ward_6.jpg",
			"graphics/modules/military_ward_7.jpg",
			"graphics/modules/military_ward_8.jpg",
			"graphics/modules/military_ward_9.jpg",
			"graphics/modules/military_ward_10.jpg",
			"graphics/modules/military_ward_11.jpg",
			"graphics/modules/military_ward_12.jpg",
			"graphics/modules/military_ward_13.jpg",
	};

	public static String getRandomImagePath() {
		int index = (int) (Math.random() * IMAGE_PATHS.length);
		if (index >= IMAGE_PATHS.length) index = IMAGE_PATHS.length - 1;
		return IMAGE_PATHS[index];
	}

	public static final String[] TRAINING_EXPEDITION_IMAGE_PATHS = {
			"graphics/modules/training_expedition.jpg",
			"graphics/modules/training_expedition_2.jpg",
			"graphics/modules/military_ward_7.jpg",
			"graphics/modules/military_ward_12.jpg",
			"graphics/modules/training_expedition_5.jpg",
	};

	public static String getRandomTrainingExpeditionImagePath() {
		int index = (int) (Math.random() * TRAINING_EXPEDITION_IMAGE_PATHS.length);
		if (index >= TRAINING_EXPEDITION_IMAGE_PATHS.length) index = TRAINING_EXPEDITION_IMAGE_PATHS.length - 1;
		return TRAINING_EXPEDITION_IMAGE_PATHS[index];
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) return EasyRules.canAfford(playerFleet, EasyRules.PRICE_MEDIUM);
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) {
			EasyRules.pay(playerFleet, EasyRules.PRICE_MEDIUM);
			station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
			updateDefenseAndStabilityBonus(station);
			return;
		}
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
		updateDefenseAndStabilityBonus(station);
	}

	private static void clearDefenseAndStabilityBonus(SectorEntityToken station) {
		String marketId = station.getMemoryWithoutUpdate().getString(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY);
		if (marketId == null) return;

		MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);
		if (market != null) {
			market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(MILITARY_WARD_DEFENSE_MOD_ID);
			market.getStability().unmodifyFlat(MILITARY_WARD_STABILITY_MOD_ID);
		}
		station.getMemoryWithoutUpdate().unset(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY);
	}

	public static void updateDefenseAndStabilityBonus(SectorEntityToken station) {
		clearDefenseAndStabilityBonus(station);

		if (!isBuilt(station)) return;

		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return;

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(
				MILITARY_WARD_DEFENSE_MOD_ID, 1f + MILITARY_WARD_DEFENSE_BONUS, "Military Paradigm (Player HQ)");
		market.getStability().modifyFlat(MILITARY_WARD_STABILITY_MOD_ID, MILITARY_WARD_STABILITY_BONUS, "Military Paradigm (Player HQ)");
		station.getMemoryWithoutUpdate().set(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY, market.getId());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		refund(station, playerFleet, playerFleet.getCargo());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI cargo) {
		if (!isBuilt(station)) return;

		clearDefenseAndStabilityBonus(station);

		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_MEDIUM);
		} else {
			cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
			cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
			cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);
		}

		if (hasHolosuiteInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
		}
		if (hasDroneReplicatorInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		}
		String aiCoreTier = getInstalledAICoreTier(station);
		if (aiCoreTier != null) {
			cargo.addCommodity(aiCoreTier, AI_CORE_COST);
		}

		if (hasFleetHQBuilt(station)) {
			playerhq.visual.Fleets.disbandAll();
			if (EasyRules.on()) {
				EasyRules.refundCredits(EasyRules.PRICE_MEDIUM);
			} else {
				cargo.addCommodity(Commodities.METALS, FLEET_HQ_METALS_COST * fraction);
				cargo.addCommodity(Commodities.RARE_METALS, FLEET_HQ_TRANSPLUTONICS_COST * fraction);
				cargo.addCommodity(Commodities.VOLATILES, FLEET_HQ_VOLATILES_COST * fraction);
				cargo.addCrew(FLEET_HQ_CREW_COST);
			}
			station.getMemoryWithoutUpdate().unset(FLEET_HQ_MEMORY_KEY);
		}
	}

	public static boolean hasHolosuiteInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasHolosuiteAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE);
	}

	public static void installHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().set(HOLOSUITE_MEMORY_KEY, true);
	}

	public static void uninstallHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasHolosuiteInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().unset(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR);
	}

	public static void installDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, true);
	}

	public static void uninstallDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasDroneReplicatorInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().unset(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static String getInstalledAICoreTier(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getString(AICORE_MEMORY_KEY);
	}

	public static boolean hasAICoreInstalled(SectorEntityToken station) {
		return getInstalledAICoreTier(station) != null;
	}

	public static boolean hasGammaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.GAMMA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasBetaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.BETA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasAlphaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ALPHA_CORE) >= AI_CORE_COST;
	}

	public static void installAICore(SectorEntityToken station, CampaignFleetAPI playerFleet, String coreCommodityId) {
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, coreCommodityId) < AI_CORE_COST) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, coreCommodityId, AI_CORE_COST);
		station.getMemoryWithoutUpdate().set(AICORE_MEMORY_KEY, coreCommodityId);
	}

	public static void uninstallAICore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return;

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(tier, AI_CORE_COST);
		}
		station.getMemoryWithoutUpdate().unset(AICORE_MEMORY_KEY);
	}

	public static float getAICoreTrainingMultiplier(SectorEntityToken station) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return 1f;
		if (Commodities.GAMMA_CORE.equals(tier)) return 2f;
		if (Commodities.BETA_CORE.equals(tier)) return 3f;
		if (Commodities.ALPHA_CORE.equals(tier)) return 4f;
		return 1f;
	}

	private static float getBaseTrainingRatio(SectorEntityToken station) {
		boolean holosuite = hasHolosuiteInstalled(station);
		boolean drone = hasDroneReplicatorInstalled(station);
		if (holosuite && drone) return TRAINING_RATE_BOTH;
		if (holosuite) return TRAINING_RATE_HOLODECK_ONLY;
		if (drone) return TRAINING_RATE_DRONE_REPLICATOR_ONLY;
		return 0f;
	}

	public static float getTrainingRatioPerMonth(SectorEntityToken station) {
		return getBaseTrainingRatio(station) * getAICoreTrainingMultiplier(station);
	}

	public static float getExpectedMonthlyTrainingXP(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return 0f;
		float marines = storageSubmarket.getCargo().getMarines();
		if (marines <= 0f) return 0f;
		return getTrainingRatioPerMonth(station) * marines;
	}

	private static SubmarketAPI getStorageSubmarket(SectorEntityToken station) {
		if (station.getMarket() == null) return null;
		return station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE);
	}

	private static void addCrewCapped(CargoAPI storage, float amount) {
		int current = storage.getCrew();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addCrew(toAdd);
	}

	private static void addMarinesCapped(CargoAPI storage, float amount) {
		int current = storage.getMarines();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addMarines(toAdd);
	}

	public static void enforceCap(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;
		CargoAPI storage = storageSubmarket.getCargo();

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();

		int crew = storage.getCrew();
		if (crew > (int) MAX_PERSONNEL) {
			int excess = crew - (int) MAX_PERSONNEL;
			storage.removeCrew(excess);
			if (playerFleet != null) playerFleet.getCargo().addCrew(excess);
		}

		int marines = storage.getMarines();
		if (marines > (int) MAX_PERSONNEL) {
			int excess = marines - (int) MAX_PERSONNEL;
			storage.removeMarines(excess);
			if (playerFleet != null) playerFleet.getCargo().addMarines(excess);
		}
	}

	private static void applyTraining(SectorEntityToken station, SubmarketAPI storageSubmarket) {
		float ratio = getTrainingRatioPerMonth(station);
		if (ratio <= 0f) return;

		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return;

		at.data.numMayHaveChanged(marines, true);
		at.data.addXP(ratio * marines);
	}

	public static float[] accumulateMonthly(SectorEntityToken station) {
		float[] stipends = new float[] { 0f, 0f };
		if (!isBuilt(station)) return stipends;

		updateDefenseAndStabilityBonus(station);

		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return stipends;
		CargoAPI storage = storageSubmarket.getCargo();

		addCrewCapped(storage, CREW_PRODUCTION_PER_MONTH);
		addMarinesCapped(storage, MARINE_PRODUCTION_PER_MONTH);

		float[] owed = computeStipends(station);
		stipends[0] = owed[0];
		stipends[1] = owed[1];

		applyTraining(station, storageSubmarket);
		return stipends;
	}

	public static float[] computeStipends(SectorEntityToken station) {
		float[] stipends = new float[] { 0f, 0f };
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return stipends;
		CargoAPI storage = storageSubmarket.getCargo();
		stipends[0] = storage.getCrew() * CREW_STIPEND_PER_UNIT;
		stipends[1] = storage.getMarines() * MARINE_STIPEND_PER_UNIT;
		return stipends;
	}

	public static PersonnelRank getStoredMarineRank(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return null;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return null;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return null;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getRank();
	}

	public static float getStoredMarineTrainingPercent(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return 0f;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return 0f;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return 0f;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getXPLevel() * 100f;
	}

	public static class MarineTransferSnapshot {
		float stationNum;
		float stationXP;
		float fleetNum;
		float fleetXP;
	}

	public static MarineTransferSnapshot snapshotMarineXP(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		MarineTransferSnapshot snap = new MarineTransferSnapshot();

		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return snap;

		snap.stationNum = storageSubmarket.getCargo().getMarines();
		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		at.data.numMayHaveChanged(snap.stationNum, true);
		snap.stationXP = at.data.xp;

		PersonnelData fleetData = PlayerFleetPersonnelTracker.getInstance().getMarineData();
		snap.fleetNum = playerFleet.getCargo().getMarines();
		fleetData.numMayHaveChanged(snap.fleetNum, true);
		snap.fleetXP = fleetData.xp;

		return snap;
	}

	public static void reconcileMarineTransfer(SectorEntityToken station, CampaignFleetAPI playerFleet, MarineTransferSnapshot before) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;

		float stationNumAfter = storageSubmarket.getCargo().getMarines();
		float fleetNumAfter = playerFleet.getCargo().getMarines();

		int withdrawn = Math.round(before.stationNum - stationNumAfter);
		if (withdrawn == 0) return;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		PersonnelData fleetData = PlayerFleetPersonnelTracker.getInstance().getMarineData();

		if (withdrawn > 0) {
			float xpPerMarine = before.stationNum > 0 ? before.stationXP / before.stationNum : 0f;
			float xpMoved = xpPerMarine * withdrawn;

			at.data.num = stationNumAfter;
			at.data.xp = Math.max(0f, before.stationXP - xpMoved);

			fleetData.num = fleetNumAfter;
			fleetData.xp = Math.min(before.fleetXP + xpMoved, Math.max(0f, fleetNumAfter));
		} else {
			int deposited = -withdrawn;
			float xpPerMarine = before.fleetNum > 0 ? before.fleetXP / before.fleetNum : 0f;
			float xpMoved = xpPerMarine * deposited;

			fleetData.num = fleetNumAfter;
			fleetData.xp = Math.max(0f, before.fleetXP - xpMoved);

			at.data.num = stationNumAfter;
			at.data.xp = Math.min(before.stationXP + xpMoved, Math.max(0f, stationNumAfter));
		}

		PlayerFleetPersonnelTracker.getInstance().update();
	}

	public static boolean hasFleetHQBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(FLEET_HQ_MEMORY_KEY);
	}

	public static boolean hasFleetHQCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) return EasyRules.canAfford(playerFleet, EasyRules.PRICE_MEDIUM);
		return playerFleet.getCargo().getCredits().get() >= FLEET_HQ_CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= FLEET_HQ_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= FLEET_HQ_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= FLEET_HQ_VOLATILES_COST
				&& PlayerHQUtils.getStationCrew(station) >= FLEET_HQ_CREW_COST;
	}

	public static void buildFleetHQ(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (hasFleetHQBuilt(station)) return;
		if (!hasFleetHQCost(station, playerFleet)) return;

		if (EasyRules.on()) {
			EasyRules.pay(playerFleet, EasyRules.PRICE_MEDIUM);
			station.getMemoryWithoutUpdate().set(FLEET_HQ_MEMORY_KEY, true);
			ensureExpeditionFindsSubmarket(station);
			return;
		}

		playerFleet.getCargo().getCredits().subtract(FLEET_HQ_CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, FLEET_HQ_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, FLEET_HQ_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, FLEET_HQ_VOLATILES_COST);
		PlayerHQUtils.removeStationCrew(station, FLEET_HQ_CREW_COST);

		station.getMemoryWithoutUpdate().set(FLEET_HQ_MEMORY_KEY, true);
		ensureExpeditionFindsSubmarket(station);
	}

	public static void uninstallFleetHQ(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasFleetHQBuilt(station)) return;

		playerhq.visual.Fleets.disbandAll();
		moveExpeditionFindsToStorage(station);

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_MEDIUM);
		} else if (storage != null) {
			float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
			storage.addCommodity(Commodities.METALS, FLEET_HQ_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, FLEET_HQ_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.VOLATILES, FLEET_HQ_VOLATILES_COST * fraction);
			storage.addCrew(FLEET_HQ_CREW_COST);
		}

		station.getMemoryWithoutUpdate().unset(FLEET_HQ_MEMORY_KEY);
	}

	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasHolosuiteInstalled(station) && !hasDroneReplicatorInstalled(station)
				&& !hasAICoreInstalled(station) && !hasFleetHQBuilt(station);
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet, PlayerHQUtils.getRefundCargo(station, playerFleet));
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	private static final String FLEET_HOLD_MOD_ID = "playerhq_fleet_double_hold";
	public static final float FLEET_HOLD_MULT = 2f;

	static boolean hasDoubleHolds(FleetMemberAPI m) {
		return m != null && m.getStats() != null && m.getStats().getCargoMod().getMultBonus(FLEET_HOLD_MOD_ID) != null;
	}

	static float getBaseCargoCapacity(FleetMemberAPI m) {
		if (m == null) return 0f;
		float capacity = m.getCargoCapacity();
		return hasDoubleHolds(m) ? capacity / FLEET_HOLD_MULT : capacity;
	}

	static float getBaseFuelCapacity(FleetMemberAPI m) {
		if (m == null) return 0f;
		float capacity = m.getFuelCapacity();
		return hasDoubleHolds(m) ? capacity / FLEET_HOLD_MULT : capacity;
	}

	public static float getFleetBaseCargoCapacity(CampaignFleetAPI fleet) {
		float total = 0f;
		if (fleet == null || fleet.getFleetData() == null) return total;
		for (FleetMemberAPI m : fleet.getFleetData().getMembersListCopy()) {
			total += getBaseCargoCapacity(m);
		}
		return total;
	}

	public static float getFleetBaseFuelCapacity(CampaignFleetAPI fleet) {
		float total = 0f;
		if (fleet == null || fleet.getFleetData() == null) return total;
		for (FleetMemberAPI m : fleet.getFleetData().getMembersListCopy()) {
			total += getBaseFuelCapacity(m);
		}
		return total;
	}

	public static final String EXPEDITION_FINDS_SUBMARKET_ID = "playerhq_expedition_finds";

	public static CargoAPI getExpeditionFindsCargo(SectorEntityToken station) {
		MarketAPI market = station.getMarket();
		if (market == null) return PlayerHQUtils.getStationStorageCargo(station);
		if (!market.hasSubmarket(EXPEDITION_FINDS_SUBMARKET_ID)) {
			market.addSubmarket(EXPEDITION_FINDS_SUBMARKET_ID);
		}
		CargoAPI cargo = market.getSubmarket(EXPEDITION_FINDS_SUBMARKET_ID).getCargo();
		cargo.initMothballedShips(Factions.PLAYER);
		return cargo;
	}

	private static final String EXPEDITION_FINDS_REORDER_MEMORY_KEY = "$playerhq_expeditionfinds_reordered_v1";

	public static void ensureExpeditionFindsSubmarket(SectorEntityToken station) {
		if (station == null || station.getMarket() == null) return;
		if (!hasFleetHQBuilt(station)) return;
		MarketAPI market = station.getMarket();
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		if (!mem.getBoolean(EXPEDITION_FINDS_REORDER_MEMORY_KEY)) {
			if (market.hasSubmarket(EXPEDITION_FINDS_SUBMARKET_ID)) {
				CargoAPI old = market.getSubmarket(EXPEDITION_FINDS_SUBMARKET_ID).getCargo();
				CargoAPI held = Global.getFactory().createCargo(true);
				held.initMothballedShips(Factions.PLAYER);
				held.addAll(old, false);
				if (old.getMothballedShips() != null) {
					for (FleetMemberAPI member : old.getMothballedShips().getMembersListCopy()) {
						old.getMothballedShips().removeFleetMember(member);
						held.getMothballedShips().addFleetMember(member);
					}
				}
				market.removeSubmarket(EXPEDITION_FINDS_SUBMARKET_ID);
				CargoAPI fresh = getExpeditionFindsCargo(station);
				fresh.addAll(held, false);
				for (FleetMemberAPI member : held.getMothballedShips().getMembersListCopy()) {
					fresh.getMothballedShips().addFleetMember(member);
				}
			}
			mem.set(EXPEDITION_FINDS_REORDER_MEMORY_KEY, true);
		}
		getExpeditionFindsCargo(station);
	}

	private static void moveExpeditionFindsToStorage(SectorEntityToken station) {
		MarketAPI market = station.getMarket();
		if (market == null || !market.hasSubmarket(EXPEDITION_FINDS_SUBMARKET_ID)) return;
		CargoAPI finds = market.getSubmarket(EXPEDITION_FINDS_SUBMARKET_ID).getCargo();
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (finds != null && storage != null) {
			storage.addAll(finds);
			if (finds.getMothballedShips() != null) {
				storage.initMothballedShips(Factions.PLAYER);
				for (FleetMemberAPI member : finds.getMothballedShips().getMembersListCopy()) {
					finds.getMothballedShips().removeFleetMember(member);
					storage.getMothballedShips().addFleetMember(member);
				}
			}
		}
		market.removeSubmarket(EXPEDITION_FINDS_SUBMARKET_ID);
	}

	public static SectorEntityToken getRatSettlementEntity() {
		try {
			if (!Global.getSettings().getModManager().isModEnabled("assortment_of_things")) return null;
			SectorEntityToken token = RatBridge.getSettlementEntity();
			if (token == null || token.getMarket() == null || token.getContainingLocation() == null) return null;
			return token;
		} catch (Throwable t) {
			Global.getLogger(MilitaryWardModule.class).warn("Player HQ: could not read the RAT settlement", t);
			return null;
		}
	}

	public static boolean isStockpileDestination(SectorEntityToken station, MarketAPI market) {
		if (market == null) return false;
		if (station != null && station.getMarket() != null && station.getMarket() == market) return false;
		return true;
	}

	static com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI getStockpileCommodity(MarketAPI market,
			CargoAPI.CargoItemType type, Object data) {
		if (market == null || type != CargoAPI.CargoItemType.RESOURCES || !(data instanceof String)) return null;
		try {
			com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI c = market.getCommodityData((String) data);
			if (c == null) return null;
			com.fs.starfarer.api.campaign.econ.CommoditySpecAPI spec = c.getCommodity();
			if (spec == null || spec.isMeta()) return null;
			return c;
		} catch (Throwable t) {
			return null;
		}
	}

	public static float getStockpiledAmount(MarketAPI market, CargoAPI.CargoItemType type, Object data) {
		com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI c = getStockpileCommodity(market, type, data);
		return c == null ? 0f : c.getStockpile();
	}

	public static void deliverToColony(MarketAPI market, boolean useStockpile, CargoAPI storage, CargoAPI.CargoItemType type,
			Object data, float units) {
		if (units <= 0f) return;
		if (useStockpile) {
			com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI c = getStockpileCommodity(market, type, data);
			if (c != null) {
				c.addToStockpile(units);
				return;
			}
		}
		if (storage != null) storage.addItems(type, data, units);
	}

	public static SubmarketAPI getCourierTargetStorage(MarketAPI market) {
		if (market == null) return null;
		for (SubmarketAPI sub : market.getSubmarketsCopy()) {
			if (sub.getPlugin() != null && sub.getPlugin().getClass().getName().endsWith("SettlementStoragePlugin")) return sub;
		}
		return market.getSubmarket(Submarkets.SUBMARKET_STORAGE);
	}

	public static float getPickupHandoffRoom(CampaignFleetAPI fleet, CargoAPI pending) {
		float used = pending != null ? pending.getSpaceUsed() : 0f;
		return Math.max(0f, getFleetBaseCargoCapacity(fleet) - used);
	}

	public static List<FleetMemberAPI> getPickupHandoffShipCandidates(CampaignFleetAPI playerFleet) {
		List<FleetMemberAPI> candidates = new ArrayList<FleetMemberAPI>();
		if (playerFleet == null) return candidates;
		FleetMemberAPI flagship = playerFleet.getFlagship();
		if (playerFleet.getFleetData() != null) {
			for (FleetMemberAPI m : playerFleet.getFleetData().getMembersListCopy()) {
				if (m == null || m == flagship || m.isFighterWing()) continue;
				candidates.add(m);
			}
		}
		CargoAPI cargo = playerFleet.getCargo();
		if (cargo != null) {
			cargo.initMothballedShips(playerFleet.getFaction().getId());
			if (cargo.getMothballedShips() != null) {
				for (FleetMemberAPI m : cargo.getMothballedShips().getMembersListCopy()) {
					if (m != null) candidates.add(m);
				}
			}
		}
		return candidates;
	}

	public static boolean takeShipForPickup(CampaignFleetAPI playerFleet, FleetMemberAPI m) {
		if (playerFleet == null || m == null) return false;
		if (m == playerFleet.getFlagship()) return false;
		PersonAPI captain = m.getCaptain();
		if (captain != null && !captain.isDefault()) m.setCaptain(null);

		if (playerFleet.getFleetData() != null && playerFleet.getFleetData().getMembersListCopy().contains(m)) {
			playerFleet.getFleetData().removeFleetMember(m);
			playerFleet.getFleetData().ensureHasFlagship();
			return true;
		}
		CargoAPI cargo = playerFleet.getCargo();
		if (cargo != null && cargo.getMothballedShips() != null
				&& cargo.getMothballedShips().getMembersListCopy().contains(m)) {
			cargo.getMothballedShips().removeFleetMember(m);
			return true;
		}
		return false;
	}

	public static void depositPickupShips(SectorEntityToken station, List<FleetMemberAPI> ships) {
		if (station == null || ships == null || ships.isEmpty()) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		storage.initMothballedShips(Factions.PLAYER);
		FleetDataAPI mothballed = storage.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : ships) {
			mothballed.addFleetMember(m);
		}
	}

	public static float getPickupHandoffFuelRoom(CampaignFleetAPI fleet, CargoAPI pending) {
		return Math.max(0f, getFleetBaseFuelCapacity(fleet) - (pending != null ? pending.getFuel() : 0f));
	}

	public static int getPickupHandoffPersonnelRoom(CampaignFleetAPI fleet, CargoAPI pending) {
		if (fleet == null) return 0;
		return (int) Math.max(0f, fleet.getCargo().getMaxPersonnel()
				- (pending != null ? pending.getCrew() + pending.getMarines() : 0));
	}

	public static CargoAPI fitPickupHandoff(SectorEntityToken station, CampaignFleetAPI fleet, CargoAPI picked, CargoAPI pending) {
		CargoAPI kept = Global.getFactory().createCargo(true);
		if (picked == null || fleet == null) return kept;
		float spaceLeft = getPickupHandoffRoom(fleet, pending);
		float fuelLeft = Math.max(0f, getFleetBaseFuelCapacity(fleet) - (pending != null ? pending.getFuel() : 0f));
		int personnelLeft = getPickupHandoffPersonnelRoom(fleet, pending);
		int crew = Math.max(0, Math.min(picked.getCrew(), personnelLeft));
		if (crew > 0) kept.addCrew(crew);
		personnelLeft -= crew;
		int marines = Math.max(0, Math.min(picked.getMarines(), personnelLeft));
		if (marines > 0) kept.addMarines(marines);

		for (CargoStackAPI stack : picked.getStacksCopy()) {
			if (stack == null || stack.isNull() || stack.isPersonnelStack()) continue;
			float size = stack.getSize();
			if (size <= 0f) continue;
			float units = size;
			if (stack.isFuelStack()) {
				units = Math.min(units, fuelLeft);
			} else {
				float perUnit = stack.getCargoSpacePerUnit();
				if (perUnit > 0f) units = Math.min(units, (float) Math.floor(Math.max(0f, spaceLeft) / perUnit));
			}
			if (units <= 0f) continue;
			if (stack.isFuelStack()) fuelLeft -= units;
			else if (stack.getCargoSpacePerUnit() > 0f) spaceLeft -= units * stack.getCargoSpacePerUnit();
			kept.addItems(stack.getType(), stack.getData(), units);
		}
		return kept;
	}

	public static void depositPickupHandoff(SectorEntityToken station, CargoAPI pending) {
		if (station == null || pending == null) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		int crew = pending.getCrew();
		int marines = pending.getMarines();
		pending.removeCrew(crew);
		pending.removeMarines(marines);
		storage.addAll(pending);
		pending.clear();

		float credits = 0f;
		int crewStored = Math.min(crew, Math.max(0, (int) MAX_PERSONNEL - storage.getCrew()));
		if (crewStored > 0) storage.addCrew(crewStored);
		credits += (crew - crewStored) * getPersonnelBasePrice(Commodities.CREW);
		int marinesStored = Math.min(marines, Math.max(0, (int) MAX_PERSONNEL - storage.getMarines()));
		if (marinesStored > 0) storage.addMarines(marinesStored);
		credits += (marines - marinesStored) * getPersonnelBasePrice(Commodities.MARINES);

		if (credits > 0f) {
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (playerFleet != null) playerFleet.getCargo().getCredits().add(credits);
			int soldCrew = crew - crewStored;
			int soldMarines = marines - marinesStored;
		}
	}

	private static float getPersonnelBasePrice(String commodityId) {
		com.fs.starfarer.api.campaign.econ.CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(commodityId);
		return spec != null ? spec.getBasePrice() : 0f;
	}

	private static float getCargoSpacePerUnit(String commodityId) {
		if (commodityId == null) return 0f;
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(commodityId);
		return spec != null ? spec.getCargoSpace() : 0f;
	}

	public static final String TRADER_EARNED_LOG_MEMORY_KEY = "$playerhq_module_militaryward_trader_earned_log";
	public static final String TRADER_BOUGHT_LOG_MEMORY_KEY = "$playerhq_module_militaryward_trader_bought_log";

	public static void logTraderEarned(SectorEntityToken station, float amount) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		float prev = mem.contains(TRADER_EARNED_LOG_MEMORY_KEY) ? mem.getFloat(TRADER_EARNED_LOG_MEMORY_KEY) : 0f;
		mem.set(TRADER_EARNED_LOG_MEMORY_KEY, prev + amount);
	}

	@SuppressWarnings("unchecked")
	public static void logTraderBought(SectorEntityToken station, playerhq.shopping.ShoppingListEngine.Result result) {
		if (result == null || result.bought.isEmpty()) return;
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		Object o = mem.get(TRADER_BOUGHT_LOG_MEMORY_KEY);
		Map<String, Integer> totals = (o instanceof Map) ? (Map<String, Integer>) o : new java.util.LinkedHashMap<String, Integer>();
		for (Map.Entry<String, Integer> e : result.bought.entrySet()) {
			Integer prev = totals.get(e.getKey());
			totals.put(e.getKey(), (prev == null ? 0 : prev) + e.getValue());
		}
		mem.set(TRADER_BOUGHT_LOG_MEMORY_KEY, totals);
	}

	public static float getTraderEarnedThisMonth(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		return mem.contains(TRADER_EARNED_LOG_MEMORY_KEY) ? mem.getFloat(TRADER_EARNED_LOG_MEMORY_KEY) : 0f;
	}

	@SuppressWarnings("unchecked")
	public static List<String> getTraderBoughtThisMonth(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRADER_BOUGHT_LOG_MEMORY_KEY);
		List<String> result = new ArrayList<String>();
		if (o instanceof Map) {
			for (Map.Entry<String, Integer> e : ((Map<String, Integer>) o).entrySet()) {
				result.add(e.getValue() + "x " + e.getKey());
			}
		}
		return result;
	}

	public static void clearTraderLogThisMonth(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(TRADER_EARNED_LOG_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(TRADER_BOUGHT_LOG_MEMORY_KEY);
	}

	public static boolean canDisbandFleetHQ(SectorEntityToken station) {
		return hasFleetHQBuilt(station) && playerhq.visual.Fleets.list().isEmpty();
	}
}
