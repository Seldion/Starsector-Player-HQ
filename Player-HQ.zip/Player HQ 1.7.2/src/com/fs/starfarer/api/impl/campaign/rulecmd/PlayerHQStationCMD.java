package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.InteractionDialogImageVisual;
import com.fs.starfarer.api.campaign.BaseCustomProductionPickerDelegateImpl;
import com.fs.starfarer.api.campaign.CampaignEntityPickerListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoPickerListener;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CoreInteractionListener;
import com.fs.starfarer.api.campaign.CoreUITabId;
import com.fs.starfarer.api.campaign.FactionProductionAPI;
import com.fs.starfarer.api.campaign.FleetMemberPickerListener;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.VisualPanelAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin.ArrowData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.loading.Description;
import com.fs.starfarer.api.ui.MarkerData;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.MarketPlaceModule;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;
import playerhq.modules.StationItemsModule;
import playerhq.util.PlayerHQUtils;

import org.lwjgl.input.Keyboard;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PlayerHQStationCMD extends BaseCommandPlugin {

	private static final String OPT_INVENTORY = "playerhq_inventory";
	private static final String OPT_SHIPS = "playerhq_ships";
	private static final String OPT_MODULES = "playerhq_modules";
	private static final String OPT_STATION_ITEMS = "playerhq_station_items";
	private static final String OPT_DISMANTLE = "playerhq_dismantle";
	private static final String OPT_CONFIRM_DISMANTLE = "playerhq_confirmDismantle";
	private static final String OPT_CANCEL_DISMANTLE = "playerhq_cancelDismantle";
	private static final String OPT_LEAVE = "playerhq_leave";

	private static final String OPT_MODULES_BACK = "playerhq_modules_back";
	private static final String OPT_MINING_VIEW = "playerhq_module_mining_view";
	private static final String OPT_MINING_BUILD = "playerhq_module_mining_build";
	private static final String OPT_MINING_FLEET_VIEW = "playerhq_module_mining_fleet_view";
	private static final String OPT_MINING_DISMANTLE = "playerhq_module_mining_dismantle";
	private static final String OPT_RECREATION_VIEW = "playerhq_module_recreation_view";
	private static final String OPT_RECREATION_BUILD = "playerhq_module_recreation_build";
	private static final String OPT_RECREATION_INSTALL_HOLOSUITE = "playerhq_module_recreation_install_holosuite";
	private static final String OPT_RECREATION_UNINSTALL_HOLOSUITE = "playerhq_module_recreation_uninstall_holosuite";
	private static final String OPT_RECREATION_INSTALL_FUSIONLAMP = "playerhq_module_recreation_install_fusionlamp";
	private static final String OPT_RECREATION_UNINSTALL_FUSIONLAMP = "playerhq_module_recreation_uninstall_fusionlamp";
	private static final String OPT_RECREATION_INSTALL_WINTERRESORT = "playerhq_module_recreation_install_winterresort";
	private static final String OPT_RECREATION_UNINSTALL_WINTERRESORT = "playerhq_module_recreation_uninstall_winterresort";
	private static final String OPT_RECREATION_DISMANTLE = "playerhq_module_recreation_dismantle";
	private static final String OPT_INDUSTRIAL_VIEW = "playerhq_module_industrial_view";
	private static final String OPT_INDUSTRIAL_BUILD = "playerhq_module_industrial_build";
	private static final String OPT_INDUSTRIAL_INSTALL_NANOFORGE = "playerhq_module_industrial_install_nanoforge";
	private static final String OPT_INDUSTRIAL_UNINSTALL_NANOFORGE = "playerhq_module_industrial_uninstall_nanoforge";
	private static final String OPT_INDUSTRIAL_INSTALL_CORRUPTED_NANOFORGE = "playerhq_module_industrial_install_corrupted_nanoforge";
	private static final String OPT_INDUSTRIAL_INSTALL_PRISTINE_NANOFORGE = "playerhq_module_industrial_install_pristine_nanoforge";
	private static final String OPT_INDUSTRIAL_NANOFORGE_BACK = "playerhq_module_industrial_nanoforge_back";
	private static final String OPT_INDUSTRIAL_INSTALL_BIOFACTORY = "playerhq_module_industrial_install_biofactory";
	private static final String OPT_INDUSTRIAL_UNINSTALL_BIOFACTORY = "playerhq_module_industrial_uninstall_biofactory";
	private static final String OPT_INDUSTRIAL_INSTALL_CATALYTICCORE = "playerhq_module_industrial_install_catalyticcore";
	private static final String OPT_INDUSTRIAL_UNINSTALL_CATALYTICCORE = "playerhq_module_industrial_uninstall_catalyticcore";
	private static final String OPT_INDUSTRIAL_INSTALL_SYNCHROTRONCORE = "playerhq_module_industrial_install_synchrotroncore";
	private static final String OPT_INDUSTRIAL_UNINSTALL_SYNCHROTRONCORE = "playerhq_module_industrial_uninstall_synchrotroncore";
	private static final String OPT_INDUSTRIAL_DISMANTLE = "playerhq_module_industrial_dismantle";
	private static final String OPT_INDUSTRIAL_PRODUCTION = "playerhq_module_industrial_production";
	private static final String OPT_INDUSTRIAL_PRODUCTION_BACK = "playerhq_module_industrial_production_back";
	private static final String OPT_INDUSTRIAL_TOGGLE_PREFIX = "playerhq_module_industrial_toggle_";
	private static final String OPT_HYDROPONICS_VIEW = "playerhq_module_hydroponics_view";
	private static final String OPT_HYDROPONICS_BUILD = "playerhq_module_hydroponics_build";
	private static final String OPT_HYDROPONICS_INSTALL_NANITES = "playerhq_module_hydroponics_install_nanites";
	private static final String OPT_HYDROPONICS_UNINSTALL_NANITES = "playerhq_module_hydroponics_uninstall_nanites";
	private static final String OPT_HYDROPONICS_INSTALL_LAMP = "playerhq_module_hydroponics_install_lamp";
	private static final String OPT_HYDROPONICS_UNINSTALL_LAMP = "playerhq_module_hydroponics_uninstall_lamp";
	private static final String OPT_HYDROPONICS_DISMANTLE = "playerhq_module_hydroponics_dismantle";

	private static final String OPT_ASSEMBLY_VIEW = "playerhq_module_assembly_view";
	private static final String OPT_ASSEMBLY_BUILD = "playerhq_module_assembly_build";
	private static final String OPT_ASSEMBLY_INSTALL_NANOFORGE = "playerhq_module_assembly_install_nanoforge";
	private static final String OPT_ASSEMBLY_INSTALL_CORRUPTED_NANOFORGE = "playerhq_module_assembly_install_corrupted_nanoforge";
	private static final String OPT_ASSEMBLY_INSTALL_PRISTINE_NANOFORGE = "playerhq_module_assembly_install_pristine_nanoforge";
	private static final String OPT_ASSEMBLY_NANOFORGE_BACK = "playerhq_module_assembly_nanoforge_back";
	private static final String OPT_ASSEMBLY_UNINSTALL_NANOFORGE = "playerhq_module_assembly_uninstall_nanoforge";
	private static final String OPT_ASSEMBLY_INSTALL_AISYSTEM_MENU = "playerhq_module_assembly_install_aisystem_menu";
	private static final String OPT_ASSEMBLY_INSTALL_GAMMA_CORE = "playerhq_module_assembly_install_gammacore";
	private static final String OPT_ASSEMBLY_INSTALL_BETA_CORE = "playerhq_module_assembly_install_betacore";
	private static final String OPT_ASSEMBLY_INSTALL_ALPHA_CORE = "playerhq_module_assembly_install_alphacore";
	private static final String OPT_ASSEMBLY_AISYSTEM_BACK = "playerhq_module_assembly_aisystem_back";
	private static final String OPT_ASSEMBLY_UNINSTALL_AISYSTEM = "playerhq_module_assembly_uninstall_aisystem";
	private static final String OPT_ASSEMBLY_DISMANTLE = "playerhq_module_assembly_dismantle";
	private static final String OPT_ASSEMBLY_INJECT_VIEW = "playerhq_module_assembly_inject_view";
	private static final String OPT_ASSEMBLY_INJECT_BACK = "playerhq_module_assembly_inject_back";
	private static final String[] OPT_ASSEMBLY_INJECT_TIER = {
			"playerhq_module_assembly_inject_tier1",
			"playerhq_module_assembly_inject_tier2",
			"playerhq_module_assembly_inject_tier3",
			"playerhq_module_assembly_inject_tier4",
	};

	private static final String OPT_MILITARYWARD_VIEW = "playerhq_module_militaryward_view";
	private static final String OPT_MILITARYWARD_BUILD = "playerhq_module_militaryward_build";
	private static final String OPT_MILITARYWARD_INSTALL_HOLOSUITE = "playerhq_module_militaryward_install_holosuite";
	private static final String OPT_MILITARYWARD_UNINSTALL_HOLOSUITE = "playerhq_module_militaryward_uninstall_holosuite";
	private static final String OPT_MILITARYWARD_INSTALL_DRONE_REPLICATOR = "playerhq_module_militaryward_install_dronereplicator";
	private static final String OPT_MILITARYWARD_UNINSTALL_DRONE_REPLICATOR = "playerhq_module_militaryward_uninstall_dronereplicator";
	private static final String OPT_MILITARYWARD_INSTALL_AICORE = "playerhq_module_militaryward_install_aicore";
	private static final String OPT_MILITARYWARD_UNINSTALL_AICORE = "playerhq_module_militaryward_uninstall_aicore";
	private static final String OPT_MILITARYWARD_AICORE_BACK = "playerhq_module_militaryward_aicore_back";
	private static final String OPT_MILITARYWARD_INSTALL_GAMMA_CORE = "playerhq_module_militaryward_install_gammacore";
	private static final String OPT_MILITARYWARD_INSTALL_BETA_CORE = "playerhq_module_militaryward_install_betacore";
	private static final String OPT_MILITARYWARD_INSTALL_ALPHA_CORE = "playerhq_module_militaryward_install_alphacore";
	private static final String OPT_MILITARYWARD_TRAINING_VIEW = "playerhq_module_militaryward_training_view";
	private static final String OPT_MILITARYWARD_TRAINING_BUILD_HQ = "playerhq_module_militaryward_training_build_hq";
	private static final String OPT_MILITARYWARD_TRAINING_UNINSTALL = "playerhq_module_militaryward_training_uninstall";
	private static final String OPT_MILITARYWARD_TRAINING_BACK = "playerhq_module_militaryward_training_back";
	private static final String[] OPT_MILITARYWARD_TRAINING_CREW_BAY = {
			"playerhq_module_militaryward_training_crew_bay1",
			"playerhq_module_militaryward_training_crew_bay2",
			"playerhq_module_militaryward_training_crew_bay3",
			"playerhq_module_militaryward_training_crew_bay4",
	};
	private static final String[] OPT_MILITARYWARD_TRAINING_UNINSTALL_BAY = {
			"playerhq_module_militaryward_training_uninstall_bay1",
			"playerhq_module_militaryward_training_uninstall_bay2",
			"playerhq_module_militaryward_training_uninstall_bay3",
			"playerhq_module_militaryward_training_uninstall_bay4",
	};
	private static final String OPT_MILITARYWARD_DISMANTLE = "playerhq_module_militaryward_dismantle";

	private static final String OPT_FLEETLOGISTIC_EXPEDITION_VIEW = "playerhq_module_fleetlogistic_expedition_view";
	private static final String OPT_FLEETLOGISTIC_LOGISTIC_VIEW = "playerhq_module_fleetlogistic_logistic_view";
	private static final String OPT_FLEETLOGISTIC_PATROL_VIEW = "playerhq_module_fleetlogistic_patrol_view";
	private static final String OPT_FLEETLOGISTIC_SALVAGE_VIEW = "playerhq_module_fleetlogistic_salvage_view";
	private static final String OPT_EXPEDITIONFLEET_BACK = "playerhq_module_expeditionfleet_back";

	private static final String[] OPT_SALVAGEFLEET_CREW_BAY = {
			"playerhq_module_salvagefleet_crew_bay1",
			"playerhq_module_salvagefleet_crew_bay2",
	};
	private static final String[] OPT_SALVAGEFLEET_UNINSTALL_BAY = {
			"playerhq_module_salvagefleet_uninstall_bay1",
			"playerhq_module_salvagefleet_uninstall_bay2",
	};
	private static final String OPT_SALVAGEFLEET_BACK = "playerhq_module_salvagefleet_back";

	private static final String[] OPT_MININGFLEET_CREW_BAY = {
			"playerhq_module_miningfleet_crew_bay1",
			"playerhq_module_miningfleet_crew_bay2",
			"playerhq_module_miningfleet_crew_bay3",
			"playerhq_module_miningfleet_crew_bay4",
	};
	private static final String[] OPT_MININGFLEET_UNINSTALL_BAY = {
			"playerhq_module_miningfleet_uninstall_bay1",
			"playerhq_module_miningfleet_uninstall_bay2",
			"playerhq_module_miningfleet_uninstall_bay3",
			"playerhq_module_miningfleet_uninstall_bay4",
	};
	private static final String OPT_MININGFLEET_BACK = "playerhq_module_miningfleet_back";

	private static final String OPT_LOGISTIC_RESUPPLY_CREW = "playerhq_module_logistic_resupply_crew";
	private static final String OPT_LOGISTIC_RESUPPLY_UNINSTALL = "playerhq_module_logistic_resupply_uninstall";
	private static final String[] OPT_LOGISTIC_COURIER_CREW_BAY = {
			"playerhq_module_logistic_courier_crew_bay1",
			"playerhq_module_logistic_courier_crew_bay2",
			"playerhq_module_logistic_courier_crew_bay3",
			"playerhq_module_logistic_courier_crew_bay4",
	};
	private static final String[] OPT_LOGISTIC_COURIER_UNINSTALL_BAY = {
			"playerhq_module_logistic_courier_uninstall_bay1",
			"playerhq_module_logistic_courier_uninstall_bay2",
			"playerhq_module_logistic_courier_uninstall_bay3",
			"playerhq_module_logistic_courier_uninstall_bay4",
	};
	private static final String OPT_COURIER_CARGO_PICK = "playerhq_courier_cargo_pick";
	private static final String OPT_COURIER_CARGO_CANCEL = "playerhq_courier_cargo_cancel";
	private static final String COURIER_PENDING_BAY_KEY = "$playerhq_courier_pending_bay";
	private static final String COURIER_PENDING_TARGET_KEY = "$playerhq_courier_pending_target";
	private static final String[] OPT_LOGISTIC_COURIER_TRADE_BAY = {
			"playerhq_module_logistic_courier_trade_bay1",
			"playerhq_module_logistic_courier_trade_bay2",
			"playerhq_module_logistic_courier_trade_bay3",
			"playerhq_module_logistic_courier_trade_bay4",
	};
	private static final String OPT_LOGISTIC_TRADE_CREW = "playerhq_module_logistic_trade_crew";
	private static final String OPT_LOGISTIC_TRADE_UNINSTALL = "playerhq_module_logistic_trade_uninstall";
	private static final String OPT_LOGISTIC_BACK = "playerhq_module_logistic_back";

	private static final String[] OPT_PATROLFLEET_CREW_BAY = {
			"playerhq_module_patrolfleet_crew_bay1",
			"playerhq_module_patrolfleet_crew_bay2",
			"playerhq_module_patrolfleet_crew_bay3",
			"playerhq_module_patrolfleet_crew_bay4",
	};
	private static final String[] OPT_PATROLFLEET_UNINSTALL_BAY = {
			"playerhq_module_patrolfleet_uninstall_bay1",
			"playerhq_module_patrolfleet_uninstall_bay2",
			"playerhq_module_patrolfleet_uninstall_bay3",
			"playerhq_module_patrolfleet_uninstall_bay4",
	};
	private static final String OPT_PATROLFLEET_BACK = "playerhq_module_patrolfleet_back";

	private static final String OPT_MODULE_DETAIL_BACK = "playerhq_module_detail_back";

	private static final String OPT_ORDER_CUSTOM_PRODUCTION = "playerhq_order_custom_production";

	private static final String OPT_STATIONITEM_INSTALL_SPACE_ELEVATOR = "playerhq_stationitem_install_spaceelevator";
	private static final String OPT_STATIONITEM_UNINSTALL_SPACE_ELEVATOR = "playerhq_stationitem_uninstall_spaceelevator";
	private static final String OPT_STATIONITEM_INSTALL_PUBLIC_SHUTTLES = "playerhq_stationitem_install_publicshuttles";
	private static final String OPT_STATIONITEM_UNINSTALL_PUBLIC_SHUTTLES = "playerhq_stationitem_uninstall_publicshuttles";
	private static final String OPT_STATIONITEM_INSTALL_MARKETPLACE = "playerhq_stationitem_install_marketplace";
	private static final String OPT_STATIONITEM_UNINSTALL_MARKETPLACE = "playerhq_stationitem_uninstall_marketplace";
	private static final String OPT_STATION_ITEMS_BACK = "playerhq_station_items_back";

	private static final String OPT_ESCAPE = "playerhq_escape";
	private static final String CURRENT_SCREEN_MEMORY_KEY = "$playerhq_current_screen";

	private static final String SCREEN_MAIN = "main";
	private static final String SCREEN_MODULES = "modules";
	private static final String SCREEN_MINING = "mining";
	private static final String SCREEN_RECREATION = "recreation";
	private static final String SCREEN_INDUSTRIAL = "industrial";
	private static final String SCREEN_HYDROPONICS = "hydroponics";
	private static final String SCREEN_ASSEMBLY = "assembly";
	private static final String SCREEN_ASSEMBLY_NANOFORGE = "assemblyNanoforge";
	private static final String SCREEN_ASSEMBLY_AISYSTEM = "assemblyAiSystem";
	private static final String SCREEN_INDUSTRIAL_NANOFORGE = "industrialNanoforge";
	private static final String SCREEN_INDUSTRIAL_PRODUCTION = "industrialProduction";
	private static final String SCREEN_ASSEMBLY_INJECT = "assemblyInject";
	private static final String SCREEN_MILITARYWARD = "militaryWard";
	private static final String SCREEN_MILITARYWARD_AICORE = "militaryWardAICore";
	private static final String SCREEN_FLEET_HQ = "fleetHQ";
	private static final String SCREEN_EXPEDITION_FLEET = "expeditionFleet";
	private static final String SCREEN_MINING_FLEET = "miningFleet";
	private static final String SCREEN_SALVAGE_FLEET = "salvageFleet";
	private static final String SCREEN_LOGISTIC_FLEET = "logisticFleet";
	private static final String SCREEN_PATROL_FLEET = "patrolFleet";
	private static final String SCREEN_STATION_ITEMS = "stationItems";
	private static final String SCREEN_CONFIRM_DISMANTLE = "confirmDismantle";
	private static final String SCREEN_SHOPPING = "shoppingList";
	private static final String SCREEN_CHARTER = "courierCharter";
	private static final String OPT_CHARTER_OPEN = "playerhq_charter_open";

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;
	private OptionPanelAPI options;
	private VisualPanelAPI visual;
	private SectorEntityToken station;
	private CampaignFleetAPI playerFleet;

	@Override
	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.text = dialog.getTextPanel();
		this.options = dialog.getOptionPanel();
		this.visual = dialog.getVisualPanel();
		this.station = dialog.getInteractionTarget();
		this.playerFleet = Global.getSector().getPlayerFleet();

		dialog.setOptionOnEscape("Escape", OPT_ESCAPE);

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

		mainKeysOwner = null;

		if (command.equals("escape")) {
			doEscape();
		} else if (command.equals("init")) {
			updateColonyInfoDescription();
			showMainMenu();
		} else if (command.equals("inventory")) {
			showInventory();
		} else if (command.equals("ships")) {
			showShips(CoreUITabId.FLEET);
		} else if (command.equals("modules")) {
			showModulesMenu();
		} else if (command.equals("stationItemsView")) {
			showStationItemsMenu();
		} else if (command.equals("stationItemsBack")) {
			showMainMenu();
		} else if (command.equals("stationItemsInstallSpaceElevator")) {
			doInstallSpaceElevator();
		} else if (command.equals("stationItemsUninstallSpaceElevator")) {
			doUninstallSpaceElevator();
		} else if (command.equals("stationItemsInstallPublicShuttles")) {
			doInstallPublicShuttles();
		} else if (command.equals("stationItemsUninstallPublicShuttles")) {
			doUninstallPublicShuttles();
		} else if (command.equals("stationItemsInstallMarketPlace")) {
			doInstallMarketPlace();
		} else if (command.equals("stationItemsUninstallMarketPlace")) {
			doUninstallMarketPlace();
		} else if (command.equals("miningView")) {
			showMiningHangarDetail();
		} else if (command.equals("miningBuild")) {
			doBuildMiningHangar();
		} else if (command.equals("miningFleetView")) {
			showMiningFleetDetail();
		} else if (command.equals("miningDismantle")) {
			doDismantleMiningHangar();
		} else if (command.equals("recreationView")) {
			showRecreationalHubDetail();
		} else if (command.equals("recreationBuild")) {
			doBuildRecreationalHub();
		} else if (command.equals("recreationInstallHolosuite")) {
			doInstallHolosuite();
		} else if (command.equals("recreationUninstallHolosuite")) {
			doUninstallHolosuite();
		} else if (command.equals("recreationInstallFusionLamp")) {
			doInstallFusionLamp();
		} else if (command.equals("recreationUninstallFusionLamp")) {
			doUninstallFusionLamp();
		} else if (command.equals("recreationInstallWinterResort")) {
			doInstallWinterResort();
		} else if (command.equals("recreationUninstallWinterResort")) {
			doUninstallWinterResort();
		} else if (command.equals("recreationDismantle")) {
			doDismantleRecreationalHub();
		} else if (command.equals("industrialView")) {
			showIndustrialHubDetail();
		} else if (command.equals("industrialBuild")) {
			doBuildIndustrialHub();
		} else if (command.equals("industrialInstallNanoforge")) {
			showIndustrialNanoforgeMenu();
		} else if (command.equals("industrialInstallCorruptedNanoforge")) {
			doInstallIndustrialCorruptedNanoforge();
		} else if (command.equals("industrialInstallPristineNanoforge")) {
			doInstallIndustrialPristineNanoforge();
		} else if (command.equals("industrialNanoforgeBack") || command.equals("industrialProductionBack")) {
			showIndustrialHubDetail();
		} else if (command.equals("industrialProduction")) {
			showIndustrialProductionMenu();
		} else if (command.equals("industrialToggle")) {
			doToggleIndustrialProduction(params.size() > 1 ? params.get(1).getString(memoryMap) : null);
		} else if (command.equals("industrialUninstallNanoforge")) {
			doUninstallNanoforge();
		} else if (command.equals("industrialInstallBiofactory")) {
			doInstallBiofactory();
		} else if (command.equals("industrialUninstallBiofactory")) {
			doUninstallBiofactory();
		} else if (command.equals("industrialInstallCatalyticCore")) {
			doInstallCatalyticCore();
		} else if (command.equals("industrialUninstallCatalyticCore")) {
			doUninstallCatalyticCore();
		} else if (command.equals("industrialInstallSynchrotronCore")) {
			doInstallSynchrotronCore();
		} else if (command.equals("industrialUninstallSynchrotronCore")) {
			doUninstallSynchrotronCore();
		} else if (command.equals("industrialDismantle")) {
			doDismantleIndustrialHub();
		} else if (command.equals("hydroponicsView")) {
			showHydroponicsHubDetail();
		} else if (command.equals("hydroponicsBuild")) {
			doBuildHydroponicsHub();
		} else if (command.equals("hydroponicsInstallNanites")) {
			doInstallSoilNanites();
		} else if (command.equals("hydroponicsUninstallNanites")) {
			doUninstallSoilNanites();
		} else if (command.equals("hydroponicsInstallLamp")) {
			doInstallBioDomeLamp();
		} else if (command.equals("hydroponicsUninstallLamp")) {
			doUninstallBioDomeLamp();
		} else if (command.equals("hydroponicsDismantle")) {
			doDismantleHydroponicsHub();
		} else if (command.equals("assemblyView")) {
			showAssemblyBayDetail();
		} else if (command.equals("assemblyBuild")) {
			doBuildAssemblyBay();
		} else if (command.equals("assemblyInstallNanoforge")) {
			showAssemblyNanoforgeMenu();
		} else if (command.equals("assemblyInstallCorruptedNanoforge")) {
			doInstallCorruptedNanoforge();
		} else if (command.equals("assemblyInstallPristineNanoforge")) {
			doInstallPristineNanoforge();
		} else if (command.equals("assemblyNanoforgeBack")) {
			showAssemblyBayDetail();
		} else if (command.equals("assemblyUninstallNanoforge")) {
			doUninstallAssemblyNanoforge();
		} else if (command.equals("assemblyInstallAiSystemMenu")) {
			showAssemblyAiSystemMenu();
		} else if (command.equals("assemblyInstallGammaCore")) {
			doInstallAssemblyAiSystem(AssemblyBayModule.AI_SYSTEM_TIER_GAMMA);
		} else if (command.equals("assemblyInstallBetaCore")) {
			doInstallAssemblyAiSystem(AssemblyBayModule.AI_SYSTEM_TIER_BETA);
		} else if (command.equals("assemblyInstallAlphaCore")) {
			doInstallAssemblyAiSystem(AssemblyBayModule.AI_SYSTEM_TIER_ALPHA);
		} else if (command.equals("assemblyAiSystemBack")) {
			showAssemblyBayDetail();
		} else if (command.equals("assemblyUninstallAiSystem")) {
			doUninstallAssemblyAiSystem();
		} else if (command.equals("assemblyDismantle")) {
			doDismantleAssemblyBay();
		} else if (command.equals("assemblyInjectView")) {
			showAssemblyInjectMenu();
		} else if (command.equals("assemblyInjectBack")) {
			showAssemblyBayDetail();
		} else if (command.equals("assemblyInjectTier1")) {
			doInjectCredits(0);
		} else if (command.equals("assemblyInjectTier2")) {
			doInjectCredits(1);
		} else if (command.equals("assemblyInjectTier3")) {
			doInjectCredits(2);
		} else if (command.equals("assemblyInjectTier4")) {
			doInjectCredits(3);
		} else if (command.equals("militaryWardView")) {
			showMilitaryWardDetail();
		} else if (command.equals("militaryWardBuild")) {
			doBuildMilitaryWard();
		} else if (command.equals("militaryWardInstallHolosuite")) {
			doInstallMilitaryWardHolosuite();
		} else if (command.equals("militaryWardUninstallHolosuite")) {
			doUninstallMilitaryWardHolosuite();
		} else if (command.equals("militaryWardInstallDroneReplicator")) {
			doInstallMilitaryWardDroneReplicator();
		} else if (command.equals("militaryWardUninstallDroneReplicator")) {
			doUninstallMilitaryWardDroneReplicator();
		} else if (command.equals("militaryWardInstallAICoreMenu")) {
			showMilitaryWardAICoreMenu();
		} else if (command.equals("militaryWardUninstallAICore")) {
			doUninstallMilitaryWardAICore();
		} else if (command.equals("militaryWardAICoreBack")) {
			showMilitaryWardDetail();
		} else if (command.equals("militaryWardInstallGammaCore")) {
			doInstallMilitaryWardAICore(Commodities.GAMMA_CORE);
		} else if (command.equals("militaryWardInstallBetaCore")) {
			doInstallMilitaryWardAICore(Commodities.BETA_CORE);
		} else if (command.equals("militaryWardInstallAlphaCore")) {
			doInstallMilitaryWardAICore(Commodities.ALPHA_CORE);
		} else if (command.equals("militaryWardTrainingView")) {
			showFleetHQDetail();
		} else if (command.equals("fleetHQBack")) {
			showMainMenu();
		} else if (command.equals("militaryWardTrainingBuildHQ")) {
			doBuildFleetHQ();
		} else if (command.equals("fleetLogisticExpeditionView")) {
			showExpeditionFleetDetail();
		} else if (command.equals("fleetLogisticLogisticView")) {
			showLogisticFleetDetail();
		} else if (command.equals("fleetLogisticPatrolView")) {
			showPatrolFleetDetail();
		} else if (command.equals("fleetLogisticSalvageView")) {
			showSalvageFleetDetail();
		} else if (command.equals("salvageFleetBack")) {
			showFleetHQDetail();
		} else if (command.equals("salvageFleetCrewBay1")) {
			doStartSalvageFleetShipPicker(0);
		} else if (command.equals("salvageFleetCrewBay2")) {
			doStartSalvageFleetShipPicker(1);
		} else if (command.equals("salvageFleetUninstallBay1")) {
			doUninstallSalvageFleetBay(0);
		} else if (command.equals("salvageFleetUninstallBay2")) {
			doUninstallSalvageFleetBay(1);
		} else if (command.equals("expeditionFleetBack")) {
			showFleetHQDetail();
		} else if (command.equals("miningFleetBack")) {
			showFleetHQDetail();
		} else if (command.equals("miningFleetCrewBay1")) {
			doStartMiningFleetShipPicker(0);
		} else if (command.equals("miningFleetCrewBay2")) {
			doStartMiningFleetShipPicker(1);
		} else if (command.equals("miningFleetCrewBay3")) {
			doStartMiningFleetShipPicker(2);
		} else if (command.equals("miningFleetCrewBay4")) {
			doStartMiningFleetShipPicker(3);
		} else if (command.equals("miningFleetUninstallBay1")) {
			doUninstallMiningFleetBay(0);
		} else if (command.equals("miningFleetUninstallBay2")) {
			doUninstallMiningFleetBay(1);
		} else if (command.equals("miningFleetUninstallBay3")) {
			doUninstallMiningFleetBay(2);
		} else if (command.equals("miningFleetUninstallBay4")) {
			doUninstallMiningFleetBay(3);
		} else if (command.equals("logisticBack")) {
			showFleetHQDetail();
		} else if (command.equals("logisticResupplyCrew")) {
			doStartResupplyBayShipPicker();
		} else if (command.equals("logisticResupplyUninstall")) {
			doUninstallResupplyBay();
		} else if (command.equals("logisticCourierCrewBay1")) {
			doStartCourierBayShipPicker(0);
		} else if (command.equals("logisticCourierCrewBay2")) {
			doStartCourierBayShipPicker(1);
		} else if (command.equals("logisticCourierCrewBay3")) {
			doStartCourierBayShipPicker(2);
		} else if (command.equals("logisticCourierCrewBay4")) {
			doStartCourierBayShipPicker(3);
		} else if (command.equals("logisticCourierUninstallBay1")) {
			doUninstallCourierBay(0);
		} else if (command.equals("logisticCourierUninstallBay2")) {
			doUninstallCourierBay(1);
		} else if (command.equals("logisticCourierUninstallBay3")) {
			doUninstallCourierBay(2);
		} else if (command.equals("logisticCourierUninstallBay4")) {
			doUninstallCourierBay(3);
		} else if (command.equals("courierCargoPick")) {
			doCourierCargoPickFromPending();
		} else if (command.equals("courierCargoCancel")) {
			clearCourierPending();
			showLogisticFleetDetail();
		} else if (command.equals("logisticCourierTradeBay1")) {
			doStartCourierTrade(0);
		} else if (command.equals("logisticCourierTradeBay2")) {
			doStartCourierTrade(1);
		} else if (command.equals("logisticCourierTradeBay3")) {
			doStartCourierTrade(2);
		} else if (command.equals("logisticCourierTradeBay4")) {
			doStartCourierTrade(3);
		} else if (command.equals("logisticTradeCrew")) {
			doStartTradeFleetShipPicker();
		} else if (command.equals("logisticTradeUninstall")) {
			doUninstallTradeFleet();
		} else if (command.equals("patrolFleetBack")) {
			showFleetHQDetail();
		} else if (command.equals("patrolFleetCrewBay1")) {
			doStartPatrolFleetShipPicker(0);
		} else if (command.equals("patrolFleetCrewBay2")) {
			doStartPatrolFleetShipPicker(1);
		} else if (command.equals("patrolFleetCrewBay3")) {
			doStartPatrolFleetShipPicker(2);
		} else if (command.equals("patrolFleetCrewBay4")) {
			doStartPatrolFleetShipPicker(3);
		} else if (command.equals("patrolFleetUninstallBay1")) {
			doUninstallPatrolFleetBay(0);
		} else if (command.equals("patrolFleetUninstallBay2")) {
			doUninstallPatrolFleetBay(1);
		} else if (command.equals("patrolFleetUninstallBay3")) {
			doUninstallPatrolFleetBay(2);
		} else if (command.equals("patrolFleetUninstallBay4")) {
			doUninstallPatrolFleetBay(3);
		} else if (command.equals("militaryWardTrainingCrewBay1")) {
			doStartExpeditionBayShipPicker(0);
		} else if (command.equals("militaryWardTrainingCrewBay2")) {
			doStartExpeditionBayShipPicker(1);
		} else if (command.equals("militaryWardTrainingCrewBay3")) {
			doStartExpeditionBayShipPicker(2);
		} else if (command.equals("militaryWardTrainingCrewBay4")) {
			doStartExpeditionBayShipPicker(3);
		} else if (command.equals("militaryWardTrainingUninstall")) {
			doDisbandFleetHQ();
		} else if (command.equals("militaryWardTrainingUninstallBay1")) {
			doUninstallExpeditionBay(0);
		} else if (command.equals("militaryWardTrainingUninstallBay2")) {
			doUninstallExpeditionBay(1);
		} else if (command.equals("militaryWardTrainingUninstallBay3")) {
			doUninstallExpeditionBay(2);
		} else if (command.equals("militaryWardTrainingUninstallBay4")) {
			doUninstallExpeditionBay(3);
		} else if (command.equals("militaryWardDismantle")) {
			doDismantleMilitaryWard();
		} else if (command.equals("charterOpen")) {
			doOpenCourierCharters();
		} else if (command.startsWith("shopping")) {
			if (command.equals("shoppingBack")) {
				showMainMenu();
			} else {
				setCurrentScreen(SCREEN_SHOPPING);
				new playerhq.shopping.ShoppingListScreen(dialog, station).handle(command.substring("shopping".length()).toLowerCase());
			}
		} else if (command.equals("orderCustomProduction")) {
			doOrderCustomProduction();
		} else if (command.equals("confirmDismantle")) {
			showConfirmDismantle();
		} else if (command.equals("doDismantle")) {
			doDismantle();
		}

		if (!command.equals("inventory") && !command.equals("ships")) {
			dialog.setOptionOnEscape("Escape", OPT_ESCAPE);
		}

		return true;
	}

	private String getSkinLabel() {
		return ConstructPlayerHQAbility.isExistingStationLowTech(station) ? "Low-Tech" : "High-Tech";
	}

	private void updateColonyInfoDescription() {
		Description desc = Global.getSettings().getDescription(station.getCustomDescriptionId(), Description.Type.CUSTOM);
		if (desc == null) return;

		desc.setText1(getColonyInfoText());
	}

	private String getColonyInfoText() {
		MarketAPI colonizedMarket = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (colonizedMarket != null) {
			return "The station sits in orbit above " + colonizedMarket.getName()
					+ ", its drones busy with assisting the colony and resource collection.";
		}

		SectorEntityToken focus = station.getOrbitFocus();
		if (focus instanceof PlanetAPI) {
			return "The station sits in orbit, " + focus.getName()
					+ " silent below as the station's drones buzz around with resource collection.";
		}

		if (focus != null) {
			return "The station drifts among the space rocks as drones buzz busily by, small asteroids "
					+ "plinking off the station's armor from time to time.";
		}

		return "The station drifts alone in open space, its drones running quiet maintenance loops.";
	}

	private void restoreDefaultVisual() {
		InteractionDialogImageVisual defaultVisual = station.getCustomInteractionDialogImageVisual();
		if (defaultVisual != null) {
			visual.showImageVisual(defaultVisual);
		}
	}

	private void setCurrentScreen(String screenId) {
		if (!SCREEN_MAIN.equals(screenId)) mainKeysOwner = null;
		station.getMemoryWithoutUpdate().set(CURRENT_SCREEN_MEMORY_KEY, screenId);
	}

	private void doEscape() {
		String screen = station.getMemoryWithoutUpdate().getString(CURRENT_SCREEN_MEMORY_KEY);
		if (screen == null) screen = SCREEN_MAIN;

		if (SCREEN_MODULES.equals(screen)) {
			showMainMenu();
		} else if (SCREEN_MINING.equals(screen) || SCREEN_RECREATION.equals(screen) || SCREEN_INDUSTRIAL.equals(screen)
				|| SCREEN_HYDROPONICS.equals(screen) || SCREEN_ASSEMBLY.equals(screen) || SCREEN_MILITARYWARD.equals(screen)) {
			showModulesMenu();
		} else if (SCREEN_ASSEMBLY_NANOFORGE.equals(screen) || SCREEN_ASSEMBLY_INJECT.equals(screen)
				|| SCREEN_ASSEMBLY_AISYSTEM.equals(screen)) {
			showAssemblyBayDetail();
		} else if (SCREEN_INDUSTRIAL_NANOFORGE.equals(screen) || SCREEN_INDUSTRIAL_PRODUCTION.equals(screen)) {
			showIndustrialHubDetail();
		} else if (SCREEN_FLEET_HQ.equals(screen)) {
			showMainMenu();
		} else if (SCREEN_MILITARYWARD_AICORE.equals(screen)) {
			showMilitaryWardDetail();
		} else if (SCREEN_CHARTER.equals(screen)) {
			showMainMenu();
		} else if (SCREEN_EXPEDITION_FLEET.equals(screen)
				|| SCREEN_LOGISTIC_FLEET.equals(screen) || SCREEN_PATROL_FLEET.equals(screen)) {
			showFleetHQDetail();
		} else if (SCREEN_MINING_FLEET.equals(screen) || SCREEN_SALVAGE_FLEET.equals(screen)) {
			showFleetHQDetail();
		} else if (SCREEN_STATION_ITEMS.equals(screen) || SCREEN_CONFIRM_DISMANTLE.equals(screen)
				|| SCREEN_SHOPPING.equals(screen)) {
			showMainMenu();
		} else {
			dialog.dismiss();
		}
	}

	private void showMainMenu() {
		restoreDefaultVisual();
		setCurrentScreen(SCREEN_MAIN);

		text.addPara("The Player HQ station (" + getSkinLabel() + ") floats silently, its automated "
				+ "systems standing ready to receive you.");

		addStorageSummary();

		options.clearOptions();
		options.addOption("Access station inventory", OPT_INVENTORY,
				"Transfer cargo between your fleet and the station's storage.");
		options.addOption("Manage Fleet [F] or Refit [R]", OPT_SHIPS,
				"Store or Refit ships using the station's hanger space.");
		options.addOption("Modules", OPT_MODULES,
				"Build modules that expand what this station can do.");

		boolean militaryWardBuilt = MilitaryWardModule.isBuilt(station);
		boolean fleetHQBuilt = MilitaryWardModule.hasFleetHQBuilt(station);
		options.addOption(fleetHQBuilt ? "Fleet HQ" : "Set Up Fleet HQ", OPT_MILITARYWARD_TRAINING_VIEW,
				!militaryWardBuilt
						? "Requires the Military Paradigm module. Build one under Modules."
						: fleetHQBuilt
								? "View the Fleet HQ's Expedition, Logistic, and Patrol Fleets, or dismantle it."
								: "Build a Fleet HQ, unlocking the Expedition Fleet, Logistic Fleet, and Patrol Fleet.");
		options.setEnabled(OPT_MILITARYWARD_TRAINING_VIEW, militaryWardBuilt);

		boolean assemblyBuilt = AssemblyBayModule.isBuilt(station);
		options.addOption("Order Custom Production", OPT_ORDER_CUSTOM_PRODUCTION, assemblyBuilt
				? "Search the Strategic Assembly's catalog of known ship and weapon designs and order one directly."
				: "Requires the Strategic Assembly module. Build one under Modules.");
		options.setEnabled(OPT_ORDER_CUSTOM_PRODUCTION, assemblyBuilt);

		boolean marketPlaceBuilt = MarketPlaceModule.isBuilt(station);
		options.addOption("Shopping List", playerhq.shopping.ShoppingListScreen.OPT_OPEN, marketPlaceBuilt
				? "Set a list of ships and items for the Exchange and the Trade Fleet to buy automatically."
				: "Requires the Market Place. Build one under Station Upgrades.");
		options.setEnabled(playerhq.shopping.ShoppingListScreen.OPT_OPEN, marketPlaceBuilt);

		boolean courierCrewed = MilitaryWardModule.getCourierBayCount(station) > 0;
		options.addOption("Courier Charters", OPT_CHARTER_OPEN, courierCrewed
				? "Choose the colonies your Courier Fleets collect from and what each of your locations should be kept stocked with."
				: "Requires a crewed Courier Bay. Crew one under Fleet HQ, Logistic Fleet.");
		options.setEnabled(OPT_CHARTER_OPEN, courierCrewed);

		options.addOption("Station Upgrades", OPT_STATION_ITEMS,
				"Upgrades the station to be more accessible to the planet's colonist improving accessibility.");
		options.addOption("Leave", OPT_LEAVE);

		options.setShortcut(OPT_INVENTORY, Keyboard.KEY_I, false, false, false, true);
		options.setShortcut(OPT_MODULES, Keyboard.KEY_M, false, false, false, true);
		if (militaryWardBuilt) {
			options.setShortcut(OPT_MILITARYWARD_TRAINING_VIEW, Keyboard.KEY_H, false, false, false, true);
		}
		if (assemblyBuilt) {
			options.setShortcut(OPT_ORDER_CUSTOM_PRODUCTION, Keyboard.KEY_O, false, false, false, true);
		}
		if (marketPlaceBuilt) {
			options.setShortcut(playerhq.shopping.ShoppingListScreen.OPT_OPEN, Keyboard.KEY_S, false, false, false, true);
		}
		if (courierCrewed) {
			options.setShortcut(OPT_CHARTER_OPEN, Keyboard.KEY_C, false, false, false, true);
		}
		options.setShortcut(OPT_STATION_ITEMS, Keyboard.KEY_Q, false, false, false, true);
		options.setShortcut(OPT_LEAVE, Keyboard.KEY_L, false, false, false, true);

		dialog.setPromptText("Player HQ");
		activateMainMenuKeys();
	}

	private static PlayerHQStationCMD mainKeysOwner;
	private static MainMenuKeyScript mainKeyScript;
	private static Object mainKeyScriptSector;

	private void activateMainMenuKeys() {
		mainKeysOwner = this;
		Object sector = Global.getSector();
		if (mainKeyScript == null || mainKeyScriptSector != sector) {
			mainKeyScript = new MainMenuKeyScript();
			mainKeyScriptSector = sector;
			Global.getSector().addTransientScript(mainKeyScript);
		}
	}

	private static class MainMenuKeyScript implements EveryFrameScript {
		private boolean prevF;
		private boolean prevR;

		@Override
		public boolean isDone() {
			return false;
		}

		@Override
		public boolean runWhilePaused() {
			return true;
		}

		@Override
		public void advance(float amount) {
			boolean f = Keyboard.isKeyDown(Keyboard.KEY_F);
			boolean r = Keyboard.isKeyDown(Keyboard.KEY_R);
			boolean fPressed = f && !prevF;
			boolean rPressed = r && !prevR;
			prevF = f;
			prevR = r;

			PlayerHQStationCMD o = mainKeysOwner;
			if (o == null) return;
			if (Global.getSector().getCampaignUI().getCurrentInteractionDialog() != o.dialog) {
				mainKeysOwner = null;
				return;
			}
			if (rPressed) {
				mainKeysOwner = null;
				o.showShips(CoreUITabId.REFIT);
			} else if (fPressed) {
				mainKeysOwner = null;
				o.showShips(CoreUITabId.FLEET);
			}
		}
	}

	private void addStorageSummary() {
		if (station.getMarket() == null) return;
		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		String[][][] rows = {
				{ { Commodities.ORE, "Ore" }, { Commodities.RARE_ORE, "Rare Ore" }, { Commodities.VOLATILES, "Volatiles" } },
				{ { Commodities.METALS, "Metals" }, { Commodities.RARE_METALS, "Transplutonics" } },
				{ { Commodities.HEAVY_MACHINERY, "Heavy Machinery" }, { Commodities.SUPPLIES, "Supplies" }, { Commodities.FUEL, "Fuel" } },
				{ { Commodities.ORGANICS, "Organics" }, { Commodities.FOOD, "Food" } },
				{ { Commodities.DOMESTIC_GOODS, "Domestic Goods" }, { Commodities.LUXURY_GOODS, "Luxury Goods" } },
				{ { Commodities.HAND_WEAPONS, "Heavy Armaments" }, { "marines", "Marines" } },
				{ { "crew", "Crew" }, { Commodities.DRUGS, "Drugs" }, { Commodities.ORGANS, "Organs" } },
		};

		List<String> lines = new ArrayList<String>();
		for (String[][] row : rows) {
			List<String> parts = new ArrayList<String>();
			for (String[] entry : row) {
				int qty;
				if ("crew".equals(entry[0])) qty = storage.getCrew();
				else if ("marines".equals(entry[0])) qty = storage.getMarines();
				else qty = (int) storage.getCommodityQuantity(entry[0]);
				if (qty > 0) parts.add(entry[1] + ": " + qty);
			}
			if (!parts.isEmpty()) lines.add(joinSummaryParts(parts));
		}

		String queueLine = null;
		if (AssemblyBayModule.isBuilt(station)) {
			List<AssemblyBayModule.ProductionOrder> queue = AssemblyBayModule.getQueue(station);
			if (queue.isEmpty()) {
				queueLine = "Production queue: empty   |   Production pool: " + (int) AssemblyBayModule.getPoolValue(station)
						+ " / " + (int) AssemblyBayModule.getPoolMax(station) + " credits";
			} else {
				int days = Math.max(1, (int) Math.ceil(AssemblyBayModule.getDaysRemaining(station)));
				queueLine = "Production queue: " + queue.get(0).name + " (" + days + (days == 1 ? " day" : " days") + " left)";
			}
		}

		if (lines.isEmpty() && queueLine == null) return;

		if (!lines.isEmpty()) text.addPara("Station storage:");
		text.setFontSmallInsignia();
		for (String line : lines) text.addPara(line);
		if (queueLine != null) text.addPara(queueLine);
		text.setFontVictor();
	}

	private static String joinSummaryParts(List<String> parts) {
		return joinSummaryParts(parts, "   |   ");
	}

	private static String joinSummaryParts(List<String> parts, String sep) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < parts.size(); i++) {
			if (i > 0) sb.append(sep);
			sb.append(parts.get(i));
		}
		return sb.toString();
	}

	private void showInventory() {
		mainKeysOwner = null;
		options.clearOptions();
		dialog.setPromptText("");
		dialog.setOptionOnEscape(null, null);

		final MilitaryWardModule.MarineTransferSnapshot marineSnapshot =
				MilitaryWardModule.snapshotMarineXP(station, playerFleet);

		visual.showCore(CoreUITabId.CARGO, station, new CoreInteractionListener() {
			@Override
			public void coreUIDismissed() {
				MilitaryWardModule.enforceCap(station);
				MilitaryWardModule.reconcileMarineTransfer(station, playerFleet, marineSnapshot);
				dialog.setOptionOnEscape("Escape", OPT_ESCAPE);
				showMainMenu();
			}
		});
	}

	private void showShips(CoreUITabId tab) {
		mainKeysOwner = null;
		options.clearOptions();
		dialog.setPromptText("");
		dialog.setOptionOnEscape(null, null);

		visual.showCore(tab, station, new CoreInteractionListener() {
			@Override
			public void coreUIDismissed() {
				dialog.setOptionOnEscape("Escape", OPT_ESCAPE);
				showMainMenu();
			}
		});
	}

	private void showModulesMenu() {
		restoreDefaultVisual();
		setCurrentScreen(SCREEN_MODULES);

		text.addPara("Select a module to build or review.");

		boolean miningBuilt = MiningHangarModule.isBuilt(station);
		boolean recreationBuilt = RecreationalHubModule.isBuilt(station);
		boolean recreationAvailable = recreationBuilt || RecreationalHubModule.canBuild(station);

		options.clearOptions();
		options.addOption("Materials Acquisition Hub" + (miningBuilt ? " (Built)" : ""), OPT_MINING_VIEW,
				"Collects a share of the system's ore, rare ore, volatiles, and organics every month.");
		if (recreationAvailable) {
			options.addOption("Resort" + (recreationBuilt ? " (Built)" : ""), OPT_RECREATION_VIEW,
					"Lets colonists from a nearby colonized planet visit the station, generating income "
					+ "every month. Only buildable while orbiting a colonized planet.");
		} else {
			options.addOption("Resort (Requires orbit of a colonized planet)", OPT_RECREATION_VIEW);
			options.setEnabled(OPT_RECREATION_VIEW, false);
		}

		boolean industrialBuilt = IndustrialHubModule.isBuilt(station);
		options.addOption("Manufactorium" + (industrialBuilt ? " (Built)" : ""), OPT_INDUSTRIAL_VIEW,
				"Refines ore and rare ore into metals and transplutonics, and produces heavy machinery "
				+ "and supplies, every month.");

		boolean hydroponicsBuilt = HydroponicsHubModule.isBuilt(station);
		options.addOption("Bio-Dome" + (hydroponicsBuilt ? " (Built)" : ""), OPT_HYDROPONICS_VIEW,
				"Produces food and organics every month.");

		boolean assemblyBuilt = AssemblyBayModule.isBuilt(station);
		options.addOption("Strategic Assembly" + (assemblyBuilt ? " (Built)" : ""), OPT_ASSEMBLY_VIEW,
				"Allows construction of ships and weapons from known blueprints, funded by a production "
				+ "capacity that grows over time.");

		boolean militaryWardBuilt = MilitaryWardModule.isBuilt(station);
		options.addOption("Military Paradigm" + (militaryWardBuilt ? " (Built)" : ""), OPT_MILITARYWARD_VIEW,
				"Slowly produces Crew and Marines, up to a cap, and can train stored Marines over time.");

		options.addOption("Back", OPT_MODULES_BACK);

		dialog.setPromptText("Player HQ - Modules");
	}

	private void showMiningHangarDetail() {
		setCurrentScreen(SCREEN_MINING);
		try {
			Global.getSettings().loadTexture(MiningHangarModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(MiningHangarModule.IMAGE_PATH, 480, 300));

		boolean built = MiningHangarModule.isBuilt(station);

		if (built) {
			text.addPara(String.format("The Materials Acquisition Hub is operational, harvesting %s%% from its "
					+ "orbiting body's deposits.",
					Math.round(MiningHangarModule.getCombinedEfficiency(station) * 100f)));

			for (String line : MiningHangarModule.getExpectedMonthlyHarvest(station)) {
				text.addPara(line);
			}

			int miningFleetMax = MilitaryWardModule.getMaxMiningFleetBays(station);
			int miningFleetCount = MilitaryWardModule.getMiningFleetBayCount(station);
			text.addPara(String.format("Mining Fleet bays %s/%s, fanning out to mine other planets and "
					+ "belts/fields in the system, and, with a Tanker, planets in nearby systems.", miningFleetCount, miningFleetMax));
			for (int i = 0; i < miningFleetMax; i++) {
				if (!MilitaryWardModule.isMiningFleetBayBuilt(station, i)) continue;
				text.addPara("Bay " + (i + 1) + ": " + MilitaryWardModule.getMiningFleetBayStatusText(station, i) + ".");
			}

			text.addPara(String.format("Salvage Fleet bays %s/%s, roaming the sector to salvage debris fields and "
					+ "recover derelict ships.", MilitaryWardModule.getSalvageFleetBayCount(station), MilitaryWardModule.MAX_SALVAGE_FLEET_BAYS));
			for (int i = 0; i < MilitaryWardModule.MAX_SALVAGE_FLEET_BAYS; i++) {
				if (!MilitaryWardModule.isSalvageFleetBayBuilt(station, i)) continue;
				text.addPara("Salvage Bay " + (i + 1) + ": " + MilitaryWardModule.getSalvageFleetBayStatusText(station, i) + ".");
			}

			if (station.getMarket() != null) {
				CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
				text.addPara(String.format("Current storage: %s/%s ore, %s/%s rare ore, "
						+ "%s/%s volatiles, %s/%s organics.",
						(int) storage.getCommodityQuantity(Commodities.ORE), (int) MiningHangarModule.getStorageCap(Commodities.ORE),
						(int) storage.getCommodityQuantity(Commodities.RARE_ORE), (int) MiningHangarModule.getStorageCap(Commodities.RARE_ORE),
						(int) storage.getCommodityQuantity(Commodities.VOLATILES), (int) MiningHangarModule.getStorageCap(Commodities.VOLATILES),
						(int) storage.getCommodityQuantity(Commodities.ORGANICS), (int) MiningHangarModule.getStorageCap(Commodities.ORGANICS)));
			}
		} else {
			text.addPara("Build a Materials Acquisition Hub to automatically collect a share of the ore, rare ore, "
					+ "volatiles, and organics available from bodies in this system every month, "
					+ "deposited straight into the station's storage.");
			text.addPara(String.format("Costs %s metals, %s transplutonics, %s volatiles, and %s heavy machinery.",
					(int) MiningHangarModule.METALS_COST, (int) MiningHangarModule.TRANSPLUTONICS_COST,
					(int) MiningHangarModule.VOLATILES_COST, (int) MiningHangarModule.HEAVY_MACHINERY_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Materials Acquisition Hub", OPT_MINING_BUILD);
			options.setEnabled(OPT_MINING_BUILD, MiningHangarModule.hasCost(station, playerFleet));
		} else {
			int miningFleetCount = MilitaryWardModule.getMiningFleetBayCount(station)
					+ MilitaryWardModule.getSalvageFleetBayCount(station);
			options.addOption("Dismantle Materials Acquisition Hub", OPT_MINING_DISMANTLE,
					miningFleetCount == 0
							? "Refunds half of the metals, transplutonics, volatiles, and heavy machinery spent to build it."
							: "Uninstall every Mining and Salvage Fleet bay first.");
			options.setEnabled(OPT_MINING_DISMANTLE, MiningHangarModule.canDismantle(station));
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Materials Acquisition Hub");
	}

	private void doBuildMiningHangar() {
		if (MiningHangarModule.isBuilt(station) || !MiningHangarModule.hasCost(station, playerFleet)) {
			showMiningHangarDetail();
			return;
		}

		MiningHangarModule.build(station, playerFleet);
		text.addPara("The Materials Acquisition Hub is now operational.");

		showMiningHangarDetail();
	}

	private void doDismantleMiningHangar() {
		if (!MiningHangarModule.canDismantle(station)) {
			showMiningHangarDetail();
			return;
		}

		MiningHangarModule.dismantle(station, playerFleet);
		text.addPara("The Materials Acquisition Hub has been dismantled, and half its resource cost returned to the station's inventory.");

		showMiningHangarDetail();
	}

	private void showRecreationalHubDetail() {
		setCurrentScreen(SCREEN_RECREATION);
		String imagePath = RecreationalHubModule.getRandomImagePath();
		try {
			Global.getSettings().loadTexture(imagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(imagePath, 480, 300));

		boolean built = RecreationalHubModule.isBuilt(station);
		boolean holosuiteInstalled = RecreationalHubModule.hasHolosuiteInstalled(station);
		boolean fusionLampInstalled = RecreationalHubModule.hasFusionLampInstalled(station);
		boolean winterResortInstalled = RecreationalHubModule.hasWinterResortInstalled(station);

		if (built) {
			float income = RecreationalHubModule.getFinalIncome(station);
			float bonusPercent = (RecreationalHubModule.getIncomeMultiplier(station) - 1f) * 100f;
			text.addPara(String.format("The Resort is operational, drawing colonists from the "
					+ "nearby colony to spend their credits at the station. Currently generating %s credits "
					+ "per month (+%s%% bonus from installed upgrades).", (int) income, Math.round(bonusPercent)));
			text.addPara(String.format("Station Accessibility: %s%% (income is scaled by this percentage; "
					+ "100%% would mean full base income). See Station Upgrades for what's contributing to it.",
					Math.round(StationItemsModule.getAccessibility(station))));
			if (!holosuiteInstalled) {
				text.addPara(String.format("Installing VR Suites would boost income by %s%%.",
						Math.round(RecreationalHubModule.getHolosuiteBonus(station) * 100f)));
			} else {
				text.addPara(String.format("VR Suites are used to get away from the harsh realities of living in "
							+ "harsh conditions, gives a %s%% based on the planets hazard rating above 100%%, "
							+ "anything below that is 10%%.",
						Math.round(RecreationalHubModule.getHolosuiteBonus(station) * 100f)));
			}
			if (!fusionLampInstalled) {
				text.addPara(String.format("Building a Beach Resort would boost income by %s%%.",
						Math.round(RecreationalHubModule.getFusionLampBonus(station) * 100f)));
			} else {
				text.addPara(String.format("A Beach Resort is built, simulating a tropical paradise for colonists "
						+ "to relax and swim. %s%% bonus to Resort income.",
							Math.round(RecreationalHubModule.getFusionLampBonus(station) * 100f)));
				}
				if (!winterResortInstalled) {
					text.addPara(String.format("Building a Winter Resort would boost income by %s%%.",
							Math.round(RecreationalHubModule.getWinterResortBonus(station) * 100f)));
				} else {
					text.addPara(String.format("A Winter Resort is built, offering colonists a winter wonderland to escape "
							+ "the heat. %s%% bonus to Resort income. (very popular with Hot and Very Hot planets)",
							Math.round(RecreationalHubModule.getWinterResortBonus(station) * 100f)));
				}
		} else {
			text.addPara("Build a Resort to let colonists from the nearby colonized planet visit "
					+ "the station, generating income every month based on the colony's size.");
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics, %s volatiles, %s "
					+ "heavy machinery, and %s Crew (from the station's own storage) to staff it.",
					(int) RecreationalHubModule.CREDIT_COST, (int) RecreationalHubModule.METALS_COST,
					(int) RecreationalHubModule.TRANSPLUTONICS_COST, (int) RecreationalHubModule.VOLATILES_COST,
					(int) RecreationalHubModule.HEAVY_MACHINERY_COST, RecreationalHubModule.CREW_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Resort", OPT_RECREATION_BUILD);
			options.setEnabled(OPT_RECREATION_BUILD, RecreationalHubModule.canBuild(station)
					&& RecreationalHubModule.hasCost(station, playerFleet));
		} else {
			if (!holosuiteInstalled) {
				options.addOption("Install VR Suites", OPT_RECREATION_INSTALL_HOLOSUITE,
						String.format("Requires one Dealmaker Holosuite. Boosts Resort income by %s%%.",
								Math.round(RecreationalHubModule.getHolosuiteBonus(station) * 100f)));
				options.setEnabled(OPT_RECREATION_INSTALL_HOLOSUITE,
						RecreationalHubModule.hasHolosuiteAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall VR Suites", OPT_RECREATION_UNINSTALL_HOLOSUITE,
						String.format("Removes the VR Suites (and their +%s%% Resort income bonus) and returns "
								+ "the Holosuite to the station's inventory.",
								Math.round(RecreationalHubModule.getHolosuiteBonus(station) * 100f)));
			}
			if (!fusionLampInstalled) {
				options.addOption("Build Beach Resort", OPT_RECREATION_INSTALL_FUSIONLAMP,
						String.format("Requires one Orbital Fusion Lamp, %s organics and %s credits, upkeep 2 Volatiles a month. "
								+ "Boosts Resort income by %s%%.",
								(int) RecreationalHubModule.BEACH_RESORT_ORGANICS_COST,
								(int) RecreationalHubModule.BEACH_RESORT_CREDIT_COST,
								Math.round(RecreationalHubModule.getFusionLampBonus(station) * 100f)));
				options.setEnabled(OPT_RECREATION_INSTALL_FUSIONLAMP,
						RecreationalHubModule.hasBeachResortCost(station, playerFleet));
			} else {
				options.addOption("Remove Beach Resort", OPT_RECREATION_UNINSTALL_FUSIONLAMP,
						String.format("Removes the Beach Resort (and its +%s%% Resort income bonus) and returns "
								+ "the Fusion Lamp to the station's inventory.",
									Math.round(RecreationalHubModule.getFusionLampBonus(station) * 100f)));
				}
				if (!winterResortInstalled) {
					options.addOption("Build Winter Resort", OPT_RECREATION_INSTALL_WINTERRESORT,
							String.format("Requires one Cryoarithmetic Engine. Boosts Resort income by %s%%.",
									Math.round(RecreationalHubModule.getWinterResortBonus(station) * 100f)));
					options.setEnabled(OPT_RECREATION_INSTALL_WINTERRESORT,
							RecreationalHubModule.hasWinterResortCost(station, playerFleet));
				} else {
					options.addOption("Remove Winter Resort", OPT_RECREATION_UNINSTALL_WINTERRESORT,
							String.format("Removes the Winter Resort (and its +%s%% Resort income bonus) and returns "
									+ "the Cryoarithmetic Engine to the station's inventory.",
									Math.round(RecreationalHubModule.getWinterResortBonus(station) * 100f)));
				}

			List<String> recreationBlockers = new ArrayList<String>();
			if (holosuiteInstalled) recreationBlockers.add("VR Suites");
			if (fusionLampInstalled) recreationBlockers.add("Beach Resort");
				if (winterResortInstalled) recreationBlockers.add("Winter Resort");
			options.addOption("Dismantle Resort", OPT_RECREATION_DISMANTLE,
					recreationBlockers.isEmpty()
							? "Refunds half of the resources spent to build it, and its staffing Crew in full."
							: "Remove the following first: " + String.join(", ", recreationBlockers) + ".");
			options.setEnabled(OPT_RECREATION_DISMANTLE, RecreationalHubModule.canDismantle(station));
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Resort");
	}

	private void doBuildRecreationalHub() {
		if (RecreationalHubModule.isBuilt(station) || !RecreationalHubModule.canBuild(station)
				|| !RecreationalHubModule.hasCost(station, playerFleet)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.build(station, playerFleet);
		text.addPara("The Resort is now operational.");

		showRecreationalHubDetail();
	}

	private void doInstallHolosuite() {
		if (!RecreationalHubModule.isBuilt(station) || RecreationalHubModule.hasHolosuiteInstalled(station)
				|| !RecreationalHubModule.hasHolosuiteAvailable(station, playerFleet)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.installHolosuite(station, playerFleet);
		text.addPara("VR Suites have been installed in the Resort.");

		showRecreationalHubDetail();
	}

	private void doUninstallHolosuite() {
		if (!RecreationalHubModule.isBuilt(station) || !RecreationalHubModule.hasHolosuiteInstalled(station)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.uninstallHolosuite(station, playerFleet);
		text.addPara("The VR Suites have been removed from the Resort and the Holosuite returned to the station's inventory.");

		showRecreationalHubDetail();
	}

	private void doInstallFusionLamp() {
		if (!RecreationalHubModule.isBuilt(station) || RecreationalHubModule.hasFusionLampInstalled(station)
				|| !RecreationalHubModule.hasBeachResortCost(station, playerFleet)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.installFusionLamp(station, playerFleet);
		text.addPara("The Beach Resort has been built.");

		showRecreationalHubDetail();
	}

	private void doUninstallFusionLamp() {
		if (!RecreationalHubModule.isBuilt(station) || !RecreationalHubModule.hasFusionLampInstalled(station)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.uninstallFusionLamp(station, playerFleet);
		text.addPara("The Beach Resort has been removed and the Fusion Lamp returned to the station's inventory.");

		showRecreationalHubDetail();
	}

	private void doInstallWinterResort() {
		if (!RecreationalHubModule.isBuilt(station) || RecreationalHubModule.hasWinterResortInstalled(station)
				|| !RecreationalHubModule.hasWinterResortCost(station, playerFleet)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.installWinterResort(station, playerFleet);
		text.addPara("The Winter Resort has been built.");

		showRecreationalHubDetail();
	}

	private void doUninstallWinterResort() {
		if (!RecreationalHubModule.isBuilt(station) || !RecreationalHubModule.hasWinterResortInstalled(station)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.uninstallWinterResort(station, playerFleet);
		text.addPara("The Winter Resort has been removed and the Cryoarithmetic Engine returned to the station's inventory.");

		showRecreationalHubDetail();
	}

	private void doDismantleRecreationalHub() {
		if (!RecreationalHubModule.canDismantle(station)) {
			showRecreationalHubDetail();
			return;
		}

		RecreationalHubModule.dismantle(station, playerFleet);
		text.addPara("The Resort has been dismantled, and half its resource cost (plus its staffing Crew, in full) returned to the station's inventory.");

		showRecreationalHubDetail();
	}

	private void showIndustrialHubDetail() {
		setCurrentScreen(SCREEN_INDUSTRIAL);
		try {
			Global.getSettings().loadTexture(IndustrialHubModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(IndustrialHubModule.IMAGE_PATH, 480, 300));

		boolean built = IndustrialHubModule.isBuilt(station);
		boolean nanoforgeInstalled = IndustrialHubModule.hasNanoforgeInstalled(station);
		boolean biofactoryInstalled = IndustrialHubModule.hasBiofactoryInstalled(station);
		boolean catalyticCoreInstalled = IndustrialHubModule.hasCatalyticCoreInstalled(station);
		boolean synchrotronCoreInstalled = IndustrialHubModule.hasSynchrotronCoreInstalled(station);

		if (built) {
			text.addPara("The Manufactorium is operational, refining ores and producing Heavy Machinery and Supplies.");

			String oreCatalyticNote = catalyticCoreInstalled
					? String.format(" (Catalytic Core -%s/+%s Consumed/Produced.)",
							(int) IndustrialHubModule.CATALYTIC_CORE_ORE_REDUCTION, (int) IndustrialHubModule.CATALYTIC_CORE_METAL_OUTPUT_BONUS)
					: ".";
			String rareOreCatalyticNote = catalyticCoreInstalled
					? String.format(" (Catalytic Core -%s/+%s Consumed/Produced.)",
							(int) IndustrialHubModule.CATALYTIC_CORE_RARE_ORE_REDUCTION, (int) IndustrialHubModule.CATALYTIC_CORE_TRANSPLUTONICS_OUTPUT_BONUS)
					: ".";
			text.setFontSmallInsignia();
			text.addPara(String.format("%s Ore -> %s Metals%s\n"
					+ "%s Rare Ore -> %s Rare Metals%s\n"
					+ "%s Metals + %s Transplutonics -> %s Heavy Machinery.\n"
					+ "%s Organics + %s Metals + %s Transplutonics + %s Volatiles + %s Food -> %s Supplies.",
					(int) IndustrialHubModule.ORE_PER_METAL, (int) IndustrialHubModule.METALS_OUTPUT_PER_BATCH_BASE, oreCatalyticNote,
					(int) IndustrialHubModule.RARE_ORE_PER_TRANSPLUTONIC, (int) IndustrialHubModule.TRANSPLUTONICS_OUTPUT_PER_BATCH_BASE, rareOreCatalyticNote,
					(int) IndustrialHubModule.HEAVY_MACHINERY_METALS_COST, (int) IndustrialHubModule.HEAVY_MACHINERY_TRANSPLUTONICS_COST,
					(int) IndustrialHubModule.HEAVY_MACHINERY_BATCH_OUTPUT,
					(int) IndustrialHubModule.SUPPLIES_BATCH_ORGANICS_COST, (int) IndustrialHubModule.SUPPLIES_BATCH_METALS_COST,
					(int) IndustrialHubModule.SUPPLIES_BATCH_TRANSPLUTONICS_COST, (int) IndustrialHubModule.SUPPLIES_BATCH_VOLATILES_COST,
					(int) IndustrialHubModule.SUPPLIES_BATCH_FOOD_COST, (int) IndustrialHubModule.SUPPLIES_BATCH_OUTPUT));
			text.setFontVictor();

			if (catalyticCoreInstalled) {
				text.addPara("A Catalytic Core is installed improving refinement.");
			}
			if (synchrotronCoreInstalled) {
				text.addPara("A Synchrotron Core is installed, allowing production of Fuel from Volatiles.");
			}
			float fuelMult = IndustrialHubModule.getSynchrotronResourceMultiplier(station);
			text.setFontSmallInsignia();
			text.addPara(String.format("%s Volatiles -> %s Fuel.",
					(int) (IndustrialHubModule.VOLATILES_PER_FUEL_BATCH * fuelMult), (int) IndustrialHubModule.FUEL_PER_BATCH));
			text.setFontVictor();
			if (nanoforgeInstalled) {
				boolean corrupted = IndustrialHubModule.isCorruptedNanoforgeInstalled(station);
				text.addPara((corrupted ? "A Corrupted Nanoforge" : "A Pristine Nanoforge")
						+ " is installed, allowing production of Domestic Goods, Luxury Goods, and Heavy "
						+ "Armaments." + (corrupted ? " Corrupted Nanoforge doubles the required resources." : ""));
			}
			float nanoforgeMult = IndustrialHubModule.getNanoforgeResourceMultiplier(station);
			text.setFontSmallInsignia();
			text.addPara(String.format("%s Metals + %s Transplutonics + %s Organics -> %s Domestic Goods.\n"
					+ "%s Metals + %s Transplutonics + %s Organics + %s Drugs -> %s Luxury Goods.\n"
					+ "%s Metals + %s Transplutonics + %s Volatiles -> %s Heavy Armaments.",
					(int) (IndustrialHubModule.DOMESTIC_GOODS_BATCH_METALS_COST * nanoforgeMult), (int) (IndustrialHubModule.DOMESTIC_GOODS_BATCH_TRANSPLUTONICS_COST * nanoforgeMult),
					(int) (IndustrialHubModule.DOMESTIC_GOODS_BATCH_ORGANICS_COST * nanoforgeMult), (int) IndustrialHubModule.DOMESTIC_GOODS_BATCH_OUTPUT,
					(int) (IndustrialHubModule.LUXURY_GOODS_BATCH_METALS_COST * nanoforgeMult), (int) (IndustrialHubModule.LUXURY_GOODS_BATCH_TRANSPLUTONICS_COST * nanoforgeMult),
					(int) (IndustrialHubModule.LUXURY_GOODS_BATCH_ORGANICS_COST * nanoforgeMult), (int) (IndustrialHubModule.LUXURY_GOODS_BATCH_DRUGS_COST * nanoforgeMult),
					(int) IndustrialHubModule.LUXURY_GOODS_BATCH_OUTPUT,
					(int) (IndustrialHubModule.HEAVY_ARMAMENTS_BATCH_METALS_COST * nanoforgeMult), (int) (IndustrialHubModule.HEAVY_ARMAMENTS_BATCH_TRANSPLUTONICS_COST * nanoforgeMult),
					(int) (IndustrialHubModule.HEAVY_ARMAMENTS_BATCH_VOLATILES_COST * nanoforgeMult), (int) IndustrialHubModule.HEAVY_ARMAMENTS_BATCH_OUTPUT));
			text.setFontVictor();
			if (biofactoryInstalled) {
				text.addPara("A Biofactory Embryo is installed, allowing production of recreational drugs "
						+ "and organs.");
			}
			float biofactoryMult = IndustrialHubModule.getBiofactoryResourceMultiplier(station);
			text.setFontSmallInsignia();
			text.addPara(String.format("%s Organics + %s Metals + %s Transplutonics -> %s Drugs.\n"
					+ "%s Organics -> %s Organs.",
					(int) (IndustrialHubModule.DRUGS_BATCH_ORGANICS_COST * biofactoryMult), (int) (IndustrialHubModule.DRUGS_BATCH_METALS_COST * biofactoryMult),
					(int) (IndustrialHubModule.DRUGS_BATCH_TRANSPLUTONICS_COST * biofactoryMult), (int) IndustrialHubModule.DRUGS_BATCH_OUTPUT,
					(int) (IndustrialHubModule.ORGANS_BATCH_ORGANICS_COST * biofactoryMult), (int) IndustrialHubModule.ORGANS_BATCH_OUTPUT));
			text.setFontVictor();

			if (station.getMarket() != null) {
				IndustrialHubModule.IndustrialHubResult preview = IndustrialHubModule.previewMonthlyProduction(station);

				List<String> nextMonthParts = new ArrayList<String>();
				nextMonthParts.add((int) preview.metals + " metals");
				nextMonthParts.add((int) preview.transplutonics + " transplutonics");
				nextMonthParts.add((int) preview.heavyMachinery + " heavy machinery");
				nextMonthParts.add((int) preview.supplies + " supplies");
				nextMonthParts.add((int) preview.fuel + " fuel");
				nextMonthParts.add((int) preview.drugs + " drugs");
				nextMonthParts.add((int) preview.organs + " organs");
				nextMonthParts.add((int) preview.domesticGoods + " domestic goods");
				nextMonthParts.add((int) preview.luxuryGoods + " luxury goods");
				nextMonthParts.add((int) preview.heavyArmaments + " heavy armaments");

				text.addPara("Estimated next month: " + String.join(", ", nextMonthParts) + " (current storage).");

				List<String> stoppedProducts = new ArrayList<String>();
				for (String key : IndustrialHubModule.PRODUCT_KEYS) {
					if (IndustrialHubModule.isProductAvailable(station, key) && !IndustrialHubModule.isProductionEnabled(station, key)) {
						stoppedProducts.add(IndustrialHubModule.getProductName(key));
					}
				}
				if (!stoppedProducts.isEmpty()) {
					text.addPara("Production switched off: " + String.join(", ", stoppedProducts) + ".");
				}
			}
		} else {
			text.addPara("Build a Manufactorium to refine the station's stored ore into metals and "
					+ "rare ore into transplutonics every month.");
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics, %s volatiles, and %s "
					+ "heavy machinery.",
					(int) IndustrialHubModule.CREDIT_COST, (int) IndustrialHubModule.METALS_COST,
					(int) IndustrialHubModule.TRANSPLUTONICS_COST, (int) IndustrialHubModule.VOLATILES_COST,
					(int) IndustrialHubModule.HEAVY_MACHINERY_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Manufactorium", OPT_INDUSTRIAL_BUILD);
			options.setEnabled(OPT_INDUSTRIAL_BUILD, IndustrialHubModule.hasCost(station, playerFleet));
		} else {
			if (!nanoforgeInstalled) {
				options.addOption("Install Nanoforge", OPT_INDUSTRIAL_INSTALL_NANOFORGE,
						"Requires one Corrupted or Pristine Nanoforge. Unlocks production of Domestic Goods, "
						+ "Luxury Goods, and Heavy Armaments.");
				options.setEnabled(OPT_INDUSTRIAL_INSTALL_NANOFORGE,
						IndustrialHubModule.hasNanoforgeAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Nanoforge", OPT_INDUSTRIAL_UNINSTALL_NANOFORGE,
						"Removes the Nanoforge and returns it to the station's inventory.");
			}
			if (!biofactoryInstalled) {
				options.addOption("Install Biofactory Embryo", OPT_INDUSTRIAL_INSTALL_BIOFACTORY,
						"Requires one Biofactory Embryo. Unlocks production of recreational drugs and organs.");
				options.setEnabled(OPT_INDUSTRIAL_INSTALL_BIOFACTORY,
						IndustrialHubModule.hasBiofactoryAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Biofactory Embryo", OPT_INDUSTRIAL_UNINSTALL_BIOFACTORY,
						"Removes the Biofactory Embryo and returns it to the station's inventory.");
			}
			if (!catalyticCoreInstalled) {
				options.addOption("Install Catalytic Core", OPT_INDUSTRIAL_INSTALL_CATALYTICCORE,
						String.format("Requires one Catalytic Core. Reduces the ore cost of refining metals "
						+ "(-%s) and boosts metals output per batch (+%s), and reduces the rare ore cost of "
						+ "refining transplutonics (-%s) and boosts transplutonics output per batch (+%s).",
						(int) IndustrialHubModule.CATALYTIC_CORE_ORE_REDUCTION,
						(int) IndustrialHubModule.CATALYTIC_CORE_METAL_OUTPUT_BONUS,
						(int) IndustrialHubModule.CATALYTIC_CORE_RARE_ORE_REDUCTION,
						(int) IndustrialHubModule.CATALYTIC_CORE_TRANSPLUTONICS_OUTPUT_BONUS));
				options.setEnabled(OPT_INDUSTRIAL_INSTALL_CATALYTICCORE,
						IndustrialHubModule.hasCatalyticCoreAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Catalytic Core", OPT_INDUSTRIAL_UNINSTALL_CATALYTICCORE,
						"Removes the Catalytic Core and returns it to the station's inventory.");
			}
			if (!synchrotronCoreInstalled) {
				options.addOption("Install Synchrotron Core", OPT_INDUSTRIAL_INSTALL_SYNCHROTRONCORE,
						"Requires one Synchrotron Core. Unlocks production of Fuel from Volatiles.");
				options.setEnabled(OPT_INDUSTRIAL_INSTALL_SYNCHROTRONCORE,
						IndustrialHubModule.hasSynchrotronCoreAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Synchrotron Core", OPT_INDUSTRIAL_UNINSTALL_SYNCHROTRONCORE,
						"Removes the Synchrotron Core (and its Fuel production) and returns it to the station's inventory.");
			}

			options.addOption("Production Settings", OPT_INDUSTRIAL_PRODUCTION,
					"Turn the monthly production of each individual resource on or off.");

			List<String> industrialBlockers = new ArrayList<String>();
			if (nanoforgeInstalled) industrialBlockers.add("Nanoforge");
			if (biofactoryInstalled) industrialBlockers.add("Biofactory Embryo");
			if (catalyticCoreInstalled) industrialBlockers.add("Catalytic Core");
			if (synchrotronCoreInstalled) industrialBlockers.add("Synchrotron Core");
			options.addOption("Dismantle Manufactorium", OPT_INDUSTRIAL_DISMANTLE,
					industrialBlockers.isEmpty()
							? "Refunds half of the resources spent to build it."
							: "Uninstall the following first: " + String.join(", ", industrialBlockers) + ".");
			options.setEnabled(OPT_INDUSTRIAL_DISMANTLE, IndustrialHubModule.canDismantle(station));
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Manufactorium");
	}

	private void doBuildIndustrialHub() {
		if (IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasCost(station, playerFleet)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.build(station, playerFleet);
		text.addPara("The Manufactorium is now operational.");

		showIndustrialHubDetail();
	}

	private void showIndustrialProductionMenu() {
		if (!IndustrialHubModule.isBuilt(station)) {
			showIndustrialHubDetail();
			return;
		}

		setCurrentScreen(SCREEN_INDUSTRIAL_PRODUCTION);
		try {
			Global.getSettings().loadTexture(IndustrialHubModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(IndustrialHubModule.IMAGE_PATH, 480, 300));
		text.addPara("Choose which resources the Manufactorium produces each month. A resource that is switched "
				+ "off is skipped entirely: its inputs stay in storage for everything else to use.");

		options.clearOptions();
		for (String key : IndustrialHubModule.PRODUCT_KEYS) {
			if (!IndustrialHubModule.isProductAvailable(station, key)) continue;
			boolean enabled = IndustrialHubModule.isProductionEnabled(station, key);
			options.addOption(IndustrialHubModule.getProductName(key) + ": " + (enabled ? "ON" : "OFF"),
					OPT_INDUSTRIAL_TOGGLE_PREFIX + key,
					enabled ? "Currently producing. Select to switch off." : "Currently stopped. Select to switch on.");
		}
		options.addOption("Back", OPT_INDUSTRIAL_PRODUCTION_BACK);

		dialog.setPromptText("Manufactorium - Production Settings");
	}

	private void doToggleIndustrialProduction(String key) {
		boolean valid = false;
		for (String k : IndustrialHubModule.PRODUCT_KEYS) {
			if (k.equals(key)) valid = true;
		}
		if (!valid || !IndustrialHubModule.isBuilt(station)) {
			showIndustrialHubDetail();
			return;
		}

		boolean nowEnabled = IndustrialHubModule.toggleProduction(station, key);
		text.addPara(IndustrialHubModule.getProductName(key) + " production is now "
				+ (nowEnabled ? "switched on." : "switched off."));

		showIndustrialProductionMenu();
	}

	private void showIndustrialNanoforgeMenu() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasNanoforgeInstalled(station)) {
			showIndustrialHubDetail();
			return;
		}

		setCurrentScreen(SCREEN_INDUSTRIAL_NANOFORGE);
		try {
			Global.getSettings().loadTexture(IndustrialHubModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(IndustrialHubModule.IMAGE_PATH, 480, 300));
		text.addPara("Choose which Nanoforge to install in the Manufactorium. Only one may be installed. A "
				+ "Corrupted Nanoforge doubles the required resources for the same Domestic Goods/Luxury "
				+ "Goods/Heavy Armaments output; a Pristine Nanoforge costs the normal amount.");

		options.clearOptions();
		options.addOption("Install Corrupted Nanoforge", OPT_INDUSTRIAL_INSTALL_CORRUPTED_NANOFORGE,
				"Requires one Corrupted Nanoforge. Unlocks production of Domestic Goods, Luxury Goods, and "
				+ "Heavy Armaments -- at double the resource cost per batch.");
		options.setEnabled(OPT_INDUSTRIAL_INSTALL_CORRUPTED_NANOFORGE,
				IndustrialHubModule.hasCorruptedNanoforgeAvailable(station, playerFleet));
		options.addOption("Install Pristine Nanoforge", OPT_INDUSTRIAL_INSTALL_PRISTINE_NANOFORGE,
				"Requires one Pristine Nanoforge. Unlocks production of Domestic Goods, Luxury Goods, and "
				+ "Heavy Armaments at the normal resource cost.");
		options.setEnabled(OPT_INDUSTRIAL_INSTALL_PRISTINE_NANOFORGE,
				IndustrialHubModule.hasPristineNanoforgeAvailable(station, playerFleet));
		options.addOption("Back", OPT_INDUSTRIAL_NANOFORGE_BACK);

		dialog.setPromptText("Manufactorium - Install Nanoforge");
	}

	private void doInstallIndustrialCorruptedNanoforge() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasNanoforgeInstalled(station)
				|| !IndustrialHubModule.hasCorruptedNanoforgeAvailable(station, playerFleet)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.installCorruptedNanoforge(station, playerFleet);
		text.addPara("The Corrupted Nanoforge has been installed in the Manufactorium.");

		showIndustrialHubDetail();
	}

	private void doInstallIndustrialPristineNanoforge() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasNanoforgeInstalled(station)
				|| !IndustrialHubModule.hasPristineNanoforgeAvailable(station, playerFleet)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.installPristineNanoforge(station, playerFleet);
		text.addPara("The Pristine Nanoforge has been installed in the Manufactorium.");

		showIndustrialHubDetail();
	}

	private void doUninstallNanoforge() {
		if (!IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasNanoforgeInstalled(station)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.uninstallNanoforge(station, playerFleet);
		text.addPara("The Nanoforge has been removed from the Manufactorium and returned to the station's inventory.");

		showIndustrialHubDetail();
	}

	private void doInstallBiofactory() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasBiofactoryInstalled(station)
				|| !IndustrialHubModule.hasBiofactoryAvailable(station, playerFleet)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.installBiofactory(station, playerFleet);
		text.addPara("The Biofactory Embryo has been installed in the Manufactorium.");

		showIndustrialHubDetail();
	}

	private void doUninstallBiofactory() {
		if (!IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasBiofactoryInstalled(station)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.uninstallBiofactory(station, playerFleet);
		text.addPara("The Biofactory Embryo has been removed from the Manufactorium and returned to the station's inventory.");

		showIndustrialHubDetail();
	}

	private void doInstallCatalyticCore() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasCatalyticCoreInstalled(station)
				|| !IndustrialHubModule.hasCatalyticCoreAvailable(station, playerFleet)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.installCatalyticCore(station, playerFleet);
		text.addPara("The Catalytic Core has been installed in the Manufactorium.");

		showIndustrialHubDetail();
	}

	private void doUninstallCatalyticCore() {
		if (!IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasCatalyticCoreInstalled(station)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.uninstallCatalyticCore(station, playerFleet);
		text.addPara("The Catalytic Core has been removed from the Manufactorium and returned to the station's inventory.");

		showIndustrialHubDetail();
	}

	private void doInstallSynchrotronCore() {
		if (!IndustrialHubModule.isBuilt(station) || IndustrialHubModule.hasSynchrotronCoreInstalled(station)
				|| !IndustrialHubModule.hasSynchrotronCoreAvailable(station, playerFleet)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.installSynchrotronCore(station, playerFleet);
		text.addPara("The Synchrotron Core has been installed in the Manufactorium.");

		showIndustrialHubDetail();
	}

	private void doUninstallSynchrotronCore() {
		if (!IndustrialHubModule.isBuilt(station) || !IndustrialHubModule.hasSynchrotronCoreInstalled(station)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.uninstallSynchrotronCore(station, playerFleet);
		text.addPara("The Synchrotron Core has been removed from the Manufactorium and returned to the station's inventory.");

		showIndustrialHubDetail();
	}

	private void doDismantleIndustrialHub() {
		if (!IndustrialHubModule.canDismantle(station)) {
			showIndustrialHubDetail();
			return;
		}

		IndustrialHubModule.dismantle(station, playerFleet);
		text.addPara("The Manufactorium has been dismantled, and half its resource cost returned to the station's inventory.");

		showIndustrialHubDetail();
	}

	private void showHydroponicsHubDetail() {
		setCurrentScreen(SCREEN_HYDROPONICS);
		try {
			Global.getSettings().loadTexture(HydroponicsHubModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(HydroponicsHubModule.IMAGE_PATH, 480, 300));

		boolean built = HydroponicsHubModule.isBuilt(station);
		boolean nanitesInstalled = HydroponicsHubModule.hasNanitesInstalled(station);
		boolean bioLampInstalled = HydroponicsHubModule.hasLampInstalled(station);

		if (built) {
			text.addPara(String.format("The Bio-Dome is operational, producing %s food and %s organics "
					+ "every month.",
					(int) HydroponicsHubModule.getFoodPerMonth(station),
					(int) HydroponicsHubModule.getOrganicsPerMonth(station)));
			if (station.getMarket() != null) {
				CargoAPI domeStorage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
				text.addPara(String.format("Current storage: %s/%s food, %s/%s organics.",
						(int) domeStorage.getCommodityQuantity(Commodities.FOOD), (int) MiningHangarModule.getStorageCap(Commodities.FOOD),
						(int) domeStorage.getCommodityQuantity(Commodities.ORGANICS), (int) MiningHangarModule.getStorageCap(Commodities.ORGANICS)));
			}
			if (nanitesInstalled) {
				text.addPara("Soil Nanites are installed, boosting food and organics production.");
			} else {
				text.addPara(String.format("Installing Soil Nanites would increase both food and organics "
						+ "production by %s each.",
						(int) HydroponicsHubModule.NANITES_BONUS));
			}
			if (bioLampInstalled) {
				text.addPara(String.format("A Fusion Lamp is installed, improving Food by %s and Organics by %s "
						+ "for an upkeep of %s Volatiles a month.",
						(int) HydroponicsHubModule.LAMP_FOOD_BONUS, (int) HydroponicsHubModule.LAMP_ORGANICS_BONUS,
						(int) HydroponicsHubModule.LAMP_VOLATILES_UPKEEP));
			} else {
				text.addPara(String.format("Installing a Fusion Lamp would simulate an actual climate improving "
						+ "Food by %s and Organics by %s but cost a upkeep of %s Volatiles a month.",
						(int) HydroponicsHubModule.LAMP_FOOD_BONUS, (int) HydroponicsHubModule.LAMP_ORGANICS_BONUS,
						(int) HydroponicsHubModule.LAMP_VOLATILES_UPKEEP));
			}
		} else {
			text.addPara("Build a Bio-Dome to automatically produce food and organics every month.");
			text.addPara(String.format("Costs %s credits, %s metals, %s organics, and %s heavy machinery.",
					(int) HydroponicsHubModule.CREDIT_COST, (int) HydroponicsHubModule.METALS_COST,
					(int) HydroponicsHubModule.ORGANICS_COST, (int) HydroponicsHubModule.HEAVY_MACHINERY_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Bio-Dome", OPT_HYDROPONICS_BUILD);
			options.setEnabled(OPT_HYDROPONICS_BUILD, HydroponicsHubModule.hasCost(station, playerFleet));
		} else {
			if (!nanitesInstalled) {
				options.addOption("Install Soil Nanites", OPT_HYDROPONICS_INSTALL_NANITES,
						"Requires one Soil Nanites. Improves the production of food and organics.");
				options.setEnabled(OPT_HYDROPONICS_INSTALL_NANITES,
						HydroponicsHubModule.hasNanitesAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Soil Nanites", OPT_HYDROPONICS_UNINSTALL_NANITES,
						"Removes the Soil Nanites and returns them to the station's inventory.");
			}

			if (!bioLampInstalled) {
				options.addOption("Install Fusion Lamp", OPT_HYDROPONICS_INSTALL_LAMP,
						"Requires one Orbital Fusion Lamp. Improves the production of food and organics.");
				options.setEnabled(OPT_HYDROPONICS_INSTALL_LAMP,
						HydroponicsHubModule.hasLampAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Fusion Lamp", OPT_HYDROPONICS_UNINSTALL_LAMP,
						"Removes the Fusion Lamp and returns it to the station's inventory.");
			}

			List<String> bioDomeBlockers = new ArrayList<String>();
			if (nanitesInstalled) bioDomeBlockers.add("Soil Nanites");
			if (bioLampInstalled) bioDomeBlockers.add("Fusion Lamp");
			options.addOption("Dismantle Bio-Dome", OPT_HYDROPONICS_DISMANTLE,
					bioDomeBlockers.isEmpty()
							? "Refunds half of the resources spent to build it."
							: "Uninstall the " + String.join(" and ", bioDomeBlockers) + " first.");
			options.setEnabled(OPT_HYDROPONICS_DISMANTLE, HydroponicsHubModule.canDismantle(station));
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Bio-Dome");
	}

	private void doBuildHydroponicsHub() {
		if (HydroponicsHubModule.isBuilt(station) || !HydroponicsHubModule.hasCost(station, playerFleet)) {
			showHydroponicsHubDetail();
			return;
		}

		HydroponicsHubModule.build(station, playerFleet);
		text.addPara("The Bio-Dome is now operational.");

		showHydroponicsHubDetail();
	}

	private void doInstallSoilNanites() {
		if (!HydroponicsHubModule.isBuilt(station) || HydroponicsHubModule.hasNanitesInstalled(station)
				|| !HydroponicsHubModule.hasNanitesAvailable(station, playerFleet)) {
			showHydroponicsHubDetail();
			return;
		}

		HydroponicsHubModule.installNanites(station, playerFleet);
		text.addPara("The Soil Nanites have been installed in the Bio-Dome.");

		showHydroponicsHubDetail();
	}

	private void doInstallBioDomeLamp() {
		if (!HydroponicsHubModule.isBuilt(station) || HydroponicsHubModule.hasLampInstalled(station)
				|| !HydroponicsHubModule.hasLampAvailable(station, playerFleet)) {
			showHydroponicsHubDetail();
			return;
		}

		HydroponicsHubModule.installLamp(station, playerFleet);
		text.addPara("The Fusion Lamp has been installed in the Bio-Dome.");

		showHydroponicsHubDetail();
	}

	private void doUninstallBioDomeLamp() {
		if (!HydroponicsHubModule.isBuilt(station) || !HydroponicsHubModule.hasLampInstalled(station)) {
			showHydroponicsHubDetail();
			return;
		}

		HydroponicsHubModule.uninstallLamp(station, playerFleet);
		text.addPara("The Fusion Lamp has been removed from the Bio-Dome and returned to the station's inventory.");

		showHydroponicsHubDetail();
	}

	private void doUninstallSoilNanites() {
		if (!HydroponicsHubModule.isBuilt(station) || !HydroponicsHubModule.hasNanitesInstalled(station)) {
			showHydroponicsHubDetail();
			return;
		}

		HydroponicsHubModule.uninstallNanites(station, playerFleet);
		text.addPara("The Soil Nanites have been removed from the Bio-Dome and returned to the station's inventory.");

		showHydroponicsHubDetail();
	}

	private void doDismantleHydroponicsHub() {
		if (!HydroponicsHubModule.canDismantle(station)) {
			showHydroponicsHubDetail();
			return;
		}

		HydroponicsHubModule.dismantle(station, playerFleet);
		text.addPara("The Bio-Dome has been dismantled, and half its resource cost returned to the station's inventory.");

		showHydroponicsHubDetail();
	}

	private void showAssemblyBayDetail() {
		setCurrentScreen(SCREEN_ASSEMBLY);
		try {
			Global.getSettings().loadTexture(AssemblyBayModule.IMAGE_PATH);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(AssemblyBayModule.IMAGE_PATH, 480, 300));

		boolean built = AssemblyBayModule.isBuilt(station);
		boolean nanoforgeInstalled = AssemblyBayModule.hasNanoforgeInstalled(station);
		boolean aiSystemInstalled = AssemblyBayModule.hasAiSystemInstalled(station);

		if (built) {
			float pool = AssemblyBayModule.getPoolValue(station);
			float monthlyGen = AssemblyBayModule.getMonthlyGeneration(station);
			text.addPara(String.format("The Strategic Assembly is operational, capable of constructing ships and "
					+ "weapons from known blueprints. Its production capacity currently stands at %s / %s "
					+ "credits, growing by %s credits per month.",
					(int) pool, (int) AssemblyBayModule.getPoolMax(station), (int) monthlyGen));
			text.addPara("Use \"Order Custom Production\" from the station's main menu to search known "
					+ "designs and place an order.");

			AssemblyBayModule.ProductionOrder activeOrder = AssemblyBayModule.getActiveOrder(station);
			if (activeOrder == null) {
				text.addPara("Nothing is currently in production.");
			} else {
				int daysLeft = (int) Math.ceil(AssemblyBayModule.getDaysRemaining(station));
				String queuedNote = activeOrder.started ? "" : ", waiting behind an earlier order";
				text.addPara(String.format("Currently building: %s%s - %s %s remaining.",
						activeOrder.name, queuedNote, daysLeft, daysLeft == 1 ? "day" : "days"));

				int queueLen = AssemblyBayModule.getQueueLength(station);
				if (queueLen > 1) {
					text.addPara((queueLen - 1) + " more order(s) waiting in the production line.");
				}
			}

			if (nanoforgeInstalled) {
				text.addPara(String.format("A %s Nanoforge is installed, reducing construction costs by %s%%, "
						+ "production line credits by %s, and raising the production capacity cap by %s.",
						AssemblyBayModule.getNanoforgeType(station),
						Math.round(AssemblyBayModule.getNanoforgeDiscount(station) * 100f),
						(int) AssemblyBayModule.getNanoforgeCreditBonus(station),
						(int) AssemblyBayModule.getNanoforgePoolCapBonus(station)));
			} else {
				text.addPara(String.format("Installing a Corrupted Nanoforge would reduce construction costs by "
						+ "%s%% and production line credits by %s, and raise the production capacity cap by %s; "
						+ "a Pristine Nanoforge would reduce costs by %s%% and production line credits by %s, "
						+ "and raise the cap by %s.",
						Math.round(AssemblyBayModule.CORRUPTED_NANOFORGE_DISCOUNT * 100f),
						(int) AssemblyBayModule.CORRUPTED_NANOFORGE_CREDIT_BONUS,
						(int) AssemblyBayModule.CORRUPTED_NANOFORGE_POOL_CAP_BONUS,
						Math.round(AssemblyBayModule.PRISTINE_NANOFORGE_DISCOUNT * 100f),
						(int) AssemblyBayModule.PRISTINE_NANOFORGE_CREDIT_BONUS,
						(int) AssemblyBayModule.PRISTINE_NANOFORGE_POOL_CAP_BONUS));
			}

			if (aiSystemInstalled) {
				text.addPara(String.format("A %s Dedicated AI System is installed, reducing construction costs by "
						+ "an additional %s%%, production line credits by %s, and raising the production "
						+ "capacity cap by %s.",
						getAiSystemTierDisplayName(AssemblyBayModule.getAiSystemTier(station)),
						Math.round(AssemblyBayModule.getAiSystemCostReduction(station) * 100f),
						(int) AssemblyBayModule.getAiSystemCreditBonus(station),
						(int) AssemblyBayModule.getAiSystemPoolCapBonus(station)));
			} else {
				text.addPara(String.format("Installing a dedicated AI system (AI core + Cryoarithmetic Engine) "
						+ "would reduce build costs by %s%%/%s%%/%s%%, production line credits by %s/%s/%s "
						+ "credits per month, and raise the production capacity cap by %s/%s/%s for a "
						+ "Gamma/Beta/Alpha core.",
						Math.round(AssemblyBayModule.GAMMA_AI_SYSTEM_COST_REDUCTION * 100f),
						Math.round(AssemblyBayModule.BETA_AI_SYSTEM_COST_REDUCTION * 100f),
						Math.round(AssemblyBayModule.ALPHA_AI_SYSTEM_COST_REDUCTION * 100f),
						(int) AssemblyBayModule.GAMMA_AI_SYSTEM_CREDIT_BONUS,
						(int) AssemblyBayModule.BETA_AI_SYSTEM_CREDIT_BONUS,
						(int) AssemblyBayModule.ALPHA_AI_SYSTEM_CREDIT_BONUS,
						(int) AssemblyBayModule.GAMMA_AI_SYSTEM_POOL_CAP_BONUS,
						(int) AssemblyBayModule.BETA_AI_SYSTEM_POOL_CAP_BONUS,
						(int) AssemblyBayModule.ALPHA_AI_SYSTEM_POOL_CAP_BONUS));
			}
		} else {
			text.addPara("Build a Strategic Assembly to construct ships and weapons from your known blueprints, "
					+ "drawing on a production capacity that grows over time.");
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics, %s volatiles, and %s "
					+ "heavy machinery.",
					(int) AssemblyBayModule.CREDIT_COST, (int) AssemblyBayModule.METALS_COST,
					(int) AssemblyBayModule.TRANSPLUTONICS_COST, (int) AssemblyBayModule.VOLATILES_COST,
					(int) AssemblyBayModule.HEAVY_MACHINERY_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Strategic Assembly", OPT_ASSEMBLY_BUILD);
			options.setEnabled(OPT_ASSEMBLY_BUILD, AssemblyBayModule.hasCost(station, playerFleet));
		} else {
			if (!nanoforgeInstalled) {
				options.addOption("Install Nanoforge", OPT_ASSEMBLY_INSTALL_NANOFORGE,
						String.format("Requires one Corrupted or Pristine Nanoforge. Reduces ship and weapon "
								+ "construction costs by %s%%/%s%%, production line credits by %s/%s, and "
								+ "raises the production capacity cap by %s/%s for a Corrupted/Pristine Nanoforge.",
								Math.round(AssemblyBayModule.CORRUPTED_NANOFORGE_DISCOUNT * 100f),
								Math.round(AssemblyBayModule.PRISTINE_NANOFORGE_DISCOUNT * 100f),
								(int) AssemblyBayModule.CORRUPTED_NANOFORGE_CREDIT_BONUS,
								(int) AssemblyBayModule.PRISTINE_NANOFORGE_CREDIT_BONUS,
								(int) AssemblyBayModule.CORRUPTED_NANOFORGE_POOL_CAP_BONUS,
								(int) AssemblyBayModule.PRISTINE_NANOFORGE_POOL_CAP_BONUS));
				options.setEnabled(OPT_ASSEMBLY_INSTALL_NANOFORGE,
						AssemblyBayModule.hasNanoforgeAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Nanoforge", OPT_ASSEMBLY_UNINSTALL_NANOFORGE,
						"Removes the Nanoforge and returns it to the station's inventory.");
			}
			if (!aiSystemInstalled) {
				options.addOption("Install Dedicated AI System", OPT_ASSEMBLY_INSTALL_AISYSTEM_MENU,
						String.format("Requires an AI core (Gamma, Beta, or Alpha) and a Cryoarithmetic Engine. "
								+ "Higher-tier cores grant a larger construction cost reduction, production "
								+ "line credit bonus, and production capacity cap bonus (%s/%s/%s for "
								+ "Gamma/Beta/Alpha).",
								(int) AssemblyBayModule.GAMMA_AI_SYSTEM_POOL_CAP_BONUS,
								(int) AssemblyBayModule.BETA_AI_SYSTEM_POOL_CAP_BONUS,
								(int) AssemblyBayModule.ALPHA_AI_SYSTEM_POOL_CAP_BONUS));
				options.setEnabled(OPT_ASSEMBLY_INSTALL_AISYSTEM_MENU,
						AssemblyBayModule.hasGammaAiSystemAvailable(station, playerFleet)
								|| AssemblyBayModule.hasBetaAiSystemAvailable(station, playerFleet)
								|| AssemblyBayModule.hasAlphaAiSystemAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Dedicated AI System", OPT_ASSEMBLY_UNINSTALL_AISYSTEM,
						"Removes the installed AI core and Cryoarithmetic Engine and returns them to the station's inventory.");
			}

			options.addOption("Inject Credits", OPT_ASSEMBLY_INJECT_VIEW,
					String.format("Spend credits to directly increase the Strategic Assembly's production "
							+ "capacity, at a rate of %s credits for every 1 credit of capacity gained.",
							(int) AssemblyBayModule.CREDITS_PER_POOL_CREDIT));
			options.setEnabled(OPT_ASSEMBLY_INJECT_VIEW, AssemblyBayModule.getPoolValue(station) < AssemblyBayModule.getPoolMax(station)
					&& playerFleet.getCargo().getCredits().get() >= AssemblyBayModule.CREDITS_PER_POOL_CREDIT);

			List<String> assemblyBlockers = new ArrayList<String>();
			if (nanoforgeInstalled) assemblyBlockers.add("Nanoforge");
			if (aiSystemInstalled) assemblyBlockers.add("Dedicated AI System");
			if (AssemblyBayModule.getQueueLength(station) > 0) assemblyBlockers.add("everything in the production queue");
			options.addOption("Dismantle Strategic Assembly", OPT_ASSEMBLY_DISMANTLE,
					assemblyBlockers.isEmpty()
							? "Refunds half of the resources spent to build it. Any accumulated production "
							+ "capacity is forfeited."
							: "Clear the following first: " + String.join(", ", assemblyBlockers) + ".");
			options.setEnabled(OPT_ASSEMBLY_DISMANTLE, AssemblyBayModule.canDismantle(station));
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Strategic Assembly");
	}

	private void doBuildAssemblyBay() {
		if (AssemblyBayModule.isBuilt(station) || !AssemblyBayModule.hasCost(station, playerFleet)) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.build(station, playerFleet);
		text.addPara("The Strategic Assembly is now operational.");

		showAssemblyBayDetail();
	}

	private void showAssemblyInjectMenu() {
		if (!AssemblyBayModule.isBuilt(station)) {
			showAssemblyBayDetail();
			return;
		}

		restoreDefaultVisual();
		setCurrentScreen(SCREEN_ASSEMBLY_INJECT);

		float pool = AssemblyBayModule.getPoolValue(station);
		text.addPara(String.format("Production capacity currently stands at %s / %s credits. Spend credits "
				+ "directly on more of it, at a rate of %s credits for every 1 credit of capacity gained.",
				(int) pool, (int) AssemblyBayModule.getPoolMax(station), (int) AssemblyBayModule.CREDITS_PER_POOL_CREDIT));

		options.clearOptions();
		for (int i = 0; i < AssemblyBayModule.INJECT_TIERS.length; i++) {
			float tier = AssemblyBayModule.INJECT_TIERS[i];
			float actual = AssemblyBayModule.getInjectableAmount(station, tier);
			float cost = AssemblyBayModule.getInjectionCost(station, tier);

			String label = "Inject " + (int) tier + " Capacity";
			String tooltip = actual < tier
					? String.format("Only %s capacity of room remains; costs %s credits.", (int) actual, (int) cost)
					: String.format("Costs %s credits.", (int) cost);

			options.addOption(label, OPT_ASSEMBLY_INJECT_TIER[i], tooltip);
			options.setEnabled(OPT_ASSEMBLY_INJECT_TIER[i],
					AssemblyBayModule.canInjectCredits(station, playerFleet, tier));
		}
		options.addOption("Back", OPT_ASSEMBLY_INJECT_BACK);

		dialog.setPromptText("Strategic Assembly - Inject Credits");
	}

	private void doInjectCredits(int tierIndex) {
		if (!AssemblyBayModule.isBuilt(station) || tierIndex < 0 || tierIndex >= AssemblyBayModule.INJECT_TIERS.length) {
			showAssemblyBayDetail();
			return;
		}

		float requested = AssemblyBayModule.INJECT_TIERS[tierIndex];
		float added = AssemblyBayModule.injectCredits(station, playerFleet, requested);
		if (added > 0f) {
			text.addPara(String.format("Production capacity increased by %s credits.", (int) added));
		} else {
			text.addPara("You no longer have the credits required for this.");
		}

		showAssemblyInjectMenu();
	}

	private void showAssemblyNanoforgeMenu() {
		if (!AssemblyBayModule.isBuilt(station) || AssemblyBayModule.hasNanoforgeInstalled(station)) {
			showAssemblyBayDetail();
			return;
		}

		restoreDefaultVisual();
		setCurrentScreen(SCREEN_ASSEMBLY_NANOFORGE);
		text.addPara("Choose which Nanoforge to install in the Strategic Assembly. Only one may be installed.");

		options.clearOptions();
		options.addOption("Install Corrupted Nanoforge", OPT_ASSEMBLY_INSTALL_CORRUPTED_NANOFORGE,
				String.format("Requires one Corrupted Nanoforge. Reduces the cost of ships and weapons built "
						+ "here by %s%% and raises the production capacity cap by %s.",
						Math.round(AssemblyBayModule.CORRUPTED_NANOFORGE_DISCOUNT * 100f),
						(int) AssemblyBayModule.CORRUPTED_NANOFORGE_POOL_CAP_BONUS));
		options.setEnabled(OPT_ASSEMBLY_INSTALL_CORRUPTED_NANOFORGE,
				AssemblyBayModule.hasCorruptedNanoforgeAvailable(station, playerFleet));
		options.addOption("Install Pristine Nanoforge", OPT_ASSEMBLY_INSTALL_PRISTINE_NANOFORGE,
				String.format("Requires one Pristine Nanoforge. Reduces the cost of ships and weapons built "
						+ "here by %s%% and raises the production capacity cap by %s.",
						Math.round(AssemblyBayModule.PRISTINE_NANOFORGE_DISCOUNT * 100f),
						(int) AssemblyBayModule.PRISTINE_NANOFORGE_POOL_CAP_BONUS));
		options.setEnabled(OPT_ASSEMBLY_INSTALL_PRISTINE_NANOFORGE,
				AssemblyBayModule.hasPristineNanoforgeAvailable(station, playerFleet));
		options.addOption("Back", OPT_ASSEMBLY_NANOFORGE_BACK);

		dialog.setPromptText("Strategic Assembly - Install Nanoforge");
	}

	private void doInstallCorruptedNanoforge() {
		if (!AssemblyBayModule.isBuilt(station) || AssemblyBayModule.hasNanoforgeInstalled(station)
				|| !AssemblyBayModule.hasCorruptedNanoforgeAvailable(station, playerFleet)) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.installCorruptedNanoforge(station, playerFleet);
		text.addPara("The Corrupted Nanoforge has been installed in the Strategic Assembly.");

		showAssemblyBayDetail();
	}

	private void doInstallPristineNanoforge() {
		if (!AssemblyBayModule.isBuilt(station) || AssemblyBayModule.hasNanoforgeInstalled(station)
				|| !AssemblyBayModule.hasPristineNanoforgeAvailable(station, playerFleet)) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.installPristineNanoforge(station, playerFleet);
		text.addPara("The Pristine Nanoforge has been installed in the Strategic Assembly.");

		showAssemblyBayDetail();
	}

	private void doUninstallAssemblyNanoforge() {
		if (!AssemblyBayModule.isBuilt(station) || !AssemblyBayModule.hasNanoforgeInstalled(station)) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.uninstallNanoforge(station, playerFleet);
		text.addPara("The Nanoforge has been removed from the Strategic Assembly and returned to the station's inventory.");

		showAssemblyBayDetail();
	}

	private String getAiSystemTierDisplayName(String tier) {
		if (AssemblyBayModule.AI_SYSTEM_TIER_ALPHA.equals(tier)) return "Alpha Core";
		if (AssemblyBayModule.AI_SYSTEM_TIER_BETA.equals(tier)) return "Beta Core";
		if (AssemblyBayModule.AI_SYSTEM_TIER_GAMMA.equals(tier)) return "Gamma Core";
		return "";
	}

	private void showAssemblyAiSystemMenu() {
		if (!AssemblyBayModule.isBuilt(station) || AssemblyBayModule.hasAiSystemInstalled(station)) {
			showAssemblyBayDetail();
			return;
		}

		restoreDefaultVisual();
		setCurrentScreen(SCREEN_ASSEMBLY_AISYSTEM);
		text.addPara("Choose which Dedicated AI System to install in the Strategic Assembly. Each tier also "
				+ "requires a Cryoarithmetic Engine, and only one tier may be installed.");

		options.clearOptions();
		options.addOption("Install Gamma Core System", OPT_ASSEMBLY_INSTALL_GAMMA_CORE,
				String.format("Requires one Gamma Core and a Cryoarithmetic Engine. Reduces construction costs "
						+ "by an additional %s%%, increases credit generation by %s per month, and raises the "
						+ "production capacity cap by %s.",
						Math.round(AssemblyBayModule.GAMMA_AI_SYSTEM_COST_REDUCTION * 100f),
						(int) AssemblyBayModule.GAMMA_AI_SYSTEM_CREDIT_BONUS,
						(int) AssemblyBayModule.GAMMA_AI_SYSTEM_POOL_CAP_BONUS));
		options.setEnabled(OPT_ASSEMBLY_INSTALL_GAMMA_CORE,
				AssemblyBayModule.hasGammaAiSystemAvailable(station, playerFleet));
		options.addOption("Install Beta Core System", OPT_ASSEMBLY_INSTALL_BETA_CORE,
				String.format("Requires one Beta Core and a Cryoarithmetic Engine. Reduces construction costs "
						+ "by an additional %s%%, increases credit generation by %s per month, and raises the "
						+ "production capacity cap by %s.",
						Math.round(AssemblyBayModule.BETA_AI_SYSTEM_COST_REDUCTION * 100f),
						(int) AssemblyBayModule.BETA_AI_SYSTEM_CREDIT_BONUS,
						(int) AssemblyBayModule.BETA_AI_SYSTEM_POOL_CAP_BONUS));
		options.setEnabled(OPT_ASSEMBLY_INSTALL_BETA_CORE,
				AssemblyBayModule.hasBetaAiSystemAvailable(station, playerFleet));
		options.addOption("Install Alpha Core System", OPT_ASSEMBLY_INSTALL_ALPHA_CORE,
				String.format("Requires one Alpha Core and a Cryoarithmetic Engine. Reduces construction costs "
						+ "by an additional %s%%, increases credit generation by %s per month, and raises the "
						+ "production capacity cap by %s.",
						Math.round(AssemblyBayModule.ALPHA_AI_SYSTEM_COST_REDUCTION * 100f),
						(int) AssemblyBayModule.ALPHA_AI_SYSTEM_CREDIT_BONUS,
						(int) AssemblyBayModule.ALPHA_AI_SYSTEM_POOL_CAP_BONUS));
		options.setEnabled(OPT_ASSEMBLY_INSTALL_ALPHA_CORE,
				AssemblyBayModule.hasAlphaAiSystemAvailable(station, playerFleet));
		options.addOption("Back", OPT_ASSEMBLY_AISYSTEM_BACK);

		dialog.setPromptText("Strategic Assembly - Install Dedicated AI System");
	}

	private void doInstallAssemblyAiSystem(String tier) {
		if (!AssemblyBayModule.isBuilt(station) || AssemblyBayModule.hasAiSystemInstalled(station)) {
			showAssemblyBayDetail();
			return;
		}

		boolean available = false;
		if (AssemblyBayModule.AI_SYSTEM_TIER_GAMMA.equals(tier)) {
			available = AssemblyBayModule.hasGammaAiSystemAvailable(station, playerFleet);
		} else if (AssemblyBayModule.AI_SYSTEM_TIER_BETA.equals(tier)) {
			available = AssemblyBayModule.hasBetaAiSystemAvailable(station, playerFleet);
		} else if (AssemblyBayModule.AI_SYSTEM_TIER_ALPHA.equals(tier)) {
			available = AssemblyBayModule.hasAlphaAiSystemAvailable(station, playerFleet);
		}
		if (!available) {
			showAssemblyAiSystemMenu();
			return;
		}

		if (AssemblyBayModule.AI_SYSTEM_TIER_GAMMA.equals(tier)) {
			AssemblyBayModule.installGammaAiSystem(station, playerFleet);
		} else if (AssemblyBayModule.AI_SYSTEM_TIER_BETA.equals(tier)) {
			AssemblyBayModule.installBetaAiSystem(station, playerFleet);
		} else if (AssemblyBayModule.AI_SYSTEM_TIER_ALPHA.equals(tier)) {
			AssemblyBayModule.installAlphaAiSystem(station, playerFleet);
		}
		text.addPara(String.format("The %s Dedicated AI System has been installed in the Strategic Assembly.",
				getAiSystemTierDisplayName(tier)));

		showAssemblyBayDetail();
	}

	private void doUninstallAssemblyAiSystem() {
		if (!AssemblyBayModule.isBuilt(station) || !AssemblyBayModule.hasAiSystemInstalled(station)) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.uninstallAiSystem(station, playerFleet);
		text.addPara("The Dedicated AI System has been removed from the Strategic Assembly and returned to the station's inventory.");

		showAssemblyBayDetail();
	}

	private void doDismantleAssemblyBay() {
		if (!AssemblyBayModule.canDismantle(station)) {
			showAssemblyBayDetail();
			return;
		}

		AssemblyBayModule.dismantle(station, playerFleet);
		text.addPara("The Strategic Assembly has been dismantled, and half its resource cost returned to the station's inventory.");

		showAssemblyBayDetail();
	}

	private void showMilitaryWardDetail() {
		setCurrentScreen(SCREEN_MILITARYWARD);
		String imagePath = MilitaryWardModule.getRandomImagePath();
		try {
			Global.getSettings().loadTexture(imagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(imagePath, 480, 300));

		boolean built = MilitaryWardModule.isBuilt(station);
		boolean holosuiteInstalled = MilitaryWardModule.hasHolosuiteInstalled(station);
		boolean droneReplicatorInstalled = MilitaryWardModule.hasDroneReplicatorInstalled(station);
		boolean aiCoreInstalled = MilitaryWardModule.hasAICoreInstalled(station);

		if (built) {
			text.addPara(String.format("The Military Paradigm is fully functional, slowly producing Crew and "
					+ "training Marines. Since the station is mostly automated, space for crew quarters is "
					+ "limited, allowing only up to %s of each to be held at the station.",
					(int) MilitaryWardModule.MAX_PERSONNEL));

			text.addPara(String.format("Your marines will patrol the colony and help during ground invasions, "
					+ "improving colony defense by %sx and +%s Stability.",
					MilitaryWardModule.MILITARY_WARD_DEFENSE_BONUS,
					(int) MilitaryWardModule.MILITARY_WARD_STABILITY_BONUS));

			CargoAPI storage = null;
			if (station.getMarket() != null) {
				storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
				text.addPara(String.format("Current storage: %s/%s crew, %s/%s marines.",
						storage.getCrew(), (int) MilitaryWardModule.MAX_PERSONNEL,
						storage.getMarines(), (int) MilitaryWardModule.MAX_PERSONNEL));
			}

			boolean hasStoredMarines = storage != null && storage.getMarines() > 0;

			if (hasStoredMarines) {
				com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelRank rank = MilitaryWardModule.getStoredMarineRank(station);
				if (rank != null) {
					text.addPara(String.format("Stored Marines are currently rated %s (%s%% of the way to Elite).",
							rank.name, (int) MilitaryWardModule.getStoredMarineTrainingPercent(station)));
				}
			}

			if (holosuiteInstalled || droneReplicatorInstalled) {
				List<String> installedNames = new ArrayList<String>();
				if (holosuiteInstalled) installedNames.add("Dealmaker Holosuite");
				if (droneReplicatorInstalled) installedNames.add("Combat Drone Replicator");
				if (aiCoreInstalled) installedNames.add(getAICoreDisplayName(MilitaryWardModule.getInstalledAICoreTier(station)));

				float ratio = MilitaryWardModule.getTrainingRatioPerMonth(station);
				text.addPara(String.format("%s installed -- total training bonus: +%s%% Marine training speed per month.",
						String.join(", ", installedNames), Math.round(ratio * 100f)));

				if (hasStoredMarines) {
					float expectedXP = MilitaryWardModule.getExpectedMonthlyTrainingXP(station);
					text.addPara(String.format("At the current stored Marine count, that's approximately %s training "
							+ "points expected to be gained this month.", Math.round(expectedXP)));
				}
			}
		} else {
			text.addPara("Build a Military Paradigm to slowly produce Crew and Marines and give them a place "
					+ "to be housed and trained aboard the station.");
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics, and %s heavy machinery.",
					(int) MilitaryWardModule.CREDIT_COST, (int) MilitaryWardModule.METALS_COST,
					(int) MilitaryWardModule.TRANSPLUTONICS_COST, (int) MilitaryWardModule.HEAVY_MACHINERY_COST));
		}

		options.clearOptions();
		if (!built) {
			options.addOption("Build Military Paradigm", OPT_MILITARYWARD_BUILD);
			options.setEnabled(OPT_MILITARYWARD_BUILD, MilitaryWardModule.hasCost(station, playerFleet));
		} else {
			if (!holosuiteInstalled) {
				options.addOption("Install Holosuite", OPT_MILITARYWARD_INSTALL_HOLOSUITE,
						"Requires one Dealmaker Holosuite. Trains stored Marines over time via realistic "
						+ "simulated combat.");
				options.setEnabled(OPT_MILITARYWARD_INSTALL_HOLOSUITE,
						MilitaryWardModule.hasHolosuiteAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Holosuite", OPT_MILITARYWARD_UNINSTALL_HOLOSUITE,
						"Removes the Holosuite and returns it to the station's inventory.");
			}
			if (!droneReplicatorInstalled) {
				options.addOption("Install Combat Drone Replicator", OPT_MILITARYWARD_INSTALL_DRONE_REPLICATOR,
						"Requires one Combat Drone Replicator. Trains stored Marines over time via "
						+ "semi-realistic terrain combat against training drones.");
				options.setEnabled(OPT_MILITARYWARD_INSTALL_DRONE_REPLICATOR,
						MilitaryWardModule.hasDroneReplicatorAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall Combat Drone Replicator", OPT_MILITARYWARD_UNINSTALL_DRONE_REPLICATOR,
						"Removes the Combat Drone Replicator and returns it to the station's inventory.");
			}
			if (!aiCoreInstalled) {
				options.addOption("Install AI Core", OPT_MILITARYWARD_INSTALL_AICORE,
						"Install a Gamma, Beta, or Alpha Core to boost Marine training speed.");
				options.setEnabled(OPT_MILITARYWARD_INSTALL_AICORE,
						MilitaryWardModule.hasGammaCoreAvailable(station, playerFleet)
								|| MilitaryWardModule.hasBetaCoreAvailable(station, playerFleet)
								|| MilitaryWardModule.hasAlphaCoreAvailable(station, playerFleet));
			} else {
				options.addOption("Uninstall AI Core", OPT_MILITARYWARD_UNINSTALL_AICORE,
						"Removes the installed core and returns it to the station's inventory, so a "
						+ "different tier can be installed in its place.");
			}

			boolean fleetHQBuilt = MilitaryWardModule.hasFleetHQBuilt(station);

			List<String> militaryWardBlockers = new ArrayList<String>();
			if (holosuiteInstalled) militaryWardBlockers.add("Holosuite");
			if (droneReplicatorInstalled) militaryWardBlockers.add("Combat Drone Replicator");
			if (aiCoreInstalled) militaryWardBlockers.add("AI Core");
			if (fleetHQBuilt) militaryWardBlockers.add("Fleet HQ");
			options.addOption("Dismantle Military Paradigm", OPT_MILITARYWARD_DISMANTLE,
					militaryWardBlockers.isEmpty()
							? "Refunds half of the resources spent to build it."
							: "Remove the following first: " + String.join(", ", militaryWardBlockers) + ".");
			options.setEnabled(OPT_MILITARYWARD_DISMANTLE, MilitaryWardModule.canDismantle(station));
		}
		options.addOption("Back", OPT_MODULE_DETAIL_BACK);

		dialog.setPromptText("Military Paradigm");
	}

	private void showFleetHQDetail() {
		if (!MilitaryWardModule.isBuilt(station)) {
			showMainMenu();
			return;
		}

		setCurrentScreen(SCREEN_FLEET_HQ);
		String imagePath = MilitaryWardModule.getRandomTrainingExpeditionImagePath();
		try {
			Global.getSettings().loadTexture(imagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(imagePath, 480, 300));

		boolean hqBuilt = MilitaryWardModule.hasFleetHQBuilt(station);

		if (!hqBuilt) {
			text.addPara("Build a Fleet HQ to unlock three fleet types run out of the station: an Expedition "
					+ "Fleet that tours planets for salvage, a Logistic Fleet that resupplies you on the go and "
					+ "couriers cargo to and from your other colonies, and a Patrol Fleet.");
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics, %s volatiles, and %s "
					+ "Crew (from the station's own storage) to staff it.",
					(int) MilitaryWardModule.FLEET_HQ_CREDIT_COST,
					(int) MilitaryWardModule.FLEET_HQ_METALS_COST,
					(int) MilitaryWardModule.FLEET_HQ_TRANSPLUTONICS_COST,
					(int) MilitaryWardModule.FLEET_HQ_VOLATILES_COST,
					MilitaryWardModule.FLEET_HQ_CREW_COST));
		} else {
			text.addPara(String.format("Expedition Fleet: %s/%s bays. Logistic Fleet: "
					+ "Resupply Bay %s, Courier %s/%s bays, Trade Fleet %s. Patrol Fleet: %s/%s bays.",
					MilitaryWardModule.getTrainingExpeditionBayCount(station), MilitaryWardModule.MAX_TRAINING_EXPEDITION_BAYS,
					MilitaryWardModule.hasResupplyBayBuilt(station) ? "built" : "not built",
					MilitaryWardModule.getCourierBayCount(station), MilitaryWardModule.MAX_COURIER_BAYS,
					MilitaryWardModule.hasTradeFleetBuilt(station) ? "built" : "not built",
					MilitaryWardModule.getPatrolFleetBayCount(station), MilitaryWardModule.MAX_PATROL_FLEET_BAYS));
		}

		options.clearOptions();
		if (!hqBuilt) {
			options.addOption("Build Fleet HQ", OPT_MILITARYWARD_TRAINING_BUILD_HQ,
					"Unlocks the Expedition Fleet, Logistic Fleet, and Patrol Fleet.");
			options.setEnabled(OPT_MILITARYWARD_TRAINING_BUILD_HQ,
					MilitaryWardModule.hasFleetHQCost(station, playerFleet));
		} else {
			options.addOption("Expedition Fleet", OPT_FLEETLOGISTIC_EXPEDITION_VIEW,
					"Crew bays with 2 Transports, 4 Freighters, and 2 Tankers that travel to planets with ruins "
							+ "(preferring higher tier ruins, up to 10 light years from the station) hunting for "
							+ "salvage.");
			options.addOption("Logistic Fleet", OPT_FLEETLOGISTIC_LOGISTIC_VIEW,
					"Crew a Resupply Bay for the Call Resupply Fleet ability, and Courier Bays that move cargo "
					+ "to and from your other colonies.");
			options.addOption("Patrol Fleet", OPT_FLEETLOGISTIC_PATROL_VIEW,
					"Crew it with 1 Capital, 4 Cruisers, and a mix of Destroyers/Frigates -- it patrols the "
					+ "system in real combat, fighting hostiles and defending friendlies, and is the only fleet "
					+ "this station fields that can actually be attacked.");

			boolean miningHubBuilt = MiningHangarModule.isBuilt(station);
			options.addOption("Mining Fleet", OPT_MINING_FLEET_VIEW,
					miningHubBuilt
							? "Crew bays with freighter-role ships that fan out to mine other planets and belts/fields "
									+ "in the system."
							: "Requires the Materials Acquisition Hub to be built.");
			options.setEnabled(OPT_MINING_FLEET_VIEW, miningHubBuilt);
			options.addOption("Salvage Fleet", OPT_FLEETLOGISTIC_SALVAGE_VIEW,
					miningHubBuilt
							? "Crew bays with 2 Tankers, 4 Freighters, and 4 Salvage Gantry ships that roam the sector "
									+ "salvaging debris fields and recovering unguarded derelict ships."
							: "Requires the Materials Acquisition Hub to be built.");
			options.setEnabled(OPT_FLEETLOGISTIC_SALVAGE_VIEW, miningHubBuilt);

			boolean canDisband = MilitaryWardModule.canDisbandFleetHQ(station);
			options.addOption("Dismantle Fleet HQ", OPT_MILITARYWARD_TRAINING_UNINSTALL,
					canDisband
							? "Removes the Fleet HQ, refunding part of its own resource cost."
							: "Uninstall every Expedition, Logistic, Patrol, Mining, and Salvage Fleet bay first.");
			options.setEnabled(OPT_MILITARYWARD_TRAINING_UNINSTALL, canDisband);
		}
		options.addOption("Back", OPT_MILITARYWARD_TRAINING_BACK);

		dialog.setPromptText("Military Paradigm - Fleet HQ");
	}

	private void showExpeditionFleetDetail() {
		if (!MilitaryWardModule.hasFleetHQBuilt(station)) {
			showFleetHQDetail();
			return;
		}

		setCurrentScreen(SCREEN_EXPEDITION_FLEET);
		String imagePath = MilitaryWardModule.getRandomTrainingExpeditionImagePath();
		try {
			Global.getSettings().loadTexture(imagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(imagePath, 480, 300));

		boolean canBuildAnother = MilitaryWardModule.canBuildAnotherExpeditionBay(station);
		int bayCount = MilitaryWardModule.getTrainingExpeditionBayCount(station);
		boolean enoughHeavyArmaments = MilitaryWardModule.hasHeavyArmamentsForBay(station, playerFleet);
		boolean enoughHeavyMachinery = MilitaryWardModule.hasHeavyMachineryForBay(station, playerFleet);

		text.addPara(String.format("Expedition Bays %s/%s.",
				bayCount, MilitaryWardModule.MAX_TRAINING_EXPEDITION_BAYS));
		for (int i = 0; i < MilitaryWardModule.MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (!MilitaryWardModule.isExpeditionBayBuilt(station, i)) continue;
			text.addPara("Bay " + (i + 1) + ": " + MilitaryWardModule.getBayStatusText(station, i) + ".");
		}
		List<String> lootThisTour = MilitaryWardModule.getTrainingExpeditionLootThisMonth(station);
		if (!lootThisTour.isEmpty()) {
			text.addPara("Found so far this month: " + String.join("; ", lootThisTour) + ".");
		}
		text.addPara("Expedition Fleets will travel to planets with ruins preferring higher tier ruins over "
				+ "lower ones and will not travel more then 10 light years from the player HQ");
		if (canBuildAnother) {
			text.addPara(String.format("Requires %s Tankers, %s Transports and %s Freighters (Pristine), %s Heavy "
					+ "Armaments, %s Heavy Machinery and the total sum of the ship's minimal crew requirements.",
					MilitaryWardModule.EXPEDITION_BAY_TANKERS_REQUIRED,
					MilitaryWardModule.EXPEDITION_BAY_TRANSPORTS_REQUIRED,
					MilitaryWardModule.EXPEDITION_BAY_FREIGHTERS_REQUIRED,
					(int) MilitaryWardModule.TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST,
					(int) MilitaryWardModule.TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST));
			text.addPara("Currently Available:\nCrew: " + PlayerHQUtils.getStationCrew(station)
					+ "\nHeavy Armaments: " + (int) PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HAND_WEAPONS)
					+ "\nHeavy Machinery: " + (int) PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY));
		}

		options.clearOptions();
		for (int i = 0; i < MilitaryWardModule.MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (MilitaryWardModule.isExpeditionBayBuilt(station, i)) {
				options.addOption("Uninstall Bay " + (i + 1), OPT_MILITARYWARD_TRAINING_UNINSTALL_BAY[i],
						"Recalls Bay " + (i + 1) + "'s training fleet if it's out, and returns its ships and "
						+ "Crew (in full) to the station's inventory, refunding part of its Heavy Armaments and "
						+ "Heavy Machinery cost.");
			} else {
				options.addOption("Crew Bay " + (i + 1), OPT_MILITARYWARD_TRAINING_CREW_BAY[i],
						"Choose exactly 2 Transports, 4 Freighters, and 2 Tankers (pristine, Destroyer or larger) "
								+ "to crew Bay " + (i + 1) + ". Also costs "
								+ (int) MilitaryWardModule.TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST + " Heavy Armaments and "
								+ (int) MilitaryWardModule.TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST + " Heavy Machinery.");
				options.setEnabled(OPT_MILITARYWARD_TRAINING_CREW_BAY[i],
						enoughHeavyArmaments && enoughHeavyMachinery);
			}
		}
		options.addOption("Back", OPT_EXPEDITIONFLEET_BACK);

		dialog.setPromptText("Fleet HQ - Expedition Fleet");
	}

	private void doBuildFleetHQ() {
		if (!MilitaryWardModule.isBuilt(station)
				|| MilitaryWardModule.hasFleetHQBuilt(station)
				|| !MilitaryWardModule.hasFleetHQCost(station, playerFleet)) {
			showFleetHQDetail();
			return;
		}

		MilitaryWardModule.buildFleetHQ(station, playerFleet);
		text.addPara("Fleet HQ built. The Expedition Fleet, Logistic Fleet, and Patrol Fleet are now available.");
		showFleetHQDetail();
	}

	private void doStartExpeditionBayShipPicker(int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_TRAINING_EXPEDITION_BAYS
				|| MilitaryWardModule.isExpeditionBayBuilt(station, bayIndex)
				|| !MilitaryWardModule.hasFleetHQBuilt(station)) {
			showExpeditionFleetDetail();
			return;
		}

		List<FleetMemberAPI> pool = MilitaryWardModule.getExpeditionFleetCandidates(station, playerFleet);
		if (!MilitaryWardModule.hasHeavyArmamentsForBay(station, playerFleet)
				|| !MilitaryWardModule.hasHeavyMachineryForBay(station, playerFleet)) {
			showExpeditionFleetDetail();
			return;
		}

		final int bayNumber = bayIndex + 1;
		final int totalShips = MilitaryWardModule.EXPEDITION_BAY_TRANSPORTS_REQUIRED
				+ MilitaryWardModule.EXPEDITION_BAY_FREIGHTERS_REQUIRED
				+ MilitaryWardModule.EXPEDITION_BAY_TANKERS_REQUIRED;

		dialog.showFleetMemberPickerDialog(
				"Choose Exactly 2 Transports, 4 Freighters, and 2 Tankers for Bay " + bayNumber,
				"Confirm", "Cancel",
				totalShips, totalShips, 64f,
				true, true,
				pool,
				new FleetMemberPickerListener() {
					@Override
					public void pickedFleetMembers(List<FleetMemberAPI> members) {
						if (!MilitaryWardModule.isValidExpeditionComposition(members)) {
							text.addPara("Your selection must be exactly 2 Transports, 4 Freighters, and 2 "
									+ "Tanker-role ships. Selection cancelled.");
							showExpeditionFleetDetail();
							return;
						}
						int crewNeeded = MilitaryWardModule.getRequiredCrewForShips(members);
						int crewAvailable = PlayerHQUtils.getStationCrew(station);
						if (crewAvailable < crewNeeded) {
							text.addPara("Crewing those ships would take " + crewNeeded + " Crew, but only "
									+ crewAvailable + " is available in the station's storage. Selection cancelled.");
							showExpeditionFleetDetail();
							return;
						}
						if (!MilitaryWardModule.hasHeavyArmamentsForBay(station, playerFleet)) {
							text.addPara("Not enough Heavy Armaments available to build this bay. Selection cancelled.");
							showExpeditionFleetDetail();
							return;
						}
						if (!MilitaryWardModule.hasHeavyMachineryForBay(station, playerFleet)) {
							text.addPara("Not enough Heavy Machinery available to build this bay. Selection cancelled.");
							showExpeditionFleetDetail();
							return;
						}
						MilitaryWardModule.buildExpeditionBayWithShips(station, playerFleet, bayIndex, members);
						text.addPara("Ships committed, along with " + crewNeeded + " Crew to staff them. The new "
								+ "Expedition Bay's training fleet will depart on its first tour on the 1st of the "
								+ "month.");
						showExpeditionFleetDetail();
					}

					@Override
					public void cancelledFleetMemberPicking() {
						showExpeditionFleetDetail();
					}
				});
	}

	private void doDisbandFleetHQ() {
		if (!MilitaryWardModule.canDisbandFleetHQ(station)) {
			showFleetHQDetail();
			return;
		}

		MilitaryWardModule.uninstallFleetHQ(station, playerFleet);
		text.addPara("Fleet HQ dismantled, refunding part of its own resource cost to the station's inventory.");
		showFleetHQDetail();
	}

	private void showMiningFleetDetail() {
		if (!MilitaryWardModule.hasFleetHQBuilt(station) || !MiningHangarModule.isBuilt(station)) {
			showFleetHQDetail();
			return;
		}

		setCurrentScreen(SCREEN_MINING_FLEET);
		String miningImagePath = MilitaryWardModule.getRandomMiningFleetImagePath();
		try {
			Global.getSettings().loadTexture(miningImagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(miningImagePath, 480, 300));

		int maxBays = MilitaryWardModule.getMaxMiningFleetBays(station);
		int bayCount = MilitaryWardModule.getMiningFleetBayCount(station);

		text.addPara(String.format("Mining Fleet bays %s/%s.", bayCount, maxBays));
		for (int i = 0; i < maxBays; i++) {
			if (!MilitaryWardModule.isMiningFleetBayBuilt(station, i)) continue;
			text.addPara("Bay " + (i + 1) + ": " + MilitaryWardModule.getMiningFleetBayStatusText(station, i) + ".");
		}
		text.addPara(String.format("Allows you to deploy mining fleets to mine planets and asteroids, not "
				+ "including the planet the station is orbiting. Requires up to %s ships of the Freighter/Mining/Carrier "
				+ "designation has a dedicated tanker slot that allows the fleets to travel up to %s ly to other systems "
				+ "to mine resources the system lacks.",
				MilitaryWardModule.MAX_MINING_FLEET_SHIPS_PER_BAY, (int) MilitaryWardModule.MINING_FLEET_MAX_RANGE_LY));
		text.addPara(String.format("Frigates/Destroyers/Cruisers %s/%s/%s Mining power (doubled for Carrier and "
				+ "Mining designations). The fleet will head to a planet to mine filling it's holds before returning, "
				+ "if the station's holds are full (%s) it will stop mining until they drop below %s and then start "
				+ "mining again, fleets will target resources that the station is in short supply of first.",
				MilitaryWardModule.MINING_POWER_FRIGATE,
				MilitaryWardModule.MINING_POWER_DESTROYER,
				MilitaryWardModule.MINING_POWER_CRUISER,
				(int) MilitaryWardModule.MINING_STOCK_CAP,
				(int) MilitaryWardModule.MINING_STOCK_THRESHOLD));
		text.addPara("Costs Crew based on the total minimum crew required for all ships.");

		options.clearOptions();
		for (int i = 0; i < maxBays; i++) {
			if (MilitaryWardModule.isMiningFleetBayBuilt(station, i)) {
				options.addOption("Uninstall Bay " + (i + 1), OPT_MININGFLEET_UNINSTALL_BAY[i],
						"Recalls Bay " + (i + 1) + "'s mining fleet if it's out (forfeiting that trip's haul), "
						+ "and returns its ships and Crew (in full) to the station's inventory.");
			} else {
				options.addOption("Crew Bay " + (i + 1), OPT_MININGFLEET_CREW_BAY[i],
						"Choose up to " + MilitaryWardModule.MAX_MINING_FLEET_SHIPS_PER_BAY + " pristine "
+ "freighter-role ships (any hull size), plus one Tanker, to crew Bay " + (i + 1) + ". Also costs Crew, "
						+ "drawn from the station's storage, based on the ships you pick.");
			}
		}
		options.addOption("Back", OPT_MININGFLEET_BACK);

		dialog.setPromptText("Military Paradigm - Fleet HQ - Mining Fleet");
	}

	private void doStartMiningFleetShipPicker(int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.getMaxMiningFleetBays(station)
				|| MilitaryWardModule.isMiningFleetBayBuilt(station, bayIndex)
				|| !MiningHangarModule.isBuilt(station)) {
			showMiningFleetDetail();
			return;
		}

		List<FleetMemberAPI> pool = MilitaryWardModule.getMiningFleetCandidates(station, playerFleet);
		final int bayNumber = bayIndex + 1;
		final int maxShips = MilitaryWardModule.MAX_MINING_FLEET_SHIPS_PER_BAY;

		dialog.showFleetMemberPickerDialog(
				"Choose up to " + maxShips + " Freighter-Role Ships and 1 Tanker for Bay " + bayNumber,
				"Confirm", "Cancel",
				6, 6, 64f,
				true, true,
				pool,
				new FleetMemberPickerListener() {
					@Override
					public void pickedFleetMembers(List<FleetMemberAPI> members) {
						if (!MilitaryWardModule.isValidMiningFleetComposition(members)) {
text.addPara("You must choose between 1 and " + maxShips + " ships, plus at most one Tanker. Selection cancelled.");
							showMiningFleetDetail();
							return;
						}
						int crewNeeded = MilitaryWardModule.getRequiredCrewForShips(members);
						int crewAvailable = PlayerHQUtils.getStationCrew(station);
						if (crewAvailable < crewNeeded) {
							text.addPara("Crewing those ships would take " + crewNeeded + " Crew, but only "
									+ crewAvailable + " is available in the station's storage. Selection cancelled.");
							showMiningFleetDetail();
							return;
						}
						MilitaryWardModule.buildMiningFleetBayWithShips(station, playerFleet, bayIndex, members);
						text.addPara("Ships committed, along with " + crewNeeded + " Crew to staff them. The new "
								+ "Mining Fleet bay will launch as soon as it is ready, provided the station's stock of a resource is low enough.");
						showMiningFleetDetail();
					}

					@Override
					public void cancelledFleetMemberPicking() {
						showMiningFleetDetail();
					}
				});
	}

	private void doUninstallMiningFleetBay(int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_MINING_FLEET_BAYS
				|| !MilitaryWardModule.isMiningFleetBayBuilt(station, bayIndex)) {
			showMiningFleetDetail();
			return;
		}

		MilitaryWardModule.uninstallMiningFleetBay(station, playerFleet, bayIndex);
		text.addPara("Bay " + (bayIndex + 1) + " uninstalled. Its ships and Crew (refunded in full) have been "
				+ "returned to the station's inventory.");
		showMiningFleetDetail();
	}

	private void showSalvageFleetDetail() {
		if (!MilitaryWardModule.hasFleetHQBuilt(station) || !MiningHangarModule.isBuilt(station)) {
			showFleetHQDetail();
			return;
		}

		setCurrentScreen(SCREEN_SALVAGE_FLEET);
		String imagePath = MilitaryWardModule.getRandomLogisticFleetImagePath();
		try {
			Global.getSettings().loadTexture(imagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(imagePath, 480, 300));

		int maxBays = MilitaryWardModule.MAX_SALVAGE_FLEET_BAYS;
		text.addPara(String.format("Salvage Fleet bays %s/%s.", MilitaryWardModule.getSalvageFleetBayCount(station), maxBays));
		for (int i = 0; i < maxBays; i++) {
			if (!MilitaryWardModule.isSalvageFleetBayBuilt(station, i)) continue;
			text.addPara("Bay " + (i + 1) + ": " + MilitaryWardModule.getSalvageFleetBayStatusText(station, i) + ".");
		}
		text.addPara("Salvage fleets are straight forward, they go out find stuff to salvage and return with it. "
				+ "Requires 2 tankers, 4 freighters, 4 salvage ships, Anything with the Salvage Gantry build in is "
				+ "considered a salvage ship. (Does not include Salvage Gantry that are installed or s-modded)",
				Misc.getTextColor(), new Color(255, 150, 0),
				"(Does not include Salvage Gantry that are installed or s-modded)");

		options.clearOptions();
		for (int i = 0; i < maxBays; i++) {
			if (MilitaryWardModule.isSalvageFleetBayBuilt(station, i)) {
				options.addOption("Uninstall Bay " + (i + 1), OPT_SALVAGEFLEET_UNINSTALL_BAY[i],
						"Recalls Bay " + (i + 1) + "'s salvage fleet if it's out (forfeiting that trip's haul), "
						+ "and returns its ships and Crew (in full) to the station's inventory.");
			} else {
				options.addOption("Crew Bay " + (i + 1), OPT_SALVAGEFLEET_CREW_BAY[i],
						"Choose 2 Tankers, 4 Freighters, and 4 pristine ships with a built-in Salvage Gantry to crew Bay "
						+ (i + 1) + ". Also costs Crew, drawn from the station's storage, based on the ships you pick.");
			}
		}
		options.addOption("Back", OPT_SALVAGEFLEET_BACK);

		dialog.setPromptText("Military Paradigm - Fleet HQ - Salvage Fleet");
	}

	private void doStartSalvageFleetShipPicker(int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_SALVAGE_FLEET_BAYS
				|| MilitaryWardModule.isSalvageFleetBayBuilt(station, bayIndex)
				|| !MiningHangarModule.isBuilt(station)) {
			showSalvageFleetDetail();
			return;
		}

		List<FleetMemberAPI> pool = MilitaryWardModule.getSalvageFleetCandidates(station, playerFleet);
		final int bayNumber = bayIndex + 1;

		dialog.showFleetMemberPickerDialog(
				"Choose 2 Tankers, 4 Freighters, and 4 Salvage Ships for Bay " + bayNumber,
				"Confirm", "Cancel",
				6, 6, 64f,
				true, true,
				pool,
				new FleetMemberPickerListener() {
					@Override
					public void pickedFleetMembers(List<FleetMemberAPI> members) {
						if (!MilitaryWardModule.isValidSalvageFleetComposition(members)) {
							text.addPara("You must choose exactly 2 Tankers, 4 Freighters, and 4 Salvage Ships. Selection cancelled.");
							showSalvageFleetDetail();
							return;
						}
						int crewNeeded = MilitaryWardModule.getRequiredCrewForShips(members);
						int crewAvailable = PlayerHQUtils.getStationCrew(station);
						if (crewAvailable < crewNeeded) {
							text.addPara("Crewing those ships would take " + crewNeeded + " Crew, but only "
									+ crewAvailable + " is available in the station's storage. Selection cancelled.");
							showSalvageFleetDetail();
							return;
						}
						MilitaryWardModule.buildSalvageFleetBayWithShips(station, playerFleet, bayIndex, members);
						text.addPara("Ships committed, along with " + crewNeeded + " Crew to staff them. The new "
								+ "Salvage Fleet bay will launch as soon as there is something to salvage.");
						showSalvageFleetDetail();
					}

					@Override
					public void cancelledFleetMemberPicking() {
						showSalvageFleetDetail();
					}
				});
	}

	private void doUninstallSalvageFleetBay(int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_SALVAGE_FLEET_BAYS
				|| !MilitaryWardModule.isSalvageFleetBayBuilt(station, bayIndex)) {
			showSalvageFleetDetail();
			return;
		}

		MilitaryWardModule.uninstallSalvageFleetBay(station, playerFleet, bayIndex);
		text.addPara("Bay " + (bayIndex + 1) + " uninstalled. Its ships and Crew (refunded in full) have been "
				+ "returned to the station's inventory.");
		showSalvageFleetDetail();
	}

	private void showLogisticFleetDetail() {
		if (!MilitaryWardModule.hasFleetHQBuilt(station)) {
			showFleetHQDetail();
			return;
		}

		setCurrentScreen(SCREEN_LOGISTIC_FLEET);
		String logisticImagePath = MilitaryWardModule.getRandomLogisticFleetImagePath();
		try {
			Global.getSettings().loadTexture(logisticImagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(logisticImagePath, 480, 300));

		boolean resupplyBuilt = MilitaryWardModule.hasResupplyBayBuilt(station);
		int courierCount = MilitaryWardModule.getCourierBayCount(station);

		boolean tradeFleetBuilt = MilitaryWardModule.hasTradeFleetBuilt(station);

		text.addPara("Logistic fleets are utility focused fleets including Courier, Trading and Resupply fleets, "
				+ "all fleets require the total of the minimal crew required for the ships given and are "
				+ "restricted to Frigates/Destroyers/Cruisers.");
		text.addPara("Resupply Bay: " + (resupplyBuilt ? "Built" : "Not built"));
		if (resupplyBuilt) {
			text.addPara("Resupply Fleet: " + MilitaryWardModule.getResupplyFleetStatusText(station) + ".");
		}
		text.addPara("Resupply Fleet allows you to call a fleet to your position that will follow you for "
				+ MilitaryWardModule.RESUPPLY_FLEET_FOLLOW_DAYS + " days, in that time you will be able to "
				+ "interact with the fleet to get Supplies/Crew/Fuel up to the amount that is in the HQ's "
				+ "inventory. Requires " + MilitaryWardModule.RESUPPLY_BAY_FREIGHTERS_REQUIRED + " Freighters, "
				+ MilitaryWardModule.RESUPPLY_BAY_TANKERS_REQUIRED + " Tanker and "
				+ MilitaryWardModule.RESUPPLY_BAY_TRANSPORTS_REQUIRED + " Transport.");
		text.addPara("Trade Bay: " + (tradeFleetBuilt ? "Built" : "Not built"));
		if (tradeFleetBuilt) {
			text.addPara("Trade Fleet: " + MilitaryWardModule.getTradeFleetStatusText(station) + ".");
		}
		text.addPara("Trade Fleet will gather up excess resources and head out to sell them for profit, the "
				+ "captain isn't as well connected as you and can not get the same prices so they will work at "
				+ "30% profits but is a way to earn credits from excess resources. Requires up to "
				+ MilitaryWardModule.TRADE_FLEET_MAX_FREIGHTERS + " Freighters and "
				+ MilitaryWardModule.TRADE_FLEET_MAX_TANKERS + " Tanker.");
		text.addPara(String.format("Courier Bays: %s/%s", courierCount, MilitaryWardModule.MAX_COURIER_BAYS));
		for (int i = 0; i < MilitaryWardModule.MAX_COURIER_BAYS; i++) {
			if (!MilitaryWardModule.isCourierBayBuilt(station, i)) continue;
			text.addPara("Courier Bay " + (i + 1) + ": " + MilitaryWardModule.getCourierBayStatusText(station, i) + ".");
		}
		text.addPara("Courier Fleets can ferry items and resources between your HQ, colonies and settlement through Courier Charters, you can "
				+ "even summon a courier fleet to take stuff off your hands and transport it to the HQ. Requires "
				+ MilitaryWardModule.COURIER_BAY_FREIGHTERS_REQUIRED + " to " + MilitaryWardModule.COURIER_BAY_MAX_FREIGHTERS + " Freighters and "
				+ MilitaryWardModule.COURIER_BAY_TANKERS_REQUIRED + " Tanker.");

		options.clearOptions();
		if (!resupplyBuilt) {
			options.addOption("Crew Resupply Bay", OPT_LOGISTIC_RESUPPLY_CREW,
					"Choose exactly 1 Tanker, 1 Transport, and 3 Freighter-role ships (Frigate, Destroyer, or Cruiser, pristine). Also costs "
					+ "Crew, drawn from the station's storage, based on the ships you pick.");
		} else {
			options.addOption("Uninstall Resupply Bay", OPT_LOGISTIC_RESUPPLY_UNINSTALL,
					"Returns its ships and Crew (in full) to the station's inventory. If the Resupply Fleet is "
					+ "currently out, this recalls it immediately, wherever it currently is.");
		}
		if (tradeFleetBuilt) {
			options.addOption("Uninstall Trade Fleet", OPT_LOGISTIC_TRADE_UNINSTALL,
					"Returns its ships and Crew (in full) to the station's inventory." + (MilitaryWardModule.isTradeFleetTouring(station)
							? " This recalls it immediately, wherever it currently is in its run, along with whatever it's currently carrying."
							: ""));
		} else {
			options.addOption("Crew Trade Fleet", OPT_LOGISTIC_TRADE_CREW,
					"Choose 1 to 5 Freighters and exactly 1 Tanker-role ship (Frigate, Destroyer, or Cruiser "
					+ "hulls only, pristine). Also costs Crew, drawn from the station's storage, based on the "
					+ "ships you pick.");
		}
		for (int i = 0; i < MilitaryWardModule.MAX_COURIER_BAYS; i++) {
			if (MilitaryWardModule.isCourierBayBuilt(station, i)) {
				boolean touring = MilitaryWardModule.isCourierBayTouring(station, i);
				options.addOption("Uninstall Courier Bay " + (i + 1), OPT_LOGISTIC_COURIER_UNINSTALL_BAY[i],
						"Returns its ships and Crew (in full) to the station's inventory." + (touring
								? " This recalls it immediately, wherever it currently is in its run."
								: ""));
			} else {
				options.addOption("Crew Courier Bay " + (i + 1), OPT_LOGISTIC_COURIER_CREW_BAY[i],
						"Choose exactly 1 Tanker and 3 Freighter-role ships (Frigate, Destroyer, or Cruiser, pristine). Also costs Crew, drawn "
						+ "from the station's storage, based on the ships you pick.");
			}
		}
		options.addOption("Back", OPT_LOGISTIC_BACK);

		dialog.setPromptText("Fleet HQ - Logistic Fleet");
	}

	private void doStartResupplyBayShipPicker() {
		if (!MilitaryWardModule.hasFleetHQBuilt(station) || MilitaryWardModule.hasResupplyBayBuilt(station)) {
			showLogisticFleetDetail();
			return;
		}

		List<FleetMemberAPI> pool = MilitaryWardModule.getResupplyFleetCandidates(station, playerFleet);

		dialog.showFleetMemberPickerDialog(
				"Choose Exactly 1 Tanker, 1 Transport, and 3 Freighters for the Resupply Bay (Frigate, Destroyer, or Cruiser hulls only)",
				"Confirm", "Cancel",
				6, 6, 64f,
				true, true,
				pool,
				new FleetMemberPickerListener() {
					@Override
					public void pickedFleetMembers(List<FleetMemberAPI> members) {
						if (!MilitaryWardModule.isValidResupplyComposition(members)) {
							text.addPara("Your selection must be exactly 1 Tanker, 1 Transport, and 3 "
									+ "Freighter-role ships. Selection cancelled.");
							showLogisticFleetDetail();
							return;
						}
						int crewNeeded = MilitaryWardModule.getRequiredCrewForShips(members);
						int crewAvailable = PlayerHQUtils.getStationCrew(station);
						if (crewAvailable < crewNeeded) {
							text.addPara("Crewing those ships would take " + crewNeeded + " Crew, but only "
									+ crewAvailable + " is available in the station's storage. Selection cancelled.");
							showLogisticFleetDetail();
							return;
						}
						MilitaryWardModule.buildResupplyBayWithShips(station, playerFleet, members);
						text.addPara("Resupply Bay crewed, along with " + crewNeeded + " Crew to staff it. The "
								+ "Call Resupply Fleet ability is now available.");
						showLogisticFleetDetail();
					}

					@Override
					public void cancelledFleetMemberPicking() {
						showLogisticFleetDetail();
					}
				});
	}

	private void doUninstallResupplyBay() {
		if (!MilitaryWardModule.hasResupplyBayBuilt(station)) {
			showLogisticFleetDetail();
			return;
		}

		MilitaryWardModule.uninstallResupplyBay(station, playerFleet);
		text.addPara("Resupply Bay uninstalled. Its ships and Crew (refunded in full) have been returned to the "
				+ "station's inventory.");
		showLogisticFleetDetail();
	}

	private void doStartCourierBayShipPicker(int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_COURIER_BAYS
				|| MilitaryWardModule.isCourierBayBuilt(station, bayIndex)
				|| !MilitaryWardModule.hasFleetHQBuilt(station)) {
			showLogisticFleetDetail();
			return;
		}

		List<FleetMemberAPI> pool = MilitaryWardModule.getCourierFleetCandidates(station, playerFleet);
		final int bayNumber = bayIndex + 1;

		dialog.showFleetMemberPickerDialog(
				"Choose 1 Tanker and 3 to 5 Freighters for Courier Bay " + bayNumber + " (Frigate, Destroyer, or Cruiser hulls only)",
				"Confirm", "Cancel",
				6, 6, 64f,
				true, true,
				pool,
				new FleetMemberPickerListener() {
					@Override
					public void pickedFleetMembers(List<FleetMemberAPI> members) {
						if (!MilitaryWardModule.isValidCourierComposition(members)) {
							text.addPara("Your selection must be 1 Tanker and 3 to 5 Freighter-role ships. "
									+ "Selection cancelled.");
							showLogisticFleetDetail();
							return;
						}
						int crewNeeded = MilitaryWardModule.getRequiredCrewForShips(members);
						int crewAvailable = PlayerHQUtils.getStationCrew(station);
						if (crewAvailable < crewNeeded) {
							text.addPara("Crewing those ships would take " + crewNeeded + " Crew, but only "
									+ crewAvailable + " is available in the station's storage. Selection cancelled.");
							showLogisticFleetDetail();
							return;
						}
						MilitaryWardModule.buildCourierBayWithShips(station, playerFleet, bayIndex, members);
						text.addPara("Courier Bay " + bayNumber + " crewed, along with " + crewNeeded + " Crew to staff it.");
						showLogisticFleetDetail();
					}

					@Override
					public void cancelledFleetMemberPicking() {
						showLogisticFleetDetail();
					}
				});
	}

	private void doUninstallCourierBay(int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_COURIER_BAYS
				|| !MilitaryWardModule.isCourierBayBuilt(station, bayIndex)) {
			showLogisticFleetDetail();
			return;
		}

		MilitaryWardModule.uninstallCourierBay(station, playerFleet, bayIndex);
		text.addPara("Courier Bay " + (bayIndex + 1) + " uninstalled. Its ships and Crew (refunded in full) have "
				+ "been returned to the station's inventory.");
		showLogisticFleetDetail();
	}

	private void doStartTradeFleetShipPicker() {
		if (!MilitaryWardModule.hasFleetHQBuilt(station) || MilitaryWardModule.hasTradeFleetBuilt(station)) {
			showLogisticFleetDetail();
			return;
		}

		List<FleetMemberAPI> pool = MilitaryWardModule.getTradeFleetCandidates(station, playerFleet);
		int minShips = 2;
		int maxShips = MilitaryWardModule.TRADE_FLEET_MAX_FREIGHTERS + MilitaryWardModule.TRADE_FLEET_MAX_TANKERS;

		dialog.showFleetMemberPickerDialog(
				"Choose 1-5 Freighters and 1 Tanker for the Trade Fleet (Frigate, Destroyer, or Cruiser hulls only)",
				"Confirm", "Cancel",
				minShips, maxShips, 64f,
				true, true,
				pool,
				new FleetMemberPickerListener() {
					@Override
					public void pickedFleetMembers(List<FleetMemberAPI> members) {
						if (!MilitaryWardModule.isValidTradeFleetComposition(members)) {
							text.addPara("Your selection must be 1-5 Freighters and 1 Tanker-role ship, all "
									+ "Frigate, Destroyer, or Cruiser hulls. Selection cancelled.");
							showLogisticFleetDetail();
							return;
						}
						int crewNeeded = MilitaryWardModule.getRequiredCrewForShips(members);
						int crewAvailable = PlayerHQUtils.getStationCrew(station);
						if (crewAvailable < crewNeeded) {
							text.addPara("Crewing those ships would take " + crewNeeded + " Crew, but only "
									+ crewAvailable + " is available in the station's storage. Selection cancelled.");
							showLogisticFleetDetail();
							return;
						}
						MilitaryWardModule.buildTradeFleetWithShips(station, playerFleet, members);
						text.addPara("Trade Fleet crewed, along with " + crewNeeded + " Crew to staff it. It will "
								+ "launch on its own once enough surplus cargo has built up at the station to "
								+ "fill its hold.");
						showLogisticFleetDetail();
					}

					@Override
					public void cancelledFleetMemberPicking() {
						showLogisticFleetDetail();
					}
				});
	}

	private void doUninstallTradeFleet() {
		if (!MilitaryWardModule.hasTradeFleetBuilt(station)) {
			showLogisticFleetDetail();
			return;
		}

		MilitaryWardModule.uninstallTradeFleet(station, playerFleet);
		text.addPara("Trade Fleet uninstalled. Its ships and Crew (refunded in full) have been returned to the "
				+ "station's inventory.");
		showLogisticFleetDetail();
	}

	private void doOpenCourierCharters() {
		if (MilitaryWardModule.getCourierBayCount(station) < 1) {
			showMainMenu();
			return;
		}
		setCurrentScreen(SCREEN_CHARTER);
		text.clear();
		options.clearOptions();
		dialog.showCustomDialog(playerhq.charter.CourierCharterDelegate.WIDTH, playerhq.charter.CourierCharterDelegate.HEIGHT,
				new playerhq.charter.CourierCharterDelegate(station, new playerhq.charter.CourierCharterDelegate.Listener() {
					public void onFinished() {
						showMainMenu();
					}
				}));
	}

	private void doStartCourierTrade(final int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_COURIER_BAYS
				|| !MilitaryWardModule.isCourierBayBuilt(station, bayIndex)
				|| MilitaryWardModule.isCourierBayTouring(station, bayIndex)) {
			showLogisticFleetDetail();
			return;
		}

		List<SectorEntityToken> targets = new ArrayList<SectorEntityToken>();
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (market == null || !market.isPlayerOwned()) continue;
			if (station.getMarket() != null && market == station.getMarket()) continue;
			if (market.getPrimaryEntity() == null) continue;
			targets.add(market.getPrimaryEntity());
		}
		SectorEntityToken ratSettlement = MilitaryWardModule.getRatSettlementEntity();
		if (ratSettlement != null && !targets.contains(ratSettlement) && ratSettlement != station) {
			targets.add(ratSettlement);
		}

		if (targets.isEmpty()) {
			showLogisticFleetDetail();
			text.addPara("You don't own any other colonies to dispatch a Courier Bay to.");
			return;
		}

		dialog.showCampaignEntityPicker("Choose a Colony to Dispatch Courier Bay " + (bayIndex + 1) + " To",
				"Selected", "Confirm",
				playerFleet.getFaction(), targets,
				new CampaignEntityPickerListener() {
					@Override
					public String getMenuItemNameOverrideFor(SectorEntityToken entity) {
						return null;
					}

					@Override
					public void pickedEntity(SectorEntityToken entity) {
						showCourierCargoPrompt(bayIndex, entity);
					}

					@Override
					public void cancelledEntityPicking() {
						showLogisticFleetDetail();
					}

					@Override
					public String getSelectedTextOverrideFor(SectorEntityToken entity) {
						return null;
					}

					@Override
					public void createInfoText(TooltipMakerAPI info, SectorEntityToken entity) {
						if (entity.getMarket() != null) {
							info.addPara(entity.getName() + " (" + entity.getMarket().getFactionId() + ")", 0f);
						}
					}

					@Override
					public boolean canConfirmSelection(SectorEntityToken entity) {
						return true;
					}

					@Override
					public float getFuelColorAlphaMult() {
						return 1f;
					}

					@Override
					public float getFuelRangeMult() {
						return 1f;
					}

					@Override
					public List<ArrowData> getArrows() {
						return new ArrayList<ArrowData>();
					}

					@Override
					public List<MarkerData> getMarkers() {
						return null;
					}

					@Override
					public Set<StarSystemAPI> getStarSystemsToShow() {
						return null;
					}
				});
	}

	private void showCourierCargoPrompt(int bayIndex, SectorEntityToken target) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(COURIER_PENDING_BAY_KEY, bayIndex);
		mem.set(COURIER_PENDING_TARGET_KEY, target);
		text.addPara("Courier Bay " + (bayIndex + 1) + " will be dispatched to " + target.getName()
				+ ". Choose which cargo from the Player HQ's storage it should carry.");
		options.clearOptions();
		options.addOption("Choose Cargo", OPT_COURIER_CARGO_PICK);
		options.addOption("Cancel", OPT_COURIER_CARGO_CANCEL);
		dialog.setOptionOnEscape("Cancel", OPT_COURIER_CARGO_CANCEL);
	}

	private void clearCourierPending() {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(COURIER_PENDING_BAY_KEY);
		mem.unset(COURIER_PENDING_TARGET_KEY);
	}

	private void doCourierCargoPickFromPending() {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		Object target = mem.get(COURIER_PENDING_TARGET_KEY);
		if (!mem.contains(COURIER_PENDING_BAY_KEY) || !(target instanceof SectorEntityToken)) {
			clearCourierPending();
			showLogisticFleetDetail();
			return;
		}
		int bayIndex = mem.getInt(COURIER_PENDING_BAY_KEY);
		clearCourierPending();
		doStartCourierCargoPicker(bayIndex, (SectorEntityToken) target);
	}

	private void doStartCourierCargoPicker(final int bayIndex, final SectorEntityToken target) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_COURIER_BAYS
				|| !MilitaryWardModule.isCourierBayBuilt(station, bayIndex)
				|| MilitaryWardModule.isCourierBayTouring(station, bayIndex) || target == null) {
			showLogisticFleetDetail();
			return;
		}

		CargoAPI hqStorage = PlayerHQUtils.getStationStorageCargo(station);
		if (hqStorage == null) {
			text.addPara("The Player HQ has no storage to courier cargo out of.");
			showLogisticFleetDetail();
			return;
		}

		CargoAPI offer = Global.getFactory().createCargo(false);
		for (CargoStackAPI stack : hqStorage.getStacksCopy()) {
			if (stack == null || stack.isNull()) continue;
			offer.addFromStack(stack);
		}
		offer.sort();

		final float capacity = MilitaryWardModule.getCourierBayCargoCapacity(station, bayIndex);
		dialog.showCargoPickerDialog("Choose Cargo to Send to " + target.getName(), "Dispatch", "Cancel",
				true, 310f, offer,
				new CargoPickerListener() {
					@Override
					public void pickedCargo(CargoAPI picked) {
						if (picked.isEmpty()) {
							MilitaryWardModule.dispatchCourierBay(station, playerFleet, bayIndex, target, picked);
							text.addPara("Courier Bay " + (bayIndex + 1) + " dispatched to " + target.getName() + ", carrying nothing.");
							showLogisticFleetDetail();
							return;
						}
						MilitaryWardModule.dispatchCourierBay(station, playerFleet, bayIndex, target, picked);
						text.addPara("Courier Bay " + (bayIndex + 1) + " dispatched to " + target.getName()
								+ ". Anything that didn't fit in its cargo capacity was left in the HQ's storage.");
						showLogisticFleetDetail();
					}

					@Override
					public void cancelledCargoSelection() {
						showLogisticFleetDetail();
					}

					@Override
					public void recreateTextPanel(TooltipMakerAPI panel, CargoAPI cargo, CargoStackAPI pickedUp,
							boolean pickedUpFromSource, CargoAPI combined) {
						float used = 0f;
						for (CargoStackAPI st : combined.getStacksCopy()) {
							if (st == null || st.isNull() || st.isFuelStack()) continue;
							used += st.getCargoSpace();
						}
						boolean over = used > capacity + 0.01f;
						panel.addPara("Pick items from the Player HQ's storage to send along, or confirm with "
								+ "nothing selected to send the fleet out empty.", 0f);
						panel.addPara("Cargo space: %s / %s", 10f,
								over ? Misc.getNegativeHighlightColor() : Misc.getHighlightColor(),
								"" + (int) used, "" + (int) capacity);
						if (over) {
							panel.addPara("Anything over the Courier Bay's capacity will be left behind.", 3f,
									Misc.getNegativeHighlightColor(), "left behind");
						}
					}
				});
	}

	private void showPatrolFleetDetail() {
		if (!MilitaryWardModule.hasFleetHQBuilt(station)) {
			showFleetHQDetail();
			return;
		}

		setCurrentScreen(SCREEN_PATROL_FLEET);
		String patrolImagePath = MilitaryWardModule.getRandomPatrolFleetImagePath();
		try {
			Global.getSettings().loadTexture(patrolImagePath);
		} catch (IOException e) { }
		visual.showImageVisual(new InteractionDialogImageVisual(patrolImagePath, 480, 300));

		int bayCount = MilitaryWardModule.getPatrolFleetBayCount(station);
		boolean canBuildAnother = MilitaryWardModule.canBuildAnotherPatrolFleetBay(station);

		text.addPara("Patrol Fleets will launch from the station patrolling to keep the system safe.");
		text.addPara(String.format("Patrol Fleets: %s/%s", bayCount, MilitaryWardModule.MAX_PATROL_FLEET_BAYS));
		for (int i = 0; i < MilitaryWardModule.MAX_PATROL_FLEET_BAYS; i++) {
			if (!MilitaryWardModule.isPatrolFleetBayBuilt(station, i)) continue;
			text.addPara("Bay " + (i + 1) + " (" + MilitaryWardModule.getPatrolFleetSize(station, i) + " ships): "
					+ MilitaryWardModule.getPatrolFleetBayStatusText(station, i) + ".");
		}
		text.addPara("Patrol Fleets require Warships and Carriers to operate, each fleet requires "
				+ MilitaryWardModule.PATROL_FLEET_CAPITALS_REQUIRED + " Capital ship, "
				+ MilitaryWardModule.PATROL_FLEET_CRUISERS_REQUIRED + " Cruisers and requires 5 points, "
				+ "Destroyers = 1 point and Frigates = 0.5 points, the ships given keep their loadout, meaning "
				+ "it will keep any weapon/wing/hullmod/vent/capacitor it is equipped with and "
				+ "will not receive any other equipment.",
				Misc.getTextColor(), new Color(255, 140, 0), "will not receive any other equipment");
		text.addPara("When lost in combat the ships will be replaced, if the fleet survives it will return to "
				+ "the HQ and begin repairs and replacement, Capitals take "
				+ MilitaryWardModule.PATROL_FLEET_CAPITAL_REBUILD_DAYS + " days, Cruisers take "
				+ MilitaryWardModule.PATROL_FLEET_CRUISER_REBUILD_DAYS + " days, Destroyers take "
				+ MilitaryWardModule.PATROL_FLEET_DESTROYER_REBUILD_DAYS + " days and Frigates take "
				+ MilitaryWardModule.PATROL_FLEET_FRIGATE_REBUILD_DAYS + " days, if the fleet is completely "
				+ "destroyed it will take the combined days of all the ships before it can be launched again.");

		options.clearOptions();
		for (int i = 0; i < MilitaryWardModule.MAX_PATROL_FLEET_BAYS; i++) {
			if (MilitaryWardModule.isPatrolFleetBayBuilt(station, i)) {
				options.addOption("Uninstall Bay " + (i + 1), OPT_PATROLFLEET_UNINSTALL_BAY[i],
						"Recalls Bay " + (i + 1) + "'s Patrol Fleet (losing whatever it's currently carrying in "
						+ "the field, if it's out on patrol) and returns fresh copies of its committed ships to "
						+ "the station's inventory.");
			} else {
				List<FleetMemberAPI> pool = MilitaryWardModule.getPatrolFleetCandidates(station, playerFleet);
				options.addOption("Crew Bay " + (i + 1), OPT_PATROLFLEET_CREW_BAY[i],
						"Choose exactly " + MilitaryWardModule.PATROL_FLEET_CAPITALS_REQUIRED + " Capital, "
						+ MilitaryWardModule.PATROL_FLEET_CRUISERS_REQUIRED + " Cruisers, and a Destroyer/Frigate "
						+ "mix worth 5 points (Destroyer = 1, Frigate = 0.5) from ships labeled Warship or "
						+ "Carrier in the Codex to crew Bay " + (i + 1) + ".");
				options.setEnabled(OPT_PATROLFLEET_CREW_BAY[i], !pool.isEmpty());
			}
		}
		options.addOption("Back", OPT_PATROLFLEET_BACK);

		dialog.setPromptText("Fleet HQ - Patrol Fleet");
	}

	private void doStartPatrolFleetShipPicker(int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_PATROL_FLEET_BAYS
				|| MilitaryWardModule.isPatrolFleetBayBuilt(station, bayIndex)
				|| !MilitaryWardModule.hasFleetHQBuilt(station)) {
			showPatrolFleetDetail();
			return;
		}

		List<FleetMemberAPI> pool = MilitaryWardModule.getPatrolFleetCandidates(station, playerFleet);
		final int bayNumber = bayIndex + 1;

		dialog.showFleetMemberPickerDialog(
				"Choose Bay " + bayNumber + "'s Ships (1 Capital, 4 Cruisers, and Destroyers/Frigates worth 5 "
				+ "points -- Destroyer = 1, Frigate = 0.5)",
				"Confirm", "Cancel",
				6, 6, 64f,
				true, true,
				pool,
				new FleetMemberPickerListener() {
					@Override
					public void pickedFleetMembers(List<FleetMemberAPI> members) {
						if (!MilitaryWardModule.isValidPatrolFleetComposition(members)) {
							text.addPara("Your selection must be exactly " + MilitaryWardModule.PATROL_FLEET_CAPITALS_REQUIRED
									+ " Capital, " + MilitaryWardModule.PATROL_FLEET_CRUISERS_REQUIRED + " Cruisers, "
									+ "and a Destroyer/Frigate mix worth 5 points. Selection cancelled.");
							showPatrolFleetDetail();
							return;
						}
						int crewNeeded = MilitaryWardModule.getRequiredCrewForShips(members);
						int stationCrew = PlayerHQUtils.getStationCrew(station);
						int crewFromStation = Math.min(stationCrew, crewNeeded);
						int crewFromFleet = crewNeeded - crewFromStation;
						int fleetCrew = playerFleet.getCargo() != null ? playerFleet.getCargo().getCrew() : 0;
						if (crewFromFleet > fleetCrew) {
							text.addPara("Crewing those ships would take " + crewNeeded + " Crew, but only "
									+ (stationCrew + fleetCrew) + " is available between the station's storage and "
									+ "your fleet. Selection cancelled.");
							showPatrolFleetDetail();
							return;
						}
						MilitaryWardModule.buildPatrolFleetWithShips(station, playerFleet, bayIndex, members);
						text.addPara(crewFromFleet > 0
								? "Ships committed, along with " + crewNeeded + " Crew to staff them (" + crewFromFleet
										+ " taken from your fleet since the station didn't have enough). Bay " + bayNumber
										+ "'s Patrol Fleet has launched and is now patrolling the system."
								: "Ships committed, along with " + crewNeeded + " Crew to staff them. Bay " + bayNumber
										+ "'s Patrol Fleet has launched and is now patrolling the system.");
						showPatrolFleetDetail();
					}

					@Override
					public void cancelledFleetMemberPicking() {
						showPatrolFleetDetail();
					}
				});
	}

	private void doUninstallPatrolFleetBay(int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_PATROL_FLEET_BAYS
				|| !MilitaryWardModule.isPatrolFleetBayBuilt(station, bayIndex)) {
			showPatrolFleetDetail();
			return;
		}

		MilitaryWardModule.uninstallPatrolFleetBay(station, playerFleet, bayIndex);
		text.addPara("Bay " + (bayIndex + 1) + " uninstalled. Fresh copies of its committed ships have been "
				+ "returned to the station's inventory.");
		showPatrolFleetDetail();
	}

	private void doUninstallExpeditionBay(int bayIndex) {
		if (!MilitaryWardModule.hasFleetHQBuilt(station)
				|| bayIndex < 0 || bayIndex >= MilitaryWardModule.MAX_TRAINING_EXPEDITION_BAYS
				|| !MilitaryWardModule.isExpeditionBayBuilt(station, bayIndex)) {
			showExpeditionFleetDetail();
			return;
		}

		MilitaryWardModule.uninstallExpeditionBay(station, playerFleet, bayIndex);
		text.addPara("Bay " + (bayIndex + 1) + " uninstalled. Its ships and Crew (refunded in full) have been "
				+ "returned to the station's inventory.");
		showExpeditionFleetDetail();
	}

	private String getAICoreDisplayName(String coreCommodityId) {
		if (Commodities.ALPHA_CORE.equals(coreCommodityId)) return "Alpha Core";
		if (Commodities.BETA_CORE.equals(coreCommodityId)) return "Beta Core";
		if (Commodities.GAMMA_CORE.equals(coreCommodityId)) return "Gamma Core";
		return "AI Core";
	}

	private void showMilitaryWardAICoreMenu() {
		if (!MilitaryWardModule.isBuilt(station) || MilitaryWardModule.hasAICoreInstalled(station)) {
			showMilitaryWardDetail();
			return;
		}

		restoreDefaultVisual();
		setCurrentScreen(SCREEN_MILITARYWARD_AICORE);
		text.addPara("Choose which AI core to install in the Military Paradigm. Only one may be installed.");

		options.clearOptions();
		options.addOption("Install Gamma Core", OPT_MILITARYWARD_INSTALL_GAMMA_CORE,
				"Requires one Gamma Core. Multiplies training speed by 2x.");
		options.setEnabled(OPT_MILITARYWARD_INSTALL_GAMMA_CORE,
				MilitaryWardModule.hasGammaCoreAvailable(station, playerFleet));
		options.addOption("Install Beta Core", OPT_MILITARYWARD_INSTALL_BETA_CORE,
				"Requires one Beta Core. Multiplies training speed by 3x.");
		options.setEnabled(OPT_MILITARYWARD_INSTALL_BETA_CORE,
				MilitaryWardModule.hasBetaCoreAvailable(station, playerFleet));
		options.addOption("Install Alpha Core", OPT_MILITARYWARD_INSTALL_ALPHA_CORE,
				"Requires one Alpha Core. Multiplies training speed by 4x.");
		options.setEnabled(OPT_MILITARYWARD_INSTALL_ALPHA_CORE,
				MilitaryWardModule.hasAlphaCoreAvailable(station, playerFleet));
		options.addOption("Back", OPT_MILITARYWARD_AICORE_BACK);

		dialog.setPromptText("Military Paradigm - Install AI Core");
	}

	private void doBuildMilitaryWard() {
		if (MilitaryWardModule.isBuilt(station) || !MilitaryWardModule.hasCost(station, playerFleet)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.build(station, playerFleet);
		text.addPara("The Military Paradigm is now operational.");

		showMilitaryWardDetail();
	}

	private void doInstallMilitaryWardHolosuite() {
		if (!MilitaryWardModule.isBuilt(station) || MilitaryWardModule.hasHolosuiteInstalled(station)
				|| !MilitaryWardModule.hasHolosuiteAvailable(station, playerFleet)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.installHolosuite(station, playerFleet);
		text.addPara("The Holosuite has been installed in the Military Paradigm.");

		showMilitaryWardDetail();
	}

	private void doUninstallMilitaryWardHolosuite() {
		if (!MilitaryWardModule.isBuilt(station) || !MilitaryWardModule.hasHolosuiteInstalled(station)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.uninstallHolosuite(station, playerFleet);
		text.addPara("The Holosuite has been removed from the Military Paradigm and returned to the station's inventory.");

		showMilitaryWardDetail();
	}

	private void doInstallMilitaryWardDroneReplicator() {
		if (!MilitaryWardModule.isBuilt(station) || MilitaryWardModule.hasDroneReplicatorInstalled(station)
				|| !MilitaryWardModule.hasDroneReplicatorAvailable(station, playerFleet)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.installDroneReplicator(station, playerFleet);
		text.addPara("The Combat Drone Replicator has been installed in the Military Paradigm.");

		showMilitaryWardDetail();
	}

	private void doUninstallMilitaryWardDroneReplicator() {
		if (!MilitaryWardModule.isBuilt(station) || !MilitaryWardModule.hasDroneReplicatorInstalled(station)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.uninstallDroneReplicator(station, playerFleet);
		text.addPara("The Combat Drone Replicator has been removed from the Military Paradigm and returned to the station's inventory.");

		showMilitaryWardDetail();
	}

	private void doInstallMilitaryWardAICore(String coreCommodityId) {
		if (!MilitaryWardModule.isBuilt(station) || MilitaryWardModule.hasAICoreInstalled(station)
				|| PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, coreCommodityId) < MilitaryWardModule.AI_CORE_COST) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.installAICore(station, playerFleet, coreCommodityId);
		text.addPara("The AI core has been installed in the Military Paradigm.");

		showMilitaryWardDetail();
	}

	private void doUninstallMilitaryWardAICore() {
		if (!MilitaryWardModule.isBuilt(station) || !MilitaryWardModule.hasAICoreInstalled(station)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.uninstallAICore(station, playerFleet);
		text.addPara("The AI core has been removed from the Military Paradigm and returned to the station's inventory.");

		showMilitaryWardDetail();
	}

	private void doDismantleMilitaryWard() {
		if (!MilitaryWardModule.canDismantle(station)) {
			showMilitaryWardDetail();
			return;
		}

		MilitaryWardModule.dismantle(station, playerFleet);
		text.addPara("The Military Paradigm has been dismantled, and half its resource cost returned to the station's inventory.");

		showMilitaryWardDetail();
	}

	private void doOrderCustomProduction() {
		if (!AssemblyBayModule.isBuilt(station)) {
			showMainMenu();
			return;
		}

		dialog.showCustomProductionPicker(new PlayerHQProductionPickerDelegate(station, playerFleet, text));
	}

	/**
	 * Not just used from the station's own docked menu -- PlayerHQRemoteProductionDialogPlugin
	 * (in the top-level playerhq package) also constructs this directly, so the same Strategic
	 * Assembly ordering flow can be opened remotely from the Player HQ Status Report's "Order
	 * Production" button. Keep this public for that reason.
	 */
	public static class PlayerHQProductionPickerDelegate extends BaseCustomProductionPickerDelegateImpl {

		private final SectorEntityToken station;
		private final CampaignFleetAPI playerFleet;
		private final TextPanelAPI text;

		public PlayerHQProductionPickerDelegate(SectorEntityToken station, CampaignFleetAPI playerFleet, TextPanelAPI text) {
			this.station = station;
			this.playerFleet = playerFleet;
			this.text = text;
		}

		@Override
		public Set<String> getAvailableShipHulls() {
			return new LinkedHashSet<String>(Global.getSector().getPlayerFaction().getKnownShips());
		}

		@Override
		public Set<String> getAvailableWeapons() {
			return new LinkedHashSet<String>(Global.getSector().getPlayerFaction().getKnownWeapons());
		}

		@Override
		public Set<String> getAvailableFighters() {
			return new LinkedHashSet<String>(Global.getSector().getPlayerFaction().getKnownFighters());
		}

		@Override
		public float getCostMult() {
			playerhq.PlayerHQRemoteProductionDialogPlugin.ping();
			return 1f - AssemblyBayModule.getTotalDiscount(station);
		}

		@Override
		public float getMaximumValue() {
			playerhq.PlayerHQRemoteProductionDialogPlugin.ping();
			return AssemblyBayModule.getPoolValue(station);
		}

		@Override
		public void notifyProductionSelected(FactionProductionAPI production) {
			int builtCount = 0;
			int failedCount = 0;

			for (FactionProductionAPI.ItemInProductionAPI item : production.getCurrent()) {
				FactionProductionAPI.ProductionItemType type = item.getType();
				if (type != FactionProductionAPI.ProductionItemType.SHIP
						&& type != FactionProductionAPI.ProductionItemType.WEAPON
						&& type != FactionProductionAPI.ProductionItemType.FIGHTER) continue;

				for (int i = 0; i < item.getQuantity(); i++) {
					boolean success;
					if (type == FactionProductionAPI.ProductionItemType.SHIP) {
						success = AssemblyBayModule.buildShip(station, playerFleet, item.getSpecId());
					} else if (type == FactionProductionAPI.ProductionItemType.FIGHTER) {
						success = AssemblyBayModule.buildWing(station, playerFleet, item.getSpecId());
					} else {
						success = AssemblyBayModule.buildWeapon(station, playerFleet, item.getSpecId());
					}
					if (success) builtCount++; else failedCount++;
				}
			}

			if (builtCount > 0 && failedCount == 0) {
				text.addPara("Order placed: " + builtCount + " item(s) added to the production queue.");
			} else if (builtCount > 0) {
				text.addPara("Order partially placed: " + builtCount + " item(s) queued, "
						+ failedCount + " could not be completed.");
			} else if (failedCount > 0) {
				text.addPara("The order could not be completed.");
			}

			if (builtCount > 0) {
				float totalDays = AssemblyBayModule.getTotalQueueDaysRemaining(station);
				text.addPara(String.format("The full production queue will be clear in ~%s day(s).",
						(int) Math.ceil(totalDays)));
			}
		}
	}

	private void showStationItemsMenu() {
		restoreDefaultVisual();
		setCurrentScreen(SCREEN_STATION_ITEMS);

		boolean spaceElevatorInstalled = StationItemsModule.hasSpaceElevatorInstalled(station);
		boolean publicShuttlesInstalled = StationItemsModule.hasPublicShuttlesInstalled(station);
		boolean marketPlaceInstalled = MarketPlaceModule.isBuilt(station);

		text.addPara("Upgrades the station to be more accessible to the planet's colonist improving accessibility.");

		text.addPara(String.format("Station Accessibility: %s%% -- scales the Resort's income (100%% is full "
				+ "base income; more is possible above that).",
				Math.round(StationItemsModule.getAccessibility(station))));
		if (StationItemsModule.hasIndustrialPlanningSkill()) {
			text.addPara(String.format("Includes a +%s%% bonus from your Industrial Planning skill.",
					Math.round(StationItemsModule.INDUSTRIAL_PLANNING_ACCESSIBILITY_BONUS)));
		}

		options.clearOptions();
		if (!spaceElevatorInstalled) {
			options.addOption("Install Space Elevator", OPT_STATIONITEM_INSTALL_SPACE_ELEVATOR,
					String.format("Requires one Fullerene Spool, %s credits, %s metals, %s transplutonics, and %s heavy "
							+ "machinery. Increases Accessibility by %s%%.",
							(int) StationItemsModule.SPACE_ELEVATOR_CREDIT_COST,
							(int) StationItemsModule.SPACE_ELEVATOR_METALS_COST, (int) StationItemsModule.SPACE_ELEVATOR_TRANSPLUTONICS_COST,
							(int) StationItemsModule.SPACE_ELEVATOR_HEAVY_MACHINERY_COST,
							(int) StationItemsModule.SPACE_ELEVATOR_ACCESSIBILITY_BONUS));
			options.setEnabled(OPT_STATIONITEM_INSTALL_SPACE_ELEVATOR,
					StationItemsModule.hasSpaceElevatorCost(station, playerFleet));
		} else {
			options.addOption("Uninstall Space Elevator", OPT_STATIONITEM_UNINSTALL_SPACE_ELEVATOR,
					"Removes the Space Elevator and returns its resources to the station's inventory.");
		}
		if (!publicShuttlesInstalled) {
			options.addOption("Install Public Shuttles", OPT_STATIONITEM_INSTALL_PUBLIC_SHUTTLES,
					String.format("Costs %s credits, %s metals, %s transplutonics, %s heavy machinery, and %s crew. Increases "
							+ "Accessibility by %s%%.",
							(int) StationItemsModule.PUBLIC_SHUTTLES_CREDIT_COST,
							(int) StationItemsModule.PUBLIC_SHUTTLES_METALS_COST, (int) StationItemsModule.PUBLIC_SHUTTLES_TRANSPLUTONICS_COST,
							(int) StationItemsModule.PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST,
							StationItemsModule.PUBLIC_SHUTTLES_CREW_COST,
							(int) StationItemsModule.PUBLIC_SHUTTLES_ACCESSIBILITY_BONUS));
			options.setEnabled(OPT_STATIONITEM_INSTALL_PUBLIC_SHUTTLES,
					StationItemsModule.hasPublicShuttlesCost(station, playerFleet));
		} else {
			options.addOption("Uninstall Public Shuttles", OPT_STATIONITEM_UNINSTALL_PUBLIC_SHUTTLES,
					"Removes Public Shuttles and returns its resources to the station's inventory.");
		}
		if (!marketPlaceInstalled) {
			options.addOption("Install Market Place", OPT_STATIONITEM_INSTALL_MARKETPLACE,
					String.format("Costs %s credits, %s metals, %s transplutonics, and %s heavy machinery. Gives "
							+ "access to an Agora tab for weapons, fighter wings, blueprints, and hull mods "
							+ "you want to sell (ships can be stored there too), and an Exchange to buy that "
							+ "same kind of stock from -- including ships of every size, saddled with D-mods, "
							+ "the best hulls only turning up now and then -- restocked fresh every "
							+ "month, both reachable from the station's own inventory screen (\"Manage Fleet\"), "
							+ "alongside Storage. Every month, merchants pay up to %s credits for the priciest "
							+ "items sitting in the Agora, plus whatever you've spent at the Exchange since the "
							+ "last sweep, and one ship stored in the Agora (if any) is sold off at complete "
							+ "random.",
							(int) MarketPlaceModule.CREDIT_COST, (int) MarketPlaceModule.METALS_COST,
							(int) MarketPlaceModule.TRANSPLUTONICS_COST, (int) MarketPlaceModule.HEAVY_MACHINERY_COST,
							(int) MarketPlaceModule.MAX_MERCHANT_BUDGET));
			options.setEnabled(OPT_STATIONITEM_INSTALL_MARKETPLACE, MarketPlaceModule.hasCost(station, playerFleet));
		} else {
			options.addOption("Uninstall Market Place", OPT_STATIONITEM_UNINSTALL_MARKETPLACE,
					"Removes the Agora and Exchange and returns their resources -- and anything, "
					+ "including any ships, still sitting in the Agora -- to the station's inventory. "
					+ "The Agora and Exchange tabs are reachable from the station's own inventory screen "
					+ "(\"Manage Fleet\") alongside Storage, same as always.");
		}
		options.addOption("Dismantle station", OPT_DISMANTLE,
				"Refunds half of the resources spent to build it and any of its modules, plus the AI core "
				+ "and any special items installed. Credits spent are not refunded. The station is "
				+ "destroyed and a new one can then be constructed.");
		options.addOption("Back", OPT_STATION_ITEMS_BACK);
		options.setShortcut(OPT_DISMANTLE, Keyboard.KEY_D, false, false, false, true);

		dialog.setPromptText("Station Upgrades");
	}

	private void doInstallMarketPlace() {
		if (MarketPlaceModule.isBuilt(station) || !MarketPlaceModule.hasCost(station, playerFleet)) {
			showStationItemsMenu();
			return;
		}

		MarketPlaceModule.install(station, playerFleet);
		text.addPara("The Market Place has been installed.");

		showStationItemsMenu();
	}

	private void doUninstallMarketPlace() {
		if (!MarketPlaceModule.isBuilt(station)) {
			showStationItemsMenu();
			return;
		}

		MarketPlaceModule.uninstall(station, playerFleet);
		text.addPara("The Agora and Exchange have been removed. Their resources, and anything "
				+ "still sitting in the Agora, have been returned to the station's inventory.");

		showStationItemsMenu();
	}

	private void doInstallSpaceElevator() {
		if (StationItemsModule.hasSpaceElevatorInstalled(station)) {
			showStationItemsMenu();
			return;
		}
		if (!StationItemsModule.hasSpaceElevatorCost(station, playerFleet)) {
			text.addPara(String.format("Not enough resources to install the Space Elevator -- you need one "
					+ "Fullerene Spool, %s credits, %s metals, %s transplutonics, and %s heavy machinery, combined between "
					+ "your fleet and the station's storage.",
					(int) StationItemsModule.SPACE_ELEVATOR_CREDIT_COST,
					(int) StationItemsModule.SPACE_ELEVATOR_METALS_COST,
					(int) StationItemsModule.SPACE_ELEVATOR_TRANSPLUTONICS_COST,
					(int) StationItemsModule.SPACE_ELEVATOR_HEAVY_MACHINERY_COST));
			showStationItemsMenu();
			return;
		}

		StationItemsModule.installSpaceElevator(station, playerFleet);
		text.addPara("The Space Elevator has been installed, improving Accessibility.");

		showStationItemsMenu();
	}

	private void doUninstallSpaceElevator() {
		if (!StationItemsModule.hasSpaceElevatorInstalled(station)) {
			showStationItemsMenu();
			return;
		}

		StationItemsModule.uninstallSpaceElevator(station, playerFleet);
		text.addPara("The Space Elevator has been removed and its resources returned to the station's inventory.");

		showStationItemsMenu();
	}

	private void doInstallPublicShuttles() {
		if (StationItemsModule.hasPublicShuttlesInstalled(station)) {
			showStationItemsMenu();
			return;
		}
		if (!StationItemsModule.hasPublicShuttlesCost(station, playerFleet)) {
			text.addPara(String.format("Not enough resources to install Public Shuttles -- you need %s credits, %s metals, "
					+ "%s transplutonics, and %s heavy machinery, combined between your fleet and the station's "
					+ "storage, plus %s crew in the station's storage.",
					(int) StationItemsModule.PUBLIC_SHUTTLES_CREDIT_COST,
					(int) StationItemsModule.PUBLIC_SHUTTLES_METALS_COST,
					(int) StationItemsModule.PUBLIC_SHUTTLES_TRANSPLUTONICS_COST,
					(int) StationItemsModule.PUBLIC_SHUTTLES_HEAVY_MACHINERY_COST,
					StationItemsModule.PUBLIC_SHUTTLES_CREW_COST));
			showStationItemsMenu();
			return;
		}

		StationItemsModule.installPublicShuttles(station, playerFleet);
		text.addPara("Public Shuttles have been installed, improving Accessibility.");

		showStationItemsMenu();
	}

	private void doUninstallPublicShuttles() {
		if (!StationItemsModule.hasPublicShuttlesInstalled(station)) {
			showStationItemsMenu();
			return;
		}

		StationItemsModule.uninstallPublicShuttles(station, playerFleet);
		text.addPara("Public Shuttles have been removed and their resources returned to the station's inventory.");

		showStationItemsMenu();
	}

	private void showConfirmDismantle() {
		setCurrentScreen(SCREEN_CONFIRM_DISMANTLE);
		text.addPara("Are you sure you want to dismantle the Player HQ station? This cannot be undone.");

		MarketAPI market = station.getMarket();
		boolean storageHasContents = market != null
				&& !market.getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo().isEmpty();
		boolean storageHasShips = PlayerHQUtils.hasShipsInStationStorage(station);

		if (storageHasShips) {
			text.addPara("The station's storage still holds ships. You'll need to transfer them out (Manage "
					+ "Fleet) before the station can be dismantled.", Misc.getNegativeHighlightColor());
		} else if (storageHasContents) {
			text.addPara("The station's storage still holds cargo. Anything you haven't transferred out will "
					+ "be jettisoned into a cargo pod near the station when it's dismantled, rather than lost.",
					Misc.getNegativeHighlightColor());
		}

		options.clearOptions();
		options.addOption("Confirm dismantle", OPT_CONFIRM_DISMANTLE);
		options.setEnabled(OPT_CONFIRM_DISMANTLE, !storageHasShips);
		options.addOption("Back", OPT_CANCEL_DISMANTLE);
	}

	private void doDismantle() {
		if (PlayerHQUtils.hasShipsInStationStorage(station)) {
			Global.getSector().getCampaignUI().getMessageDisplay().addMessage(
					"Ships still in storage -- can not dismantle station", Color.RED);
			showConfirmDismantle();
			return;
		}

		ConstructPlayerHQAbility.dismantleStation(playerFleet);
		text.addPara("The Player HQ station has been dismantled. Half of its resource cost, its AI core, "
				+ "half of the resource cost of any modules built on it, and any special items installed "
				+ "in those modules, have been returned to your cargo hold. Any other cargo left in the "
				+ "station's storage has been jettisoned into a cargo pod near where it stood. Credits spent "
				+ "are not refunded.");

		// The station no longer exists past this point, so make sure Escape just closes the dialog
		// instead of re-rendering a menu (e.g. showMainMenu) against the now-dismantled station.
		setCurrentScreen(SCREEN_MAIN);

		options.clearOptions();
		options.addOption("Leave", OPT_LEAVE);
		dialog.setPromptText("");
	}
}
