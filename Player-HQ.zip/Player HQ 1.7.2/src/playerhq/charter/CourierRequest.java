package playerhq.charter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CourierRequest implements Serializable {

	public int id;
	public String destMarketId;
	public List<CharterItem> items = new ArrayList<CharterItem>();
	public boolean allWeapons = false;
	public boolean allWings = false;
	public boolean allSpecials = false;
	public int daysLeft = 0;
	public boolean inTransit = false;
	public int runs = 0;
	public String status = "New request";

	public CourierRequest(int id, String destMarketId) {
		this.id = id;
		this.destMarketId = destMarketId;
	}

	public boolean hasAnything() {
		return !items.isEmpty() || allWeapons || allWings || allSpecials;
	}
}
