package playerhq.charter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CourierCharterState implements Serializable {

	public static final int MIN_INTERVAL_DAYS = 10;

	public List<String> supplyMarketIds = new ArrayList<String>();
	public List<CourierRequest> requests = new ArrayList<CourierRequest>();
	public int intervalDays = MIN_INTERVAL_DAYS;
	public int nextId = 1;
}
