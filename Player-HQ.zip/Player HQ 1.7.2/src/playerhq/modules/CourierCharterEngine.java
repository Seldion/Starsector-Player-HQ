package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;

import playerhq.charter.CharterItem;
import playerhq.charter.CourierCharterData;
import playerhq.charter.CourierCharterState;
import playerhq.charter.CourierRequest;
import playerhq.util.PlayerHQUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CourierCharterEngine {

	public static final String STATE_PICKUP = "charter_pickup";
	public static final String STATE_DELIVER = "charter_deliver";

	private static final String ID_KEY = "$playerhq_charter_run_id";
	private static final String PLAN_KEY = "$playerhq_charter_run_plan";
	private static final String NEEDS_KEY = "$playerhq_charter_run_needs";
	private static final String SHIPS_KEY = "$playerhq_charter_run_ships";
	private static final String LOADED_KEY = "$playerhq_charter_run_loaded";
	private static final String DEST_KEY = "$playerhq_charter_run_dest";
	private static final String LIMITED_KEY = "$playerhq_charter_run_limited";

	public static boolean isCharterState(String state) {
		return STATE_PICKUP.equals(state) || STATE_DELIVER.equals(state);
	}

	public static boolean isCharterRun(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().contains(MilitaryWardModule.bayKey(ID_KEY, bayIndex));
	}

	public static String statusText(SectorEntityToken station, int bayIndex, String state) {
		SectorEntityToken target = MilitaryWardModule.getCourierTargetEntity(station, bayIndex);
		String name = target != null ? target.getName() : "its next stop";
		if (STATE_PICKUP.equals(state)) return "collecting cargo at " + name;
		return "delivering a request to " + name;
	}

	public static void advanceDaily(SectorEntityToken station) {
		CourierCharterState state = CourierCharterData.getState();
		for (CourierRequest r : new ArrayList<CourierRequest>(state.requests)) {
			if (r.inTransit) continue;
			if (r.daysLeft > 0) r.daysLeft--;
			if (r.daysLeft > 0) continue;
			attempt(station, state, r);
		}
	}

	private static void attempt(SectorEntityToken station, CourierCharterState state, CourierRequest r) {
		MarketAPI dest = CourierCharterData.getMarket(r.destMarketId);
		if (!CourierCharterData.isUsableMarket(dest, station)) {
			r.status = "Location is not available";
			r.daysLeft = state.intervalDays;
			return;
		}
		if (!r.hasAnything()) {
			r.status = "Nothing requested yet";
			r.daysLeft = state.intervalDays;
			return;
		}
		List<MarketAPI> sources = usableSources(station, state, dest);
		if (sources.isEmpty()) {
			r.status = "No supply colonies";
			r.daysLeft = state.intervalDays;
			return;
		}
		int bay = MilitaryWardModule.findIdleCourierBayIndex(station);
		if (bay < 0) {
			r.status = "Waiting for a free Courier Fleet";
			return;
		}

		List<CharterItem> needs = computeNeeds(r, dest, sources);
		if (needs.isEmpty()) {
			r.status = "Fully stocked";
			r.daysLeft = state.intervalDays;
			return;
		}

		List<MarketAPI> plan = planSources(sources, needs);
		if (plan.isEmpty()) {
			r.status = "Nothing available at the supply colonies";
			r.daysLeft = state.intervalDays;
			return;
		}

		if (!launch(station, state, r, bay, dest, needs, plan)) {
			r.status = "Could not launch a Courier Fleet";
			r.daysLeft = state.intervalDays;
		}
	}

	private static List<MarketAPI> usableSources(SectorEntityToken station, CourierCharterState state, MarketAPI dest) {
		List<MarketAPI> sources = new ArrayList<MarketAPI>();
		for (String id : state.supplyMarketIds) {
			MarketAPI m = CourierCharterData.getMarket(id);
			if (m == null || m == dest || !CourierCharterData.isUsableMarket(m, station)) continue;
			if (sources.contains(m)) continue;
			sources.add(m);
		}
		sortByDistance(station, sources);
		return sources;
	}

	private static String key(String type, String id, String data) {
		return type + "|" + id + "|" + (data == null ? "" : data);
	}

	private static List<CharterItem> computeNeeds(CourierRequest r, MarketAPI dest, List<MarketAPI> sources) {
		List<CharterItem> needs = new ArrayList<CharterItem>();
		SubmarketAPI destSub = MilitaryWardModule.getCourierTargetStorage(dest);
		CargoAPI destCargo = destSub != null ? destSub.getCargo() : null;
		List<String> seen = new ArrayList<String>();

		for (CharterItem item : r.items) {
			if (item == null || item.amount <= 0) continue;
			int need = item.amount;
			if (destCargo != null) need = Math.max(0, item.amount - (int) countIn(destCargo, item));
			if (need <= 0) continue;
			CharterItem copy = item.copy();
			copy.amount = need;
			needs.add(copy);
			seen.add(key(item.type, item.id, item.data));
		}

		if (r.allWeapons || r.allWings || r.allSpecials) {
			List<CharterItem> all = new ArrayList<CharterItem>();
			for (MarketAPI m : sources) {
				SubmarketAPI sub = MilitaryWardModule.getCourierTargetStorage(m);
				if (sub == null || sub.getCargo() == null) continue;
				for (CargoStackAPI stack : sub.getCargo().getStacksCopy()) {
					if (stack == null || stack.isNull()) continue;
					CargoAPI.CargoItemType type = stack.getType();
					boolean take = (r.allWeapons && type == CargoAPI.CargoItemType.WEAPONS)
							|| (r.allWings && type == CargoAPI.CargoItemType.FIGHTER_CHIP)
							|| (r.allSpecials && type == CargoAPI.CargoItemType.SPECIAL);
					if (!take) continue;
					int amount = (int) stack.getSize();
					if (amount <= 0) continue;
					String id;
					String data = null;
					if (type == CargoAPI.CargoItemType.SPECIAL) {
						SpecialItemData sd = stack.getSpecialDataIfSpecial();
						if (sd == null) continue;
						id = sd.getId();
						data = sd.getData();
					} else {
						if (stack.getData() == null) continue;
						id = String.valueOf(stack.getData());
					}
					String k = key(type.name(), id, data);
					if (seen.contains(k)) continue;
					CharterItem existing = null;
					for (CharterItem a : all) {
						if (key(a.type, a.id, a.data).equals(k)) {
							existing = a;
							break;
						}
					}
					if (existing != null) existing.amount += amount;
					else all.add(new CharterItem(type.name(), id, data, stack.getDisplayName(), amount));
				}
			}
			needs.addAll(all);
		}
		return needs;
	}

	private static Object dataFor(CargoAPI cargo, CharterItem item) {
		if (!CargoAPI.CargoItemType.SPECIAL.name().equals(item.type)) return item.cargoData();
		for (CargoStackAPI stack : cargo.getStacksCopy()) {
			if (stack == null || stack.isNull() || !stack.isSpecialStack()) continue;
			SpecialItemData sd = stack.getSpecialDataIfSpecial();
			if (sd == null || !item.id.equals(sd.getId())) continue;
			if (item.data == null ? sd.getData() == null : item.data.equals(sd.getData())) return sd;
		}
		return item.cargoData();
	}

	private static float countIn(CargoAPI cargo, CharterItem item) {
		if (cargo == null || item == null) return 0f;
		if (item.isShip()) {
			int n = 0;
			if (cargo.getMothballedShips() != null) {
				for (FleetMemberAPI m : cargo.getMothballedShips().getMembersListCopy()) {
					if (item.id.equals(m.getHullId())) n++;
				}
			}
			return n;
		}
		CargoAPI.CargoItemType type = item.cargoType();
		if (type == null) return 0f;
		if (type == CargoAPI.CargoItemType.SPECIAL) {
			float n = 0f;
			for (CargoStackAPI stack : cargo.getStacksCopy()) {
				if (stack == null || stack.isNull() || !stack.isSpecialStack()) continue;
				SpecialItemData sd = stack.getSpecialDataIfSpecial();
				if (sd == null || !item.id.equals(sd.getId())) continue;
				if (item.data == null ? sd.getData() == null : item.data.equals(sd.getData())) n += stack.getSize();
			}
			return n;
		}
		try {
			return cargo.getQuantity(type, item.cargoData());
		} catch (Throwable t) {
			return 0f;
		}
	}

	private static List<MarketAPI> planSources(List<MarketAPI> sources, List<CharterItem> needs) {
		List<Integer> remaining = new ArrayList<Integer>();
		for (CharterItem n : needs) remaining.add(n.amount);

		List<MarketAPI> plan = new ArrayList<MarketAPI>();
		for (MarketAPI m : sources) {
			SubmarketAPI sub = MilitaryWardModule.getCourierTargetStorage(m);
			if (sub == null || sub.getCargo() == null) continue;
			boolean contributes = false;
			for (int i = 0; i < needs.size(); i++) {
				int rem = remaining.get(i);
				if (rem <= 0) continue;
				int avail = (int) countIn(sub.getCargo(), needs.get(i));
				int take = Math.min(rem, avail);
				if (take > 0) {
					contributes = true;
					remaining.set(i, rem - take);
				}
			}
			if (contributes) plan.add(m);
		}
		return plan;
	}

	private static void sortByDistance(final SectorEntityToken station, List<MarketAPI> markets) {
		Collections.sort(markets, new Comparator<MarketAPI>() {
			public int compare(MarketAPI a, MarketAPI b) {
				return Float.compare(distanceScore(station, a), distanceScore(station, b));
			}
		});
	}

	private static float distanceScore(SectorEntityToken station, MarketAPI m) {
		SectorEntityToken e = m.getPrimaryEntity();
		if (e == null) return Float.MAX_VALUE;
		float ly = Misc.getDistanceLY(station, e);
		float local = e.getContainingLocation() == station.getContainingLocation() ? Misc.getDistance(station, e) : 0f;
		return ly * 100000f + local;
	}

	private static boolean launch(SectorEntityToken station, CourierCharterState state, CourierRequest r, int bayIndex, MarketAPI dest,
			List<CharterItem> needs, List<MarketAPI> plan) {
		List<FleetMemberAPI> ships = MilitaryWardModule.getCourierBayCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return false;
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return false;

		MilitaryWardModule.outfitFleetShips(station, ships, false);

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER, "Courier Fleet " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		MilitaryWardModule.markAsNonInteractiveTraffic(fleet, MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		try {
			fleet.getFleetData().setSyncNeeded();
			fleet.getFleetData().syncIfNeeded();
			fleet.getCargo().updateSpaceUsed();
		} catch (Throwable t) {
		}
		MilitaryWardModule.injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		MilitaryWardModule.refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);

		SectorEntityToken first = plan.get(0).getPrimaryEntity();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, first, MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				"Collecting cargo at " + first.getName());

		List<String> planIds = new ArrayList<String>();
		for (MarketAPI m : plan) planIds.add(m.getId());

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_HOLD_MEMORY_KEY, bayIndex), Global.getFactory().createCargo(true));
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex), first);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_SUPPLIES_TO_DELIVER_MEMORY_KEY, bayIndex), 0f);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_TOURING_MEMORY_KEY, bayIndex), true);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_STATE_MEMORY_KEY, bayIndex), STATE_PICKUP);
		mem.set(MilitaryWardModule.bayKey(ID_KEY, bayIndex), r.id);
		mem.set(MilitaryWardModule.bayKey(PLAN_KEY, bayIndex), planIds);
		mem.set(MilitaryWardModule.bayKey(NEEDS_KEY, bayIndex), needs);
		mem.set(MilitaryWardModule.bayKey(SHIPS_KEY, bayIndex), new ArrayList<FleetMemberAPI>());
		mem.set(MilitaryWardModule.bayKey(LOADED_KEY, bayIndex), Global.getFactory().createCargo(true));
		mem.set(MilitaryWardModule.bayKey(DEST_KEY, bayIndex), dest.getId());
		mem.set(MilitaryWardModule.bayKey(LIMITED_KEY, bayIndex), false);

		r.inTransit = true;
		r.daysLeft = state.intervalDays;
		r.status = "Courier Fleet " + (bayIndex + 1) + " dispatched";
		return true;
	}

	@SuppressWarnings("unchecked")
	private static <T> T get(SectorEntityToken station, String key, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(MilitaryWardModule.bayKey(key, bayIndex));
		return (T) o;
	}

	public static void advanceRealtime(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, String state) {
		SectorEntityToken target = MilitaryWardModule.getCourierTargetEntity(station, bayIndex);

		if (STATE_PICKUP.equals(state)) {
			if (target == null) {
				List<String> plan = get(station, PLAN_KEY, bayIndex);
				if (plan != null && !plan.isEmpty()) plan.remove(0);
				routeToNextStop(station, bayIndex, fleet);
				return;
			}
			if (!MilitaryWardModule.courierHasArrived(fleet, target, MilitaryWardModule.COURIER_FLEET_ARRIVAL_RANGE,
					MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS)) return;
			loadAt(station, bayIndex, fleet, target.getMarket());
			List<String> plan = get(station, PLAN_KEY, bayIndex);
			if (plan != null && !plan.isEmpty()) plan.remove(0);
			routeToNextStop(station, bayIndex, fleet);
			return;
		}

		if (STATE_DELIVER.equals(state)) {
			if (target == null) {
				startReturn(station, bayIndex, fleet);
				return;
			}
			if (!MilitaryWardModule.courierHasArrived(fleet, target, MilitaryWardModule.COURIER_FLEET_ARRIVAL_RANGE,
					MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS)) return;
			deliver(station, bayIndex, fleet, target.getMarket());
			startReturn(station, bayIndex, fleet);
		}
	}

	private static void routeToNextStop(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		List<String> plan = get(station, PLAN_KEY, bayIndex);
		SectorEntityToken next = null;
		while (plan != null && !plan.isEmpty()) {
			MarketAPI m = CourierCharterData.getMarket(plan.get(0));
			if (m != null && m.getPrimaryEntity() != null) {
				next = m.getPrimaryEntity();
				break;
			}
			plan.remove(0);
		}
		String state = STATE_PICKUP;
		String label = "Collecting cargo at ";
		if (next == null) {
			String destId = get(station, DEST_KEY, bayIndex);
			MarketAPI dest = CourierCharterData.getMarket(destId);
			if (dest == null || dest.getPrimaryEntity() == null) {
				startReturn(station, bayIndex, fleet);
				return;
			}
			next = dest.getPrimaryEntity();
			state = STATE_DELIVER;
			label = "Delivering cargo to ";
		}
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, next, MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				label + next.getName());
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex), next);
		mem.set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_STATE_MEMORY_KEY, bayIndex), state);
	}

	private static void startReturn(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, MilitaryWardModule.COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				"Returning to the station");
		station.getMemoryWithoutUpdate().set(MilitaryWardModule.bayKey(MilitaryWardModule.COURIER_FLEET_STATE_MEMORY_KEY, bayIndex),
				MilitaryWardModule.COURIER_FLEET_STATE_RETURNING);
	}

	private static void loadAt(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, MarketAPI market) {
		if (market == null) return;
		SubmarketAPI sub = MilitaryWardModule.getCourierTargetStorage(market);
		if (sub == null || sub.getCargo() == null) return;
		CargoAPI source = sub.getCargo();
		List<CharterItem> needs = get(station, NEEDS_KEY, bayIndex);
		CargoAPI loaded = get(station, LOADED_KEY, bayIndex);
		List<FleetMemberAPI> carried = get(station, SHIPS_KEY, bayIndex);
		if (needs == null || loaded == null) return;

		CargoAPI fleetCargo = MilitaryWardModule.getCourierFleetHold(station, bayIndex);
		float spaceLeft = Math.max(0f, MilitaryWardModule.getFleetBaseCargoCapacity(fleet) - fleetCargo.getSpaceUsed());
		int personnelLeft = (int) Math.max(0f, fleet.getCargo().getMaxPersonnel() - fleetCargo.getTotalPersonnel());
		float fuelRoom = Math.max(0f, MilitaryWardModule.getFleetBaseFuelCapacity(fleet) - fleetCargo.getFuel());
		boolean limited = false;

		for (CharterItem item : needs) {
			if (item == null || item.amount <= 0) continue;

			if (item.isShip()) {
				if (carried == null || source.getMothballedShips() == null) continue;
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(source.getMothballedShips().getMembersListCopy())) {
					if (item.amount <= 0) break;
					if (!item.id.equals(m.getHullId())) continue;
					source.getMothballedShips().removeFleetMember(m);
					carried.add(m);
					item.amount--;
				}
				continue;
			}

			CargoAPI.CargoItemType type = item.cargoType();
			if (type == null) continue;
			Object data = dataFor(source, item);
			float avail = countIn(source, item);
			float want = Math.min(item.amount, (float) Math.floor(avail));
			if (want <= 0f) continue;

			CargoAPI probe = Global.getFactory().createCargo(true);
			probe.addItems(type, data, 1f);
			List<CargoStackAPI> probeStacks = probe.getStacksCopy();
			if (probeStacks.isEmpty()) continue;
			CargoStackAPI ps = probeStacks.get(0);

			float units;
			if (ps.isFuelStack()) {
				units = Math.min(want, fuelRoom);
				fuelRoom -= (float) Math.floor(units);
			} else if (ps.isPersonnelStack()) {
				units = Math.min(want, personnelLeft);
				personnelLeft -= (int) Math.floor(units);
			} else {
				float perUnit = ps.getCargoSpacePerUnit();
				units = perUnit > 0f ? Math.min(want, (float) Math.floor(spaceLeft / perUnit)) : want;
				spaceLeft -= units * Math.max(0f, perUnit);
			}
			units = (float) Math.floor(units);
			if (units < want) limited = true;
			if (units <= 0f) continue;

			source.removeItems(type, data, units);
			fleetCargo.addItems(type, data, units);
			loaded.addItems(type, data, units);
			item.amount -= (int) units;
		}
		if (limited) station.getMemoryWithoutUpdate().set(MilitaryWardModule.bayKey(LIMITED_KEY, bayIndex), true);
	}

	private static void deliver(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, MarketAPI dest) {
		if (dest == null) return;
		SubmarketAPI sub = MilitaryWardModule.getCourierTargetStorage(dest);
		if (sub == null || sub.getCargo() == null) return;
		CargoAPI destCargo = sub.getCargo();
		CargoAPI loaded = get(station, LOADED_KEY, bayIndex);
		List<FleetMemberAPI> carried = get(station, SHIPS_KEY, bayIndex);
		Integer requestId = get(station, ID_KEY, bayIndex);
		boolean limited = station.getMemoryWithoutUpdate().getBoolean(MilitaryWardModule.bayKey(LIMITED_KEY, bayIndex));

		StringBuilder summary = new StringBuilder();
		int kinds = 0;
		if (loaded != null) {
			CargoAPI fleetCargo = MilitaryWardModule.getCourierFleetHold(station, bayIndex);
			for (CargoStackAPI stack : new ArrayList<CargoStackAPI>(loaded.getStacksCopy())) {
				if (stack == null || stack.isNull()) continue;
				float inFleet = fleetCargo.getQuantity(stack.getType(), stack.getData());
				float units = Math.min(stack.getSize(), inFleet);
				if (units <= 0f) continue;
				fleetCargo.removeItems(stack.getType(), stack.getData(), units);
				destCargo.addItems(stack.getType(), stack.getData(), units);
				kinds++;
				if (kinds <= 6) {
					if (summary.length() > 0) summary.append(", ");
					summary.append((int) units).append(" ").append(stack.getDisplayName());
				}
			}
			loaded.clear();
		}
		if (carried != null && !carried.isEmpty()) {
			destCargo.initMothballedShips(Factions.PLAYER);
			if (destCargo.getMothballedShips() != null) {
				for (FleetMemberAPI m : carried) {
					destCargo.getMothballedShips().addFleetMember(m);
					kinds++;
					if (kinds <= 6) {
						if (summary.length() > 0) summary.append(", ");
						summary.append("1 ").append(m.getHullSpec().getHullName());
					}
				}
				carried.clear();
			}
		}
		if (kinds > 6) summary.append(" and more");

		CourierCharterState state = CourierCharterData.getState();
		CourierRequest r = requestId != null ? CourierCharterData.findRequest(requestId) : null;
		if (r != null) {
			r.runs++;
			r.inTransit = false;
			r.status = "Delivered, next check in " + (limited ? 1 : state.intervalDays) + " day" + (limited ? "" : "s");
			r.daysLeft = limited ? 1 : state.intervalDays;
		}
		station.getMemoryWithoutUpdate().unset(MilitaryWardModule.bayKey(ID_KEY, bayIndex));
		if (summary.length() > 0) {
			Global.getSector().getCampaignUI().addMessage("Courier Fleet " + (bayIndex + 1) + " delivered to "
					+ dest.getName() + ": " + summary);
		}
	}

	public static void onRunEnded(SectorEntityToken station, int bayIndex, boolean keepShips) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		if (!mem.contains(MilitaryWardModule.bayKey(ID_KEY, bayIndex))
				&& !mem.contains(MilitaryWardModule.bayKey(SHIPS_KEY, bayIndex))) return;

		Integer requestId = get(station, ID_KEY, bayIndex);
		List<FleetMemberAPI> carried = get(station, SHIPS_KEY, bayIndex);
		if (keepShips && carried != null && !carried.isEmpty()) {
			CargoAPI hq = PlayerHQUtils.getStationStorageCargo(station);
			if (hq != null) {
				hq.initMothballedShips(Factions.PLAYER);
				if (hq.getMothballedShips() != null) {
					for (FleetMemberAPI m : carried) hq.getMothballedShips().addFleetMember(m);
				}
			}
		}
		if (requestId != null) {
			CourierRequest r = CourierCharterData.findRequest(requestId);
			if (r != null && r.inTransit) {
				r.inTransit = false;
				r.status = keepShips ? "Courier Fleet recalled" : "Courier Fleet was lost";
			}
		}
		mem.unset(MilitaryWardModule.bayKey(ID_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(PLAN_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(NEEDS_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(SHIPS_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(LOADED_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(DEST_KEY, bayIndex));
		mem.unset(MilitaryWardModule.bayKey(LIMITED_KEY, bayIndex));
	}
}
