package playerhq.modules;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignClockAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI.ShipTypeHints;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.ListMap;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class AssemblyBayModule {

	public static final String MEMORY_KEY = "$playerhq_module_assembly";
	public static final String NANOFORGE_MEMORY_KEY = "$playerhq_module_assembly_nanoforge";
	public static final String NANOFORGE_ITEM_KEY = "$playerhq_module_assembly_nanoforge_item";
	// Stores which AI system tier is installed: AI_SYSTEM_TIER_GAMMA / _BETA / _ALPHA, or unset if none.
	public static final String AI_SYSTEM_MEMORY_KEY = "$playerhq_module_assembly_ai_system";
	public static final String CRYOARITHMETIC_MEMORY_KEY = "$playerhq_module_assembly_cryoarithmetic";
	public static final String POOL_MEMORY_KEY = "$playerhq_module_assembly_pool";

	public static final float CREDIT_COST = 125000f;
	public static final float METALS_COST = 10000f;
	public static final float TRANSPLUTONICS_COST = 7500f;
	public static final float VOLATILES_COST = 2500f;
	public static final float HEAVY_MACHINERY_COST = 3000f;

	public static final float POOL_BASE_MAX = 500000f;
	public static final float POOL_MONTHLY_BASE = 10000f;

	public static final float CORRUPTED_NANOFORGE_DISCOUNT = 0.10f;
	public static final float PRISTINE_NANOFORGE_DISCOUNT = 0.25f;
	public static final float CORRUPTED_NANOFORGE_CREDIT_BONUS = 5000f;
	public static final float PRISTINE_NANOFORGE_CREDIT_BONUS = 10000f;
	public static final float CORRUPTED_NANOFORGE_POOL_CAP_BONUS = 100000f;
	public static final float PRISTINE_NANOFORGE_POOL_CAP_BONUS = 250000f;

	public static final String AI_SYSTEM_TIER_GAMMA = "GAMMA";
	public static final String AI_SYSTEM_TIER_BETA = "BETA";
	public static final String AI_SYSTEM_TIER_ALPHA = "ALPHA";

	public static final float GAMMA_CORE_COST = 1f;
	public static final float BETA_CORE_COST = 1f;
	public static final float ALPHA_CORE_COST = 1f;

	public static final float GAMMA_AI_SYSTEM_COST_REDUCTION = 0.05f;
	public static final float BETA_AI_SYSTEM_COST_REDUCTION = 0.10f;
	public static final float ALPHA_AI_SYSTEM_COST_REDUCTION = 0.25f;

	public static final float GAMMA_AI_SYSTEM_CREDIT_BONUS = 5000f;
	public static final float BETA_AI_SYSTEM_CREDIT_BONUS = 10000f;
	public static final float ALPHA_AI_SYSTEM_CREDIT_BONUS = 15000f;

	public static final float GAMMA_AI_SYSTEM_POOL_CAP_BONUS = 75000f;
	public static final float BETA_AI_SYSTEM_POOL_CAP_BONUS = 150000f;
	public static final float ALPHA_AI_SYSTEM_POOL_CAP_BONUS = 250000f;

	public static final float CREDITS_PER_POOL_CREDIT = 10f;
	public static final float[] INJECT_TIERS = { 1000f, 5000f, 25000f, 100000f };

	public static final String IMAGE_PATH = "graphics/modules/assembly_bay.jpg";

	public static final String QUEUE_MEMORY_KEY = "$playerhq_module_assembly_queue";
	public static final String DELIVERED_SHIPS_KEY = "$playerhq_module_assembly_delivered_ships";
	public static final String DELIVERED_WEAPONS_KEY = "$playerhq_module_assembly_delivered_weapons";
	public static final String DELIVERED_WINGS_KEY = "$playerhq_module_assembly_delivered_wings";

	public static final float DAYS_PER_CREDIT_COST = 1f / 5000f;
	public static final float MIN_BUILD_DAYS = 1f;

	public static class ProductionOrder implements Serializable {
		private static final long serialVersionUID = 1L;

		public String category;
		public String id;
		public String name;
		public float cost;
		public float durationDays;
		public boolean started;
		public long startTimestamp;
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= VOLATILES_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, VOLATILES_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
		station.getMemoryWithoutUpdate().set(POOL_MEMORY_KEY, 0f);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		refund(station, playerFleet, playerFleet.getCargo());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI cargo) {
		if (!isBuilt(station)) return;

		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);

		if (hasNanoforgeInstalled(station)) {
			String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
			if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
		}
		if (hasAiSystemInstalled(station)) {
			String tier = getAiSystemTier(station);
			if (AI_SYSTEM_TIER_ALPHA.equals(tier)) {
				cargo.addCommodity(Commodities.ALPHA_CORE, ALPHA_CORE_COST);
			} else if (AI_SYSTEM_TIER_BETA.equals(tier)) {
				cargo.addCommodity(Commodities.BETA_CORE, BETA_CORE_COST);
			} else {
				cargo.addCommodity(Commodities.GAMMA_CORE, GAMMA_CORE_COST);
			}
		}
		if (hasCryoarithmeticEngineInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null), 1);
		}
	}

	public static boolean hasNanoforgeInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(NANOFORGE_MEMORY_KEY);
	}

	public static boolean hasNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CORRUPTED_NANOFORGE)
				|| PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	public static boolean hasCorruptedNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CORRUPTED_NANOFORGE);
	}

	public static boolean hasPristineNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	public static void installCorruptedNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		installNanoforgeTier(station, playerFleet, Items.CORRUPTED_NANOFORGE);
	}

	public static void installPristineNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		installNanoforgeTier(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	private static void installNanoforgeTier(SectorEntityToken station, CampaignFleetAPI playerFleet, String itemId) {
		if (!PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, itemId)) return;

		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, itemId, 1);
		station.getMemoryWithoutUpdate().set(NANOFORGE_ITEM_KEY, itemId);
		station.getMemoryWithoutUpdate().set(NANOFORGE_MEMORY_KEY, true);
	}

	public static void uninstallNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasNanoforgeInstalled(station)) return;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
		PlayerHQUtils.addToStationInventory(station, itemId, 1);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_ITEM_KEY);
	}

	public static float getNanoforgeDiscount(SectorEntityToken station) {
		if (!hasNanoforgeInstalled(station)) return 0f;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (Items.PRISTINE_NANOFORGE.equals(itemId)) return PRISTINE_NANOFORGE_DISCOUNT;
		return CORRUPTED_NANOFORGE_DISCOUNT;
	}

	public static String getNanoforgeType(SectorEntityToken station) {
		if (!hasNanoforgeInstalled(station)) return null;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (Items.PRISTINE_NANOFORGE.equals(itemId)) return "Pristine";
		return "Corrupted";
	}

	public static boolean hasAiSystemInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().get(AI_SYSTEM_MEMORY_KEY) != null;
	}

	public static String getAiSystemTier(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getString(AI_SYSTEM_MEMORY_KEY);
	}

	public static boolean hasGammaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.GAMMA_CORE) >= GAMMA_CORE_COST;
	}

	public static boolean hasBetaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.BETA_CORE) >= BETA_CORE_COST;
	}

	public static boolean hasAlphaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ALPHA_CORE) >= ALPHA_CORE_COST;
	}

	public static boolean hasCryoarithmeticEngineInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(CRYOARITHMETIC_MEMORY_KEY);
	}

	public static boolean hasCryoarithmeticEngineAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CRYOARITHMETIC_ENGINE);
	}

	public static boolean hasGammaAiSystemAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return hasGammaCoreAvailable(station, playerFleet) && hasCryoarithmeticEngineAvailable(station, playerFleet);
	}

	public static boolean hasBetaAiSystemAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return hasBetaCoreAvailable(station, playerFleet) && hasCryoarithmeticEngineAvailable(station, playerFleet);
	}

	public static boolean hasAlphaAiSystemAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return hasAlphaCoreAvailable(station, playerFleet) && hasCryoarithmeticEngineAvailable(station, playerFleet);
	}

	public static void installGammaAiSystem(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasGammaAiSystemAvailable(station, playerFleet)) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.GAMMA_CORE, GAMMA_CORE_COST);
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.CRYOARITHMETIC_ENGINE, 1);
		station.getMemoryWithoutUpdate().set(AI_SYSTEM_MEMORY_KEY, AI_SYSTEM_TIER_GAMMA);
		station.getMemoryWithoutUpdate().set(CRYOARITHMETIC_MEMORY_KEY, true);
	}

	public static void installBetaAiSystem(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasBetaAiSystemAvailable(station, playerFleet)) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.BETA_CORE, BETA_CORE_COST);
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.CRYOARITHMETIC_ENGINE, 1);
		station.getMemoryWithoutUpdate().set(AI_SYSTEM_MEMORY_KEY, AI_SYSTEM_TIER_BETA);
		station.getMemoryWithoutUpdate().set(CRYOARITHMETIC_MEMORY_KEY, true);
	}

	public static void installAlphaAiSystem(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasAlphaAiSystemAvailable(station, playerFleet)) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.ALPHA_CORE, ALPHA_CORE_COST);
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.CRYOARITHMETIC_ENGINE, 1);
		station.getMemoryWithoutUpdate().set(AI_SYSTEM_MEMORY_KEY, AI_SYSTEM_TIER_ALPHA);
		station.getMemoryWithoutUpdate().set(CRYOARITHMETIC_MEMORY_KEY, true);
	}

	public static void uninstallAiSystem(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasAiSystemInstalled(station)) return;

		String tier = getAiSystemTier(station);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			if (AI_SYSTEM_TIER_ALPHA.equals(tier)) {
				storage.addCommodity(Commodities.ALPHA_CORE, ALPHA_CORE_COST);
			} else if (AI_SYSTEM_TIER_BETA.equals(tier)) {
				storage.addCommodity(Commodities.BETA_CORE, BETA_CORE_COST);
			} else {
				storage.addCommodity(Commodities.GAMMA_CORE, GAMMA_CORE_COST);
			}
		}
		PlayerHQUtils.addToStationInventory(station, Items.CRYOARITHMETIC_ENGINE, 1);
		station.getMemoryWithoutUpdate().unset(AI_SYSTEM_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(CRYOARITHMETIC_MEMORY_KEY);
	}

	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasNanoforgeInstalled(station)
				&& !hasAiSystemInstalled(station) && !hasCryoarithmeticEngineInstalled(station)
				&& getQueueLength(station) == 0;
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet, PlayerHQUtils.getRefundCargo(station, playerFleet));
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(POOL_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(QUEUE_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(DELIVERED_SHIPS_KEY);
		station.getMemoryWithoutUpdate().unset(DELIVERED_WEAPONS_KEY);
		station.getMemoryWithoutUpdate().unset(DELIVERED_WINGS_KEY);
	}

	public static float getNanoforgeCreditBonus(SectorEntityToken station) {
		if (!hasNanoforgeInstalled(station)) return 0f;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (Items.PRISTINE_NANOFORGE.equals(itemId)) return PRISTINE_NANOFORGE_CREDIT_BONUS;
		return CORRUPTED_NANOFORGE_CREDIT_BONUS;
	}

	public static float getNanoforgePoolCapBonus(SectorEntityToken station) {
		if (!hasNanoforgeInstalled(station)) return 0f;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (Items.PRISTINE_NANOFORGE.equals(itemId)) return PRISTINE_NANOFORGE_POOL_CAP_BONUS;
		return CORRUPTED_NANOFORGE_POOL_CAP_BONUS;
	}

	public static float getAiSystemCostReduction(SectorEntityToken station) {
		String tier = getAiSystemTier(station);
		if (AI_SYSTEM_TIER_ALPHA.equals(tier)) return ALPHA_AI_SYSTEM_COST_REDUCTION;
		if (AI_SYSTEM_TIER_BETA.equals(tier)) return BETA_AI_SYSTEM_COST_REDUCTION;
		if (AI_SYSTEM_TIER_GAMMA.equals(tier)) return GAMMA_AI_SYSTEM_COST_REDUCTION;
		return 0f;
	}

	public static float getAiSystemCreditBonus(SectorEntityToken station) {
		String tier = getAiSystemTier(station);
		if (AI_SYSTEM_TIER_ALPHA.equals(tier)) return ALPHA_AI_SYSTEM_CREDIT_BONUS;
		if (AI_SYSTEM_TIER_BETA.equals(tier)) return BETA_AI_SYSTEM_CREDIT_BONUS;
		if (AI_SYSTEM_TIER_GAMMA.equals(tier)) return GAMMA_AI_SYSTEM_CREDIT_BONUS;
		return 0f;
	}

	public static float getAiSystemPoolCapBonus(SectorEntityToken station) {
		String tier = getAiSystemTier(station);
		if (AI_SYSTEM_TIER_ALPHA.equals(tier)) return ALPHA_AI_SYSTEM_POOL_CAP_BONUS;
		if (AI_SYSTEM_TIER_BETA.equals(tier)) return BETA_AI_SYSTEM_POOL_CAP_BONUS;
		if (AI_SYSTEM_TIER_GAMMA.equals(tier)) return GAMMA_AI_SYSTEM_POOL_CAP_BONUS;
		return 0f;
	}

	public static float getTotalDiscount(SectorEntityToken station) {
		float total = getNanoforgeDiscount(station) + getAiSystemCostReduction(station);
		return Math.min(1f, total);
	}

	public static float getMonthlyGeneration(SectorEntityToken station) {
		return POOL_MONTHLY_BASE + getNanoforgeCreditBonus(station) + getAiSystemCreditBonus(station);
	}

	public static float getPoolMax(SectorEntityToken station) {
		return POOL_BASE_MAX + getNanoforgePoolCapBonus(station) + getAiSystemPoolCapBonus(station);
	}

	public static float getPoolValue(SectorEntityToken station) {
		if (!isBuilt(station)) return 0f;
		return station.getMemoryWithoutUpdate().getFloat(POOL_MEMORY_KEY);
	}

	private static void setPoolValue(SectorEntityToken station, float value) {
		if (value < 0f) value = 0f;
		float max = getPoolMax(station);
		if (value > max) value = max;
		station.getMemoryWithoutUpdate().set(POOL_MEMORY_KEY, value);
	}

	public static void accumulateMonthly(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		setPoolValue(station, getPoolValue(station) + getMonthlyGeneration(station));
	}

	public static float getInjectableAmount(SectorEntityToken station, float requestedIncrease) {
		if (!isBuilt(station)) return 0f;
		float room = getPoolMax(station) - getPoolValue(station);
		return Math.max(0f, Math.min(requestedIncrease, room));
	}

	public static float getInjectionCost(SectorEntityToken station, float requestedIncrease) {
		return getInjectableAmount(station, requestedIncrease) * CREDITS_PER_POOL_CREDIT;
	}

	public static boolean canInjectCredits(SectorEntityToken station, CampaignFleetAPI playerFleet, float requestedIncrease) {
		float actual = getInjectableAmount(station, requestedIncrease);
		if (actual <= 0f) return false;
		return playerFleet.getCargo().getCredits().get() >= actual * CREDITS_PER_POOL_CREDIT;
	}

	public static float injectCredits(SectorEntityToken station, CampaignFleetAPI playerFleet, float requestedIncrease) {
		float actual = getInjectableAmount(station, requestedIncrease);
		if (actual <= 0f) return 0f;

		float cost = actual * CREDITS_PER_POOL_CREDIT;
		if (playerFleet.getCargo().getCredits().get() < cost) return 0f;

		playerFleet.getCargo().getCredits().subtract(cost);
		setPoolValue(station, getPoolValue(station) + actual);
		return actual;
	}

	public static float getShipCost(SectorEntityToken station, ShipHullSpecAPI hull) {
		return hull.getBaseValue() * (1f - getTotalDiscount(station));
	}

	public static float getWeaponCost(SectorEntityToken station, WeaponSpecAPI weapon) {
		return weapon.getBaseValue() * (1f - getTotalDiscount(station));
	}

	public static float getWingCost(SectorEntityToken station, FighterWingSpecAPI wing) {
		return wing.getBaseValue() * (1f - getTotalDiscount(station));
	}

	public static boolean canAfford(SectorEntityToken station, CampaignFleetAPI playerFleet, float cost) {
		return cost <= getPoolValue(station) && playerFleet.getCargo().getCredits().get() >= cost;
	}

	public static String getFirstVariantId(String hullId) {
		if (hullId == null) return null;
		try {
			String bareId = hullId + "_Hull";
			if (Global.getSettings().getVariant(bareId) != null) return bareId;
		} catch (Throwable t) {
		}
		ListMap<String> variantsByHull = Global.getSettings().getHullIdToVariantListMap();
		List<String> variants = variantsByHull.get(hullId);
		if (variants == null || variants.isEmpty()) return null;
		for (String variantId : variants) {
			try {
				com.fs.starfarer.api.combat.ShipVariantAPI variant = Global.getSettings().getVariant(variantId);
				if (variant == null) continue;
				if (!variant.getSMods().isEmpty() || !variant.getPermaMods().isEmpty()) continue;
				return variantId;
			} catch (Throwable t) {
			}
		}
		return variants.get(0);
	}

	public static float getBuildDurationDays(float cost) {
		float days = (float) Math.ceil(cost * DAYS_PER_CREDIT_COST);
		return Math.max(MIN_BUILD_DAYS, days);
	}

	@SuppressWarnings("unchecked")
	public static List<ProductionOrder> getQueue(SectorEntityToken station) {
		Object stored = station.getMemoryWithoutUpdate().get(QUEUE_MEMORY_KEY);
		if (stored instanceof List) {
			return new ArrayList<ProductionOrder>((List<ProductionOrder>) stored);
		}
		return new ArrayList<ProductionOrder>();
	}

	private static void setQueue(SectorEntityToken station, List<ProductionOrder> queue) {
		station.getMemoryWithoutUpdate().set(QUEUE_MEMORY_KEY, new ArrayList<ProductionOrder>(queue));
	}

	public static ProductionOrder getActiveOrder(SectorEntityToken station) {
		List<ProductionOrder> queue = getQueue(station);
		return queue.isEmpty() ? null : queue.get(0);
	}

	public static int getQueueLength(SectorEntityToken station) {
		return getQueue(station).size();
	}

	public static float getTotalQueueDaysRemaining(SectorEntityToken station) {
		List<ProductionOrder> queue = getQueue(station);
		if (queue.isEmpty()) return 0f;

		float total = getDaysRemaining(station);
		for (int i = 1; i < queue.size(); i++) {
			total += queue.get(i).durationDays;
		}
		return total;
	}

	public static float getDaysRemaining(SectorEntityToken station) {
		ProductionOrder active = getActiveOrder(station);
		if (active == null) return 0f;
		if (!active.started) return active.durationDays;

		float elapsed = Global.getSector().getClock().getElapsedDaysSince(active.startTimestamp);
		return Math.max(0f, active.durationDays - elapsed);
	}

	private static void enqueue(SectorEntityToken station, ProductionOrder order) {
		List<ProductionOrder> queue = getQueue(station);
		queue.add(order);
		setQueue(station, queue);
	}

	private static void deliverOrder(SectorEntityToken station, ProductionOrder order) {
		if (station.getMarket() == null) return;
		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		if ("ship".equals(order.category)) {
			String variantId = getFirstVariantId(order.id);
			if (variantId != null) {
				storage.addMothballedShip(FleetMemberType.SHIP, variantId, null);
				appendDelivered(station, DELIVERED_SHIPS_KEY, order.name);
			}
		} else if ("weapon".equals(order.category)) {
			storage.addWeapons(order.id, 1);
			appendDelivered(station, DELIVERED_WEAPONS_KEY, order.name);
		} else if ("wing".equals(order.category)) {
			storage.addFighters(order.id, 1);
			appendDelivered(station, DELIVERED_WINGS_KEY, order.name);
		}
	}

	@SuppressWarnings("unchecked")
	private static List<String> getStringList(SectorEntityToken station, String key) {
		Object stored = station.getMemoryWithoutUpdate().get(key);
		if (stored instanceof List) {
			return new ArrayList<String>((List<String>) stored);
		}
		return new ArrayList<String>();
	}

	private static void appendDelivered(SectorEntityToken station, String key, String name) {
		List<String> list = getStringList(station, key);
		list.add(name);
		station.getMemoryWithoutUpdate().set(key, list);
	}

	public static List<String> getDeliveredShipsThisMonth(SectorEntityToken station) {
		return getStringList(station, DELIVERED_SHIPS_KEY);
	}

	public static List<String> getDeliveredWeaponsThisMonth(SectorEntityToken station) {
		return getStringList(station, DELIVERED_WEAPONS_KEY);
	}

	public static List<String> getDeliveredWingsThisMonth(SectorEntityToken station) {
		return getStringList(station, DELIVERED_WINGS_KEY);
	}

	public static void clearDeliveredThisMonth(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(DELIVERED_SHIPS_KEY);
		station.getMemoryWithoutUpdate().unset(DELIVERED_WEAPONS_KEY);
		station.getMemoryWithoutUpdate().unset(DELIVERED_WINGS_KEY);
	}

	public static void advanceProduction(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		if (station.getMarket() == null) return;

		List<ProductionOrder> queue = getQueue(station);
		if (queue.isEmpty()) return;

		ProductionOrder active = queue.get(0);
		CampaignClockAPI clock = Global.getSector().getClock();

		if (!active.started) {
			active.started = true;
			active.startTimestamp = clock.getTimestamp();
			setQueue(station, queue);
			return;
		}

		float elapsed = clock.getElapsedDaysSince(active.startTimestamp);
		if (elapsed < active.durationDays) return;

		deliverOrder(station, active);
		queue.remove(0);
		setQueue(station, queue);
	}

	public static boolean buildShip(SectorEntityToken station, CampaignFleetAPI playerFleet, String hullId) {
		if (!isBuilt(station)) return false;
		if (station.getMarket() == null) return false;

		ShipHullSpecAPI hull = Global.getSettings().getHullSpec(hullId);
		if (hull == null) return false;
		if (!Global.getSector().getPlayerFaction().knowsShip(hullId)) return false;

		String variantId = getFirstVariantId(hullId);
		if (variantId == null) return false;

		float cost = getShipCost(station, hull);
		if (!canAfford(station, playerFleet, cost)) return false;

		playerFleet.getCargo().getCredits().subtract(cost);
		setPoolValue(station, getPoolValue(station) - cost);

		ProductionOrder order = new ProductionOrder();
		order.category = "ship";
		order.id = hullId;
		order.name = hull.getHullName();
		order.cost = cost;
		order.durationDays = getBuildDurationDays(cost);
		enqueue(station, order);
		return true;
	}

	public static boolean buildWeapon(SectorEntityToken station, CampaignFleetAPI playerFleet, String weaponId) {
		if (!isBuilt(station)) return false;
		if (station.getMarket() == null) return false;

		WeaponSpecAPI weapon = Global.getSettings().getWeaponSpec(weaponId);
		if (weapon == null) return false;
		if (!Global.getSector().getPlayerFaction().knowsWeapon(weaponId)) return false;

		float cost = getWeaponCost(station, weapon);
		if (!canAfford(station, playerFleet, cost)) return false;

		playerFleet.getCargo().getCredits().subtract(cost);
		setPoolValue(station, getPoolValue(station) - cost);

		ProductionOrder order = new ProductionOrder();
		order.category = "weapon";
		order.id = weaponId;
		order.name = weapon.getWeaponName();
		order.cost = cost;
		order.durationDays = getBuildDurationDays(cost);
		enqueue(station, order);
		return true;
	}

	public static boolean buildWing(SectorEntityToken station, CampaignFleetAPI playerFleet, String wingId) {
		if (!isBuilt(station)) return false;
		if (station.getMarket() == null) return false;

		FighterWingSpecAPI wing = Global.getSettings().getFighterWingSpec(wingId);
		if (wing == null) return false;
		if (!Global.getSector().getPlayerFaction().knowsFighter(wingId)) return false;

		float cost = getWingCost(station, wing);
		if (!canAfford(station, playerFleet, cost)) return false;

		playerFleet.getCargo().getCredits().subtract(cost);
		setPoolValue(station, getPoolValue(station) - cost);

		ProductionOrder order = new ProductionOrder();
		order.category = "wing";
		order.id = wingId;
		order.name = wing.getWingName();
		order.cost = cost;
		order.durationDays = getBuildDurationDays(cost);
		enqueue(station, order);
		return true;
	}

	public static List<ShipHullSpecAPI> getKnownBuildableHulls() {
		List<ShipHullSpecAPI> result = new ArrayList<ShipHullSpecAPI>();

		FactionAPI playerFaction = Global.getSector().getPlayerFaction();
		if (playerFaction == null) return result;

		ListMap<String> variantsByHull = Global.getSettings().getHullIdToVariantListMap();

		for (ShipHullSpecAPI spec : Global.getSettings().getAllShipHullSpecs()) {
			if (spec.isDHull()) continue;

			java.util.EnumSet<ShipTypeHints> hints = spec.getHints();
			if (hints.contains(ShipTypeHints.STATION)) continue;
			if (hints.contains(ShipTypeHints.MODULE)) continue;
			if (hints.contains(ShipTypeHints.UNDER_PARENT)) continue;
			if (hints.contains(ShipTypeHints.HIDE_IN_CODEX)) continue;

			if (!playerFaction.knowsShip(spec.getHullId())) continue;

			List<String> variants = variantsByHull.get(spec.getHullId());
			if (variants == null || variants.isEmpty()) continue;

			result.add(spec);
		}

		Collections.sort(result, new Comparator<ShipHullSpecAPI>() {
			@Override
			public int compare(ShipHullSpecAPI a, ShipHullSpecAPI b) {
				return a.getHullName().compareToIgnoreCase(b.getHullName());
			}
		});

		return result;
	}

	public static List<WeaponSpecAPI> getKnownBuildableWeapons() {
		List<WeaponSpecAPI> result = new ArrayList<WeaponSpecAPI>();

		FactionAPI playerFaction = Global.getSector().getPlayerFaction();
		if (playerFaction == null) return result;

		for (WeaponSpecAPI spec : Global.getSettings().getAllWeaponSpecs()) {
			if (!playerFaction.knowsWeapon(spec.getWeaponId())) continue;
			result.add(spec);
		}

		Collections.sort(result, new Comparator<WeaponSpecAPI>() {
			@Override
			public int compare(WeaponSpecAPI a, WeaponSpecAPI b) {
				return a.getWeaponName().compareToIgnoreCase(b.getWeaponName());
			}
		});

		return result;
	}
}
