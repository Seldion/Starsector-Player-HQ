package playerhq.modules;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignClockAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.ai.FleetAssignmentDataAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainAPI;
import com.fs.starfarer.api.campaign.CampaignTerrainPlugin;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.procgen.SalvageEntityGenDataSpec;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageEntity;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.intel.raid.RaidIntel;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelAtEntity;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelData;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker.PersonnelRank;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidBeltTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.loading.VariantSource;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.Misc;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.RepairGantry;
import com.fs.starfarer.api.impl.campaign.FleetEncounterContext;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageEntityGeneratorOld;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import playerhq.PlayerHQFleetLossIntel;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.abilities.CourierPickupTransferDialogPlugin;
import playerhq.abilities.ResupplyTransferDialogPlugin;
import playerhq.util.PlayerHQUtils;

public class MilitaryWardModule {

	public static final String MEMORY_KEY = "$playerhq_module_militaryward";
	public static final String HOLOSUITE_MEMORY_KEY = "$playerhq_module_militaryward_holosuite";
	public static final String DRONE_REPLICATOR_MEMORY_KEY = "$playerhq_module_militaryward_dronereplicator";
	public static final String AICORE_MEMORY_KEY = "$playerhq_module_militaryward_aicore";

	public static final float CREDIT_COST = 35000f;
	public static final float METALS_COST = 4000f;
	public static final float TRANSPLUTONICS_COST = 1500f;
	public static final float HEAVY_MACHINERY_COST = 300f;

	public static final float MAX_PERSONNEL = 5000f;

	public static final float CREW_PRODUCTION_PER_MONTH = 100f;
	public static final float MARINE_PRODUCTION_PER_MONTH = 50f;

	public static final float CREW_STIPEND_PER_UNIT = 0.5f;
	public static final float MARINE_STIPEND_PER_UNIT = 10f;

	public static final float TRAINING_RATE_HOLODECK_ONLY = 0.03f;
	public static final float TRAINING_RATE_DRONE_REPLICATOR_ONLY = 0.03f;
	public static final float TRAINING_RATE_BOTH = 0.08f;

	public static final float AI_CORE_COST = 1f;

	public static final float MILITARY_WARD_DEFENSE_BONUS = 0.50f;
	public static final float MILITARY_WARD_STABILITY_BONUS = 1f;
	public static final String MILITARY_WARD_BONUS_MARKET_MEMORY_KEY = "$playerhq_module_militaryward_bonus_market";
	private static final String MILITARY_WARD_DEFENSE_MOD_ID = "playerhq_militaryward_defense";
	private static final String MILITARY_WARD_STABILITY_MOD_ID = "playerhq_militaryward_stability";

	public static final int MAX_TRAINING_EXPEDITION_BAYS = 4;

	public static final int EXPEDITION_BAY_TRANSPORTS_REQUIRED = 2;
	public static final int EXPEDITION_BAY_FREIGHTERS_REQUIRED = 4;
	public static final int EXPEDITION_BAY_TANKERS_REQUIRED = 2;

	public static final float TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST = 10f;
	public static final float TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST = 10f;

	public static final String FLEET_HQ_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_hq";
	public static final float FLEET_HQ_CREDIT_COST = 10000f;
	public static final float FLEET_HQ_METALS_COST = 350f;
	public static final float FLEET_HQ_TRANSPLUTONICS_COST = 35f;
	public static final float FLEET_HQ_VOLATILES_COST = 20f;
	public static final int FLEET_HQ_CREW_COST = 50;

	public static final String TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_ships";
	public static final String TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_crewcost";
	public static final String TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_touring";
	public static final String TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_fleet";
	public static final String TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_planet";
	public static final String TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_lootlog";
	public static final String TRAINING_EXPEDITIONS_STATE_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_state";
	public static final String TRAINING_EXPEDITIONS_ORBIT_DAY_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_orbitday";
	public static final String TRAINING_EXPEDITIONS_RESPAWN_MANIFEST_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_respawnmanifest";
	public static final String TRAINING_EXPEDITIONS_DESTROYED_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_destroyed";
	public static final String TRAINING_EXPEDITIONS_RESPAWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_respawndaysleft";
	public static final String TRAINING_EXPEDITIONS_DESTROYED_CAUSE_MEMORY_KEY = "$playerhq_module_militaryward_trainingexpeditions_destroyedcause";

	private static final String TRAINING_EXPEDITIONS_STATE_OUTBOUND = "outbound";
	private static final String TRAINING_EXPEDITIONS_STATE_WORKING = "working";
	private static final String TRAINING_EXPEDITIONS_STATE_RETURNING = "returning";

	private static final float TRAINING_EXPEDITIONS_ASSIGNMENT_DURATION_CAP_DAYS = 999f;
	private static final float TRAINING_EXPEDITIONS_ARRIVAL_RANGE = 300f;

	// Fleets roll for loot every 10 days spent in orbit, and give up (heading home to resupply)
	// after 3 months (90 days) spent searching without finding anything.
	public static final int TRAINING_EXPEDITIONS_LOOT_ROLL_INTERVAL_DAYS = 10;
	public static final int TRAINING_EXPEDITIONS_MAX_ORBIT_DAYS = 90;

	// How far (in light years) from the Player HQ an Expedition Fleet is willing to travel to reach
	// a planet with ruins.
	public static final float TRAINING_EXPEDITIONS_MAX_RANGE_LY = 10f;

	public static final float RUINS_CHANCE_SCATTERED = 0.02f;
	public static final float RUINS_CHANCE_WIDESPREAD = 0.04f;
	public static final float RUINS_CHANCE_EXTENSIVE = 0.06f;
	public static final float RUINS_CHANCE_VAST = 0.14f;

	public static final float SALVAGING_BONUS_SCATTERED = 0.02f;
	public static final float SALVAGING_BONUS_WIDESPREAD = 0.02f;
	public static final float SALVAGING_BONUS_EXTENSIVE = 0.02f;
	public static final float SALVAGING_BONUS_VAST = 0.02f;

	public static final float MAX_LOOT_SHIP_VALUE = 200000f;

	public static final float LOOT_SHIP_CHANCE_3_DMODS = 0.01f;
	public static final float LOOT_SHIP_CHANCE_2_DMODS = 0.10f;
	public static final float LOOT_SHIP_CHANCE_1_DMOD = 0.30f;
	public static final int MAX_LOOT_SHIP_DMODS = 3;

	private static final float LOOT_WEIGHT_WEAPON = 40f;
	private static final float LOOT_WEIGHT_FIGHTER = 28f;
	private static final float LOOT_WEIGHT_HULLMOD = 14f;
	private static final float LOOT_WEIGHT_BLUEPRINT = 12f;
	private static final float LOOT_WEIGHT_SHIP = 4f;
	private static final float LOOT_WEIGHT_SPECIAL_ITEM = 2f;

	private static final String[] SPECIAL_ITEM_LOOT_POOL = {
			Items.CORRUPTED_NANOFORGE, Items.PRISTINE_NANOFORGE, Items.SYNCHROTRON,
			Items.ORBITAL_FUSION_LAMP, Items.MANTLE_BORE, Items.CATALYTIC_CORE,
			Items.SOIL_NANITES, Items.BIOFACTORY_EMBRYO, Items.FULLERENE_SPOOL,
			Items.PLASMA_DYNAMO, Items.CRYOARITHMETIC_ENGINE, Items.DRONE_REPLICATOR,
			Items.DEALMAKER_HOLOSUITE,
	};

	public static final String[] IMAGE_PATHS = {
			"graphics/modules/military_ward.jpg",
			"graphics/modules/military_ward_2.jpg",
			"graphics/modules/military_ward_3.jpg",
			"graphics/modules/military_ward_4.jpg",
			"graphics/modules/military_ward_5.jpg",
			"graphics/modules/military_ward_6.jpg",
			"graphics/modules/military_ward_7.jpg",
			"graphics/modules/military_ward_8.jpg",
			"graphics/modules/military_ward_9.jpg",
			"graphics/modules/military_ward_10.jpg",
			"graphics/modules/military_ward_11.jpg",
			"graphics/modules/military_ward_12.jpg",
			"graphics/modules/military_ward_13.jpg",
	};

	public static String getRandomImagePath() {
		int index = (int) (Math.random() * IMAGE_PATHS.length);
		if (index >= IMAGE_PATHS.length) index = IMAGE_PATHS.length - 1;
		return IMAGE_PATHS[index];
	}

	public static final String[] TRAINING_EXPEDITION_IMAGE_PATHS = {
			"graphics/modules/training_expedition.jpg",
			"graphics/modules/training_expedition_2.jpg",
			"graphics/modules/training_expedition_3.jpg",
			"graphics/modules/training_expedition_4.jpg",
			"graphics/modules/training_expedition_5.jpg",
	};

	public static final String[] LOGISTIC_FLEET_IMAGE_PATHS = {
			"graphics/modules/logistic_fleet.jpg",
			"graphics/modules/logistic_fleet_2.jpg",
	};

	public static String getRandomLogisticFleetImagePath() {
		int index = (int) (Math.random() * LOGISTIC_FLEET_IMAGE_PATHS.length);
		if (index >= LOGISTIC_FLEET_IMAGE_PATHS.length) index = LOGISTIC_FLEET_IMAGE_PATHS.length - 1;
		return LOGISTIC_FLEET_IMAGE_PATHS[index];
	}

	public static final String[] PATROL_FLEET_IMAGE_PATHS = {
			"graphics/modules/patrol_fleet.jpg",
			"graphics/modules/patrol_fleet_2.jpg",
			"graphics/modules/patrol_fleet_3.jpg",
	};

	public static String getRandomPatrolFleetImagePath() {
		int index = (int) (Math.random() * PATROL_FLEET_IMAGE_PATHS.length);
		if (index >= PATROL_FLEET_IMAGE_PATHS.length) index = PATROL_FLEET_IMAGE_PATHS.length - 1;
		return PATROL_FLEET_IMAGE_PATHS[index];
	}

	public static final String[] MINING_FLEET_IMAGE_PATHS = {
			"graphics/modules/mining_fleet.jpg",
			"graphics/modules/mining_fleet_2.jpg",
			"graphics/modules/mining_fleet_3.jpg",
			"graphics/modules/mining_fleet_4.jpg",
			"graphics/modules/mining_fleet_5.jpg",
			"graphics/modules/mining_fleet_6.jpg",
	};

	public static String getRandomMiningFleetImagePath() {
		int index = (int) (Math.random() * MINING_FLEET_IMAGE_PATHS.length);
		if (index >= MINING_FLEET_IMAGE_PATHS.length) index = MINING_FLEET_IMAGE_PATHS.length - 1;
		return MINING_FLEET_IMAGE_PATHS[index];
	}

	public static String getRandomTrainingExpeditionImagePath() {
		int index = (int) (Math.random() * TRAINING_EXPEDITION_IMAGE_PATHS.length);
		if (index >= TRAINING_EXPEDITION_IMAGE_PATHS.length) index = TRAINING_EXPEDITION_IMAGE_PATHS.length - 1;
		return TRAINING_EXPEDITION_IMAGE_PATHS[index];
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
		updateDefenseAndStabilityBonus(station);
	}

	private static void clearDefenseAndStabilityBonus(SectorEntityToken station) {
		String marketId = station.getMemoryWithoutUpdate().getString(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY);
		if (marketId == null) return;

		MarketAPI market = Global.getSector().getEconomy().getMarket(marketId);
		if (market != null) {
			market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(MILITARY_WARD_DEFENSE_MOD_ID);
			market.getStability().unmodifyFlat(MILITARY_WARD_STABILITY_MOD_ID);
		}
		station.getMemoryWithoutUpdate().unset(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY);
	}

	public static void updateDefenseAndStabilityBonus(SectorEntityToken station) {
		clearDefenseAndStabilityBonus(station);

		if (!isBuilt(station)) return;

		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return;

		market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(
				MILITARY_WARD_DEFENSE_MOD_ID, 1f + MILITARY_WARD_DEFENSE_BONUS, "Military Paradigm (Player HQ)");
		market.getStability().modifyFlat(MILITARY_WARD_STABILITY_MOD_ID, MILITARY_WARD_STABILITY_BONUS, "Military Paradigm (Player HQ)");
		station.getMemoryWithoutUpdate().set(MILITARY_WARD_BONUS_MARKET_MEMORY_KEY, market.getId());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		refund(station, playerFleet, playerFleet.getCargo());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI cargo) {
		if (!isBuilt(station)) return;

		clearDefenseAndStabilityBonus(station);

		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);

		if (hasHolosuiteInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
		}
		if (hasDroneReplicatorInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DRONE_REPLICATOR, null), 1);
		}
		String aiCoreTier = getInstalledAICoreTier(station);
		if (aiCoreTier != null) {
			cargo.addCommodity(aiCoreTier, AI_CORE_COST);
		}

		if (hasFleetHQBuilt(station)) {
			disbandAllBaysInto(station, cargo, playerFleet.getFaction().getId());
			disbandAllPatrolFleetBaysInto(station, cargo, playerFleet.getFaction().getId());
			disbandAllSalvageBaysInto(station, cargo, playerFleet.getFaction().getId());
			cargo.addCommodity(Commodities.METALS, FLEET_HQ_METALS_COST * fraction);
			cargo.addCommodity(Commodities.RARE_METALS, FLEET_HQ_TRANSPLUTONICS_COST * fraction);
			cargo.addCommodity(Commodities.VOLATILES, FLEET_HQ_VOLATILES_COST * fraction);
			cargo.addCrew(FLEET_HQ_CREW_COST);
			station.getMemoryWithoutUpdate().unset(FLEET_HQ_MEMORY_KEY);
		}
	}

	public static boolean hasHolosuiteInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasHolosuiteAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE);
	}

	public static void installHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().set(HOLOSUITE_MEMORY_KEY, true);
	}

	public static void uninstallHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasHolosuiteInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().unset(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static boolean hasDroneReplicatorAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR);
	}

	public static void installDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().set(DRONE_REPLICATOR_MEMORY_KEY, true);
	}

	public static void uninstallDroneReplicator(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasDroneReplicatorInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DRONE_REPLICATOR, 1);
		station.getMemoryWithoutUpdate().unset(DRONE_REPLICATOR_MEMORY_KEY);
	}

	public static String getInstalledAICoreTier(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getString(AICORE_MEMORY_KEY);
	}

	public static boolean hasAICoreInstalled(SectorEntityToken station) {
		return getInstalledAICoreTier(station) != null;
	}

	public static boolean hasGammaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.GAMMA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasBetaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.BETA_CORE) >= AI_CORE_COST;
	}

	public static boolean hasAlphaCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ALPHA_CORE) >= AI_CORE_COST;
	}

	public static void installAICore(SectorEntityToken station, CampaignFleetAPI playerFleet, String coreCommodityId) {
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, coreCommodityId) < AI_CORE_COST) return;

		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, coreCommodityId, AI_CORE_COST);
		station.getMemoryWithoutUpdate().set(AICORE_MEMORY_KEY, coreCommodityId);
	}

	public static void uninstallAICore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return;

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.addCommodity(tier, AI_CORE_COST);
		}
		station.getMemoryWithoutUpdate().unset(AICORE_MEMORY_KEY);
	}

	public static float getAICoreTrainingMultiplier(SectorEntityToken station) {
		String tier = getInstalledAICoreTier(station);
		if (tier == null) return 1f;
		if (Commodities.GAMMA_CORE.equals(tier)) return 2f;
		if (Commodities.BETA_CORE.equals(tier)) return 3f;
		if (Commodities.ALPHA_CORE.equals(tier)) return 4f;
		return 1f;
	}

	private static float getBaseTrainingRatio(SectorEntityToken station) {
		boolean holosuite = hasHolosuiteInstalled(station);
		boolean drone = hasDroneReplicatorInstalled(station);
		if (holosuite && drone) return TRAINING_RATE_BOTH;
		if (holosuite) return TRAINING_RATE_HOLODECK_ONLY;
		if (drone) return TRAINING_RATE_DRONE_REPLICATOR_ONLY;
		return 0f;
	}

	public static float getTrainingRatioPerMonth(SectorEntityToken station) {
		return getBaseTrainingRatio(station) * getAICoreTrainingMultiplier(station);
	}

	public static float getExpectedMonthlyTrainingXP(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return 0f;
		float marines = storageSubmarket.getCargo().getMarines();
		if (marines <= 0f) return 0f;
		return getTrainingRatioPerMonth(station) * marines;
	}

	private static SubmarketAPI getStorageSubmarket(SectorEntityToken station) {
		if (station.getMarket() == null) return null;
		return station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE);
	}

	private static void addCrewCapped(CargoAPI storage, float amount) {
		int current = storage.getCrew();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addCrew(toAdd);
	}

	private static void addMarinesCapped(CargoAPI storage, float amount) {
		int current = storage.getMarines();
		int space = (int) MAX_PERSONNEL - current;
		if (space <= 0 || amount <= 0f) return;
		int toAdd = (int) Math.min(amount, space);
		if (toAdd > 0) storage.addMarines(toAdd);
	}

	public static void enforceCap(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;
		CargoAPI storage = storageSubmarket.getCargo();

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();

		int crew = storage.getCrew();
		if (crew > (int) MAX_PERSONNEL) {
			int excess = crew - (int) MAX_PERSONNEL;
			storage.removeCrew(excess);
			if (playerFleet != null) playerFleet.getCargo().addCrew(excess);
		}

		int marines = storage.getMarines();
		if (marines > (int) MAX_PERSONNEL) {
			int excess = marines - (int) MAX_PERSONNEL;
			storage.removeMarines(excess);
			if (playerFleet != null) playerFleet.getCargo().addMarines(excess);
		}
	}

	private static void applyTraining(SectorEntityToken station, SubmarketAPI storageSubmarket) {
		float ratio = getTrainingRatioPerMonth(station);
		if (ratio <= 0f) return;

		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return;

		at.data.numMayHaveChanged(marines, true);
		at.data.addXP(ratio * marines);
	}

	public static float[] accumulateMonthly(SectorEntityToken station) {
		float[] stipends = new float[] { 0f, 0f };
		if (!isBuilt(station)) return stipends;

		updateDefenseAndStabilityBonus(station);

		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return stipends;
		CargoAPI storage = storageSubmarket.getCargo();

		addCrewCapped(storage, CREW_PRODUCTION_PER_MONTH);
		addMarinesCapped(storage, MARINE_PRODUCTION_PER_MONTH);

		float[] owed = computeStipends(station);
		stipends[0] = owed[0];
		stipends[1] = owed[1];

		applyTraining(station, storageSubmarket);
		return stipends;
	}

	public static float[] computeStipends(SectorEntityToken station) {
		float[] stipends = new float[] { 0f, 0f };
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return stipends;
		CargoAPI storage = storageSubmarket.getCargo();
		stipends[0] = storage.getCrew() * CREW_STIPEND_PER_UNIT;
		stipends[1] = storage.getMarines() * MARINE_STIPEND_PER_UNIT;
		return stipends;
	}

	public static PersonnelRank getStoredMarineRank(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return null;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return null;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return null;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getRank();
	}

	public static float getStoredMarineTrainingPercent(SectorEntityToken station) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return 0f;
		CargoAPI storage = storageSubmarket.getCargo();
		float marines = storage.getMarines();
		if (marines <= 0f) return 0f;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		if (at == null) return 0f;

		at.data.numMayHaveChanged(marines, true);
		return at.data.getXPLevel() * 100f;
	}

	public static class MarineTransferSnapshot {
		float stationNum;
		float stationXP;
		float fleetNum;
		float fleetXP;
	}

	public static MarineTransferSnapshot snapshotMarineXP(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		MarineTransferSnapshot snap = new MarineTransferSnapshot();

		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return snap;

		snap.stationNum = storageSubmarket.getCargo().getMarines();
		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		at.data.numMayHaveChanged(snap.stationNum, true);
		snap.stationXP = at.data.xp;

		PersonnelData fleetData = PlayerFleetPersonnelTracker.getInstance().getMarineData();
		snap.fleetNum = playerFleet.getCargo().getMarines();
		fleetData.numMayHaveChanged(snap.fleetNum, true);
		snap.fleetXP = fleetData.xp;

		return snap;
	}

	public static void reconcileMarineTransfer(SectorEntityToken station, CampaignFleetAPI playerFleet, MarineTransferSnapshot before) {
		SubmarketAPI storageSubmarket = getStorageSubmarket(station);
		if (storageSubmarket == null) return;

		float stationNumAfter = storageSubmarket.getCargo().getMarines();
		float fleetNumAfter = playerFleet.getCargo().getMarines();

		int withdrawn = Math.round(before.stationNum - stationNumAfter);
		if (withdrawn == 0) return;

		PersonnelAtEntity at = PlayerFleetPersonnelTracker.getInstance()
				.getDroppedOffAt(Commodities.MARINES, station, storageSubmarket, true);
		PersonnelData fleetData = PlayerFleetPersonnelTracker.getInstance().getMarineData();

		if (withdrawn > 0) {
			float xpPerMarine = before.stationNum > 0 ? before.stationXP / before.stationNum : 0f;
			float xpMoved = xpPerMarine * withdrawn;

			at.data.num = stationNumAfter;
			at.data.xp = Math.max(0f, before.stationXP - xpMoved);

			fleetData.num = fleetNumAfter;
			fleetData.xp = Math.min(before.fleetXP + xpMoved, Math.max(0f, fleetNumAfter));
		} else {
			int deposited = -withdrawn;
			float xpPerMarine = before.fleetNum > 0 ? before.fleetXP / before.fleetNum : 0f;
			float xpMoved = xpPerMarine * deposited;

			fleetData.num = fleetNumAfter;
			fleetData.xp = Math.max(0f, before.fleetXP - xpMoved);

			at.data.num = stationNumAfter;
			at.data.xp = Math.min(before.stationXP + xpMoved, Math.max(0f, stationNumAfter));
		}

		PlayerFleetPersonnelTracker.getInstance().update();
	}

	static String bayKey(String base, int bayIndex) {
		return base + "_" + bayIndex;
	}

	public static boolean hasFleetHQBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(FLEET_HQ_MEMORY_KEY);
	}

	public static boolean hasFleetHQCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return playerFleet.getCargo().getCredits().get() >= FLEET_HQ_CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= FLEET_HQ_METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= FLEET_HQ_TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= FLEET_HQ_VOLATILES_COST
				&& PlayerHQUtils.getStationCrew(station) >= FLEET_HQ_CREW_COST;
	}

	public static void buildFleetHQ(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (hasFleetHQBuilt(station)) return;
		if (!hasFleetHQCost(station, playerFleet)) return;

		playerFleet.getCargo().getCredits().subtract(FLEET_HQ_CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, FLEET_HQ_METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, FLEET_HQ_TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, FLEET_HQ_VOLATILES_COST);
		PlayerHQUtils.removeStationCrew(station, FLEET_HQ_CREW_COST);

		station.getMemoryWithoutUpdate().set(FLEET_HQ_MEMORY_KEY, true);
	}

	public static boolean isExpeditionBayBuilt(SectorEntityToken station, int bayIndex) {
		return getCommittedShips(station, bayIndex) != null || isExpeditionBayDestroyed(station, bayIndex);
	}

	public static boolean isExpeditionBayDestroyed(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(TRAINING_EXPEDITIONS_DESTROYED_MEMORY_KEY, bayIndex));
	}

	private static String getExpeditionBayDestroyedCause(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(TRAINING_EXPEDITIONS_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : "unknown causes";
	}

	public static int getTrainingExpeditionBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (isExpeditionBayBuilt(station, i)) count++;
		}
		return count;
	}

	public static boolean canBuildAnotherExpeditionBay(SectorEntityToken station) {
		return hasFleetHQBuilt(station)
				&& getTrainingExpeditionBayCount(station) < MAX_TRAINING_EXPEDITION_BAYS;
	}

	public static boolean isBayTouring(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY, bayIndex));
	}

	public static List<FleetMemberAPI> getExpeditionFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return getLogisticCandidatesFromEverywhere(station, playerFleet, true);
	}

	public static boolean isValidExpeditionComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.size() != EXPEDITION_BAY_TRANSPORTS_REQUIRED + EXPEDITION_BAY_FREIGHTERS_REQUIRED
				+ EXPEDITION_BAY_TANKERS_REQUIRED) return false;
		int transports = 0, freighters = 0, tankers = 0;
		for (FleetMemberAPI m : chosen) {
			LogisticShipRole role = classifyLogisticShip(m, true);
			if (role == LogisticShipRole.TRANSPORT) transports++;
			else if (role == LogisticShipRole.FREIGHTER) freighters++;
			else if (role == LogisticShipRole.TANKER) tankers++;
		}
		return transports == EXPEDITION_BAY_TRANSPORTS_REQUIRED && freighters == EXPEDITION_BAY_FREIGHTERS_REQUIRED
				&& tankers == EXPEDITION_BAY_TANKERS_REQUIRED;
	}

	public static boolean systemHasRuins(SectorEntityToken station) {
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return false;
		for (PlanetAPI p : system.getPlanets()) {
			if (p.isStar() || p.getMarket() == null) continue;
			if (getRuinsTier(p.getMarket()) > 0) return true;
		}
		return false;
	}

	public static int getRequiredCrewForShips(List<FleetMemberAPI> ships) {
		int total = 0;
		for (FleetMemberAPI m : ships) {
			total += Math.round(m.getMinCrew());
		}
		return total;
	}

	private static void stripAutoAssignedOfficer(FleetMemberAPI m) {
		if (m == null) return;
		PersonAPI captain = m.getCaptain();
		if (captain != null && !captain.isDefault()) {
			m.setCaptain(null);
		}
		m.getStats().getSuppliesPerMonth().unmodifyMult(NO_SUPPLY_UPKEEP_SOURCE);
		removeDoubleHolds(m);
	}

	private static void removeShipFromWhereverItIs(SectorEntityToken station, CampaignFleetAPI playerFleet, FleetMemberAPI m) {
		if (playerFleet.getFleetData() != null && playerFleet.getFleetData().getMembersListCopy().contains(m)) {
			playerFleet.getFleetData().removeFleetMember(m);
			playerFleet.getFleetData().ensureHasFlagship();
			return;
		}

		CargoAPI fleetCargo = playerFleet.getCargo();
		fleetCargo.initMothballedShips(playerFleet.getFaction().getId());
		if (fleetCargo.getMothballedShips() != null && fleetCargo.getMothballedShips().getMembersListCopy().contains(m)) {
			fleetCargo.getMothballedShips().removeFleetMember(m);
			return;
		}

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.initMothballedShips(playerFleet.getFaction().getId());
			if (storage.getMothballedShips() != null) {
				storage.getMothballedShips().removeFleetMember(m);
			}
		}
	}

	public static void buildExpeditionBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet,
			int bayIndex, List<FleetMemberAPI> chosen) {
		if (bayIndex < 0 || bayIndex >= MAX_TRAINING_EXPEDITION_BAYS) return;
		if (!hasFleetHQBuilt(station) || isExpeditionBayBuilt(station, bayIndex)) return;
		if (!isValidExpeditionComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HAND_WEAPONS)
				< TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST) return;
		if (PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY)
				< TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HAND_WEAPONS, TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST);
		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex), new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, bayIndex), crewNeeded);
	}

	public static boolean hasHeavyArmamentsForBay(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HAND_WEAPONS)
				>= TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST;
	}

	public static boolean hasHeavyMachineryForBay(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY)
				>= TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST;
	}

	private static void disbandAllBaysInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		if (getTrainingExpeditionBayCount(station) < 1) return;

		if (destination != null) {
			destination.initMothballedShips(factionId);
		}

		for (int i = 0; i < MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (!isExpeditionBayBuilt(station, i)) continue;

			if (isBayTouring(station, i)) {
				recallTouringFleet(station, i);
			}
			List<FleetMemberAPI> ships = getReturnableShips(station, getCommittedShips(station, i),
					bayKey(TRAINING_EXPEDITIONS_RESPAWN_MANIFEST_MEMORY_KEY, i));
			if (ships != null && !ships.isEmpty() && destination != null && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			if (destination != null) {
				int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, i));
				if (crewCost > 0) {
					destination.addCrew(crewCost);
				}
				destination.addCommodity(Commodities.HAND_WEAPONS,
						TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
				destination.addCommodity(Commodities.HEAVY_MACHINERY,
						TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
			}
			clearBayMemory(station, i);
		}
	}

	public static void uninstallExpeditionBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MAX_TRAINING_EXPEDITION_BAYS) return;
		if (!isExpeditionBayBuilt(station, bayIndex)) return;

		if (isBayTouring(station, bayIndex)) {
			recallTouringFleet(station, bayIndex);
		}

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.initMothballedShips(playerFleet.getFaction().getId());
			List<FleetMemberAPI> ships = getReturnableShips(station, getCommittedShips(station, bayIndex),
					bayKey(TRAINING_EXPEDITIONS_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex));
			if (ships != null && !ships.isEmpty() && storage.getMothballedShips() != null) {
				FleetDataAPI mothballed = storage.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) {
				storage.addCrew(crewCost);
			}
			storage.addCommodity(Commodities.HAND_WEAPONS,
					TRAINING_EXPEDITION_BAY_HEAVY_ARMAMENTS_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
			storage.addCommodity(Commodities.HEAVY_MACHINERY,
					TRAINING_EXPEDITION_BAY_HEAVY_MACHINERY_COST * ConstructPlayerHQAbility.REFUND_FRACTION);
		}

		clearBayMemory(station, bayIndex);
	}

	public static void uninstallFleetHQ(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasFleetHQBuilt(station)) return;

		disbandAllBaysInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
		disbandResupplyBayInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
		disbandAllCourierBaysInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
		disbandTradeFleetInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
		disbandAllPatrolFleetBaysInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
		disbandAllSalvageBaysInto(station, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
			storage.addCommodity(Commodities.METALS, FLEET_HQ_METALS_COST * fraction);
			storage.addCommodity(Commodities.RARE_METALS, FLEET_HQ_TRANSPLUTONICS_COST * fraction);
			storage.addCommodity(Commodities.VOLATILES, FLEET_HQ_VOLATILES_COST * fraction);
			storage.addCrew(FLEET_HQ_CREW_COST);
		}

		station.getMemoryWithoutUpdate().unset(FLEET_HQ_MEMORY_KEY);
	}

	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasHolosuiteInstalled(station) && !hasDroneReplicatorInstalled(station)
				&& !hasAICoreInstalled(station) && !hasFleetHQBuilt(station);
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet, PlayerHQUtils.getRefundCargo(station, playerFleet));
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getCommittedShips(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	private static CampaignFleetAPI getTouringFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY, bayIndex));
	}

	private static String getExpeditionPlanetId(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : null;
	}

	private static String getExpeditionState(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(TRAINING_EXPEDITIONS_STATE_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : null;
	}

	public static String getExpeditionPlanetName(SectorEntityToken station, int bayIndex) {
		PlanetAPI planet = findPlanetAnywhere(getExpeditionPlanetId(station, bayIndex));
		return planet != null ? planet.getName() : null;
	}

	public static String getBayStatusText(SectorEntityToken station, int bayIndex) {
		if (isExpeditionBayDestroyed(station, bayIndex)) {
			int daysLeft = Math.max(station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex)), 0);
			return "destroyed by " + getExpeditionBayDestroyedCause(station, bayIndex) + " -- rebuilding, ready again in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		if (!isBayTouring(station, bayIndex)) {
			return "docked at the station, ready to depart in search of ruins";
		}

		String planetName = getExpeditionPlanetName(station, bayIndex);
		String planet = planetName != null ? planetName : "a planet";
		String state = getExpeditionState(station, bayIndex);

		if (TRAINING_EXPEDITIONS_STATE_RETURNING.equals(state)) {
			return "returning to the station";
		}
		if (TRAINING_EXPEDITIONS_STATE_WORKING.equals(state)) {
			int orbitDay = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_ORBIT_DAY_MEMORY_KEY, bayIndex));
			int daysLeft = Math.max(TRAINING_EXPEDITIONS_MAX_ORBIT_DAYS - orbitDay, 0);
			return "searching the ruins in orbit of " + planet + " (gives up and returns home in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s") + " if nothing is found)";
		}
		return "moving to " + planet;
	}

	// Every currently touring bay's planet is off-limits to a newly-launching bay -- only one
	// Expedition Fleet may orbit a given planet at a time.
	private static Set<String> getClaimedExpeditionPlanetIds(SectorEntityToken station, int excludingBayIndex) {
		Set<String> claimed = new HashSet<String>();
		for (int i = 0; i < MAX_TRAINING_EXPEDITION_BAYS; i++) {
			if (i == excludingBayIndex) continue;
			if (!isBayTouring(station, i)) continue;
			String planetId = getExpeditionPlanetId(station, i);
			if (planetId != null) claimed.add(planetId);
		}
		return claimed;
	}

	// Searches every star system in the sector for the closest, highest-tier ruins planet within
	// range that isn't already claimed by another Expedition Fleet.
	private static PlanetAPI pickExpeditionPlanet(SectorEntityToken station, Set<String> excludePlanetIds) {
		int bestTier = 0;
		float bestDistanceLY = Float.MAX_VALUE;
		PlanetAPI best = null;

		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			for (PlanetAPI p : system.getPlanets()) {
				if (p.isStar() || p.getMarket() == null) continue;
				if (excludePlanetIds != null && excludePlanetIds.contains(p.getId())) continue;

				int tier = getRuinsTier(p.getMarket());
				if (tier <= 0) continue;

				float distanceLY = Misc.getDistanceLY(station, p);
				if (distanceLY > TRAINING_EXPEDITIONS_MAX_RANGE_LY) continue;

				if (tier > bestTier || (tier == bestTier && distanceLY < bestDistanceLY)) {
					bestTier = tier;
					bestDistanceLY = distanceLY;
					best = p;
				}
			}
		}
		return best;
	}

	public static void launchTrainingExpeditionIfDue(SectorEntityToken station) {
		if (!isBuilt(station)) return;
		for (int bayIndex = 0; bayIndex < MAX_TRAINING_EXPEDITION_BAYS; bayIndex++) {
			launchBay(station, bayIndex);
		}
	}

	static void markAsNonInteractiveTraffic(CampaignFleetAPI fleet, float noEngagingDays) {
		MemoryAPI mem = fleet.getMemoryWithoutUpdate();
		mem.set(MemFlags.MEMORY_KEY_MAKE_NON_HOSTILE, true);
		mem.set(MemFlags.FLEET_IGNORED_BY_OTHER_FLEETS, true);
		mem.set(MemFlags.FLEET_IGNORES_OTHER_FLEETS, true);
		fleet.setNoEngaging(noEngagingDays);
	}

	private static final String NO_SUPPLY_UPKEEP_SOURCE = "playerhq_fleet_no_supply_upkeep";
	public static final float SPAWNED_FLEET_STARTING_SUPPLIES = 10f;

	private static final String FLEET_HOLD_MOD_ID = "playerhq_fleet_double_hold";
	public static final float FLEET_HOLD_MULT = 2f;

	static boolean hasDoubleHolds(FleetMemberAPI m) {
		return m != null && m.getStats() != null && m.getStats().getCargoMod().getMultBonus(FLEET_HOLD_MOD_ID) != null;
	}

	static void removeDoubleHolds(FleetMemberAPI m) {
		if (m == null || m.getStats() == null) return;
		m.getStats().getCargoMod().unmodifyMult(FLEET_HOLD_MOD_ID);
		m.getStats().getFuelMod().unmodifyMult(FLEET_HOLD_MOD_ID);
	}

	static float getBaseCargoCapacity(FleetMemberAPI m) {
		if (m == null) return 0f;
		float capacity = m.getCargoCapacity();
		return hasDoubleHolds(m) ? capacity / FLEET_HOLD_MULT : capacity;
	}

	static float getBaseFuelCapacity(FleetMemberAPI m) {
		if (m == null) return 0f;
		float capacity = m.getFuelCapacity();
		return hasDoubleHolds(m) ? capacity / FLEET_HOLD_MULT : capacity;
	}

	public static float getFleetBaseCargoCapacity(CampaignFleetAPI fleet) {
		float total = 0f;
		if (fleet == null || fleet.getFleetData() == null) return total;
		for (FleetMemberAPI m : fleet.getFleetData().getMembersListCopy()) {
			total += getBaseCargoCapacity(m);
		}
		return total;
	}

	public static float getFleetBaseFuelCapacity(CampaignFleetAPI fleet) {
		float total = 0f;
		if (fleet == null || fleet.getFleetData() == null) return total;
		for (FleetMemberAPI m : fleet.getFleetData().getMembersListCopy()) {
			total += getBaseFuelCapacity(m);
		}
		return total;
	}

	static void clearLegacyHoldMods(CampaignFleetAPI fleet) {
		if (fleet == null || fleet.getFleetData() == null) return;
		boolean changed = false;
		for (FleetMemberAPI m : fleet.getFleetData().getMembersListCopy()) {
			if (hasDoubleHolds(m)) {
				removeDoubleHolds(m);
				changed = true;
			}
		}
		if (changed) {
			try {
				fleet.getFleetData().setSyncNeeded();
				fleet.getFleetData().syncIfNeeded();
				fleet.getCargo().updateSpaceUsed();
			} catch (Throwable t) {
			}
		}
	}

	static void fillFleetHold(CampaignFleetAPI fleet) {
		if (fleet == null) return;
		CargoAPI cargo = fleet.getCargo();
		if (cargo == null) return;
		int freeCrew = cargo.getFreeCrewSpace();
		if (freeCrew > 0) cargo.addCrew(freeCrew);
		float space = cargo.getSpaceLeft();
		if (space > 0f) cargo.addSupplies(space);
		int freeFuel = cargo.getFreeFuelSpace();
		if (freeFuel > 0) cargo.addFuel(freeFuel);
	}

	static void injectFleetLogistics(CampaignFleetAPI fleet, List<FleetMemberAPI> ships) {
		injectFleetLogistics(fleet, ships, true);
	}

	static void injectFleetLogistics(CampaignFleetAPI fleet, List<FleetMemberAPI> ships, boolean fullHold) {
		clearLegacyHoldMods(fleet);
		if (fullHold) {
			fleet.getCargo().addCrew(getRequiredCrewForShips(ships));
			fillFleetHold(fleet);
		} else {
			fleet.getCargo().addCrew(getRequiredCrewForShips(ships));
			fleet.getCargo().addSupplies(SPAWNED_FLEET_STARTING_SUPPLIES);
			float remainingCargoSpace = fleet.getCargo().getSpaceLeft();
			if (remainingCargoSpace > 0f) fleet.getCargo().addSupplies(remainingCargoSpace);
		}
		for (FleetMemberAPI m : ships) {
			if (m == null) continue;
			m.getStats().getSuppliesPerMonth().modifyMult(NO_SUPPLY_UPKEEP_SOURCE, 0f, "Player HQ fleet");
			if (m.getRepairTracker() != null) {
				m.getRepairTracker().setMothballed(false);
				m.getRepairTracker().setCrashMothballed(false);
			}
		}
		maintainFleetCR(ships);
	}

	static void stripNonDeliverableSupplies(CargoAPI cargo, float deliverableSupplies) {
		if (cargo == null) return;
		float excess = cargo.getSupplies() - Math.max(0f, deliverableSupplies);
		if (excess > 0f) cargo.removeSupplies(excess);
	}

	private static final String LOGISTICS_TOPOFF_DAY_COUNTER_KEY = "$playerhq_fleet_logistics_topoff_daycounter";
	private static final int LOGISTICS_TOPOFF_INTERVAL_DAYS = 3;

	private static void topOffFleetSuppliesIfLow(CampaignFleetAPI fleet) {
		topOffFleetSuppliesIfLow(fleet, true);
	}

	static void topOffFleetSuppliesIfLow(CampaignFleetAPI fleet, boolean includeSupplies) {
		if (fleet == null) return;
		MemoryAPI fleetMem = fleet.getMemoryWithoutUpdate();
		boolean firstTopOff = !fleetMem.contains(LOGISTICS_TOPOFF_DAY_COUNTER_KEY);
		int daysSinceTopOff = fleetMem.getInt(LOGISTICS_TOPOFF_DAY_COUNTER_KEY) + 1;
		if (!firstTopOff && daysSinceTopOff < LOGISTICS_TOPOFF_INTERVAL_DAYS) {
			fleetMem.set(LOGISTICS_TOPOFF_DAY_COUNTER_KEY, daysSinceTopOff);
			return;
		}
		fleetMem.set(LOGISTICS_TOPOFF_DAY_COUNTER_KEY, 0);
		if (fleet.getFleetData() != null) maintainFleetCR(fleet.getFleetData().getMembersListCopy());
		fillFleetHold(fleet);
	}

	static void maintainFleetCR(List<FleetMemberAPI> ships) {
		if (ships == null) return;
		for (FleetMemberAPI m : ships) {
			if (m == null || m.getRepairTracker() == null) continue;
			if (m.getRepairTracker().isMothballed() || m.getRepairTracker().isCrashMothballed() || m.isMothballed()) {
				m.getRepairTracker().setMothballed(false);
				m.getRepairTracker().setCrashMothballed(false);
			}
			m.updateStats();
			m.getRepairTracker().setCR(m.getRepairTracker().getMaxCR());
		}
	}

	static void refreshFleetCR(CampaignFleetAPI fleet) {
		if (fleet == null || fleet.getFleetData() == null) return;
		try {
			fleet.getFleetData().setSyncNeeded();
			fleet.getFleetData().syncIfNeeded();
		} catch (Throwable t) {
		}
		maintainFleetCR(fleet.getFleetData().getMembersListCopy());
		for (FleetMemberAPI m : fleet.getFleetData().getMembersListCopy()) {
			try {
				Global.getLogger(MilitaryWardModule.class).info("Player HQ fleet CR check: fleet=" + fleet.getName()
						+ " ship=" + m.getShipName() + " hull=" + m.getHullSpec().getHullId()
						+ " variant=" + m.getVariant().getHullVariantId()
						+ " cr=" + m.getRepairTracker().getCR() + " maxCR=" + m.getRepairTracker().getMaxCR()
						+ " hullFraction=" + m.getStatus().getHullFraction()
						+ " dmods=" + DModManager.getNumDMods(m.getVariant())
						+ " smods=" + m.getVariant().getSMods()
						+ " perma=" + m.getVariant().getPermaMods()
						+ " mothballed=" + m.getRepairTracker().isMothballed());
			} catch (Throwable t) {
			}
		}
	}

	private static int getDaysRemainingInMonth(SectorEntityToken station) {
		CampaignClockAPI clock = Global.getSector().getClock();
		int daysInMonth = clock.getCal().getActualMaximum(Calendar.DAY_OF_MONTH);
		return daysInMonth - clock.getDay();
	}

	private static SectorEntityToken findAsteroidBeltOrField(StarSystemAPI system) {
		List<SectorEntityToken> candidates = getAsteroidBeltOrFieldCandidates(system);
		if (candidates.isEmpty()) return null;

		SectorEntityToken picked = candidates.get((int) (Math.random() * candidates.size()));
		if (picked.getName() == null || picked.getName().trim().isEmpty()) {
			picked.setName("Asteroid Field");
		}
		return picked;
	}

	private static void positionFleetAtPlanet(CampaignFleetAPI fleet, PlanetAPI planet) {
		fleet.setCircularOrbitPointingDown(planet, (float) (Math.random() * 360f),
				planet.getRadius() + 250f, TRAINING_EXPEDITIONS_MAX_ORBIT_DAYS * 2f);
	}

	private static void launchBay(SectorEntityToken station, int bayIndex) {
		if (isBayTouring(station, bayIndex)) return;

		List<FleetMemberAPI> ships = getCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return;

		PlanetAPI targetPlanet = pickExpeditionPlanet(station, getClaimedExpeditionPlanetIds(station, bayIndex));
		if (targetPlanet == null) return;

		StarSystemAPI homeSystem = station.getStarSystem();
		if (homeSystem == null) return;

		outfitFleetShips(station, ships, false);

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Expedition Fleet " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, TRAINING_EXPEDITIONS_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		injectFleetLogistics(fleet, ships);
		homeSystem.addEntity(fleet);
		refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, targetPlanet, TRAINING_EXPEDITIONS_ASSIGNMENT_DURATION_CAP_DAYS,
				"Traveling to " + targetPlanet.getName());

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY, bayIndex), targetPlanet.getId());
		mem.set(bayKey(TRAINING_EXPEDITIONS_ORBIT_DAY_MEMORY_KEY, bayIndex), 0);
		mem.set(bayKey(TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY, bayIndex), true);
		mem.set(bayKey(TRAINING_EXPEDITIONS_STATE_MEMORY_KEY, bayIndex), TRAINING_EXPEDITIONS_STATE_OUTBOUND);
	}

	public static void advanceTrainingExpeditionDaily(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_TRAINING_EXPEDITION_BAYS; bayIndex++) {
			advanceBayDaily(station, bayIndex);
		}
	}

	public static void advanceTrainingExpeditionsRealtime(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_TRAINING_EXPEDITION_BAYS; bayIndex++) {
			advanceExpeditionBayRealtime(station, bayIndex);
		}
	}

	private static void advanceExpeditionBayRealtime(SectorEntityToken station, int bayIndex) {
		if (!isBayTouring(station, bayIndex)) return;
		String state = getExpeditionState(station, bayIndex);
		if (state == null) return;

		CampaignFleetAPI fleet = getTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) return;

		if (TRAINING_EXPEDITIONS_STATE_OUTBOUND.equals(state)) {
			PlanetAPI planet = findPlanetAnywhere(getExpeditionPlanetId(station, bayIndex));
			if (planet == null || fleet.getContainingLocation() != planet.getContainingLocation()) return;
			if (Misc.getDistance(fleet, planet) <= TRAINING_EXPEDITIONS_ARRIVAL_RANGE) {
				fleet.clearAssignments();
				positionFleetAtPlanet(fleet, planet);
				station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_STATE_MEMORY_KEY, bayIndex),
						TRAINING_EXPEDITIONS_STATE_WORKING);
			}
			return;
		}

		if (TRAINING_EXPEDITIONS_STATE_RETURNING.equals(state)) {
			if (fleet.getContainingLocation() != station.getContainingLocation()) return;
			if (Misc.getDistance(fleet, station) > TRAINING_EXPEDITIONS_ARRIVAL_RANGE) return;
			recallTouringFleet(station, bayIndex);
		}
	}

	private static void advanceBayDaily(SectorEntityToken station, int bayIndex) {
		if (isExpeditionBayDestroyed(station, bayIndex)) {
			advanceLogisticFleetRespawn(station,
					bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex), bayKey(TRAINING_EXPEDITIONS_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(TRAINING_EXPEDITIONS_DESTROYED_MEMORY_KEY, bayIndex), bayKey(TRAINING_EXPEDITIONS_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(TRAINING_EXPEDITIONS_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			return;
		}
		if (!isBayTouring(station, bayIndex)) return;

		CampaignFleetAPI fleet = getTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) {
			markLogisticFleetDestroyed(station, "Expedition Fleet " + (bayIndex + 1), getCommittedShips(station, bayIndex),
					"unknown causes",
					bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex), bayKey(TRAINING_EXPEDITIONS_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(TRAINING_EXPEDITIONS_DESTROYED_MEMORY_KEY, bayIndex), bayKey(TRAINING_EXPEDITIONS_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(TRAINING_EXPEDITIONS_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			clearTouringState(station, bayIndex);
			return;
		}
		topOffFleetSuppliesIfLow(fleet);

		String state = getExpeditionState(station, bayIndex);
		if (!TRAINING_EXPEDITIONS_STATE_WORKING.equals(state)) return;

		PlanetAPI planet = findPlanetAnywhere(getExpeditionPlanetId(station, bayIndex));
		if (planet == null) return;

		int orbitDay = station.getMemoryWithoutUpdate().getInt(bayKey(TRAINING_EXPEDITIONS_ORBIT_DAY_MEMORY_KEY, bayIndex)) + 1;
		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_ORBIT_DAY_MEMORY_KEY, bayIndex), orbitDay);

		if (orbitDay % TRAINING_EXPEDITIONS_LOOT_ROLL_INTERVAL_DAYS == 0) {
			rollForLoot(station, planet);
		}

		if (orbitDay >= TRAINING_EXPEDITIONS_MAX_ORBIT_DAYS) {
			// Full 90 days in orbit -- return home.
			sendBayHome(station, bayIndex, fleet);
		}
	}

	private static void sendBayHome(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, TRAINING_EXPEDITIONS_ASSIGNMENT_DURATION_CAP_DAYS,
				"Returning to the station");
		station.getMemoryWithoutUpdate().set(bayKey(TRAINING_EXPEDITIONS_STATE_MEMORY_KEY, bayIndex), TRAINING_EXPEDITIONS_STATE_RETURNING);
	}

	private static void recallTouringFleet(SectorEntityToken station, int bayIndex) {
		CampaignFleetAPI fleet = getTouringFleet(station, bayIndex);
		if (fleet != null) {
			List<FleetMemberAPI> ships = getCommittedShips(station, bayIndex);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearTouringState(station, bayIndex);
	}

	private static void clearTouringState(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(TRAINING_EXPEDITIONS_TOURING_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_PLANET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_STATE_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(TRAINING_EXPEDITIONS_ORBIT_DAY_MEMORY_KEY, bayIndex));
	}

	private static void clearBayMemory(SectorEntityToken station, int bayIndex) {
		clearTouringState(station, bayIndex);
		station.getMemoryWithoutUpdate().unset(bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(TRAINING_EXPEDITIONS_CREW_COST_MEMORY_KEY, bayIndex));
		clearLogisticFleetDestroyedState(station,
				bayKey(TRAINING_EXPEDITIONS_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex), bayKey(TRAINING_EXPEDITIONS_DESTROYED_MEMORY_KEY, bayIndex),
				bayKey(TRAINING_EXPEDITIONS_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex), bayKey(TRAINING_EXPEDITIONS_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
	}

	private static PlanetAPI findPlanet(StarSystemAPI system, String planetId) {
		if (system == null || planetId == null) return null;
		for (PlanetAPI p : system.getPlanets()) {
			if (planetId.equals(p.getId())) return p;
		}
		return null;
	}

	// Like findPlanet, but searches every star system in the sector -- needed for Expedition Fleets,
	// which may now be sent to ruins in a system other than the Player HQ's home system.
	private static PlanetAPI findPlanetAnywhere(String planetId) {
		if (planetId == null) return null;
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			PlanetAPI found = findPlanet(system, planetId);
			if (found != null) return found;
		}
		return null;
	}

	private static int getRuinsTier(MarketAPI market) {
		if (market == null) return 0;
		if (market.hasCondition(Conditions.RUINS_VAST)) return 4;
		if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) return 3;
		if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) return 2;
		if (market.hasCondition(Conditions.RUINS_SCATTERED)) return 1;
		return 0;
	}

	private static float getBaseRuinsChanceForTier(int tier) {
		switch (tier) {
			case 4: return RUINS_CHANCE_VAST;
			case 3: return RUINS_CHANCE_EXTENSIVE;
			case 2: return RUINS_CHANCE_WIDESPREAD;
			case 1: return RUINS_CHANCE_SCATTERED;
			default: return 0f;
		}
	}

	private static boolean hasSalvagingSkill() {
		return Global.getSector().getPlayerStats() != null
				&& Global.getSector().getPlayerStats().getSkillLevel(Skills.SALVAGING) > 0;
	}

	private static float getRuinsChance(MarketAPI market) {
		int tier = getRuinsTier(market);
		if (tier <= 0) return 0f;

		float chance = getBaseRuinsChanceForTier(tier);
		if (hasSalvagingSkill()) {
			switch (tier) {
				case 4: chance += SALVAGING_BONUS_VAST; break;
				case 3: chance += SALVAGING_BONUS_EXTENSIVE; break;
				case 2: chance += SALVAGING_BONUS_WIDESPREAD; break;
				default: chance += SALVAGING_BONUS_SCATTERED; break;
			}
		}
		return chance;
	}

	private static boolean rollForLoot(SectorEntityToken station, PlanetAPI planet) {
		MarketAPI market = planet.getMarket();
		if (market == null) return false;

		float chance = getRuinsChance(market);
		if (chance <= 0f) return false;
		if (Math.random() >= chance) return false;

		String lootLine = generateLoot(station);
		if (lootLine == null) return false;

		logLoot(station, planet.getName(), lootLine);
		return true;
	}

	@SuppressWarnings("unchecked")
	private static void logLoot(SectorEntityToken station, String planetName, String lootLine) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		Object o = mem.get(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY);
		List<String> log = (o instanceof List) ? (List<String>) o : new ArrayList<String>();
		log.add(lootLine + " -- found at " + planetName);
		mem.set(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY, log);
	}

	@SuppressWarnings("unchecked")
	public static List<String> getTrainingExpeditionLootThisMonth(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY);
		return (o instanceof List) ? new ArrayList<String>((List<String>) o) : new ArrayList<String>();
	}

	public static void clearTrainingExpeditionLootThisMonth(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(TRAINING_EXPEDITIONS_LOOT_LOG_MEMORY_KEY);
	}

	private static final String[] FLEET_UPGRADE_HULLMOD_NAMES = { "augmenteddrivefield", "efficiencyoverhaul" };
	private static final String HULLMOD_NAME_TANKER = "auxiliaryfueltanks";
	private static final String HULLMOD_NAME_TRANSPORT = "additionalberthing";
	private static final String HULLMOD_NAME_FREIGHTER = "expandedcargoholds";
	private static final String FLEET_ADDED_MOD_TAG_PREFIX = "phq_fleet_mod_";
	private static final String GEAR_STRIPPED_TAG = "phq_gear_stripped";
	private static List<String> cachedFleetUpgradeHullMods = null;

	private static String normalizeName(String name) {
		return name == null ? "" : name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
	}

	private static List<String> getFleetUpgradeHullMods() {
		if (cachedFleetUpgradeHullMods != null) return cachedFleetUpgradeHullMods;
		List<String> result = new ArrayList<String>();
		for (String wanted : FLEET_UPGRADE_HULLMOD_NAMES) {
			for (HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
				if (wanted.equals(normalizeName(spec.getDisplayName())) || wanted.equals(normalizeName(spec.getId()))) {
					result.add(spec.getId());
					break;
				}
			}
		}
		cachedFleetUpgradeHullMods = result;
		return result;
	}

	private static String resolveHullModIdByName(String wanted) {
		for (HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
			if (wanted.equals(normalizeName(spec.getDisplayName())) || wanted.equals(normalizeName(spec.getId()))) {
				return spec.getId();
			}
		}
		return null;
	}

	private static WeaponSpecAPI resolveMiningLaser() {
		try {
			WeaponSpecAPI direct = Global.getSettings().getWeaponSpec("mininglaser");
			if (direct != null) return direct;
		} catch (Throwable t) { }
		for (WeaponSpecAPI spec : Global.getSettings().getAllWeaponSpecs()) {
			if ("mininglaser".equals(normalizeName(spec.getWeaponName()))) return spec;
		}
		return null;
	}

	private static String resolveMiningPodWingId() {
		try {
			FighterWingSpecAPI direct = Global.getSettings().getFighterWingSpec("mining_drone_wing");
			if (direct != null) return direct.getId();
		} catch (Throwable t) { }
		for (FighterWingSpecAPI spec : Global.getSettings().getAllFighterWingSpecs()) {
			String n = normalizeName(spec.getWingName());
			if (n.equals("miningpod") || n.equals("miningpodwing") || n.equals("miningpods")) return spec.getId();
		}
		return null;
	}

	private static String getOutfitRoleHullModId(FleetMemberAPI m) {
		if (m == null || m.getHullSpec() == null) return null;
		Set<ShipHullSpecAPI.ShipTypeHints> hints = m.getHullSpec().getHints();
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.TANKER) || hasDesignationContaining(m, "tanker")) {
			return resolveHullModIdByName(HULLMOD_NAME_TANKER);
		}
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.TRANSPORT) || hasDesignationContaining(m, "transport")) {
			return resolveHullModIdByName(HULLMOD_NAME_TRANSPORT);
		}
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.FREIGHTER) || hasDesignationContaining(m, "freighter")) {
			return resolveHullModIdByName(HULLMOD_NAME_FREIGHTER);
		}
		return null;
	}

	private static Set<String> getManagedHullModIds() {
		Set<String> ids = new HashSet<String>();
		ids.addAll(getFleetUpgradeHullMods());
		for (String name : new String[] { HULLMOD_NAME_TANKER, HULLMOD_NAME_TRANSPORT, HULLMOD_NAME_FREIGHTER }) {
			String id = resolveHullModIdByName(name);
			if (id != null) ids.add(id);
		}
		return ids;
	}

	private static String describeCaller() {
		try {
			StackTraceElement[] st = Thread.currentThread().getStackTrace();
			StringBuilder sb = new StringBuilder();
			int added = 0;
			for (int i = 3; i < st.length && added < 3; i++) {
				if (sb.length() > 0) sb.append(" < ");
				sb.append(st[i].getMethodName()).append(":").append(st[i].getLineNumber());
				added++;
			}
			return sb.toString();
		} catch (Throwable t) {
			return "unknown";
		}
	}

	static void outfitFleetShips(SectorEntityToken station, List<FleetMemberAPI> ships, boolean mining) {
		if (ships == null || ships.isEmpty()) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		List<String> baseMods = getFleetUpgradeHullMods();
		Set<String> managedMods = getManagedHullModIds();
		WeaponSpecAPI laser = mining ? resolveMiningLaser() : null;
		String laserId = laser != null ? laser.getWeaponId() : null;
		String podId = mining ? resolveMiningPodWingId() : null;

		String caller = describeCaller();
		for (FleetMemberAPI m : ships) {
			if (m == null || m.getVariant() == null) continue;
			List<String> gearLog = new ArrayList<String>();
			try {
				ShipVariantAPI v = m.getVariant().clone();
				v.setSource(VariantSource.REFIT);
				boolean changed = false;
				ShipHullSpecAPI hull = v.getHullSpec();
				boolean alreadyStripped = v.hasTag(GEAR_STRIPPED_TAG);

				for (String slotId : new ArrayList<String>(v.getNonBuiltInWeaponSlots())) {
					if (alreadyStripped) break;
					String weaponId = v.getWeaponId(slotId);
					if (weaponId == null || weaponId.isEmpty()) continue;
					if (laserId != null && laserId.equals(weaponId)) continue;
					v.clearSlot(slotId);
					if (storage != null) storage.addWeapons(weaponId, 1);
						gearLog.add("weapon:" + weaponId);
					changed = true;
				}

				int bays = hull.getFighterBays();
				for (int i = 0; i < bays; i++) {
					if (hull.isBuiltInWing(i)) continue;
					String wingId = v.getWingId(i);
					boolean hasWing = wingId != null && !wingId.isEmpty();
					if (hasWing && !alreadyStripped && !(podId != null && podId.equals(wingId))) {
						v.setWingId(i, null);
						if (storage != null) storage.addFighters(wingId, 1);
							gearLog.add("wing:" + wingId);
						hasWing = false;
						changed = true;
					}
					if (!hasWing && podId != null) {
						v.setWingId(i, podId);
						changed = true;
					}
				}

				if (laser != null) {
					for (String slotId : new ArrayList<String>(v.getNonBuiltInWeaponSlots())) {
						String weaponId = v.getWeaponId(slotId);
						if (weaponId != null && !weaponId.isEmpty()) continue;
						WeaponSlotAPI slot = v.getSlot(slotId);
						if (slot == null || slot.isDecorative() || slot.isSystemSlot() || slot.isStationModule()) continue;
						if (!slot.weaponFits(laser)) continue;
						v.addWeapon(slotId, laserId);
						changed = true;
					}
				}

				for (String modId : new ArrayList<String>(v.getNonBuiltInHullmods())) {
					if (alreadyStripped) break;
					if (v.getPermaMods().contains(modId) || v.getSMods().contains(modId)) continue;
					v.removeMod(modId);
					HullModSpecAPI modSpec = Global.getSettings().getHullModSpec(modId);
					if (storage != null && !managedMods.contains(modId) && modSpec != null && !modSpec.isHidden()
							&& !modSpec.isHiddenEverywhere() && !modSpec.isAlwaysUnlocked()) {
						storage.addHullmods(modId, 1);
						gearLog.add("hullmod:" + modId);
					}
					changed = true;
				}

				if (!alreadyStripped) {
					v.addTag(GEAR_STRIPPED_TAG);
					changed = true;
				}

				List<String> wanted = new ArrayList<String>(baseMods);
				String roleMod = getOutfitRoleHullModId(m);
				if (roleMod != null) wanted.add(roleMod);
				for (String modId : wanted) {
					String tag = FLEET_ADDED_MOD_TAG_PREFIX + modId;
					if (v.hasHullMod(modId)) {
						if (v.hasTag(tag) && !v.getSMods().contains(modId)) {
							v.removePermaMod(modId);
							v.addPermaMod(modId, true);
							changed = true;
						}
						continue;
					}
					v.addPermaMod(modId, true);
					v.addTag(tag);
					changed = true;
				}

				if (changed) {
					v.getWeaponGroups().clear();
					v.autoGenerateWeaponGroups();
					m.setVariant(v, false, true);
					m.updateStats();
				}
			} catch (Throwable t) {
				Global.getLogger(MilitaryWardModule.class).warn("Player HQ: could not outfit " + m.getShipName(), t);
			}
			if (!gearLog.isEmpty()) {
				Global.getLogger(MilitaryWardModule.class).info("Player HQ gear moved to storage: ship=" + m.getShipName()
						+ " hull=" + m.getHullSpec().getHullId() + " variant=" + m.getVariant().getHullVariantId()
						+ " mining=" + mining + " via=" + caller + " items=" + gearLog);
			}
		}
	}

	private static <T> T pickRandom(List<T> list) {
		if (list == null || list.isEmpty()) return null;
		return list.get((int) (Math.random() * list.size()));
	}

	private static FighterWingSpecAPI pickRandomRegularFighter() {
		List<FighterWingSpecAPI> pool = new ArrayList<FighterWingSpecAPI>();
		for (FighterWingSpecAPI spec : Global.getSettings().getAllFighterWingSpecs()) {
			if (!spec.isRegularFighter() || spec.hasTag(Tags.NO_DROP)) continue;
			pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static WeaponSpecAPI pickRandomDroppableWeapon() {
		List<WeaponSpecAPI> pool = new ArrayList<WeaponSpecAPI>();
		for (WeaponSpecAPI spec : Global.getSettings().getAllWeaponSpecs()) {
			if (spec.hasTag(Tags.NO_DROP)) continue;
			if (spec.getAIHints() != null && spec.getAIHints().contains(WeaponAPI.AIHints.SYSTEM)) continue;
			WeaponAPI.WeaponType type = spec.getType();
			if (type != WeaponAPI.WeaponType.BALLISTIC && type != WeaponAPI.WeaponType.ENERGY
					&& type != WeaponAPI.WeaponType.MISSILE) continue;
			pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static boolean isDroppableHull(ShipHullSpecAPI hull) {
		if (hull == null || hull.isDHull()) return false;
		if (hull.hasTag(Tags.NO_DROP)) return false;
		java.util.EnumSet<ShipHullSpecAPI.ShipTypeHints> hints = hull.getHints();
		if (hints != null) {
			if (hints.contains(ShipHullSpecAPI.ShipTypeHints.MODULE)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.STATION)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.UNDER_PARENT)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.HIDE_IN_CODEX)) return false;
		}
		return true;
	}

	private static String collectGameDrop(CargoAPI storage, String group, float valueMult) {
		for (int attempt = 0; attempt < 5; attempt++) {
			SalvageEntityGenDataSpec.DropData drop = new SalvageEntityGenDataSpec.DropData();
			drop.chances = 1;
			drop.group = group;
			drop.valueMult = valueMult;
			List<SalvageEntityGenDataSpec.DropData> dropRandom = new ArrayList<SalvageEntityGenDataSpec.DropData>();
			dropRandom.add(drop);
			CargoAPI result;
			try {
				result = SalvageEntity.generateSalvage(new java.util.Random(), 1f, 1f, 1f, 1f,
						new ArrayList<SalvageEntityGenDataSpec.DropData>(), dropRandom);
			} catch (Throwable t) {
				return null;
			}
			if (result == null) continue;
			List<CargoStackAPI> stacks = result.getStacksCopy();
			if (stacks == null || stacks.isEmpty()) continue;
			StringBuilder line = new StringBuilder();
			for (CargoStackAPI stack : stacks) {
				if (stack == null || stack.isNull()) continue;
				if (stack.isModSpecStack() && isBlockedLootHullMod(stack.getHullModSpecIfHullMod())) continue;
				storage.addFromStack(stack);
				if (line.length() > 0) line.append(", ");
				line.append((int) stack.getSize()).append(" ").append(stack.getDisplayName());
			}
			if (line.length() > 0) return line.toString();
		}
		return null;
	}

	private static final String[] BLOCKED_LOOT_HULLMOD_NAMES = { "Dynamic Utility System" };

	private static boolean isBlockedLootHullMod(HullModSpecAPI spec) {
		if (spec == null || spec.getDisplayName() == null) return false;
		for (String name : BLOCKED_LOOT_HULLMOD_NAMES) {
			if (name.equalsIgnoreCase(spec.getDisplayName())) return true;
		}
		return false;
	}

	private static HullModSpecAPI pickRandomHullMod() {
		List<HullModSpecAPI> pool = new ArrayList<HullModSpecAPI>();
		for (HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
			if (spec.isHidden() || spec.isHiddenEverywhere() || spec.isAlwaysUnlocked() || spec.hasTag(Tags.HULLMOD_NO_DROP)) continue;
			if (isBlockedLootHullMod(spec)) continue;
			pool.add(spec);
		}
		return pickRandom(pool);
	}

	private static boolean isLootableHullSize(HullSize size) {
		return size == HullSize.FRIGATE || size == HullSize.DESTROYER
				|| size == HullSize.CRUISER || size == HullSize.CAPITAL_SHIP;
	}

	private static List<String> getLootableShipVariantIds() {
		List<String> result = new ArrayList<String>();
		for (String variantId : Global.getSettings().getAllVariantIds()) {
			ShipVariantAPI variant = Global.getSettings().getVariant(variantId);
			if (variant == null) continue;
			ShipHullSpecAPI hull = variant.getHullSpec();
			if (!isDroppableHull(hull)) continue;
			if (variantId.endsWith("_Hull")) continue;
			if (hull.getBaseValue() > MAX_LOOT_SHIP_VALUE) continue;
			if (!isLootableHullSize(hull.getHullSize())) continue;
			result.add(variantId);
		}
		return result;
	}

	private static List<ShipHullSpecAPI> getLootableHullSpecs() {
		List<ShipHullSpecAPI> result = new ArrayList<ShipHullSpecAPI>();
		Set<String> seen = new HashSet<String>();
		for (ShipHullSpecAPI hull : Global.getSettings().getAllShipHullSpecs()) {
			if (hull.isDHull()) continue;
			if (hull.getBaseValue() > MAX_LOOT_SHIP_VALUE) continue;
			if (!isLootableHullSize(hull.getHullSize())) continue;
			if (seen.add(hull.getHullId())) result.add(hull);
		}
		return result;
	}

	private static int rollLootShipDMods() {
		float roll = (float) Math.random();
		if (roll < LOOT_SHIP_CHANCE_3_DMODS) return 3;
		if (roll < LOOT_SHIP_CHANCE_3_DMODS + LOOT_SHIP_CHANCE_2_DMODS) return 2;
		if (roll < LOOT_SHIP_CHANCE_3_DMODS + LOOT_SHIP_CHANCE_2_DMODS + LOOT_SHIP_CHANCE_1_DMOD) return 1;
		return 0;
	}

	private static String generateShip(String factionId, CargoAPI storage) {
		String variantId = pickRandom(getLootableShipVariantIds());
		if (variantId == null) return null;

		FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, variantId);

		int dmodsWanted = rollLootShipDMods();
		if (dmodsWanted > 0) {
			DModManager.addDMods(member.getVariant(), false, dmodsWanted, null);
		}
		int dmodsActual = Math.min(DModManager.getNumDMods(member.getVariant()), MAX_LOOT_SHIP_DMODS);

		storage.initMothballedShips(factionId);
		storage.getMothballedShips().addFleetMember(member);

		String dmodNote = dmodsActual > 0 ? ", " + dmodsActual + " D-mod" + (dmodsActual > 1 ? "s" : "") : "";
		return "1 " + member.getHullSpec().getHullName() + " (ship" + dmodNote + ", stored at the station)";
	}

	private static String generateBlueprint(CargoAPI storage) {
		String line = collectGameDrop(storage, "blueprints_low", 1f);
		if (line == null) return null;
		return line + " (blueprint)";
	}

	private static String generateLoot(SectorEntityToken station) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return null;

		WeightedRandomPicker<String> categoryPicker = new WeightedRandomPicker<String>();
		categoryPicker.add("weapon", LOOT_WEIGHT_WEAPON);
		categoryPicker.add("fighter", LOOT_WEIGHT_FIGHTER);
		categoryPicker.add("hullmod", LOOT_WEIGHT_HULLMOD);
		categoryPicker.add("blueprint", LOOT_WEIGHT_BLUEPRINT);
		categoryPicker.add("ship", LOOT_WEIGHT_SHIP);
		categoryPicker.add("special", LOOT_WEIGHT_SPECIAL_ITEM);
		String category = categoryPicker.pick();
		if (category == null) return null;

		if (category.equals("weapon")) {
			WeaponSpecAPI spec = pickRandomDroppableWeapon();
			if (spec == null) return null;
			storage.addWeapons(spec.getWeaponId(), 1);
			return "1 " + spec.getWeaponName() + " (weapon)";
		}
		if (category.equals("fighter")) {
			FighterWingSpecAPI spec = pickRandomRegularFighter();
			if (spec == null) return null;
			storage.addFighters(spec.getId(), 1);
			return "1 " + spec.getWingName() + " (fighter wing)";
		}
		if (category.equals("hullmod")) {
			String hullModLine = collectGameDrop(storage, "any_hullmod_low", 1f);
			if (hullModLine != null) return hullModLine + " (hull mod)";
			HullModSpecAPI spec = pickRandomHullMod();
			if (spec == null) return null;
			storage.addHullmods(spec.getId(), 1);
			return "1 " + spec.getDisplayName() + " (hull mod)";
		}
		if (category.equals("blueprint")) {
			return generateBlueprint(storage);
		}
		if (category.equals("ship")) {
			return generateShip(Factions.PLAYER, storage);
		}
		if (category.equals("special")) {
			String itemId = SPECIAL_ITEM_LOOT_POOL[(int) (Math.random() * SPECIAL_ITEM_LOOT_POOL.length)];
			storage.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
			SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec(itemId);
			return "1 " + (spec != null ? spec.getName() : itemId) + " (special item)";
		}
		return null;
	}

	public static final int MAX_MINING_FLEET_BAYS = 2;
	public static final int MAX_MINING_FLEET_SHIPS_PER_BAY = 6;
	public static final int MAX_MINING_FLEET_TANKERS_PER_BAY = 1;

	public static final int MINING_POWER_FRIGATE = 5;
	public static final int MINING_POWER_DESTROYER = 10;
	public static final int MINING_POWER_CRUISER = 15;
		private static final int SPECIALIZED_MINING_POWER_MULTIPLIER = 2;

	public static final float MINING_FLEET_RESOURCES_PER_POWER = 1f;

	private static final String MINING_FLEET_BELT_TARGET_ID = "playerhq_miningfleet_belt";

	private static final String MINING_FLEET_STATE_OUTBOUND = "outbound";
	private static final String MINING_FLEET_STATE_WORKING = "working";
	private static final String MINING_FLEET_STATE_RETURNING = "returning";

	private static final float MINING_FLEET_ASSIGNMENT_DURATION_CAP_DAYS = 999f;
	private static final float MINING_FLEET_ARRIVAL_RANGE = 300f;
	public static final float MINING_STOCK_THRESHOLD = 10000f;
	public static final float MINING_STOCK_CAP = 20000f;
	public static final float MINING_FLEET_MAX_RANGE_LY = 10f;
	private static final String MINING_EXTERNAL_PREFIX = "ext:";
	private static final String MINING_ACTIVE_MEMORY_KEY_PREFIX = "$playerhq_module_militaryward_miningfleet_active_";
	private static final String[] MINING_RESOURCE_IDS = { Commodities.ORE, Commodities.RARE_ORE, Commodities.VOLATILES, Commodities.ORGANICS };
	public static final int MINING_FLEET_RELAUNCH_COOLDOWN_DAYS = 4;
	private static final float MINING_FLEET_FIELD_ORBIT_RADIUS = 200f;
	private static final float MINING_FLEET_ORBIT_DAYS = 60f;
	public static final String MINING_FLEET_LAUNCH_ENABLED_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_launchenabled";
	public static final String MINING_FLEET_COOLDOWN_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_cooldown";
	public static final String MINING_FLEET_LOAD_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_load";
	public static final String MINING_FLEET_CARRIED_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_carried";

	public static final String MINING_FLEET_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_ships";
	public static final String MINING_FLEET_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_crewcost";
	public static final String MINING_FLEET_TARGET_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_target";
	public static final String MINING_FLEET_TARGET_ENTITY_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_targetentity";
	public static final String MINING_FLEET_TOURING_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_touring";
	public static final String MINING_FLEET_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_fleet";
	public static final String MINING_FLEET_DAY_OFFSET_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_dayoffset";
	public static final String MINING_FLEET_STATE_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_state";
	public static final String MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_respawnmanifest";
	public static final String MINING_FLEET_DESTROYED_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_destroyed";
	public static final String MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_respawndaysleft";
	public static final String MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_destroyedcause";

	private static final float MINING_FLEET_BELT_MIN_STAR_DISTANCE = 3000f;

	private static List<SectorEntityToken> getAsteroidBeltOrFieldCandidates(StarSystemAPI system) {
		List<SectorEntityToken> candidates = new ArrayList<SectorEntityToken>();
		if (system == null) return candidates;

		List<PlanetAPI> stars = new ArrayList<PlanetAPI>();
		for (PlanetAPI p : system.getPlanets()) {
			if (p.isStar()) stars.add(p);
		}

		for (Object object : system.getEntities(CampaignTerrainAPI.class)) {
			CampaignTerrainAPI terrain = (CampaignTerrainAPI) object;
			CampaignTerrainPlugin plugin = terrain.getPlugin();
			if (!(plugin instanceof AsteroidBeltTerrainPlugin) && !(plugin instanceof AsteroidFieldTerrainPlugin)) continue;

			boolean tooCloseToStar = false;
			for (PlanetAPI star : stars) {
				if (Misc.getDistance(terrain, star) < MINING_FLEET_BELT_MIN_STAR_DISTANCE) {
					tooCloseToStar = true;
					break;
				}
			}
			if (!tooCloseToStar) candidates.add(terrain);
		}
		return candidates;
	}

	private static boolean systemHasAsteroidBeltOrField(StarSystemAPI system) {
		return !getAsteroidBeltOrFieldCandidates(system).isEmpty();
	}

	private static String getStationOwnTargetId(SectorEntityToken station) {
		SectorEntityToken focus = station.getOrbitFocus();
		if (focus instanceof PlanetAPI) return focus.getId();
		if (focus != null) return MINING_FLEET_BELT_TARGET_ID;
		return null;
	}

	private static PlanetAPI resolveMiningPlanet(StarSystemAPI system, String targetId) {
		if (targetId == null) return null;
		if (targetId.startsWith(MINING_EXTERNAL_PREFIX)) {
			SectorEntityToken e = Global.getSector().getEntityById(targetId.substring(MINING_EXTERNAL_PREFIX.length()));
			return (e instanceof PlanetAPI) ? (PlanetAPI) e : null;
		}
		return findPlanet(system, targetId);
	}

	private static List<String> getExternalMiningTargetIds(SectorEntityToken station) {
		List<String> ids = new ArrayList<String>();
		StarSystemAPI home = station.getStarSystem();
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			if (system == null || system == home) continue;
			if (system.hasTag(Tags.THEME_HIDDEN)) continue;
			if (Misc.getDistanceLY(station.getLocationInHyperspace(), system.getLocation()) > MINING_FLEET_MAX_RANGE_LY) continue;
			if (!isSystemSafeForTrade(system)) continue;
			for (PlanetAPI p : system.getPlanets()) {
				if (p.isStar()) continue;
				if (!MiningHangarModule.hasOreDeposit(p) && !MiningHangarModule.hasRareOreDeposit(p)
						&& !MiningHangarModule.hasVolatilesDeposit(p) && !MiningHangarModule.hasOrganicsDeposit(p)) continue;
				ids.add(MINING_EXTERNAL_PREFIX + p.getId());
			}
		}
		return ids;
	}

	public static List<String> getMiningFleetTargetIds(SectorEntityToken station) {
		List<String> ids = new ArrayList<String>();
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return ids;

		String ownTargetId = getStationOwnTargetId(station);

		for (PlanetAPI p : system.getPlanets()) {
			if (p.isStar()) continue;
			if (p.getId().equals(ownTargetId)) continue;
			ids.add(p.getId());
		}

		if (systemHasAsteroidBeltOrField(system)) {
			ids.add(MINING_FLEET_BELT_TARGET_ID);
		}

		return ids;
	}

	public static int getMaxMiningFleetBays(SectorEntityToken station) {
		return MAX_MINING_FLEET_BAYS;
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getMiningFleetCommittedShips(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	public static boolean isMiningFleetBayBuilt(SectorEntityToken station, int bayIndex) {
		return getMiningFleetCommittedShips(station, bayIndex) != null || isMiningFleetBayDestroyed(station, bayIndex);
	}

	public static boolean isMiningFleetBayDestroyed(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex));
	}

	private static String getMiningFleetDestroyedCause(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : "unknown causes";
	}

	public static int getMiningFleetBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_MINING_FLEET_BAYS; i++) {
			if (isMiningFleetBayBuilt(station, i)) count++;
		}
		return count;
	}

	private static boolean isEligibleMiningShip(FleetMemberAPI m) {
		if (isAutomatedShipBlocked(m)) return false;
		if (m.getHullSpec() == null) return false;
		if (m.getHullSpec().getHullSize() == HullSize.CAPITAL_SHIP) return false;
		Set<ShipHullSpecAPI.ShipTypeHints> hints = m.getHullSpec().getHints();
		boolean eligibleRole = hints.contains(ShipHullSpecAPI.ShipTypeHints.FREIGHTER)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.TRANSPORT)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.CIVILIAN)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.PHASE)
				|| isMiningTankerShip(m)
				|| hasMiningOrCarrierDesignation(m);
		if (!eligibleRole) return false;
		if (m.getVariant() != null && DModManager.getNumDMods(m.getVariant()) > 0) return false;
		if (hasSMods(m)) return false;
		return true;
	}

	public static boolean isMiningTankerShip(FleetMemberAPI m) {
		if (m == null || m.getHullSpec() == null) return false;
		return m.getHullSpec().getHints().contains(ShipHullSpecAPI.ShipTypeHints.TANKER) || hasDesignationContaining(m, "tanker");
	}

	public static boolean isValidMiningFleetComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.isEmpty()) return false;
		int tankers = 0;
		int others = 0;
		for (FleetMemberAPI m : chosen) {
			if (isMiningTankerShip(m)) tankers++;
			else others++;
		}
		if (tankers > MAX_MINING_FLEET_TANKERS_PER_BAY) return false;
		if (others > MAX_MINING_FLEET_SHIPS_PER_BAY) return false;
		return others + tankers > 0;
	}

	public static boolean hasMiningTanker(List<FleetMemberAPI> ships) {
		if (ships == null) return false;
		for (FleetMemberAPI m : ships) {
			if (isMiningTankerShip(m)) return true;
		}
		return false;
	}

	private static boolean canMineOutsideSystem(SectorEntityToken station, int bayIndex) {
		return hasMiningTanker(getMiningFleetCommittedShips(station, bayIndex));
	}

	public static int getMiningPower(FleetMemberAPI m) {
		if (m.getHullSpec() == null) return 0;
		HullSize size = m.getHullSpec().getHullSize();
		int base;
		if (size == HullSize.FRIGATE) base = MINING_POWER_FRIGATE;
		else if (size == HullSize.DESTROYER) base = MINING_POWER_DESTROYER;
		else if (size == HullSize.CRUISER) base = MINING_POWER_CRUISER;
		else return 0;
		return hasMiningOrCarrierDesignation(m) ? base * SPECIALIZED_MINING_POWER_MULTIPLIER : base;
	}

	private static boolean hasMiningOrCarrierDesignation(FleetMemberAPI m) {
		if (m.getHullSpec() == null || !m.getHullSpec().hasDesignation()) return false;
		String designation = m.getHullSpec().getDesignation().toLowerCase(Locale.ROOT);
		return designation.contains("mining") || designation.contains("miner") || designation.contains("carrier")
				|| designation.contains("drone tender");
	}

	public static int getTotalMiningPower(List<FleetMemberAPI> ships) {
		int total = 0;
		for (FleetMemberAPI m : ships) total += getMiningPower(m);
		return total;
	}

	public static List<FleetMemberAPI> getMiningFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		List<FleetMemberAPI> result = new ArrayList<FleetMemberAPI>();
		if (playerFleet.getFleetData() != null) {
			for (FleetMemberAPI m : playerFleet.getFleetData().getMembersListCopy()) {
				if (m.isFlagship()) continue;
				if (isEligibleMiningShip(m)) result.add(m);
			}
		}
		addMiningCandidatesFrom(playerFleet.getCargo(), playerFleet.getFaction().getId(), result);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) addMiningCandidatesFrom(storage, playerFleet.getFaction().getId(), result);
		return result;
	}

	private static void addMiningCandidatesFrom(CargoAPI cargo, String factionId, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : mothballed.getMembersListCopy()) {
			if (isEligibleMiningShip(m)) out.add(m);
		}
	}

	public static void buildMiningFleetBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex, List<FleetMemberAPI> chosen) {
		if (!MiningHangarModule.isBuilt(station)) return;
		if (bayIndex < 0 || bayIndex >= getMaxMiningFleetBays(station) || isMiningFleetBayBuilt(station, bayIndex)) return;
		if (!isValidMiningFleetComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		station.getMemoryWithoutUpdate().set(bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex), new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(bayKey(MINING_FLEET_CREW_COST_MEMORY_KEY, bayIndex), crewNeeded);
	}

	public static boolean isMiningFleetBayTouring(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(MINING_FLEET_TOURING_MEMORY_KEY, bayIndex));
	}

	private static CampaignFleetAPI getMiningTouringFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(MINING_FLEET_FLEET_MEMORY_KEY, bayIndex));
	}

	public static String getMiningFleetTargetId(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getString(bayKey(MINING_FLEET_TARGET_MEMORY_KEY, bayIndex));
	}

	public static String getMiningFleetTargetName(SectorEntityToken station, int bayIndex) {
		String targetId = getMiningFleetTargetId(station, bayIndex);
		if (targetId == null) return null;
		if (MINING_FLEET_BELT_TARGET_ID.equals(targetId)) return "the system's asteroid belt/field";
		PlanetAPI planet = resolveMiningPlanet(station.getStarSystem(), targetId);
		if (planet == null) return null;
		if (targetId.startsWith(MINING_EXTERNAL_PREFIX) && planet.getStarSystem() != null) {
			return planet.getName() + " in the " + planet.getStarSystem().getBaseName() + " system";
		}
		return planet.getName();
	}

	private static SectorEntityToken resolveMiningFleetTargetEntity(SectorEntityToken station, String targetId) {
		if (targetId == null) return null;
		if (MINING_FLEET_BELT_TARGET_ID.equals(targetId)) return findAsteroidBeltOrField(station.getStarSystem());
		return resolveMiningPlanet(station.getStarSystem(), targetId);
	}

	private static boolean[] getMiningTargetResourceFlags(StarSystemAPI system, String targetId) {
		if (MINING_FLEET_BELT_TARGET_ID.equals(targetId)) {
			return new boolean[] { true, true, true, false };
		}
		PlanetAPI planet = resolveMiningPlanet(system, targetId);
		return new boolean[] {
				MiningHangarModule.hasOreDeposit(planet),
				MiningHangarModule.hasRareOreDeposit(planet),
				MiningHangarModule.hasVolatilesDeposit(planet),
				MiningHangarModule.hasOrganicsDeposit(planet)
		};
	}

	private static boolean isMiningResourceActive(SectorEntityToken station, String commodityId) {
		return station.getMemoryWithoutUpdate().getBoolean(MINING_ACTIVE_MEMORY_KEY_PREFIX + commodityId);
	}

	private static boolean hasActiveMiningResource(SectorEntityToken station) {
		for (String id : MINING_RESOURCE_IDS) {
			if (isMiningResourceActive(station, id)) return true;
		}
		return false;
	}

	public static void updateMiningLaunchGate(SectorEntityToken station) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		for (String id : MINING_RESOURCE_IDS) {
			float qty = storage.getCommodityQuantity(id);
			boolean active = mem.getBoolean(MINING_ACTIVE_MEMORY_KEY_PREFIX + id);
			if (!active && qty < MINING_STOCK_THRESHOLD) active = true;
			else if (active && qty >= MINING_STOCK_CAP) active = false;
			mem.set(MINING_ACTIVE_MEMORY_KEY_PREFIX + id, active);
		}
	}

	private static float getMiningFleetTargetWeight(SectorEntityToken station, CargoAPI storage, StarSystemAPI system, String targetId) {
		boolean[] flags = getMiningTargetResourceFlags(system, targetId);
		float weight = 0f;
		for (int i = 0; i < MINING_RESOURCE_IDS.length; i++) {
			if (!flags[i] || !isMiningResourceActive(station, MINING_RESOURCE_IDS[i])) continue;
			weight = Math.max(weight, Math.max(1f, MINING_STOCK_CAP - storage.getCommodityQuantity(MINING_RESOURCE_IDS[i])));
		}
		if (weight > 0f && targetId.startsWith(MINING_EXTERNAL_PREFIX)) {
			PlanetAPI planet = resolveMiningPlanet(system, targetId);
			if (planet != null) {
				float ly = Misc.getDistanceLY(station.getLocationInHyperspace(), planet.getStarSystem().getLocation());
				weight = weight / (1f + 0.25f * ly);
			}
		}
		return weight;
	}

	private static List<String> getMiningLaunchTargets(SectorEntityToken station, boolean allowExternal) {
		List<String> result = new ArrayList<String>();
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		StarSystemAPI system = station.getStarSystem();
		if (storage == null || system == null) return result;
		List<String> available = getMiningFleetTargetIds(station);
		if (allowExternal) available.addAll(getExternalMiningTargetIds(station));
		for (String targetId : available) {
			if (getMiningFleetTargetWeight(station, storage, system, targetId) > 0f) result.add(targetId);
		}
		return result;
	}

	private static int getMiningFleetCooldownDays(SectorEntityToken station, int bayIndex) {
		return Math.max(0, station.getMemoryWithoutUpdate().getInt(bayKey(MINING_FLEET_COOLDOWN_MEMORY_KEY, bayIndex)));
	}

	private static float getMiningFleetLoad(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFloat(bayKey(MINING_FLEET_LOAD_MEMORY_KEY, bayIndex));
	}

	private static float getMiningFleetCapacity(SectorEntityToken station, int bayIndex) {
		return Math.max(1f, getTradeFleetTotalCargoCapacity(getMiningFleetCommittedShips(station, bayIndex)));
	}

	private static String pickMiningFleetTarget(SectorEntityToken station, boolean allowExternal) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return null;

		StarSystemAPI system = station.getStarSystem();
		WeightedRandomPicker<String> picker = new WeightedRandomPicker<String>();
		for (String targetId : getMiningLaunchTargets(station, false)) {
			picker.add(targetId, getMiningFleetTargetWeight(station, storage, system, targetId));
		}
		if (picker.isEmpty() && allowExternal) {
			for (String targetId : getMiningLaunchTargets(station, true)) {
				picker.add(targetId, getMiningFleetTargetWeight(station, storage, system, targetId));
			}
		}
		return picker.isEmpty() ? null : picker.pick();
	}

	private static String getMiningFleetState(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(MINING_FLEET_STATE_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : null;
	}

	private static SectorEntityToken getMiningFleetTargetEntity(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(MINING_FLEET_TARGET_ENTITY_MEMORY_KEY, bayIndex));
		return (o instanceof SectorEntityToken) ? (SectorEntityToken) o : null;
	}

	public static String getMiningFleetBayStatusText(SectorEntityToken station, int bayIndex) {
		if (isMiningFleetBayDestroyed(station, bayIndex)) {
			int daysLeft = Math.max(station.getMemoryWithoutUpdate().getInt(bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex)), 0);
			return "destroyed by " + getMiningFleetDestroyedCause(station, bayIndex) + " -- rebuilding, ready again in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		if (!isMiningFleetBayTouring(station, bayIndex)) {
			int cooldown = getMiningFleetCooldownDays(station, bayIndex);
			if (cooldown > 0) {
				return "docked at the station, relaunching in " + cooldown + " day" + (cooldown == 1 ? "" : "s");
			}
			if (!hasActiveMiningResource(station)) {
				return "docked at the station, holding until a resource drops below " + (int) MINING_STOCK_THRESHOLD;
			}
			if (getMiningLaunchTargets(station, canMineOutsideSystem(station, bayIndex)).isEmpty()) {
				return "docked at the station, no reachable target offers the resources the station needs";
			}
			return "docked at the station, ready to launch";
		}
		String target = getMiningFleetTargetName(station, bayIndex);
		if (target == null) target = "its target";
		String state = getMiningFleetState(station, bayIndex);
		if (MINING_FLEET_STATE_RETURNING.equals(state)) return "returning to the station";
		if (MINING_FLEET_STATE_WORKING.equals(state)) {
			return "mining " + target + " (cargo " + (int) getMiningFleetLoad(station, bayIndex) + "/"
					+ (int) getMiningFleetCapacity(station, bayIndex) + ")";
		}
		return "moving to " + target;
	}

	public static void launchMiningFleetsIfReady(SectorEntityToken station) {
		if (!MiningHangarModule.isBuilt(station)) return;
		updateMiningLaunchGate(station);
		if (!hasActiveMiningResource(station)) return;
		for (int bayIndex = 0; bayIndex < MAX_MINING_FLEET_BAYS; bayIndex++) {
			launchMiningBay(station, bayIndex);
		}
	}

	private static void launchMiningBay(SectorEntityToken station, int bayIndex) {
		if (isMiningFleetBayTouring(station, bayIndex)) return;
		if (isMiningFleetBayDestroyed(station, bayIndex)) return;
		if (getMiningFleetCooldownDays(station, bayIndex) > 0) return;
		List<FleetMemberAPI> ships = getMiningFleetCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return;

		String targetId = pickMiningFleetTarget(station, canMineOutsideSystem(station, bayIndex));
		if (targetId == null) return;
		SectorEntityToken targetEntity = resolveMiningFleetTargetEntity(station, targetId);
		if (targetEntity == null) return;

		outfitFleetShips(station, ships, true);

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Mining Fleet " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, MINING_FLEET_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, targetEntity, MINING_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				"Traveling to mine " + targetEntity.getName());

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(MINING_FLEET_TARGET_MEMORY_KEY, bayIndex), targetId);
		mem.set(bayKey(MINING_FLEET_TARGET_ENTITY_MEMORY_KEY, bayIndex), targetEntity);
		mem.set(bayKey(MINING_FLEET_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(MINING_FLEET_TOURING_MEMORY_KEY, bayIndex), true);
		mem.set(bayKey(MINING_FLEET_STATE_MEMORY_KEY, bayIndex), MINING_FLEET_STATE_OUTBOUND);
		mem.set(bayKey(MINING_FLEET_LOAD_MEMORY_KEY, bayIndex), 0f);
		mem.set(bayKey(MINING_FLEET_CARRIED_MEMORY_KEY, bayIndex), new LinkedHashMap<String, Float>());
	}

	public static void advanceMiningFleetsDaily(SectorEntityToken station) {
		disbandRetiredMiningBays(station);
		for (int bayIndex = 0; bayIndex < MAX_MINING_FLEET_BAYS; bayIndex++) {
			advanceMiningBayDaily(station, bayIndex);
		}
	}

	public static void advanceMiningFleetsRealtime(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_MINING_FLEET_BAYS; bayIndex++) {
			advanceMiningBayRealtime(station, bayIndex);
		}
	}

	private static void advanceMiningBayRealtime(SectorEntityToken station, int bayIndex) {
		if (!isMiningFleetBayTouring(station, bayIndex)) return;
		String state = getMiningFleetState(station, bayIndex);
		if (state == null) return;

		CampaignFleetAPI fleet = getMiningTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) return;

		if (MINING_FLEET_STATE_OUTBOUND.equals(state)) {
			SectorEntityToken target = getMiningFleetTargetEntity(station, bayIndex);
			if (target == null || fleet.getContainingLocation() != target.getContainingLocation()) return;
			if (Misc.getDistance(fleet, target) <= MINING_FLEET_ARRIVAL_RANGE) {
				fleet.clearAssignments();
				float orbitRadius = (target instanceof PlanetAPI)
						? ((PlanetAPI) target).getRadius() + 250f : MINING_FLEET_FIELD_ORBIT_RADIUS;
				fleet.setCircularOrbitPointingDown(target, (float) (Math.random() * 360f), orbitRadius, MINING_FLEET_ORBIT_DAYS);
				station.getMemoryWithoutUpdate().set(bayKey(MINING_FLEET_STATE_MEMORY_KEY, bayIndex), MINING_FLEET_STATE_WORKING);
			}
			return;
		}

		if (MINING_FLEET_STATE_RETURNING.equals(state)) {
			if (fleet.getContainingLocation() != station.getContainingLocation()) return;
			if (Misc.getDistance(fleet, station) > MINING_FLEET_ARRIVAL_RANGE) return;
			recallMiningFleet(station, bayIndex);
		}
	}

	private static void beginMiningFleetReturn(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		fleet.setOrbit(null);
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, MINING_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				"Returning to the station");
		station.getMemoryWithoutUpdate().set(bayKey(MINING_FLEET_STATE_MEMORY_KEY, bayIndex), MINING_FLEET_STATE_RETURNING);
	}

	private static void advanceMiningBayDaily(SectorEntityToken station, int bayIndex) {
		if (isMiningFleetBayDestroyed(station, bayIndex)) {
			advanceLogisticFleetRespawn(station,
					bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			return;
		}
		if (!isMiningFleetBayTouring(station, bayIndex)) {
			int cooldown = getMiningFleetCooldownDays(station, bayIndex);
			if (cooldown > 0) station.getMemoryWithoutUpdate().set(bayKey(MINING_FLEET_COOLDOWN_MEMORY_KEY, bayIndex), cooldown - 1);
			return;
		}

		CampaignFleetAPI fleet = getMiningTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) {
			markLogisticFleetDestroyed(station, "Mining Fleet " + (bayIndex + 1), getMiningFleetCommittedShips(station, bayIndex),
					"unknown causes",
					bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			clearMiningTouringState(station, bayIndex);
			return;
		}
		topOffFleetSuppliesIfLow(fleet);

		String state = getMiningFleetState(station, bayIndex);
		if (MINING_FLEET_STATE_WORKING.equals(state)) {
			mineForOneDay(station, bayIndex, fleet);
		}
	}

	@SuppressWarnings("unchecked")
	private static void mineForOneDay(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		String targetId = getMiningFleetTargetId(station, bayIndex);
		List<FleetMemberAPI> ships = getMiningFleetCommittedShips(station, bayIndex);
		if (targetId == null || ships == null) return;
		float perResource = getTotalMiningPower(ships) * MINING_FLEET_RESOURCES_PER_POWER;

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		Object o = mem.get(bayKey(MINING_FLEET_CARRIED_MEMORY_KEY, bayIndex));
		Map<String, Float> carried = (o instanceof Map) ? (Map<String, Float>) o : new LinkedHashMap<String, Float>();

		boolean[] flags = getMiningTargetResourceFlags(station.getStarSystem(), targetId);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		float load = getMiningFleetLoad(station, bayIndex);
		boolean gathered = false;
		for (int i = 0; i < MINING_RESOURCE_IDS.length; i++) {
			if (!flags[i] || perResource <= 0f) continue;
			String id = MINING_RESOURCE_IDS[i];
			Float existing = carried.get(id);
			float alreadyCarried = existing != null ? existing : 0f;
			float stored = storage != null ? storage.getCommodityQuantity(id) : 0f;
			if (stored + alreadyCarried >= MINING_STOCK_CAP) continue;
			carried.put(id, alreadyCarried + perResource);
			load += perResource;
			gathered = true;
		}
		mem.set(bayKey(MINING_FLEET_CARRIED_MEMORY_KEY, bayIndex), carried);
		mem.set(bayKey(MINING_FLEET_LOAD_MEMORY_KEY, bayIndex), load);

		if (!gathered || load >= getMiningFleetCapacity(station, bayIndex) || perResource <= 0f) {
			beginMiningFleetReturn(station, bayIndex, fleet);
		}
	}

	@SuppressWarnings("unchecked")
	private static void depositMiningHaul(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(MINING_FLEET_CARRIED_MEMORY_KEY, bayIndex));
		if (!(o instanceof Map)) return;
		Map<String, Float> carried = (Map<String, Float>) o;

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		Map<String, Float> gathered = new LinkedHashMap<String, Float>();
		for (Map.Entry<String, Float> entry : carried.entrySet()) {
			float amount = entry.getValue() != null ? entry.getValue() : 0f;
			if (amount <= 0f) continue;
			storage.addCommodity(entry.getKey(), amount);
			gathered.put(entry.getKey(), amount);
		}

		if (!gathered.isEmpty()) {
			logMiningHaul(station, gathered);
		}
	}

	private static float addCappedResource(CargoAPI storage, String commodityId, float amount) {
		if (amount <= 0f) return 0f;
		float space = MiningHangarModule.getStorageCap(commodityId) - storage.getCommodityQuantity(commodityId);
		if (space <= 0f) return 0f;
		float toAdd = Math.min(amount, space);
		storage.addCommodity(commodityId, toAdd);
		return toAdd;
	}

	private static void addCappedResourceLogged(CargoAPI storage, String commodityId, float amount, Map<String, Float> gathered) {
		float added = addCappedResource(storage, commodityId, amount);
		if (added > 0f) {
			Float existing = gathered.get(commodityId);
			gathered.put(commodityId, (existing != null ? existing : 0f) + added);
		}
	}

	private static final String MINING_FLEET_HAUL_LOG_MEMORY_KEY = "$playerhq_module_militaryward_miningfleet_haullog";

	@SuppressWarnings("unchecked")
	private static void logMiningHaul(SectorEntityToken station, Map<String, Float> gathered) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		Object o = mem.get(MINING_FLEET_HAUL_LOG_MEMORY_KEY);
		Map<String, Float> totals = (o instanceof Map) ? (Map<String, Float>) o : new LinkedHashMap<String, Float>();
		for (Map.Entry<String, Float> entry : gathered.entrySet()) {
			Float existing = totals.get(entry.getKey());
			totals.put(entry.getKey(), (existing != null ? existing : 0f) + entry.getValue());
		}
		mem.set(MINING_FLEET_HAUL_LOG_MEMORY_KEY, totals);
	}

	@SuppressWarnings("unchecked")
	public static List<String> getMiningFleetHaulThisMonth(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(MINING_FLEET_HAUL_LOG_MEMORY_KEY);
		Map<String, Float> totals = (o instanceof Map) ? (Map<String, Float>) o : null;

		List<String> result = new ArrayList<String>();
		if (totals != null) {
			for (Map.Entry<String, Float> entry : totals.entrySet()) {
				result.add((int) (float) entry.getValue() + "x " + Global.getSettings().getCommoditySpec(entry.getKey()).getName());
			}
		}
		return result;
	}

	public static void clearMiningFleetHaulThisMonth(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(MINING_FLEET_HAUL_LOG_MEMORY_KEY);
	}

	private static void despawnMiningFleet(SectorEntityToken station, int bayIndex) {
		CampaignFleetAPI fleet = getMiningTouringFleet(station, bayIndex);
		if (fleet != null) {
			List<FleetMemberAPI> ships = getMiningFleetCommittedShips(station, bayIndex);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearMiningTouringState(station, bayIndex);
	}

	private static void recallMiningFleet(SectorEntityToken station, int bayIndex) {
		depositMiningHaul(station, bayIndex);
		despawnMiningFleet(station, bayIndex);
		station.getMemoryWithoutUpdate().set(bayKey(MINING_FLEET_COOLDOWN_MEMORY_KEY, bayIndex), MINING_FLEET_RELAUNCH_COOLDOWN_DAYS);
	}

	private static void clearMiningTouringState(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(MINING_FLEET_TOURING_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_TARGET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_TARGET_ENTITY_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_STATE_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_LOAD_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(MINING_FLEET_CARRIED_MEMORY_KEY, bayIndex));
	}

	private static void clearMiningBayMemory(SectorEntityToken station, int bayIndex) {
		clearMiningTouringState(station, bayIndex);
		station.getMemoryWithoutUpdate().unset(bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(MINING_FLEET_CREW_COST_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(MINING_FLEET_COOLDOWN_MEMORY_KEY, bayIndex));
		clearLogisticFleetDestroyedState(station,
				bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex),
				bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
	}

	public static void uninstallMiningFleetBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MAX_MINING_FLEET_BAYS || !isMiningFleetBayBuilt(station, bayIndex)) return;

		if (isMiningFleetBayTouring(station, bayIndex)) {
			despawnMiningFleet(station, bayIndex);
		}

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			storage.initMothballedShips(playerFleet.getFaction().getId());
			List<FleetMemberAPI> ships = getReturnableShips(station, getMiningFleetCommittedShips(station, bayIndex),
					bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex));
			if (ships != null && !ships.isEmpty() && storage.getMothballedShips() != null) {
				FleetDataAPI mothballed = storage.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(MINING_FLEET_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) {
				storage.addCrew(crewCost);
			}
		}

		clearMiningBayMemory(station, bayIndex);
	}

	private enum LogisticShipRole { TANKER, TRANSPORT, FREIGHTER }

	private static LogisticShipRole classifyLogisticShip(FleetMemberAPI m, boolean allowTransport) {
		if (isAutomatedShipBlocked(m)) return null;
		if (m.getHullSpec() == null) return null;
		if (m.getHullSpec().getHullSize() == HullSize.CAPITAL_SHIP) return null;
		Set<ShipHullSpecAPI.ShipTypeHints> hints = m.getHullSpec().getHints();
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.TANKER) || hasDesignationContaining(m, "tanker")) {
			return LogisticShipRole.TANKER;
		}
		if (allowTransport && (hints.contains(ShipHullSpecAPI.ShipTypeHints.TRANSPORT) || hasDesignationContaining(m, "transport"))) {
			return LogisticShipRole.TRANSPORT;
		}
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.FREIGHTER) || hasDesignationContaining(m, "freighter")) {
			return LogisticShipRole.FREIGHTER;
		}
		return null;
	}

	private static boolean hasDesignationContaining(FleetMemberAPI m, String substring) {
		if (!m.getHullSpec().hasDesignation()) return false;
		String designation = m.getHullSpec().getDesignation();
		return designation != null && designation.toLowerCase(Locale.ROOT).contains(substring);
	}

	private static boolean hasSMods(FleetMemberAPI m) {
		return m.getVariant() != null && m.getVariant().getSMods() != null && !m.getVariant().getSMods().isEmpty();
	}

	private static boolean isAutomatedShip(FleetMemberAPI m) {
		return m != null && m.getVariant() != null && m.getVariant().hasHullMod(HullMods.AUTOMATED);
	}

	private static boolean isAutomatedShipBlocked(FleetMemberAPI m) {
		if (!isAutomatedShip(m)) return false;
		return Global.getSector().getPlayerStats().getSkillLevel(Skills.AUTOMATED_SHIPS) <= 0f;
	}

	private static boolean isPristine(FleetMemberAPI m) {
		return (m.getVariant() == null || DModManager.getNumDMods(m.getVariant()) <= 0) && !hasSMods(m);
	}

	private static List<FleetMemberAPI> getLogisticCandidatesFromEverywhere(SectorEntityToken station, CampaignFleetAPI playerFleet, boolean allowTransport) {
		List<FleetMemberAPI> result = new ArrayList<FleetMemberAPI>();
		if (playerFleet.getFleetData() != null) {
			for (FleetMemberAPI m : playerFleet.getFleetData().getMembersListCopy()) {
				if (m.isFlagship()) continue;
				cleanLeftoverFleetMods(m);
				if (classifyLogisticShip(m, allowTransport) != null && isPristine(m)) result.add(m);
			}
		}
		addLogisticCandidatesFrom(playerFleet.getCargo(), playerFleet.getFaction().getId(), allowTransport, result);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) addLogisticCandidatesFrom(storage, playerFleet.getFaction().getId(), allowTransport, result);
		return result;
	}

	private static void addLogisticCandidatesFrom(CargoAPI cargo, String factionId, boolean allowTransport, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : mothballed.getMembersListCopy()) {
			cleanLeftoverFleetMods(m);
			if (classifyLogisticShip(m, allowTransport) != null && isPristine(m)) out.add(m);
		}
	}

	private static void returnShipsToStorage(SectorEntityToken station, CampaignFleetAPI playerFleet, List<FleetMemberAPI> ships) {
		if (ships == null || ships.isEmpty()) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		storage.initMothballedShips(playerFleet.getFaction().getId());
		FleetDataAPI mothballed = storage.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : ships) {
			stripAutoAssignedOfficer(m);
			mothballed.addFleetMember(m);
		}
	}

	public static final int LOGISTIC_FLEET_RESPAWN_DAYS = 30;

	private static List<ShipVariantAPI> snapshotVariants(List<FleetMemberAPI> ships) {
		List<ShipVariantAPI> manifest = new ArrayList<ShipVariantAPI>();
		if (ships != null) {
			for (FleetMemberAPI m : ships) {
				if (m != null && m.getVariant() != null) manifest.add(m.getVariant().clone());
			}
		}
		return manifest;
	}

	private static List<FleetMemberAPI> buildFreshShipsFromManifest(List<ShipVariantAPI> manifest) {
		List<FleetMemberAPI> rebuilt = new ArrayList<FleetMemberAPI>();
		if (manifest != null) {
			for (ShipVariantAPI variant : manifest) {
				rebuilt.add(Global.getFactory().createFleetMember(FleetMemberType.SHIP, variant.clone()));
			}
		}
		return rebuilt;
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getReturnableShips(SectorEntityToken station, List<FleetMemberAPI> committedShips, String manifestKey) {
		List<FleetMemberAPI> result;
		if (committedShips != null) {
			result = committedShips;
		} else {
			Object o = station.getMemoryWithoutUpdate().get(manifestKey);
			result = (o instanceof List) ? buildFreshShipsFromManifest((List<ShipVariantAPI>) o) : null;
		}
		stripShipsBare(result);
		return result;
	}

	private static boolean removeFleetManagedMods(ShipVariantAPI v) {
		boolean changed = false;
		Set<String> managed = getManagedHullModIds();
		for (String modId : new ArrayList<String>(v.getPermaMods())) {
			String tag = FLEET_ADDED_MOD_TAG_PREFIX + modId;
			if (!managed.contains(modId) && !v.hasTag(tag)) continue;
			v.removePermaMod(modId);
			v.getSMods().remove(modId);
			v.removeMod(modId);
			v.removeTag(tag);
			changed = true;
		}
		for (String modId : new ArrayList<String>(v.getSMods())) {
			if (!managed.contains(modId)) continue;
			v.getSMods().remove(modId);
			v.removeMod(modId);
			changed = true;
		}
		return changed;
	}

	private static void cleanLeftoverFleetMods(FleetMemberAPI m) {
		if (m == null || m.getVariant() == null) return;
		try {
			Set<String> sMods = m.getVariant().getSMods();
			if (sMods == null || sMods.isEmpty()) return;
			if (!getManagedHullModIds().containsAll(sMods)) return;
			ShipVariantAPI v = m.getVariant().clone();
			v.setSource(VariantSource.REFIT);
			if (removeFleetManagedMods(v)) {
				m.setVariant(v, false, true);
				m.updateStats();
			}
		} catch (Throwable t) {
			Global.getLogger(MilitaryWardModule.class).warn("Player HQ: could not clean leftover mods on " + m.getShipName(), t);
		}
	}

	private static void stripShipsBare(List<FleetMemberAPI> ships) {
		if (ships == null) return;
		for (FleetMemberAPI m : ships) {
			if (m == null || m.getVariant() == null) continue;
			removeDoubleHolds(m);
			try {
				m.setCaptain(null);
				ShipVariantAPI v = m.getVariant().clone();
				v.setSource(VariantSource.REFIT);
				ShipHullSpecAPI hull = v.getHullSpec();

				for (String slotId : new ArrayList<String>(v.getNonBuiltInWeaponSlots())) {
					String weaponId = v.getWeaponId(slotId);
					if (weaponId != null && !weaponId.isEmpty()) v.clearSlot(slotId);
				}
				int bays = hull.getFighterBays();
				for (int i = 0; i < bays; i++) {
					if (hull.isBuiltInWing(i)) continue;
					String wingId = v.getWingId(i);
					if (wingId != null && !wingId.isEmpty()) v.setWingId(i, null);
				}
				removeFleetManagedMods(v);
				for (String modId : new ArrayList<String>(v.getNonBuiltInHullmods())) {
					if (v.getPermaMods().contains(modId) || v.getSMods().contains(modId)) continue;
					v.removeMod(modId);
				}
				v.removeTag(GEAR_STRIPPED_TAG);

				v.getWeaponGroups().clear();
				v.autoGenerateWeaponGroups();
				m.setVariant(v, false, true);
				m.updateStats();
			} catch (Throwable t) {
				Global.getLogger(MilitaryWardModule.class).warn("Player HQ: could not strip " + m.getShipName(), t);
			}
		}
	}

	private static void markLogisticFleetDestroyed(SectorEntityToken station, String reportLabel, List<FleetMemberAPI> lostShips, String cause,
			String shipsKey, String manifestKey, String destroyedKey, String daysLeftKey, String causeKey) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(manifestKey, snapshotVariants(lostShips));
		mem.unset(shipsKey);
		mem.set(destroyedKey, true);
		mem.set(daysLeftKey, LOGISTIC_FLEET_RESPAWN_DAYS);
		mem.set(causeKey, cause);
		PlayerHQFleetLossIntel.report(station, reportLabel, cause);
	}

	@SuppressWarnings("unchecked")
	private static void advanceLogisticFleetRespawn(SectorEntityToken station,
			String shipsKey, String manifestKey, String destroyedKey, String daysLeftKey, String causeKey) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		int daysLeft = mem.getInt(daysLeftKey) - 1;
		if (daysLeft > 0) {
			mem.set(daysLeftKey, daysLeft);
			return;
		}

		Object o = mem.get(manifestKey);
		mem.set(shipsKey, buildFreshShipsFromManifest((o instanceof List) ? (List<ShipVariantAPI>) o : null));
		mem.unset(manifestKey);
		mem.unset(destroyedKey);
		mem.unset(daysLeftKey);
		mem.unset(causeKey);
	}

	private static void clearLogisticFleetDestroyedState(SectorEntityToken station,
			String manifestKey, String destroyedKey, String daysLeftKey, String causeKey) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(manifestKey);
		mem.unset(destroyedKey);
		mem.unset(daysLeftKey);
		mem.unset(causeKey);
	}

	public static final int RESUPPLY_BAY_MAX_SHIPS = 5;
	public static final int RESUPPLY_BAY_TANKERS_REQUIRED = 1;
	public static final int RESUPPLY_BAY_TRANSPORTS_REQUIRED = 1;
	public static final int RESUPPLY_BAY_FREIGHTERS_REQUIRED = 3;

	public static final String RESUPPLY_BAY_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_ships";
	public static final String RESUPPLY_BAY_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_crewcost";
	public static final String RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_respawnmanifest";
	public static final String RESUPPLY_BAY_DESTROYED_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_destroyed";
	public static final String RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_respawndaysleft";
	public static final String RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY = "$playerhq_module_militaryward_resupplybay_destroyedcause";

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getResupplyBayCommittedShips(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(RESUPPLY_BAY_SHIPS_MEMORY_KEY);
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	public static boolean hasResupplyBayBuilt(SectorEntityToken station) {
		return getResupplyBayCommittedShips(station) != null || isResupplyBayDestroyed(station);
	}

	public static boolean isResupplyBayDestroyed(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(RESUPPLY_BAY_DESTROYED_MEMORY_KEY);
	}

	private static String getResupplyBayDestroyedCause(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
		return (o instanceof String) ? (String) o : "unknown causes";
	}

	private static void handleResupplyFleetFoundDestroyed(SectorEntityToken station, String cause) {
		markLogisticFleetDestroyed(station, "Resupply Fleet", getResupplyBayCommittedShips(station), cause,
				RESUPPLY_BAY_SHIPS_MEMORY_KEY, RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY,
				RESUPPLY_BAY_DESTROYED_MEMORY_KEY, RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
		clearResupplyFleetState(station);
	}

	public static List<FleetMemberAPI> getResupplyFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return getLogisticCandidatesFromEverywhere(station, playerFleet, true);
	}

	public static boolean isValidResupplyComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.size() != RESUPPLY_BAY_MAX_SHIPS) return false;
		int tankers = 0, transports = 0, freighters = 0;
		for (FleetMemberAPI m : chosen) {
			LogisticShipRole role = classifyLogisticShip(m, true);
			if (role == LogisticShipRole.TANKER) tankers++;
			else if (role == LogisticShipRole.TRANSPORT) transports++;
			else if (role == LogisticShipRole.FREIGHTER) freighters++;
			else return false;
		}
		return tankers == RESUPPLY_BAY_TANKERS_REQUIRED && transports == RESUPPLY_BAY_TRANSPORTS_REQUIRED
				&& freighters == RESUPPLY_BAY_FREIGHTERS_REQUIRED;
	}

	public static void buildResupplyBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, List<FleetMemberAPI> chosen) {
		if (!hasFleetHQBuilt(station) || hasResupplyBayBuilt(station)) return;
		if (!isValidResupplyComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		station.getMemoryWithoutUpdate().set(RESUPPLY_BAY_SHIPS_MEMORY_KEY, new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(RESUPPLY_BAY_CREW_COST_MEMORY_KEY, crewNeeded);
	}

	public static void uninstallResupplyBay(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasResupplyBayBuilt(station)) return;
		recallResupplyFleetImmediately(station);
		returnShipsToStorage(station, playerFleet,
				getReturnableShips(station, getResupplyBayCommittedShips(station), RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY));
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			int crewCost = station.getMemoryWithoutUpdate().getInt(RESUPPLY_BAY_CREW_COST_MEMORY_KEY);
			if (crewCost > 0) storage.addCrew(crewCost);
		}
		station.getMemoryWithoutUpdate().unset(RESUPPLY_BAY_SHIPS_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(RESUPPLY_BAY_CREW_COST_MEMORY_KEY);
		clearLogisticFleetDestroyedState(station,
				RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_MEMORY_KEY,
				RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
	}

	private static void disbandResupplyBayInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		if (!hasResupplyBayBuilt(station)) return;
		recallResupplyFleetImmediately(station);
		if (destination != null) {
			destination.initMothballedShips(factionId);
			List<FleetMemberAPI> ships = getReturnableShips(station, getResupplyBayCommittedShips(station), RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY);
			if (ships != null && !ships.isEmpty() && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(RESUPPLY_BAY_CREW_COST_MEMORY_KEY);
			if (crewCost > 0) destination.addCrew(crewCost);
		}
		station.getMemoryWithoutUpdate().unset(RESUPPLY_BAY_SHIPS_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(RESUPPLY_BAY_CREW_COST_MEMORY_KEY);
		clearLogisticFleetDestroyedState(station,
				RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_MEMORY_KEY,
				RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
	}

	public static final int RESUPPLY_FLEET_FOLLOW_DAYS = 6;
	public static final int RESUPPLY_FLEET_POST_RETURN_COOLDOWN_DAYS = 6;
	private static final float RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS = 999f;
	private static final float RESUPPLY_FLEET_ARRIVAL_RANGE = 300f;
	private static final float RESUPPLY_FLEET_REARM_RANGE = 800f;

	private static final String RESUPPLY_FLEET_STATE_OUTBOUND = "outbound";
	private static final String RESUPPLY_FLEET_STATE_FOLLOWING = "following";
	private static final String RESUPPLY_FLEET_STATE_RETURNING = "returning";
	private static final String RESUPPLY_FLEET_STATE_COOLDOWN = "cooldown";

	public static final String RESUPPLY_FLEET_STATE_MEMORY_KEY = "$playerhq_module_militaryward_resupplyfleet_state";
	public static final String RESUPPLY_FLEET_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_resupplyfleet_fleet";
	public static final String RESUPPLY_FLEET_TIMER_MEMORY_KEY = "$playerhq_module_militaryward_resupplyfleet_timer";
	private static final String RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY = "$playerhq_module_militaryward_resupplyfleet_interactlocked";

	private static String getResupplyFleetState(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(RESUPPLY_FLEET_STATE_MEMORY_KEY);
		return (o instanceof String) ? (String) o : null;
	}

	public static boolean isResupplyFleetActive(SectorEntityToken station) {
		return getResupplyFleetState(station) != null;
	}

	private static CampaignFleetAPI getResupplyTouringFleet(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getFleet(RESUPPLY_FLEET_FLEET_MEMORY_KEY);
	}

	public static String getResupplyFleetStatusText(SectorEntityToken station) {
		if (isResupplyBayDestroyed(station)) {
			int daysLeft = Math.max(station.getMemoryWithoutUpdate().getInt(RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY), 0);
			return "destroyed by " + getResupplyBayDestroyedCause(station) + " -- rebuilding, ready again in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		String state = getResupplyFleetState(station);
		if (state == null) return "docked at the station, ready to be called";
		if (RESUPPLY_FLEET_STATE_OUTBOUND.equals(state)) return "en route to intercept your fleet";
		if (RESUPPLY_FLEET_STATE_FOLLOWING.equals(state)) return "escorting your fleet";
		if (RESUPPLY_FLEET_STATE_RETURNING.equals(state)) return "returning to the station";
		if (RESUPPLY_FLEET_STATE_COOLDOWN.equals(state)) return "back at the station, resting its crew before its next run";
		return "unavailable";
	}

	public static boolean dispatchResupplyFleet(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasResupplyBayBuilt(station) || isResupplyFleetActive(station) || playerFleet == null) return false;
		List<FleetMemberAPI> ships = getResupplyBayCommittedShips(station);
		if (ships == null || ships.isEmpty()) return false;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return false;

		outfitFleetShips(station, ships, false);

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER, "Resupply Fleet", false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		fleet.getMemoryWithoutUpdate().set(MemFlags.DO_NOT_TRY_TO_AVOID_NEARBY_FLEETS, true);
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_FLEET_DO_NOT_GET_SIDETRACKED, true);
		injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);

		fleet.addAssignment(FleetAssignment.INTERCEPT, playerFleet, RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_OUTBOUND);
		mem.set(RESUPPLY_FLEET_FLEET_MEMORY_KEY, fleet);
		return true;
	}

	public static void advanceResupplyFleetRealtime(SectorEntityToken station) {
		String state = getResupplyFleetState(station);
		if (state == null) return;

		boolean expectingLiveFleet = RESUPPLY_FLEET_STATE_OUTBOUND.equals(state) || RESUPPLY_FLEET_STATE_FOLLOWING.equals(state)
				|| RESUPPLY_FLEET_STATE_RETURNING.equals(state);

		CampaignFleetAPI fleet = getResupplyTouringFleet(station);
		if (fleet == null || !fleet.isAlive()) {
			if (expectingLiveFleet) {
				handleResupplyFleetFoundDestroyed(station, "unknown causes");
			} else {
				clearResupplyFleetState(station);
			}
			return;
		}

		if (RESUPPLY_FLEET_STATE_OUTBOUND.equals(state) || RESUPPLY_FLEET_STATE_FOLLOWING.equals(state)) {
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (playerFleet == null) return;
			if (fleet.getContainingLocation() != playerFleet.getContainingLocation()) return;

			float dist = Misc.getDistance(fleet, playerFleet);
			MemoryAPI mem = station.getMemoryWithoutUpdate();
			boolean locked = mem.getBoolean(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY);

			if (dist > RESUPPLY_FLEET_ARRIVAL_RANGE) {
				FleetAssignmentDataAPI current = fleet.getCurrentAssignment();
				if (current == null || current.getAssignment() != FleetAssignment.FOLLOW || current.getTarget() != playerFleet) {
					fleet.clearAssignments();
					fleet.addAssignment(FleetAssignment.FOLLOW, playerFleet, RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS);
				}
			}

			if (!locked && dist <= RESUPPLY_FLEET_ARRIVAL_RANGE) {
				boolean firstMeeting = RESUPPLY_FLEET_STATE_OUTBOUND.equals(state);
				if (firstMeeting) {
					fleet.clearAssignments();
					mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_FOLLOWING);
				}
				mem.set(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY, true);
				openResupplyTransferDialog(station, fleet, playerFleet, firstMeeting);
			} else if (locked && dist > RESUPPLY_FLEET_REARM_RANGE) {
				mem.unset(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY);
			}
			return;
		}

		if (RESUPPLY_FLEET_STATE_RETURNING.equals(state)) {
			if (fleet.getContainingLocation() != station.getContainingLocation()) return;
			if (Misc.getDistance(fleet, station) > RESUPPLY_FLEET_ARRIVAL_RANGE) return;
			finishResupplyFleetReturn(station, fleet);
		}
	}

	private static void openResupplyTransferDialog(final SectorEntityToken station, final CampaignFleetAPI fleet,
			CampaignFleetAPI playerFleet, final boolean firstMeeting) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		CargoAPI offer = Global.getFactory().createCargo(true);
		if (storage != null) {
			offer.addSupplies(storage.getSupplies());
			offer.addFuel(storage.getFuel());
			offer.addCrew(storage.getCrew());
		}

		Runnable onDismiss = new Runnable() {
			@Override
			public void run() {
				if (firstMeeting) beginResupplyFleetFollow(station, fleet);
			}
		};

		if (offer.getSupplies() <= 0f && offer.getFuel() <= 0f && offer.getCrew() <= 0) {
			Global.getSector().getCampaignUI().addMessage(firstMeeting
					? "The Resupply Fleet meets up with you, but the Player HQ's storage has no Supplies, Fuel, "
							+ "or Crew on hand to transfer."
					: "You rendezvous with the Resupply Fleet again, but the Player HQ's storage has nothing new "
							+ "to transfer.");
			onDismiss.run();
			return;
		}

		Global.getSector().getCampaignUI().addMessage(firstMeeting
				? "The Resupply Fleet meets up with your fleet."
				: "You rendezvous with the Resupply Fleet again.");
		Global.getSector().getCampaignUI().showInteractionDialog(
				new ResupplyTransferDialogPlugin(station, offer, onDismiss), playerFleet);
	}

	private static void beginResupplyFleetFollow(SectorEntityToken station, CampaignFleetAPI fleet) {
		if (fleet == null || !fleet.isAlive()) {
			handleResupplyFleetFoundDestroyed(station, "unknown causes");
			return;
		}
		fleet.clearAssignments();
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet != null) {
			fleet.addAssignment(FleetAssignment.FOLLOW, playerFleet, RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS);
		}
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_FOLLOWING);
		mem.set(RESUPPLY_FLEET_TIMER_MEMORY_KEY, RESUPPLY_FLEET_FOLLOW_DAYS);
	}

	private static void beginResupplyFleetReturn(SectorEntityToken station, CampaignFleetAPI fleet) {
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, RESUPPLY_FLEET_ASSIGNMENT_DURATION_CAP_DAYS);
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_RETURNING);
		mem.unset(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY);
	}

	private static void finishResupplyFleetReturn(SectorEntityToken station, CampaignFleetAPI fleet) {
		List<FleetMemberAPI> ships = getResupplyBayCommittedShips(station);
		if (ships != null) {
			for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
				fleet.getFleetData().removeFleetMember(m);
			}
		}
		fleet.despawn();

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(RESUPPLY_FLEET_FLEET_MEMORY_KEY);
		mem.set(RESUPPLY_FLEET_STATE_MEMORY_KEY, RESUPPLY_FLEET_STATE_COOLDOWN);
		mem.set(RESUPPLY_FLEET_TIMER_MEMORY_KEY, RESUPPLY_FLEET_POST_RETURN_COOLDOWN_DAYS);
	}

	private static void clearResupplyFleetState(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(RESUPPLY_FLEET_STATE_MEMORY_KEY);
		mem.unset(RESUPPLY_FLEET_FLEET_MEMORY_KEY);
		mem.unset(RESUPPLY_FLEET_TIMER_MEMORY_KEY);
		mem.unset(RESUPPLY_FLEET_INTERACT_LOCKED_MEMORY_KEY);
	}

	public static void advanceResupplyFleetDaily(SectorEntityToken station) {
		if (isResupplyBayDestroyed(station)) {
			advanceLogisticFleetRespawn(station,
					RESUPPLY_BAY_SHIPS_MEMORY_KEY, RESUPPLY_BAY_RESPAWN_MANIFEST_MEMORY_KEY,
					RESUPPLY_BAY_DESTROYED_MEMORY_KEY, RESUPPLY_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, RESUPPLY_BAY_DESTROYED_CAUSE_MEMORY_KEY);
			return;
		}

		String state = getResupplyFleetState(station);
		if (state == null) return;

		if (RESUPPLY_FLEET_STATE_OUTBOUND.equals(state) || RESUPPLY_FLEET_STATE_RETURNING.equals(state)) {
			CampaignFleetAPI travelling = getResupplyTouringFleet(station);
			if (travelling != null && travelling.isAlive()) {
				topOffFleetSuppliesIfLow(travelling);
			}
			return;
		}

		if (RESUPPLY_FLEET_STATE_FOLLOWING.equals(state)) {
			CampaignFleetAPI fleet = getResupplyTouringFleet(station);
			if (fleet == null || !fleet.isAlive()) {
				handleResupplyFleetFoundDestroyed(station, "unknown causes");
				return;
			}
			topOffFleetSuppliesIfLow(fleet);
			int daysLeft = station.getMemoryWithoutUpdate().getInt(RESUPPLY_FLEET_TIMER_MEMORY_KEY) - 1;
			if (daysLeft <= 0) {
				beginResupplyFleetReturn(station, fleet);
			} else {
				station.getMemoryWithoutUpdate().set(RESUPPLY_FLEET_TIMER_MEMORY_KEY, daysLeft);
			}
			return;
		}

		if (RESUPPLY_FLEET_STATE_COOLDOWN.equals(state)) {
			int daysLeft = station.getMemoryWithoutUpdate().getInt(RESUPPLY_FLEET_TIMER_MEMORY_KEY) - 1;
			if (daysLeft <= 0) {
				clearResupplyFleetState(station);
			} else {
				station.getMemoryWithoutUpdate().set(RESUPPLY_FLEET_TIMER_MEMORY_KEY, daysLeft);
			}
		}
	}

	private static void recallResupplyFleetImmediately(SectorEntityToken station) {
		if (!isResupplyFleetActive(station)) return;
		CampaignFleetAPI fleet = getResupplyTouringFleet(station);
		if (fleet != null && fleet.isAlive()) {
			List<FleetMemberAPI> ships = getResupplyBayCommittedShips(station);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearResupplyFleetState(station);
	}

	public static final int MAX_COURIER_BAYS = 2;
	public static final int COURIER_BAY_MAX_FREIGHTERS = 5;
	public static final int COURIER_BAY_TANKERS_REQUIRED = 1;
	public static final int COURIER_BAY_FREIGHTERS_REQUIRED = 3;

	public static final String COURIER_BAY_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_ships";
	public static final String COURIER_BAY_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_crewcost";
	public static final String COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_respawnmanifest";
	public static final String COURIER_BAY_DESTROYED_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_destroyed";
	public static final String COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_respawndaysleft";
	public static final String COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_destroyedcause";

	@SuppressWarnings("unchecked")
	static List<FleetMemberAPI> getCourierBayCommittedShips(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	public static boolean isCourierBayBuilt(SectorEntityToken station, int bayIndex) {
		return getCourierBayCommittedShips(station, bayIndex) != null || isCourierBayDestroyed(station, bayIndex);
	}

	public static boolean isCourierBayDestroyed(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex));
	}

	private static String getCourierBayDestroyedCause(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : "unknown causes";
	}

	public static int getCourierBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_COURIER_BAYS; i++) {
			if (isCourierBayBuilt(station, i)) count++;
		}
		return count;
	}

	public static List<FleetMemberAPI> getCourierFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return getLogisticCandidatesFromEverywhere(station, playerFleet, false);
	}

	public static boolean isValidCourierComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.size() > COURIER_BAY_TANKERS_REQUIRED + COURIER_BAY_MAX_FREIGHTERS) return false;
		int tankers = 0, freighters = 0;
		for (FleetMemberAPI m : chosen) {
			LogisticShipRole role = classifyLogisticShip(m, false);
			if (role == LogisticShipRole.TANKER) tankers++;
			else if (role == LogisticShipRole.FREIGHTER) freighters++;
			else return false;
		}
		return tankers == COURIER_BAY_TANKERS_REQUIRED && freighters >= COURIER_BAY_FREIGHTERS_REQUIRED
				&& freighters <= COURIER_BAY_MAX_FREIGHTERS;
	}

	public static void buildCourierBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex, List<FleetMemberAPI> chosen) {
		if (!hasFleetHQBuilt(station)) return;
		if (bayIndex < 0 || bayIndex >= MAX_COURIER_BAYS || isCourierBayBuilt(station, bayIndex)) return;
		if (!isValidCourierComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		station.getMemoryWithoutUpdate().set(bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex), new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, bayIndex), crewNeeded);
	}

	public static void uninstallCourierBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MAX_COURIER_BAYS || !isCourierBayBuilt(station, bayIndex)) return;

		if (isCourierPickupFleetActive(station) && getCourierPickupSourceBay(station) == bayIndex) {
			recallCourierPickupImmediately(station);
		}

		if (isCourierBayTouring(station, bayIndex)) {
			despawnCourierFleet(station, bayIndex);
		}

		returnShipsToStorage(station, playerFleet, getReturnableShips(station, getCourierBayCommittedShips(station, bayIndex),
				bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex)));
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) storage.addCrew(crewCost);
		}
		station.getMemoryWithoutUpdate().unset(bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, bayIndex));
		clearLogisticFleetDestroyedState(station,
				bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex),
				bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
	}

	private static void disbandAllCourierBaysInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		recallCourierPickupImmediately(station);
		if (destination != null) destination.initMothballedShips(factionId);
		for (int i = 0; i < MAX_COURIER_BAYS; i++) {
			if (!isCourierBayBuilt(station, i)) continue;
			if (isCourierBayTouring(station, i)) {
				despawnCourierFleet(station, i);
			}
			List<FleetMemberAPI> ships = getReturnableShips(station, getCourierBayCommittedShips(station, i),
					bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, i));
			if (ships != null && !ships.isEmpty() && destination != null && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			if (destination != null) {
				int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, i));
				if (crewCost > 0) destination.addCrew(crewCost);
			}
			station.getMemoryWithoutUpdate().unset(bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, i));
			station.getMemoryWithoutUpdate().unset(bayKey(COURIER_BAY_CREW_COST_MEMORY_KEY, i));
			clearLogisticFleetDestroyedState(station,
					bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, i), bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, i),
					bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, i), bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, i));
		}
	}

	static final String COURIER_FLEET_STATE_OUTBOUND = "outbound";
	static final String COURIER_FLEET_STATE_RETURNING = "returning";

	static final float COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS = 999f;
	static final float COURIER_FLEET_ARRIVAL_RANGE = 300f;

	public static final String COURIER_FLEET_TOURING_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_touring";
	public static final String COURIER_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_fleet";
	public static final String COURIER_FLEET_DAY_OFFSET_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_dayoffset";
	public static final String COURIER_FLEET_TARGET_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_target";
	public static final String COURIER_FLEET_HOLD_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_hold";
	public static final String COURIER_FLEET_SUPPLIES_TO_DELIVER_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_suppliestodeliver";
	public static final String COURIER_FLEET_STATE_MEMORY_KEY = "$playerhq_module_militaryward_courierbay_state";

	public static boolean isCourierBayTouring(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(COURIER_FLEET_TOURING_MEMORY_KEY, bayIndex));
	}

	private static CampaignFleetAPI getCourierTouringFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(COURIER_FLEET_MEMORY_KEY, bayIndex));
	}

	static SectorEntityToken getCourierTargetEntity(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex));
		return (o instanceof SectorEntityToken) ? (SectorEntityToken) o : null;
	}

	public static CargoAPI getCourierFleetHold(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(COURIER_FLEET_HOLD_MEMORY_KEY, bayIndex));
		if (o instanceof CargoAPI) return (CargoAPI) o;
		CargoAPI hold = Global.getFactory().createCargo(true);
		station.getMemoryWithoutUpdate().set(bayKey(COURIER_FLEET_HOLD_MEMORY_KEY, bayIndex), hold);
		return hold;
	}

	static String getCourierFleetState(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(COURIER_FLEET_STATE_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : null;
	}

	public static String getCourierBayStatusText(SectorEntityToken station, int bayIndex) {
		if (isCourierBayDestroyed(station, bayIndex)) {
			int daysLeft = Math.max(station.getMemoryWithoutUpdate().getInt(bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex)), 0);
			return "destroyed by " + getCourierBayDestroyedCause(station, bayIndex) + " -- rebuilding, ready again in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		if (isCourierPickupFleetActive(station) && getCourierPickupSourceBay(station) == bayIndex) {
			return "called away by \"Call Fleet\" -- " + getCourierPickupStatusText(station);
		}
		if (!isCourierBayTouring(station, bayIndex)) {
			return "docked at the station, ready to dispatch";
		}
		SectorEntityToken target = getCourierTargetEntity(station, bayIndex);
		String targetName = target != null ? target.getName() : "its destination";
		String state = getCourierFleetState(station, bayIndex);
		if (CourierCharterEngine.isCharterState(state)) return CourierCharterEngine.statusText(station, bayIndex, state);
		return COURIER_FLEET_STATE_RETURNING.equals(state) ? "returning to the station" : ("en route to " + targetName);
	}

	public static void dispatchCourierBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex,
			SectorEntityToken target, CargoAPI outboundCargo) {
		if (!isCourierBayBuilt(station, bayIndex) || isCourierBayTouring(station, bayIndex) || target == null) return;

		List<FleetMemberAPI> ships = getCourierBayCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return;

		outfitFleetShips(station, ships, false);

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Courier Fleet " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		try {
			fleet.getFleetData().setSyncNeeded();
			fleet.getFleetData().syncIfNeeded();
			fleet.getCargo().updateSpaceUsed();
		} catch (Throwable t) {
		}
		CargoAPI loaded = fitCargoToFleet(outboundCargo, fleet);
		CargoAPI hqStorage = PlayerHQUtils.getStationStorageCargo(station);
		if (hqStorage != null) hqStorage.removeAll(loaded);
		station.getMemoryWithoutUpdate().set(bayKey(COURIER_FLEET_HOLD_MEMORY_KEY, bayIndex), Global.getFactory().createCargo(true));
		getCourierFleetHold(station, bayIndex).addAll(loaded);
		injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, target, COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				"Delivering cargo to " + target.getName());
		float suppliesToDeliver = loaded.getSupplies();

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex), target);
		mem.set(bayKey(COURIER_FLEET_SUPPLIES_TO_DELIVER_MEMORY_KEY, bayIndex), suppliesToDeliver);
		mem.set(bayKey(COURIER_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(COURIER_FLEET_TOURING_MEMORY_KEY, bayIndex), true);
		mem.set(bayKey(COURIER_FLEET_STATE_MEMORY_KEY, bayIndex), COURIER_FLEET_STATE_OUTBOUND);
	}

	public static void advanceCourierFleetsDaily(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_COURIER_BAYS; bayIndex++) {
			advanceCourierBayDaily(station, bayIndex);
		}
		CourierCharterEngine.advanceDaily(station);
	}

	public static void advanceCourierFleetsRealtime(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_COURIER_BAYS; bayIndex++) {
			advanceCourierBayRealtime(station, bayIndex);
		}
	}

	static boolean courierHasArrived(CampaignFleetAPI fleet, SectorEntityToken target, float baseRange, float assignmentCapDays) {
		if (fleet == null || target == null) return false;
		if (fleet.getContainingLocation() != target.getContainingLocation()) {
			if (fleet.getCurrentAssignment() == null) {
				fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, target, assignmentCapDays);
			}
			return false;
		}
		if (Misc.getDistance(fleet, target) <= baseRange + target.getRadius()) return true;
		return fleet.getCurrentAssignment() == null;
	}

	private static void advanceCourierBayRealtime(SectorEntityToken station, int bayIndex) {
		if (!isCourierBayTouring(station, bayIndex)) return;
		String state = getCourierFleetState(station, bayIndex);
		if (state == null) return;

		CampaignFleetAPI fleet = getCourierTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) return;

		if (CourierCharterEngine.isCharterState(state)) {
			CourierCharterEngine.advanceRealtime(station, bayIndex, fleet, state);
			return;
		}

		if (COURIER_FLEET_STATE_OUTBOUND.equals(state)) {
			SectorEntityToken target = getCourierTargetEntity(station, bayIndex);
			if (target == null) return;
			if (courierHasArrived(fleet, target, COURIER_FLEET_ARRIVAL_RANGE, COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS)) {
				arriveAndTurnAroundCourierFleet(station, bayIndex, fleet, target);
			}
			return;
		}

		if (COURIER_FLEET_STATE_RETURNING.equals(state)) {
			if (!courierHasArrived(fleet, station, COURIER_FLEET_ARRIVAL_RANGE, COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS)) return;
			recallCourierFleet(station, bayIndex);
		}
	}

	private static void advanceCourierBayDaily(SectorEntityToken station, int bayIndex) {
		if (isCourierBayDestroyed(station, bayIndex)) {
			advanceLogisticFleetRespawn(station,
					bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			return;
		}
		if (!isCourierBayTouring(station, bayIndex)) return;

		CampaignFleetAPI fleet = getCourierTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) {
			markLogisticFleetDestroyed(station, "Courier Fleet " + (bayIndex + 1), getCourierBayCommittedShips(station, bayIndex),
					"unknown causes",
					bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			clearCourierTouringState(station, bayIndex);
			return;
		}
		topOffFleetSuppliesIfLow(fleet, !CourierCharterEngine.isCharterRun(station, bayIndex));
	}

	public static SectorEntityToken getRatSettlementEntity() {
		try {
			if (!Global.getSettings().getModManager().isModEnabled("assortment_of_things")) return null;
			SectorEntityToken token = RatBridge.getSettlementEntity();
			if (token == null || token.getMarket() == null || token.getContainingLocation() == null) return null;
			return token;
		} catch (Throwable t) {
			Global.getLogger(MilitaryWardModule.class).warn("Player HQ: could not read the RAT settlement", t);
			return null;
		}
	}

	public static SubmarketAPI getCourierTargetStorage(MarketAPI market) {
		if (market == null) return null;
		for (SubmarketAPI sub : market.getSubmarketsCopy()) {
			if (sub.getPlugin() != null && sub.getPlugin().getClass().getName().endsWith("SettlementStoragePlugin")) return sub;
		}
		return market.getSubmarket(Submarkets.SUBMARKET_STORAGE);
	}

	private static CargoAPI fitCargoToFleet(CargoAPI source, CampaignFleetAPI fleet) {
		CargoAPI kept = Global.getFactory().createCargo(true);
		CargoAPI fleetCargo = fleet != null ? fleet.getCargo() : null;
		if (source == null || fleetCargo == null) return kept;
		float spaceLeft = getFleetBaseCargoCapacity(fleet);
		float fuelLeft = getFleetBaseFuelCapacity(fleet);
		int personnelLeft = (int) fleetCargo.getMaxPersonnel();

		int crew = Math.min(source.getCrew(), personnelLeft);
		if (crew > 0) kept.addCrew(crew);
		personnelLeft -= crew;
		int marines = Math.min(source.getMarines(), personnelLeft);
		if (marines > 0) kept.addMarines(marines);

		for (CargoStackAPI stack : source.getStacksCopy()) {
			if (stack == null || stack.isNull()) continue;
			float size = stack.getSize();
			if (size <= 0f) continue;
			float units;
			if (stack.isFuelStack()) {
				units = Math.min(size, Math.max(0f, fuelLeft));
				fuelLeft -= units;
			} else {
				float perUnit = stack.getCargoSpacePerUnit();
				if (perUnit > 0f) {
					units = Math.min(size, (float) Math.floor(Math.max(0f, spaceLeft) / perUnit));
					spaceLeft -= units * perUnit;
				} else {
					units = size;
				}
			}
			if (units <= 0f) continue;
			kept.addItems(stack.getType(), stack.getData(), units);
		}
		return kept;
	}

	public static float getPickupHandoffRoom(CampaignFleetAPI fleet, CargoAPI pending) {
		float used = pending != null ? pending.getSpaceUsed() : 0f;
		return Math.max(0f, getFleetBaseCargoCapacity(fleet) - used);
	}

	public static CargoAPI fitPickupHandoff(SectorEntityToken station, CampaignFleetAPI fleet, CargoAPI picked, CargoAPI pending) {
		CargoAPI kept = Global.getFactory().createCargo(true);
		if (picked == null || fleet == null) return kept;
		float spaceLeft = getPickupHandoffRoom(fleet, pending);
		float fuelLeft = Math.max(0f, getFleetBaseFuelCapacity(fleet) - (pending != null ? pending.getFuel() : 0f));
		int personnelLeft = (int) Math.max(0f, fleet.getCargo().getMaxPersonnel()
				- (pending != null ? pending.getCrew() + pending.getMarines() : 0));
		int crew = Math.max(0, Math.min(picked.getCrew(), personnelLeft));
		if (crew > 0) kept.addCrew(crew);
		personnelLeft -= crew;
		int marines = Math.max(0, Math.min(picked.getMarines(), personnelLeft));
		if (marines > 0) kept.addMarines(marines);

		for (CargoStackAPI stack : picked.getStacksCopy()) {
			if (stack == null || stack.isNull()) continue;
			float size = stack.getSize();
			if (size <= 0f) continue;
			float units = size;
			if (stack.isFuelStack()) {
				units = Math.min(units, fuelLeft);
			} else {
				float perUnit = stack.getCargoSpacePerUnit();
				if (perUnit > 0f) units = Math.min(units, (float) Math.floor(Math.max(0f, spaceLeft) / perUnit));
			}
			if (units <= 0f) continue;
			if (stack.isFuelStack()) fuelLeft -= units;
			else if (stack.getCargoSpacePerUnit() > 0f) spaceLeft -= units * stack.getCargoSpacePerUnit();
			kept.addItems(stack.getType(), stack.getData(), units);
		}
		return kept;
	}

	public static void depositPickupHandoff(SectorEntityToken station, CargoAPI pending) {
		if (station == null || pending == null) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		int crew = pending.getCrew();
		int marines = pending.getMarines();
		pending.removeCrew(crew);
		pending.removeMarines(marines);
		storage.addAll(pending);
		pending.clear();

		float credits = 0f;
		int crewStored = Math.min(crew, Math.max(0, (int) MAX_PERSONNEL - storage.getCrew()));
		if (crewStored > 0) storage.addCrew(crewStored);
		credits += (crew - crewStored) * getPersonnelBasePrice(Commodities.CREW);
		int marinesStored = Math.min(marines, Math.max(0, (int) MAX_PERSONNEL - storage.getMarines()));
		if (marinesStored > 0) storage.addMarines(marinesStored);
		credits += (marines - marinesStored) * getPersonnelBasePrice(Commodities.MARINES);

		if (credits > 0f) {
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (playerFleet != null) playerFleet.getCargo().getCredits().add(credits);
			int soldCrew = crew - crewStored;
			int soldMarines = marines - marinesStored;
			Global.getSector().getCampaignUI().addMessage("The Player HQ was already full, so the Courier Fleet sold "
					+ (soldCrew > 0 ? soldCrew + " crew" : "")
					+ (soldCrew > 0 && soldMarines > 0 ? " and " : "")
					+ (soldMarines > 0 ? soldMarines + " marines" : "")
					+ " for " + Misc.getDGSCredits(credits) + " credits.");
		}
	}

	private static float getPersonnelBasePrice(String commodityId) {
		com.fs.starfarer.api.campaign.econ.CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(commodityId);
		return spec != null ? spec.getBasePrice() : 0f;
	}

	static void depositHoldCapped(CargoAPI storage, CargoAPI hold) {
		if (storage == null || hold == null) return;
		addCrewCapped(storage, hold.getCrew());
		addMarinesCapped(storage, hold.getMarines());
		hold.removeCrew(hold.getCrew());
		hold.removeMarines(hold.getMarines());
		for (CargoStackAPI stack : new ArrayList<CargoStackAPI>(hold.getStacksCopy())) {
			if (stack == null || stack.isNull() || !stack.isCommodityStack()) continue;
			String commodityId = stack.getCommodityId();
			if (commodityId == null) continue;
			float space = MiningHangarModule.getStorageCap(commodityId) - storage.getCommodityQuantity(commodityId);
			float toDrop = stack.getSize() - Math.max(0f, Math.min(stack.getSize(), space));
			if (toDrop > 0f) hold.removeCommodity(commodityId, toDrop);
		}
		storage.addAll(hold);
		if (hold.getMothballedShips() != null && !hold.getMothballedShips().getMembersListCopy().isEmpty()) {
			storage.initMothballedShips(Factions.PLAYER);
			for (FleetMemberAPI ship : hold.getMothballedShips().getMembersListCopy()) {
				hold.getMothballedShips().removeFleetMember(ship);
				storage.getMothballedShips().addFleetMember(ship);
			}
		}
	}

	public static float getCourierBayCargoCapacity(SectorEntityToken station, int bayIndex) {
		List<FleetMemberAPI> ships = getCourierBayCommittedShips(station, bayIndex);
		if (ships == null) return 0f;
		float total = 0f;
		for (FleetMemberAPI m : ships) {
			if (m != null) total += getBaseCargoCapacity(m);
		}
		return total;
	}

	private static void arriveAndTurnAroundCourierFleet(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet,
			SectorEntityToken target) {
		if (target != null && target.getMarket() != null) {
			SubmarketAPI targetStorage = getCourierTargetStorage(target.getMarket());
			if (targetStorage != null) {
				CargoAPI colonyCargo = targetStorage.getCargo();
				CargoAPI pickedUp = Global.getFactory().createCargo(true);
				pickedUp.addAll(colonyCargo);
				CargoAPI hqStorage = PlayerHQUtils.getStationStorageCargo(station);
				if (hqStorage != null) {
					if (hqStorage.getCrew() >= (int) MAX_PERSONNEL) pickedUp.removeCrew(pickedUp.getCrew());
					if (hqStorage.getMarines() >= (int) MAX_PERSONNEL) pickedUp.removeMarines(pickedUp.getMarines());
					for (CargoStackAPI stack : new ArrayList<CargoStackAPI>(pickedUp.getStacksCopy())) {
						if (stack.isNull() || !stack.isCommodityStack()) continue;
						String commodityId = stack.getCommodityId();
						if (commodityId == null) continue;
						if (hqStorage.getCommodityQuantity(commodityId) >= MiningHangarModule.getStorageCap(commodityId)) {
							pickedUp.removeCommodity(commodityId, stack.getSize());
						}
					}
				}
				CargoAPI hold = getCourierFleetHold(station, bayIndex);
				CargoAPI delivered = Global.getFactory().createCargo(true);
				delivered.addAll(hold);
				hold.clear();
				CargoAPI taken = fitCargoToFleet(pickedUp, fleet);
				colonyCargo.removeAll(taken);
				colonyCargo.addAll(delivered);
				hold.addAll(taken);
			}
		}

		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, COURIER_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				"Returning to the station");
		station.getMemoryWithoutUpdate().set(bayKey(COURIER_FLEET_STATE_MEMORY_KEY, bayIndex), COURIER_FLEET_STATE_RETURNING);
	}

	private static void recallCourierFleet(SectorEntityToken station, int bayIndex) {
		despawnCourierFleet(station, bayIndex);
	}

	private static void depositCourierCargoUncapped(CargoAPI storage, CargoAPI fleetCargo) {
		if (storage == null || fleetCargo == null) return;
		stripNonDeliverableSupplies(fleetCargo, 0f);
		storage.addAll(fleetCargo);
	}

	private static void depositCourierCargoCapped(CargoAPI storage, CargoAPI fleetCargo) {
		depositCourierCargoCapped(storage, fleetCargo, 0f);
	}

	private static void depositCourierCargoCapped(CargoAPI storage, CargoAPI fleetCargo, float suppliesToKeep) {
		if (storage == null || fleetCargo == null) return;

		stripNonDeliverableSupplies(fleetCargo, suppliesToKeep);
		addCrewCapped(storage, fleetCargo.getCrew());
		addMarinesCapped(storage, fleetCargo.getMarines());
		fleetCargo.removeCrew(fleetCargo.getCrew());
		fleetCargo.removeMarines(fleetCargo.getMarines());

		for (CargoStackAPI stack : new ArrayList<CargoStackAPI>(fleetCargo.getStacksCopy())) {
			if (stack.isNull() || !stack.isCommodityStack()) continue;
			String commodityId = stack.getCommodityId();
			if (commodityId == null) continue;
			float space = MiningHangarModule.getStorageCap(commodityId) - storage.getCommodityQuantity(commodityId);
			float toAdd = Math.max(0f, Math.min(stack.getSize(), space));
			float toDrop = stack.getSize() - toAdd;
			if (toDrop > 0f) fleetCargo.removeCommodity(commodityId, toDrop);
		}

		storage.addAll(fleetCargo);
	}

	private static void despawnCourierFleet(SectorEntityToken station, int bayIndex) {
		CourierCharterEngine.onRunEnded(station, bayIndex, true);
		CampaignFleetAPI fleet = getCourierTouringFleet(station, bayIndex);
		if (fleet != null) {
			CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
			if (storage != null) {
				storage.addAll(getCourierFleetHold(station, bayIndex));
			}
			List<FleetMemberAPI> ships = getCourierBayCommittedShips(station, bayIndex);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearCourierTouringState(station, bayIndex);
	}

	static void clearCourierTouringState(SectorEntityToken station, int bayIndex) {
		CourierCharterEngine.onRunEnded(station, bayIndex, false);
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(COURIER_FLEET_TOURING_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(COURIER_FLEET_HOLD_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(COURIER_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(COURIER_FLEET_TARGET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(COURIER_FLEET_DAY_OFFSET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(COURIER_FLEET_STATE_MEMORY_KEY, bayIndex));
	}

	// --- Courier Pickup Fleet: an on-call courier summoned via "Call Fleet" that comes to find the
	// player and follows for a few days, rather than delivering supplies to a market on a fixed
	// schedule. Borrows one idle Courier Bay's committed ships for the run -- same intercept/
	// follow/return pattern as the Resupply Fleet -- except the player GIVES it cargo instead of
	// taking from it, and everything it's carrying gets deposited into the station's storage once
	// it makes it home. Deliberately does NOT reuse the per-bay COURIER_FLEET_* touring state (that
	// belongs to the scheduled market-delivery run for that bay); instead it reserves a bay index
	// of its own and every place that bay's ships could otherwise be reclaimed while it's away
	// (uninstalling that bay, dismantling the Fleet HQ) recalls this fleet first.

	public static final int COURIER_PICKUP_FOLLOW_DAYS = 6;
	public static final int COURIER_PICKUP_POST_RETURN_COOLDOWN_DAYS = 6;
	private static final float COURIER_PICKUP_ASSIGNMENT_DURATION_CAP_DAYS = 999f;
	private static final float COURIER_PICKUP_ARRIVAL_RANGE = 300f;
	private static final float COURIER_PICKUP_REARM_RANGE = 800f;

	private static final String COURIER_PICKUP_STATE_OUTBOUND = "outbound";
	private static final String COURIER_PICKUP_STATE_FOLLOWING = "following";
	private static final String COURIER_PICKUP_STATE_RETURNING = "returning";
	private static final String COURIER_PICKUP_STATE_COOLDOWN = "cooldown";

	public static final String COURIER_PICKUP_STATE_MEMORY_KEY = "$playerhq_module_militaryward_courierpickup_state";
	public static final String COURIER_PICKUP_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_courierpickup_fleet";
	public static final String COURIER_PICKUP_TIMER_MEMORY_KEY = "$playerhq_module_militaryward_courierpickup_timer";
	private static final String COURIER_PICKUP_INTERACT_LOCKED_MEMORY_KEY = "$playerhq_module_militaryward_courierpickup_interactlocked";
	private static final String COURIER_PICKUP_SOURCE_BAY_MEMORY_KEY = "$playerhq_module_militaryward_courierpickup_sourcebay";

	private static String getCourierPickupState(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(COURIER_PICKUP_STATE_MEMORY_KEY);
		return (o instanceof String) ? (String) o : null;
	}

	public static boolean isCourierPickupFleetActive(SectorEntityToken station) {
		return getCourierPickupState(station) != null;
	}

	private static CampaignFleetAPI getCourierPickupFleet(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getFleet(COURIER_PICKUP_FLEET_MEMORY_KEY);
	}

	private static int getCourierPickupSourceBay(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getInt(COURIER_PICKUP_SOURCE_BAY_MEMORY_KEY);
	}

	public static String getCourierPickupTrackerText(SectorEntityToken station) {
		String status = getCourierPickupStatusText(station);
		String where = getCourierPickupLocationText(station);
		return where != null ? status + " (" + where + ")" : status;
	}

	public static String getResupplyFleetLocationText(SectorEntityToken station) {
		return getFleetLocationText(getResupplyTouringFleet(station));
	}

	public static String getCourierPickupLocationText(SectorEntityToken station) {
		return getFleetLocationText(getCourierPickupFleet(station));
	}

	private static String getFleetLocationText(CampaignFleetAPI fleet) {
		if (fleet == null || !fleet.isAlive() || fleet.getContainingLocation() == null) return null;
		if (fleet.isInHyperspace()) {
			StarSystemAPI near = Misc.getNearestStarSystem(fleet);
			return near != null ? "in hyperspace near " + near.getBaseName() : "in hyperspace";
		}
		if (fleet.getContainingLocation() instanceof StarSystemAPI) {
			return "in the " + ((StarSystemAPI) fleet.getContainingLocation()).getBaseName() + " system";
		}
		return null;
	}

	public static String getCourierPickupStatusText(SectorEntityToken station) {
		String state = getCourierPickupState(station);
		if (state == null) {
			return hasCourierBayAvailableForPickup(station)
					? "docked at the station, ready to be called"
					: "no Courier Bay currently available to send";
		}
		if (COURIER_PICKUP_STATE_OUTBOUND.equals(state)) return "en route to intercept your fleet";
		if (COURIER_PICKUP_STATE_FOLLOWING.equals(state)) return "escorting your fleet";
		if (COURIER_PICKUP_STATE_RETURNING.equals(state)) return "returning to the station";
		if (COURIER_PICKUP_STATE_COOLDOWN.equals(state)) return "back at the station, resting its crew before its next run";
		return "unavailable";
	}

	static int findIdleCourierBayIndex(SectorEntityToken station) {
		Integer reserved = isCourierPickupFleetActive(station) ? getCourierPickupSourceBay(station) : null;
		for (int i = 0; i < MAX_COURIER_BAYS; i++) {
			if (reserved != null && reserved == i) continue;
			if (isCourierBayBuilt(station, i) && !isCourierBayDestroyed(station, i) && !isCourierBayTouring(station, i)) {
				return i;
			}
		}
		return -1;
	}

	public static boolean hasCourierBayAvailableForPickup(SectorEntityToken station) {
		return findIdleCourierBayIndex(station) >= 0;
	}

	public static boolean dispatchCourierPickupFleet(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (isCourierPickupFleetActive(station) || playerFleet == null) return false;
		int bayIndex = findIdleCourierBayIndex(station);
		if (bayIndex < 0) return false;

		List<FleetMemberAPI> ships = getCourierBayCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return false;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return false;

		outfitFleetShips(station, ships, false);

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER, "Courier Fleet", false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, COURIER_PICKUP_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		fleet.getMemoryWithoutUpdate().set(MemFlags.DO_NOT_TRY_TO_AVOID_NEARBY_FLEETS, true);
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_FLEET_DO_NOT_GET_SIDETRACKED, true);
		injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);

		fleet.addAssignment(FleetAssignment.INTERCEPT, playerFleet, COURIER_PICKUP_ASSIGNMENT_DURATION_CAP_DAYS);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(COURIER_PICKUP_SOURCE_BAY_MEMORY_KEY, bayIndex);
		mem.set(COURIER_PICKUP_STATE_MEMORY_KEY, COURIER_PICKUP_STATE_OUTBOUND);
		mem.set(COURIER_PICKUP_FLEET_MEMORY_KEY, fleet);
		return true;
	}

	public static void advanceCourierPickupFleetRealtime(SectorEntityToken station) {
		String state = getCourierPickupState(station);
		if (state == null) return;

		boolean expectingLiveFleet = COURIER_PICKUP_STATE_OUTBOUND.equals(state) || COURIER_PICKUP_STATE_FOLLOWING.equals(state)
				|| COURIER_PICKUP_STATE_RETURNING.equals(state);

		CampaignFleetAPI fleet = getCourierPickupFleet(station);
		if (fleet == null || !fleet.isAlive()) {
			if (expectingLiveFleet) {
				handleCourierPickupFoundDestroyed(station, "unknown causes");
			} else {
				clearCourierPickupState(station);
			}
			return;
		}

		if (COURIER_PICKUP_STATE_OUTBOUND.equals(state) || COURIER_PICKUP_STATE_FOLLOWING.equals(state)) {
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (playerFleet == null) return;
			if (fleet.getContainingLocation() != playerFleet.getContainingLocation()) return;

			float dist = Misc.getDistance(fleet, playerFleet);
			MemoryAPI mem = station.getMemoryWithoutUpdate();
			boolean locked = mem.getBoolean(COURIER_PICKUP_INTERACT_LOCKED_MEMORY_KEY);

			if (dist > COURIER_PICKUP_ARRIVAL_RANGE) {
				FleetAssignmentDataAPI current = fleet.getCurrentAssignment();
				if (current == null || current.getAssignment() != FleetAssignment.FOLLOW || current.getTarget() != playerFleet) {
					fleet.clearAssignments();
					fleet.addAssignment(FleetAssignment.FOLLOW, playerFleet, COURIER_PICKUP_ASSIGNMENT_DURATION_CAP_DAYS);
				}
			}

			if (!locked && dist <= COURIER_PICKUP_ARRIVAL_RANGE) {
				boolean firstMeeting = COURIER_PICKUP_STATE_OUTBOUND.equals(state);
				if (firstMeeting) {
					fleet.clearAssignments();
					mem.set(COURIER_PICKUP_STATE_MEMORY_KEY, COURIER_PICKUP_STATE_FOLLOWING);
				}
				mem.set(COURIER_PICKUP_INTERACT_LOCKED_MEMORY_KEY, true);
				openCourierPickupTransferDialog(station, fleet, playerFleet, firstMeeting);
			} else if (locked && dist > COURIER_PICKUP_REARM_RANGE) {
				mem.unset(COURIER_PICKUP_INTERACT_LOCKED_MEMORY_KEY);
			}
			return;
		}

		if (COURIER_PICKUP_STATE_RETURNING.equals(state)) {
			if (!courierHasArrived(fleet, station, COURIER_PICKUP_ARRIVAL_RANGE, COURIER_PICKUP_ASSIGNMENT_DURATION_CAP_DAYS)) return;
			finishCourierPickupReturn(station, fleet);
		}
	}

	private static void openCourierPickupTransferDialog(final SectorEntityToken station, final CampaignFleetAPI fleet,
			CampaignFleetAPI playerFleet, final boolean firstMeeting) {
		Runnable onDismiss = new Runnable() {
			@Override
			public void run() {
				if (fleet != null && fleet.isAlive()) beginCourierPickupReturn(station, fleet);
			}
		};

		Global.getSector().getCampaignUI().addMessage(firstMeeting
				? "The Courier Fleet meets up with your fleet."
				: "You rendezvous with the Courier Fleet again.");
		Global.getSector().getCampaignUI().showInteractionDialog(
				new CourierPickupTransferDialogPlugin(station, fleet, onDismiss), playerFleet);
	}

	private static void beginCourierPickupFollow(SectorEntityToken station, CampaignFleetAPI fleet) {
		if (fleet == null || !fleet.isAlive()) {
			handleCourierPickupFoundDestroyed(station, "unknown causes");
			return;
		}
		fleet.clearAssignments();
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet != null) {
			fleet.addAssignment(FleetAssignment.FOLLOW, playerFleet, COURIER_PICKUP_ASSIGNMENT_DURATION_CAP_DAYS);
		}
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(COURIER_PICKUP_STATE_MEMORY_KEY, COURIER_PICKUP_STATE_FOLLOWING);
		mem.set(COURIER_PICKUP_TIMER_MEMORY_KEY, COURIER_PICKUP_FOLLOW_DAYS);
	}

	private static void beginCourierPickupReturn(SectorEntityToken station, CampaignFleetAPI fleet) {
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, COURIER_PICKUP_ASSIGNMENT_DURATION_CAP_DAYS);
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(COURIER_PICKUP_STATE_MEMORY_KEY, COURIER_PICKUP_STATE_RETURNING);
		mem.unset(COURIER_PICKUP_INTERACT_LOCKED_MEMORY_KEY);
	}

	private static void finishCourierPickupReturn(SectorEntityToken station, CampaignFleetAPI fleet) {
		int bayIndex = getCourierPickupSourceBay(station);
		List<FleetMemberAPI> ships = getCourierBayCommittedShips(station, bayIndex);
		if (ships != null) {
			for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
				fleet.getFleetData().removeFleetMember(m);
			}
		}
		fleet.despawn();

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(COURIER_PICKUP_FLEET_MEMORY_KEY);
		mem.unset(COURIER_PICKUP_SOURCE_BAY_MEMORY_KEY);
		mem.set(COURIER_PICKUP_STATE_MEMORY_KEY, COURIER_PICKUP_STATE_COOLDOWN);
		mem.set(COURIER_PICKUP_TIMER_MEMORY_KEY, COURIER_PICKUP_POST_RETURN_COOLDOWN_DAYS);
	}

	private static void clearCourierPickupState(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(COURIER_PICKUP_STATE_MEMORY_KEY);
		mem.unset(COURIER_PICKUP_FLEET_MEMORY_KEY);
		mem.unset(COURIER_PICKUP_TIMER_MEMORY_KEY);
		mem.unset(COURIER_PICKUP_INTERACT_LOCKED_MEMORY_KEY);
		mem.unset(COURIER_PICKUP_SOURCE_BAY_MEMORY_KEY);
	}

	public static void advanceCourierPickupFleetDaily(SectorEntityToken station) {
		String state = getCourierPickupState(station);
		if (state == null) return;

		if (COURIER_PICKUP_STATE_OUTBOUND.equals(state) || COURIER_PICKUP_STATE_RETURNING.equals(state)) {
			CampaignFleetAPI travelling = getCourierPickupFleet(station);
			if (travelling != null && travelling.isAlive()) {
				topOffFleetSuppliesIfLow(travelling, false);
			}
			return;
		}

		if (COURIER_PICKUP_STATE_FOLLOWING.equals(state)) {
			CampaignFleetAPI fleet = getCourierPickupFleet(station);
			if (fleet == null || !fleet.isAlive()) {
				handleCourierPickupFoundDestroyed(station, "unknown causes");
				return;
			}
			topOffFleetSuppliesIfLow(fleet, false);
			int daysLeft = station.getMemoryWithoutUpdate().getInt(COURIER_PICKUP_TIMER_MEMORY_KEY) - 1;
			if (daysLeft <= 0) {
				beginCourierPickupReturn(station, fleet);
			} else {
				station.getMemoryWithoutUpdate().set(COURIER_PICKUP_TIMER_MEMORY_KEY, daysLeft);
			}
			return;
		}

		if (COURIER_PICKUP_STATE_COOLDOWN.equals(state)) {
			int daysLeft = station.getMemoryWithoutUpdate().getInt(COURIER_PICKUP_TIMER_MEMORY_KEY) - 1;
			if (daysLeft <= 0) {
				clearCourierPickupState(station);
			} else {
				station.getMemoryWithoutUpdate().set(COURIER_PICKUP_TIMER_MEMORY_KEY, daysLeft);
			}
		}
	}

	private static void handleCourierPickupFoundDestroyed(SectorEntityToken station, String cause) {
		int bayIndex = getCourierPickupSourceBay(station);
		markLogisticFleetDestroyed(station, "Courier Fleet", getCourierBayCommittedShips(station, bayIndex), cause,
				bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
				bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
				bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
		clearCourierPickupState(station);
	}

	private static void recallCourierPickupImmediately(SectorEntityToken station) {
		if (!isCourierPickupFleetActive(station)) return;
		CampaignFleetAPI fleet = getCourierPickupFleet(station);
		int bayIndex = getCourierPickupSourceBay(station);
		if (fleet != null && fleet.isAlive()) {
			List<FleetMemberAPI> ships = getCourierBayCommittedShips(station, bayIndex);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearCourierPickupState(station);
	}

	// --- Trade Fleet: a single logistics bay that auto-launches (no player trigger needed) once the
	// station has accumulated enough surplus resources to fill its ships' cargo holds. It orbits the
	// station "loading" that surplus, then heads out to sell it at the most profitable market it can
	// find in a system that's fully safe for the player (no hostile colony/station present, no
	// active raid from a player-hostile faction, and no pirate activity), before returning home.

	public static final int MAX_TRADE_FLEET_BAYS = 1;
	public static final int TRADE_FLEET_MAX_FREIGHTERS = 5;
	public static final int TRADE_FLEET_MAX_TANKERS = 1;
	
	public static final String TRADE_FLEET_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_ships";
	public static final String TRADE_FLEET_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_crewcost";
	public static final String TRADE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_respawnmanifest";
	public static final String TRADE_FLEET_DESTROYED_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_destroyed";
	public static final String TRADE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_respawndaysleft";
	public static final String TRADE_FLEET_DESTROYED_CAUSE_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_destroyedcause";

	public static final String TRADE_FLEET_TOURING_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_touring";
	public static final String TRADE_FLEET_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_fleet";
	public static final String TRADE_FLEET_STATE_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_state";
	public static final String TRADE_FLEET_TARGET_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_target";
	public static final String TRADE_FLEET_LOADING_DAY_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_loadingday";
	public static final String TRADE_FLEET_LAST_PROCEEDS_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_lastproceeds";

	private static final String TRADE_FLEET_STATE_LOADING = "loading";
	private static final String TRADE_FLEET_STATE_OUTBOUND = "outbound";
	private static final String TRADE_FLEET_STATE_RETURNING = "returning";

	private static final int TRADE_FLEET_LOADING_DAYS = 2;
	private static final float TRADE_FLEET_ASSIGNMENT_DURATION_CAP_DAYS = 999f;
	private static final float TRADE_FLEET_ARRIVAL_RANGE = 300f;
	// Deliberately low -- selling to yourself this way is meant to be inefficient compared to normal
	// trading, just a way to turn otherwise-idle surplus into some income.
	private static final float TRADE_FLEET_SALE_VALUE_FRACTION = 0.3f;

	private static LogisticShipRole classifyTradeFleetShip(FleetMemberAPI m) {
		if (isAutomatedShipBlocked(m)) return null;
		if (m.getHullSpec() == null) return null;
		if (m.getHullSpec().getHullSize() == HullSize.CAPITAL_SHIP) return null;
		Set<ShipHullSpecAPI.ShipTypeHints> hints = m.getHullSpec().getHints();
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.TANKER) || hasDesignationContaining(m, "tanker")) {
			return LogisticShipRole.TANKER;
		}
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.FREIGHTER) || hasDesignationContaining(m, "freighter")) {
			return LogisticShipRole.FREIGHTER;
		}
		return null;
	}

	private static void addTradeFleetCandidatesFrom(CargoAPI cargo, String factionId, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : mothballed.getMembersListCopy()) {
			if (classifyTradeFleetShip(m) != null && isPristine(m)) out.add(m);
		}
	}

	public static List<FleetMemberAPI> getTradeFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		List<FleetMemberAPI> result = new ArrayList<FleetMemberAPI>();
		if (playerFleet.getFleetData() != null) {
			for (FleetMemberAPI m : playerFleet.getFleetData().getMembersListCopy()) {
				if (m.isFlagship()) continue;
				if (classifyTradeFleetShip(m) != null && isPristine(m)) result.add(m);
			}
		}
		addTradeFleetCandidatesFrom(playerFleet.getCargo(), playerFleet.getFaction().getId(), result);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) addTradeFleetCandidatesFrom(storage, playerFleet.getFaction().getId(), result);
		return result;
	}

	public static boolean isValidTradeFleetComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.isEmpty()) return false;
		int tankers = 0, freighters = 0;
		for (FleetMemberAPI m : chosen) {
			LogisticShipRole role = classifyTradeFleetShip(m);
			if (role == LogisticShipRole.TANKER) tankers++;
			else if (role == LogisticShipRole.FREIGHTER) freighters++;
			else return false;
		}
		if (freighters < 1 || freighters > TRADE_FLEET_MAX_FREIGHTERS) return false;
		if (tankers < 1 || tankers > TRADE_FLEET_MAX_TANKERS) return false;
		return tankers == TRADE_FLEET_MAX_TANKERS;
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getTradeFleetCommittedShips(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRADE_FLEET_SHIPS_MEMORY_KEY);
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	public static boolean hasTradeFleetBuilt(SectorEntityToken station) {
		return getTradeFleetCommittedShips(station) != null || isTradeFleetDestroyed(station);
	}

	public static boolean isTradeFleetDestroyed(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(TRADE_FLEET_DESTROYED_MEMORY_KEY);
	}

	private static String getTradeFleetDestroyedCause(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRADE_FLEET_DESTROYED_CAUSE_MEMORY_KEY);
		return (o instanceof String) ? (String) o : "unknown causes";
	}

	public static void buildTradeFleetWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, List<FleetMemberAPI> chosen) {
		if (!hasFleetHQBuilt(station) || hasTradeFleetBuilt(station)) return;
		if (!isValidTradeFleetComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		station.getMemoryWithoutUpdate().set(TRADE_FLEET_SHIPS_MEMORY_KEY, new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(TRADE_FLEET_CREW_COST_MEMORY_KEY, crewNeeded);
	}

	public static boolean isTradeFleetTouring(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(TRADE_FLEET_TOURING_MEMORY_KEY);
	}

	public static void uninstallTradeFleet(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasTradeFleetBuilt(station)) return;

		if (isTradeFleetTouring(station)) {
			despawnTradeFleet(station);
		}

		returnShipsToStorage(station, playerFleet, getReturnableShips(station, getTradeFleetCommittedShips(station),
				TRADE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY));
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) {
			int crewCost = station.getMemoryWithoutUpdate().getInt(TRADE_FLEET_CREW_COST_MEMORY_KEY);
			if (crewCost > 0) storage.addCrew(crewCost);
		}
		station.getMemoryWithoutUpdate().unset(TRADE_FLEET_SHIPS_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(TRADE_FLEET_CREW_COST_MEMORY_KEY);
		clearLogisticFleetDestroyedState(station,
				TRADE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, TRADE_FLEET_DESTROYED_MEMORY_KEY,
				TRADE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, TRADE_FLEET_DESTROYED_CAUSE_MEMORY_KEY);
	}

	private static void disbandTradeFleetInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		if (!hasTradeFleetBuilt(station)) return;
		if (destination != null) destination.initMothballedShips(factionId);
		if (isTradeFleetTouring(station)) {
			despawnTradeFleet(station);
		}
		List<FleetMemberAPI> ships = getReturnableShips(station, getTradeFleetCommittedShips(station), TRADE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY);
		if (ships != null && !ships.isEmpty() && destination != null && destination.getMothballedShips() != null) {
			FleetDataAPI mothballed = destination.getMothballedShips();
			for (FleetMemberAPI m : ships) {
				stripAutoAssignedOfficer(m);
				mothballed.addFleetMember(m);
			}
		}
		if (destination != null) {
			int crewCost = station.getMemoryWithoutUpdate().getInt(TRADE_FLEET_CREW_COST_MEMORY_KEY);
			if (crewCost > 0) destination.addCrew(crewCost);
		}
		station.getMemoryWithoutUpdate().unset(TRADE_FLEET_SHIPS_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(TRADE_FLEET_CREW_COST_MEMORY_KEY);
		clearLogisticFleetDestroyedState(station,
				TRADE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, TRADE_FLEET_DESTROYED_MEMORY_KEY,
				TRADE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, TRADE_FLEET_DESTROYED_CAUSE_MEMORY_KEY);
	}

	private static CampaignFleetAPI getTradeTouringFleet(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getFleet(TRADE_FLEET_FLEET_MEMORY_KEY);
	}

	private static String getTradeFleetState(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRADE_FLEET_STATE_MEMORY_KEY);
		return (o instanceof String) ? (String) o : null;
	}

	private static MarketAPI getTradeFleetTargetMarket(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRADE_FLEET_TARGET_MEMORY_KEY);
		return (o instanceof MarketAPI) ? (MarketAPI) o : null;
	}

	public static String getTradeFleetStatusText(SectorEntityToken station) {
		if (isTradeFleetDestroyed(station)) {
			int daysLeft = Math.max(station.getMemoryWithoutUpdate().getInt(TRADE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY), 0);
			return "destroyed by " + getTradeFleetDestroyedCause(station) + " -- rebuilding, ready again in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		if (!isTradeFleetTouring(station)) {
			List<FleetMemberAPI> ships = getTradeFleetCommittedShips(station);
			float capacity = getTradeFleetTradeCapacity(ships);
			if (capacity <= 0f) {
				return "docked at the station, its ships report no cargo capacity";
			}
			float surplus = getStationSurplusCargoSpace(station);
			if (surplus < capacity) {
				return "docked at the station, waiting for enough surplus cargo to fill its hold (" + (int) surplus + "/" + (int) capacity + ")";
			}
			return "docked at the station, ready to launch";
		}
		String state = getTradeFleetState(station);
		if (TRADE_FLEET_STATE_LOADING.equals(state)) {
			if (station.getMemoryWithoutUpdate().getInt(TRADE_FLEET_LOADING_DAY_MEMORY_KEY) >= TRADE_FLEET_LOADING_DAYS) {
				return "loaded, waiting for a safe market to sell at";
			}
			return "loading surplus cargo at the station";
		}
		if (TRADE_FLEET_STATE_RETURNING.equals(state)) {
			return "returning to the station";
		}
		MarketAPI target = getTradeFleetTargetMarket(station);
		String targetName = (target != null && target.getPrimaryEntity() != null)
				? target.getPrimaryEntity().getName() : "its destination";
		return "en route to sell its cargo at " + targetName;
	}

	private static float getTradeFleetTotalCargoCapacity(List<FleetMemberAPI> ships) {
		float capacity = 0f;
		if (ships != null) {
			for (FleetMemberAPI m : ships) {
				if (m != null) capacity += getBaseCargoCapacity(m);
			}
		}
		return capacity;
	}

	// Only the amount of each commodity stockpiled above this threshold counts as "surplus" the
	// Trade Fleet is allowed to take -- the station always keeps at least this much of everything
	// in reserve for its own use.
	public static final float TRADE_FLEET_SURPLUS_THRESHOLD = 8000f;
	public static final String TRADE_FLEET_HOLD_MEMORY_KEY = "$playerhq_module_militaryward_tradefleet_hold";

	public static CargoAPI getTradeFleetHold(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRADE_FLEET_HOLD_MEMORY_KEY);
		if (o instanceof CargoAPI) return (CargoAPI) o;
		CargoAPI hold = Global.getFactory().createCargo(true);
		station.getMemoryWithoutUpdate().set(TRADE_FLEET_HOLD_MEMORY_KEY, hold);
		return hold;
	}

	private static boolean isTradeableResource(String commodityId) {
		return commodityId != null && !Commodities.FUEL.equals(commodityId);
	}

	private static float getTradeFleetTradeCapacity(List<FleetMemberAPI> ships) {
		return Math.max(0f, getTradeFleetTotalCargoCapacity(ships));
	}

	private static void topOffTradeFleet(CampaignFleetAPI fleet) {
		if (fleet == null) return;
		fillFleetHold(fleet);
		maintainFleetCR(fleet.getFleetData().getMembersListCopy());
	}

	private static void injectTradeFleetLogistics(CampaignFleetAPI fleet, List<FleetMemberAPI> ships) {
		for (FleetMemberAPI m : ships) {
			if (m == null) continue;
			m.getStats().getSuppliesPerMonth().modifyMult(NO_SUPPLY_UPKEEP_SOURCE, 0f, "Player HQ fleet");
			if (m.getRepairTracker() != null) {
				m.getRepairTracker().setMothballed(false);
				m.getRepairTracker().setCrashMothballed(false);
			}
		}
		topOffTradeFleet(fleet);
	}

	private static Set<String> getResourceCommodityIdsInStorage(CargoAPI storage) {
		Set<String> ids = new HashSet<String>();
		if (storage == null) return ids;
		for (CargoStackAPI stack : storage.getStacksCopy()) {
			if (stack == null || stack.isNull() || !stack.isResourceStack()) continue;
			String commodityId = stack.getCommodityId();
			if (isTradeableResource(commodityId)) ids.add(commodityId);
		}
		return ids;
	}

	private static float getSurplusQuantity(CargoAPI storage, String commodityId) {
		if (storage == null || commodityId == null) return 0f;
		return Math.max(0f, storage.getCommodityQuantity(commodityId) - TRADE_FLEET_SURPLUS_THRESHOLD);
	}

	private static float getCargoSpacePerUnit(String commodityId) {
		if (commodityId == null) return 0f;
		CommoditySpecAPI spec = Global.getSettings().getCommoditySpec(commodityId);
		return spec != null ? spec.getCargoSpace() : 0f;
	}

	private static float getStationSurplusCargoSpace(SectorEntityToken station) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return 0f;
		float total = 0f;
		for (String commodityId : getResourceCommodityIdsInStorage(storage)) {
			float surplusUnits = getSurplusQuantity(storage, commodityId);
			if (surplusUnits <= 0f) continue;
			total += surplusUnits * getCargoSpacePerUnit(commodityId);
		}
		return total;
	}

	private static void loadTradeFleetCargo(SectorEntityToken station, CampaignFleetAPI fleet, float capacity) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		CargoAPI hold = getTradeFleetHold(station);

		float loaded = 0f;
		for (String commodityId : getResourceCommodityIdsInStorage(storage)) {
			if (loaded >= capacity) break;

			float surplusUnits = getSurplusQuantity(storage, commodityId);
			if (surplusUnits <= 0f) continue;

			float spacePerUnit = getCargoSpacePerUnit(commodityId);
			float unitsToMove = surplusUnits;
			if (spacePerUnit > 0f) {
				float maxUnitsBySpace = (capacity - loaded) / spacePerUnit;
				unitsToMove = Math.min(unitsToMove, maxUnitsBySpace);
			}
			if (unitsToMove <= 0f) continue;

			storage.removeCommodity(commodityId, unitsToMove);
			hold.addCommodity(commodityId, unitsToMove);
			loaded += unitsToMove * spacePerUnit;
		}
	}

	// A system counts as fully friendly (safe to sell in) only if none of its markets belong to a
	// faction hostile to the player and none show pirate activity, and it isn't currently the target
	// of a raid launched by a faction hostile to the player.
	private static boolean isSystemSafeForTrade(StarSystemAPI system) {
		if (system == null) return false;
		FactionAPI playerFaction = Global.getSector().getPlayerFaction();

		for (MarketAPI market : Misc.getMarketsInLocation(system)) {
			if (market == null) continue;
			if (market.getFaction() != null && market.getFaction().isHostileTo(playerFaction)) return false;
			if (market.hasCondition(Conditions.PIRATE_ACTIVITY)) return false;
		}

		for (IntelInfoPlugin intel : Global.getSector().getIntelManager().getIntel(RaidIntel.class)) {
			if (!(intel instanceof RaidIntel)) continue;
			RaidIntel raid = (RaidIntel) intel;
			if (raid.getSystem() != system) continue;
			if (raid.getFaction() != null && raid.getFaction().isHostileTo(playerFaction)) return false;
		}

		return true;
	}

	// Picks the market with the lowest combined on-hand stockpile of whatever the fleet is carrying
	// (in a system that's fully safe for the player, excluding the player's own markets) -- a market
	// that's short on those goods is treated as the best place to dump them.
	private static MarketAPI pickTradeFleetTargetMarket(SectorEntityToken station, Set<String> cargoCommodityIds) {
		FactionAPI playerFaction = Global.getSector().getPlayerFaction();
		MarketAPI best = null;
		float bestStockpile = Float.MAX_VALUE;
		


		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (market == null || market.isHidden() || market.isPlayerOwned()) continue;
			if (market.getPrimaryEntity() == null) continue;
			if (market.getFaction() != null && market.getFaction().isHostileTo(playerFaction)) continue;
			if (!isSystemSafeForTrade(market.getStarSystem())) continue;

			float combinedStockpile = 0f;
			if (cargoCommodityIds != null) {
				for (String commodityId : cargoCommodityIds) {
					CommodityOnMarketAPI data = market.getCommodityData(commodityId);
					if (data != null) combinedStockpile += data.getStockpile();
				}
			}

			if (combinedStockpile < bestStockpile) {
				bestStockpile = combinedStockpile;
				best = market;
			}

			}
return best;
	}

	// Deliberately inefficient -- only 30% of what the target market would actually pay for each
	// commodity, regardless of anything else -- a way to turn surplus into some income without
	// making self-trading a better deal than just using the goods yourself. The fleet's own
	// operating supplies are never sold.
	private static float sellTradeFleetCargo(CargoAPI cargo, MarketAPI market) {
		if (cargo == null) return 0f;

		float proceeds = 0f;
		for (CargoStackAPI stack : new ArrayList<CargoStackAPI>(cargo.getStacksCopy())) {
			if (stack == null || stack.isNull() || !stack.isResourceStack()) continue;
			String commodityId = stack.getCommodityId();
			if (!isTradeableResource(commodityId)) continue;
			float quantity = stack.getSize();
			if (quantity <= 0f) continue;

			float value;
			if (market != null) {
				value = market.getDemandPrice(commodityId, quantity, true);
			} else {
				value = stack.getBaseValuePerUnit() * quantity;
			}
			proceeds += value;
			cargo.removeCommodity(commodityId, quantity);
		}

		return proceeds * TRADE_FLEET_SALE_VALUE_FRACTION;
	}

	public static void launchTradeFleetIfDue(SectorEntityToken station) {
		if (!isBuilt(station) || !hasFleetHQBuilt(station)) return;
		if (!hasTradeFleetBuilt(station) || isTradeFleetDestroyed(station) || isTradeFleetTouring(station)) return;

		List<FleetMemberAPI> ships = getTradeFleetCommittedShips(station);
		if (ships == null || ships.isEmpty()) return;

		outfitFleetShips(station, ships, false);
		maintainFleetCR(ships);

		float capacity = getTradeFleetTradeCapacity(ships);
		float surplusSpace = getStationSurplusCargoSpace(station);
		if (capacity <= 0f || surplusSpace < capacity) {
			int mothballed = 0;
			for (FleetMemberAPI m : ships) if (m != null && m.isMothballed()) mothballed++;
			Global.getLogger(MilitaryWardModule.class).info("Player HQ Trade Fleet not launching: capacity=" + capacity
					+ " surplusSpace=" + surplusSpace + " ships=" + ships.size() + " mothballed=" + mothballed);
			return;
		}

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return;

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER, "Trade Fleet", false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, TRADE_FLEET_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		injectTradeFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);
		fleet.setCircularOrbitPointingDown(station, (float) (Math.random() * 360f),
				station.getRadius() + 250f, TRADE_FLEET_LOADING_DAYS * 8f);

		station.getMemoryWithoutUpdate().set(TRADE_FLEET_HOLD_MEMORY_KEY, Global.getFactory().createCargo(true));
		loadTradeFleetCargo(station, fleet, capacity);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(TRADE_FLEET_FLEET_MEMORY_KEY, fleet);
		mem.set(TRADE_FLEET_TOURING_MEMORY_KEY, true);
		mem.set(TRADE_FLEET_STATE_MEMORY_KEY, TRADE_FLEET_STATE_LOADING);
		mem.set(TRADE_FLEET_LOADING_DAY_MEMORY_KEY, 0);
	}

	public static final String TRADER_EARNED_LOG_MEMORY_KEY = "$playerhq_module_militaryward_trader_earned_log";
	public static final String TRADER_BOUGHT_LOG_MEMORY_KEY = "$playerhq_module_militaryward_trader_bought_log";

	private static void logTraderEarned(SectorEntityToken station, float amount) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		float prev = mem.contains(TRADER_EARNED_LOG_MEMORY_KEY) ? mem.getFloat(TRADER_EARNED_LOG_MEMORY_KEY) : 0f;
		mem.set(TRADER_EARNED_LOG_MEMORY_KEY, prev + amount);
	}

	@SuppressWarnings("unchecked")
	private static void logTraderBought(SectorEntityToken station, playerhq.shopping.ShoppingListEngine.Result result) {
		if (result == null || result.bought.isEmpty()) return;
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		Object o = mem.get(TRADER_BOUGHT_LOG_MEMORY_KEY);
		Map<String, Integer> totals = (o instanceof Map) ? (Map<String, Integer>) o : new java.util.LinkedHashMap<String, Integer>();
		for (Map.Entry<String, Integer> e : result.bought.entrySet()) {
			Integer prev = totals.get(e.getKey());
			totals.put(e.getKey(), (prev == null ? 0 : prev) + e.getValue());
		}
		mem.set(TRADER_BOUGHT_LOG_MEMORY_KEY, totals);
	}

	public static float getTraderEarnedThisMonth(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		return mem.contains(TRADER_EARNED_LOG_MEMORY_KEY) ? mem.getFloat(TRADER_EARNED_LOG_MEMORY_KEY) : 0f;
	}

	@SuppressWarnings("unchecked")
	public static List<String> getTraderBoughtThisMonth(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(TRADER_BOUGHT_LOG_MEMORY_KEY);
		List<String> result = new ArrayList<String>();
		if (o instanceof Map) {
			for (Map.Entry<String, Integer> e : ((Map<String, Integer>) o).entrySet()) {
				result.add(e.getValue() + "x " + e.getKey());
			}
		}
		return result;
	}

	public static void clearTraderLogThisMonth(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(TRADER_EARNED_LOG_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(TRADER_BOUGHT_LOG_MEMORY_KEY);
	}

	public static void advanceTradeFleetRealtime(SectorEntityToken station) {
		if (!isTradeFleetTouring(station)) return;
		String state = getTradeFleetState(station);
		if (state == null) return;

		CampaignFleetAPI fleet = getTradeTouringFleet(station);
		if (fleet == null || !fleet.isAlive()) return;

		if (TRADE_FLEET_STATE_OUTBOUND.equals(state)) {
			MarketAPI target = getTradeFleetTargetMarket(station);
			SectorEntityToken targetEntity = target != null ? target.getPrimaryEntity() : null;
			if (targetEntity == null || fleet.getContainingLocation() != targetEntity.getContainingLocation()) return;
			if (Misc.getDistance(fleet, targetEntity) <= TRADE_FLEET_ARRIVAL_RANGE) {
				float proceeds = sellTradeFleetCargo(getTradeFleetHold(station), target);
				if (proceeds > 0f) {
					Global.getSector().getPlayerFleet().getCargo().getCredits().add(proceeds);
					station.getMemoryWithoutUpdate().set(TRADE_FLEET_LAST_PROCEEDS_MEMORY_KEY, proceeds);
					logTraderEarned(station, proceeds);
				}
				playerhq.shopping.ShoppingListEngine.Result bought = playerhq.shopping.ShoppingListEngine.autoBuyAtMarket(
						station, getTradeFleetHold(station), target, getFleetBaseCargoCapacity(fleet));
				logTraderBought(station, bought);
				fleet.clearAssignments();
				fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, TRADE_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
						"Returning to the station");
				station.getMemoryWithoutUpdate().set(TRADE_FLEET_STATE_MEMORY_KEY, TRADE_FLEET_STATE_RETURNING);
			}
			return;
		}

		if (TRADE_FLEET_STATE_RETURNING.equals(state)) {
			if (fleet.getContainingLocation() != station.getContainingLocation()) return;
			if (Misc.getDistance(fleet, station) > TRADE_FLEET_ARRIVAL_RANGE) return;
			despawnTradeFleet(station);
		}
	}

	public static void advanceTradeFleetDaily(SectorEntityToken station) {
		if (isTradeFleetDestroyed(station)) {
			advanceLogisticFleetRespawn(station,
					TRADE_FLEET_SHIPS_MEMORY_KEY, TRADE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY,
					TRADE_FLEET_DESTROYED_MEMORY_KEY, TRADE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY,
					TRADE_FLEET_DESTROYED_CAUSE_MEMORY_KEY);
			return;
		}
		if (!isTradeFleetTouring(station)) return;

		CampaignFleetAPI fleet = getTradeTouringFleet(station);
		if (fleet == null || !fleet.isAlive()) {
			markLogisticFleetDestroyed(station, "Trade Fleet", getTradeFleetCommittedShips(station), "unknown causes",
					TRADE_FLEET_SHIPS_MEMORY_KEY, TRADE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY,
					TRADE_FLEET_DESTROYED_MEMORY_KEY, TRADE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY,
					TRADE_FLEET_DESTROYED_CAUSE_MEMORY_KEY);
			clearTradeFleetTouringState(station);
			return;
		}
		topOffFleetSuppliesIfLow(fleet);

		String state = getTradeFleetState(station);
		if (!TRADE_FLEET_STATE_LOADING.equals(state)) return;

		int loadingDay = station.getMemoryWithoutUpdate().getInt(TRADE_FLEET_LOADING_DAY_MEMORY_KEY) + 1;
		station.getMemoryWithoutUpdate().set(TRADE_FLEET_LOADING_DAY_MEMORY_KEY, loadingDay);
		if (loadingDay < TRADE_FLEET_LOADING_DAYS) return;

		Set<String> cargoCommodityIds = new HashSet<String>();
		for (CargoStackAPI stack : getTradeFleetHold(station).getStacksCopy()) {
			if (stack == null || stack.isNull() || !stack.isResourceStack()) continue;
			if (stack.getCommodityId() != null) cargoCommodityIds.add(stack.getCommodityId());
		}

		MarketAPI target = pickTradeFleetTargetMarket(station, cargoCommodityIds);
		if (target == null || target.getPrimaryEntity() == null) {
			// Nowhere safe to sell right now -- stay put and check again tomorrow.
			return;
		}

		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, target.getPrimaryEntity(), TRADE_FLEET_ASSIGNMENT_DURATION_CAP_DAYS,
				"Traveling to " + target.getPrimaryEntity().getName());
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(TRADE_FLEET_TARGET_MEMORY_KEY, target);
		mem.set(TRADE_FLEET_STATE_MEMORY_KEY, TRADE_FLEET_STATE_OUTBOUND);
	}

	private static void despawnTradeFleet(SectorEntityToken station) {
		CampaignFleetAPI fleet = getTradeTouringFleet(station);
		if (fleet != null) {
			CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
			if (storage != null) depositHoldCapped(storage, getTradeFleetHold(station));
			List<FleetMemberAPI> ships = getTradeFleetCommittedShips(station);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearTradeFleetTouringState(station);
	}

	private static void clearTradeFleetTouringState(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(TRADE_FLEET_TOURING_MEMORY_KEY);
		mem.unset(TRADE_FLEET_FLEET_MEMORY_KEY);
		mem.unset(TRADE_FLEET_STATE_MEMORY_KEY);
		mem.unset(TRADE_FLEET_TARGET_MEMORY_KEY);
		mem.unset(TRADE_FLEET_LOADING_DAY_MEMORY_KEY);
		mem.unset(TRADE_FLEET_HOLD_MEMORY_KEY);
	}

	public static final int MAX_PATROL_FLEET_BAYS = 4;

	public static final int PATROL_FLEET_CAPITALS_REQUIRED = 1;
	public static final int PATROL_FLEET_CRUISERS_REQUIRED = 4;
	public static final int PATROL_FLEET_BOTTOM_TIER_HALF_POINTS_REQUIRED = 10;
	public static final int PATROL_FLEET_DESTROYER_HALF_POINTS = 2;
	public static final int PATROL_FLEET_FRIGATE_HALF_POINTS = 1;

	public static final int PATROL_FLEET_FRIGATE_REBUILD_DAYS = 3;
	public static final int PATROL_FLEET_DESTROYER_REBUILD_DAYS = 6;
	public static final int PATROL_FLEET_CRUISER_REBUILD_DAYS = 10;
	public static final int PATROL_FLEET_CAPITAL_REBUILD_DAYS = 16;

	public static final int PATROL_FLEET_WIPED_REBUILD_DAYS = 30;

	private static final float PATROL_FLEET_ORBIT_DURATION_DAYS = 6f;
	private static final float PATROL_FLEET_ORBIT_ASSIGNMENT_DURATION_CAP_DAYS = 999f;
	public static final int PATROL_FLEET_PERIODIC_RETURN_INTERVAL_DAYS = 90;
	public static final int PATROL_FLEET_PERIODIC_RETURN_COOLDOWN_DAYS = 30;

	public static final String PATROL_FLEET_LOADOUT_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_loadout";
	public static final String PATROL_FLEET_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_crewcost";
	public static final String PATROL_FLEET_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_fleet";
	public static final String PATROL_FLEET_DEPLOYED_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_deployed";
	public static final String PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_cooldowndaysleft";
	public static final String PATROL_FLEET_WIPED_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_wiped";
	public static final String PATROL_FLEET_LIMPING_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_limping";
	public static final String PATROL_FLEET_PERIODIC_RETURN_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_periodicreturn";
	public static final String PATROL_FLEET_ORBIT_TARGET_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_orbittarget";
	public static final String PATROL_FLEET_ORBIT_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_orbitdaysleft";
	public static final String PATROL_FLEET_DAYS_UNTIL_PERIODIC_RETURN_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_daysuntilperiodicreturn";

	private static final int PATROL_FLEET_OFFICER_LEVEL = 17;
	private static final String[] PATROL_FLEET_OFFICER_ELITE_SKILLS = {
			Skills.HELMSMANSHIP,
			Skills.TARGET_ANALYSIS,
			Skills.COMBAT_ENDURANCE,
			Skills.POINT_DEFENSE,
			Skills.IMPACT_MITIGATION,
			Skills.BALLISTIC_MASTERY,
			Skills.FIELD_MODULATION,
			Skills.DAMAGE_CONTROL,
			Skills.SYSTEMS_EXPERTISE,
			Skills.MISSILE_SPECIALIZATION,
			Skills.GUNNERY_IMPLANTS,
			Skills.ENERGY_WEAPON_MASTERY,
			Skills.ELECTRONIC_WARFARE,
			Skills.FLUX_REGULATION,
			Skills.FIELD_REPAIRS,
			Skills.ORDNANCE_EXPERTISE,
			Skills.POLARIZED_ARMOR,
	};

	private static boolean isWarshipOrCarrier(FleetMemberAPI m) {
		if (isAutomatedShipBlocked(m)) return false;
		if (m.getHullSpec() == null) return false;
		ShipHullSpecAPI spec = m.getHullSpec();
		if (spec.isCarrier()) return true;
		if (spec.isCivilianNonCarrier()) return false;
		if (spec.isPhase() || spec.getHints().contains(ShipHullSpecAPI.ShipTypeHints.PHASE)) return false;
		return !m.isStation();
	}

	public static List<FleetMemberAPI> getPatrolFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		List<FleetMemberAPI> result = new ArrayList<FleetMemberAPI>();
		if (playerFleet.getFleetData() != null) {
			for (FleetMemberAPI m : playerFleet.getFleetData().getMembersListCopy()) {
				if (m.isFlagship()) continue;
				if (isWarshipOrCarrier(m)) result.add(m);
			}
		}
		addPatrolCandidatesFrom(playerFleet.getCargo(), playerFleet.getFaction().getId(), result);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) addPatrolCandidatesFrom(storage, playerFleet.getFaction().getId(), result);
		return result;
	}

	private static void addPatrolCandidatesFrom(CargoAPI cargo, String factionId, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : mothballed.getMembersListCopy()) {
			if (isWarshipOrCarrier(m)) out.add(m);
		}
	}

	public static boolean isValidPatrolFleetComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null || chosen.isEmpty()) return false;
		int capitals = 0, cruisers = 0, bottomHalfPoints = 0;
		for (FleetMemberAPI m : chosen) {
			if (m.getHullSpec() == null) return false;
			HullSize size = m.getHullSpec().getHullSize();
			if (size == HullSize.CAPITAL_SHIP) capitals++;
			else if (size == HullSize.CRUISER) cruisers++;
			else if (size == HullSize.DESTROYER) bottomHalfPoints += PATROL_FLEET_DESTROYER_HALF_POINTS;
			else if (size == HullSize.FRIGATE) bottomHalfPoints += PATROL_FLEET_FRIGATE_HALF_POINTS;
			else return false;
		}
		return capitals == PATROL_FLEET_CAPITALS_REQUIRED && cruisers == PATROL_FLEET_CRUISERS_REQUIRED
				&& bottomHalfPoints == PATROL_FLEET_BOTTOM_TIER_HALF_POINTS_REQUIRED;
	}

	@SuppressWarnings("unchecked")
	private static List<ShipVariantAPI> getPatrolFleetLoadout(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(PATROL_FLEET_LOADOUT_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<ShipVariantAPI>) o : null;
	}

	public static boolean isPatrolFleetBayBuilt(SectorEntityToken station, int bayIndex) {
		return getPatrolFleetLoadout(station, bayIndex) != null;
	}

	public static int getPatrolFleetBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_PATROL_FLEET_BAYS; i++) {
			if (isPatrolFleetBayBuilt(station, i)) count++;
		}
		return count;
	}

	public static boolean canBuildAnotherPatrolFleetBay(SectorEntityToken station) {
		return hasFleetHQBuilt(station) && getPatrolFleetBayCount(station) < MAX_PATROL_FLEET_BAYS;
	}

	public static int getPatrolFleetSize(SectorEntityToken station, int bayIndex) {
		List<ShipVariantAPI> loadout = getPatrolFleetLoadout(station, bayIndex);
		return loadout != null ? loadout.size() : 0;
	}

	private static FleetMemberAPI buildFreshPatrolShip(ShipVariantAPI variant) {
		FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, variant.clone());
		if (variant.hasHullMod(HullMods.AUTOMATED)) {
			member.setCaptain(createPatrolAlphaCoreOfficer());
		} else {
			member.setCaptain(createPatrolFleetOfficer());
		}
		return member;
	}

	private static FleetMemberAPI buildReturnedPatrolShip(ShipVariantAPI variant) {
		if (variant.hasHullMod(HullMods.AUTOMATED)) {
			return Global.getFactory().createFleetMember(FleetMemberType.SHIP, variant.clone());
		}
		return buildFreshPatrolShip(variant);
	}

	private static PersonAPI createPatrolAlphaCoreOfficer() {
		return Misc.getAICoreOfficerPlugin(Commodities.ALPHA_CORE).createPerson(Commodities.ALPHA_CORE,
				Factions.PLAYER, new java.util.Random());
	}

	private static PersonAPI createPatrolFleetOfficer() {
		PersonAPI officer = Global.getSector().getFaction(Factions.PLAYER).createRandomPerson();
		MutableCharacterStatsAPI stats = officer.getStats();
		stats.setSkipRefresh(true);

		stats.setLevel(PATROL_FLEET_OFFICER_LEVEL);
		for (String skillId : PATROL_FLEET_OFFICER_ELITE_SKILLS) {
			stats.setSkillLevel(skillId, 2f);
		}

		stats.setSkipRefresh(false);
		stats.refreshCharacterStatsEffects();

		officer.setPersonality(Personalities.STEADY);
		officer.setRankId(Ranks.SPACE_COMMANDER);
		officer.setPostId(Ranks.POST_OFFICER);
		return officer;
	}

	public static void buildPatrolFleetWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex, List<FleetMemberAPI> chosen) {
		if (bayIndex < 0 || bayIndex >= MAX_PATROL_FLEET_BAYS) return;
		if (!hasFleetHQBuilt(station) || isPatrolFleetBayBuilt(station, bayIndex)) return;
		if (!isValidPatrolFleetComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);

		List<ShipVariantAPI> loadout = new ArrayList<ShipVariantAPI>();
		for (FleetMemberAPI m : chosen) {
			ShipVariantAPI variant = m.getVariant() != null ? m.getVariant().clone() : null;
			if (variant == null) continue;
			loadout.add(variant);
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		if (loadout.isEmpty()) return;

		int crewFromStation = Math.min(PlayerHQUtils.getStationCrew(station), crewNeeded);
		PlayerHQUtils.removeStationCrew(station, crewFromStation);
		int crewRemaining = crewNeeded - crewFromStation;
		if (crewRemaining > 0 && playerFleet.getCargo() != null) {
			CargoAPI fleetCargo = playerFleet.getCargo();
			fleetCargo.removeCrew(Math.min(fleetCargo.getCrew(), crewRemaining));
		}
		station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_LOADOUT_MEMORY_KEY, bayIndex), loadout);
		station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_CREW_COST_MEMORY_KEY, bayIndex), crewNeeded);
		deployPatrolFleet(station, bayIndex);
	}

	public static boolean isPatrolFleetDeployed(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(PATROL_FLEET_DEPLOYED_MEMORY_KEY, bayIndex));
	}

	public static boolean isPatrolFleetWiped(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(PATROL_FLEET_WIPED_MEMORY_KEY, bayIndex));
	}

	public static int getPatrolFleetCooldownDaysLeft(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getInt(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex));
	}

	private static CampaignFleetAPI getPatrolFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(PATROL_FLEET_FLEET_MEMORY_KEY, bayIndex));
	}

	public static String getPatrolFleetBayStatusText(SectorEntityToken station, int bayIndex) {
		if (!isPatrolFleetBayBuilt(station, bayIndex)) return null;
		if (isPatrolFleetDeployed(station, bayIndex)) {
			return "patrolling the system";
		}
		int daysLeft = Math.max(getPatrolFleetCooldownDaysLeft(station, bayIndex), 0);
		if (isPatrolFleetWiped(station, bayIndex)) {
			return "wiped out in battle -- rebuilding, redeploys in " + daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		if (station.getMemoryWithoutUpdate().getBoolean(bayKey(PATROL_FLEET_PERIODIC_RETURN_MEMORY_KEY, bayIndex))) {
			return "back at the station for scheduled maintenance, redeploys in " + daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		return "recovering at the station, redeploys in " + daysLeft + " day" + (daysLeft == 1 ? "" : "s");
	}

	private static int computeRebuildDaysForLosses(List<ShipVariantAPI> loadout, List<FleetMemberAPI> survivors) {
		int frigates = 0, destroyers = 0, cruisers = 0, capitals = 0;
		for (ShipVariantAPI variant : loadout) {
			if (variant.getHullSpec() == null) continue;
			HullSize size = variant.getHullSpec().getHullSize();
			if (size == HullSize.FRIGATE) frigates++;
			else if (size == HullSize.DESTROYER) destroyers++;
			else if (size == HullSize.CRUISER) cruisers++;
			else if (size == HullSize.CAPITAL_SHIP) capitals++;
		}
		for (FleetMemberAPI m : survivors) {
			if (m.getHullSpec() == null) continue;
			HullSize size = m.getHullSpec().getHullSize();
			if (size == HullSize.FRIGATE && frigates > 0) frigates--;
			else if (size == HullSize.DESTROYER && destroyers > 0) destroyers--;
			else if (size == HullSize.CRUISER && cruisers > 0) cruisers--;
			else if (size == HullSize.CAPITAL_SHIP && capitals > 0) capitals--;
		}
		return frigates * PATROL_FLEET_FRIGATE_REBUILD_DAYS
				+ destroyers * PATROL_FLEET_DESTROYER_REBUILD_DAYS
				+ cruisers * PATROL_FLEET_CRUISER_REBUILD_DAYS
				+ capitals * PATROL_FLEET_CAPITAL_REBUILD_DAYS;
	}

	private static List<SectorEntityToken> getPatrolFleetOrbitCandidates(SectorEntityToken station) {
		List<SectorEntityToken> targets = new ArrayList<SectorEntityToken>();
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return targets;

		FactionAPI playerFaction = Global.getSector().getFaction(Factions.PLAYER);

		for (Object object : system.getEntities(SectorEntityToken.class)) {
			SectorEntityToken entity = (SectorEntityToken) object;
			if (entity == station) continue;
			MarketAPI market = entity.getMarket();
			if (market == null) continue;
			if (market.getFaction() != null && playerFaction.isHostileTo(market.getFaction())) continue;
			targets.add(entity);
		}
		for (Object object : system.getEntities(JumpPointAPI.class)) {
			JumpPointAPI jumpPoint = (JumpPointAPI) object;
			if (jumpPoint != station) targets.add(jumpPoint);
		}
		return targets;
	}

	private static final float PATROL_FLEET_COMBAT_RESPONSE_RANGE = 4000f;

	public static final String PATROL_FLEET_COMBAT_TARGET_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_combattarget";
	public static final String PATROL_FLEET_THREAT_QUEUE_MEMORY_KEY = "$playerhq_module_militaryward_patrolfleet_threatqueue";

	// Event-driven (not polled): PlayerHQFleetLossListener calls these two off the vanilla
	// reportBattleOccurred/reportBattleFinished campaign event hooks, so Patrol Fleets only
	// react to a friendly colony under attack when a battle actually starts or ends anywhere
	// in the sector, instead of the station having to check on a timer.

	public static void handlePatrolThreatBattleOccurred(SectorEntityToken station) {
		if (getPatrolFleetBayCount(station) == 0) return;

		List<SectorEntityToken> underAttack = getFriendlyColoniesUnderAttack(station);
		if (underAttack.isEmpty()) return;

		if (addNewlyThreatenedColonies(station, underAttack)) {
			redirectAllPatrolBaysToThreatQueue(station);
		}
	}

	public static void handlePatrolThreatBattleFinished(SectorEntityToken station) {
		if (getPatrolFleetBayCount(station) == 0) return;

		List<SectorEntityToken> stillUnderAttack = getFriendlyColoniesUnderAttack(station);
		if (pruneClearedColoniesFromThreatQueue(station, stillUnderAttack)) {
			redirectAllPatrolBaysToThreatQueue(station);
		}
	}

	private static List<SectorEntityToken> getFriendlyColoniesUnderAttack(SectorEntityToken station) {
		List<SectorEntityToken> result = new ArrayList<SectorEntityToken>();
		StarSystemAPI system = station.getStarSystem();
		if (system == null) return result;

		FactionAPI playerFaction = Global.getSector().getFaction(Factions.PLAYER);

		List<SectorEntityToken> friendlyColonies = new ArrayList<SectorEntityToken>();
		for (Object object : system.getEntities(SectorEntityToken.class)) {
			SectorEntityToken entity = (SectorEntityToken) object;
			if (entity == station) continue;
			MarketAPI market = entity.getMarket();
			if (market == null || market.getFaction() == null) continue;
			if (playerFaction.isHostileTo(market.getFaction())) continue;
			friendlyColonies.add(entity);
		}
		if (friendlyColonies.isEmpty()) return result;

		for (CampaignFleetAPI fleet : system.getFleets()) {
			if (fleet == null || !fleet.isAlive() || fleet.getFaction() == null) continue;
			if (!playerFaction.isHostileTo(fleet.getFaction())) continue;
			if (fleet.getBattle() == null) continue;

			for (SectorEntityToken colony : friendlyColonies) {
				if (result.contains(colony)) continue;
				if (Misc.getDistance(fleet, colony) <= PATROL_FLEET_COMBAT_RESPONSE_RANGE) {
					result.add(colony);
				}
			}
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	private static List<SectorEntityToken> getPatrolThreatQueue(SectorEntityToken station) {
		Object o = station.getMemoryWithoutUpdate().get(PATROL_FLEET_THREAT_QUEUE_MEMORY_KEY);
		return (o instanceof List) ? (List<SectorEntityToken>) o : new ArrayList<SectorEntityToken>();
	}

	private static boolean addNewlyThreatenedColonies(SectorEntityToken station, List<SectorEntityToken> newlyDetected) {
		List<SectorEntityToken> queue = getPatrolThreatQueue(station);
		boolean changed = false;
		for (SectorEntityToken colony : newlyDetected) {
			if (!queue.contains(colony)) {
				queue.add(colony);
				changed = true;
			}
		}
		if (changed) station.getMemoryWithoutUpdate().set(PATROL_FLEET_THREAT_QUEUE_MEMORY_KEY, queue);
		return changed;
	}

	private static boolean pruneClearedColoniesFromThreatQueue(SectorEntityToken station, List<SectorEntityToken> stillUnderAttack) {
		List<SectorEntityToken> queue = getPatrolThreatQueue(station);
		if (queue.isEmpty()) return false;

		List<SectorEntityToken> updated = new ArrayList<SectorEntityToken>();
		boolean changed = false;
		for (SectorEntityToken colony : queue) {
			if (stillUnderAttack.contains(colony)) {
				updated.add(colony);
			} else {
				changed = true;
			}
		}
		if (changed) station.getMemoryWithoutUpdate().set(PATROL_FLEET_THREAT_QUEUE_MEMORY_KEY, updated);
		return changed;
	}

	private static void redirectAllPatrolBaysToThreatQueue(SectorEntityToken station) {
		List<SectorEntityToken> queue = getPatrolThreatQueue(station);
		SectorEntityToken head = queue.isEmpty() ? null : queue.get(0);

		for (int bayIndex = 0; bayIndex < MAX_PATROL_FLEET_BAYS; bayIndex++) {
			if (!isPatrolFleetDeployed(station, bayIndex)) continue;

			CampaignFleetAPI fleet = getPatrolFleet(station, bayIndex);
			if (fleet == null || !fleet.isAlive()) continue;
			if (isPatrolFleetLimping(station, bayIndex)) continue;

			MemoryAPI mem = station.getMemoryWithoutUpdate();
			Object o = mem.get(bayKey(PATROL_FLEET_COMBAT_TARGET_MEMORY_KEY, bayIndex));
			SectorEntityToken currentlyDefending = (o instanceof SectorEntityToken) ? (SectorEntityToken) o : null;

			if (head != null) {
				if (currentlyDefending != head) {
					fleet.clearAssignments();
					fleet.addAssignment(FleetAssignment.DEFEND_LOCATION, head,
							PATROL_FLEET_ORBIT_ASSIGNMENT_DURATION_CAP_DAYS, "Defending " + head.getName());
					mem.set(bayKey(PATROL_FLEET_COMBAT_TARGET_MEMORY_KEY, bayIndex), head);
				}
			} else if (currentlyDefending != null) {
				mem.unset(bayKey(PATROL_FLEET_COMBAT_TARGET_MEMORY_KEY, bayIndex));
				Object o2 = mem.get(bayKey(PATROL_FLEET_ORBIT_TARGET_MEMORY_KEY, bayIndex));
				SectorEntityToken currentOrbitTarget = (o2 instanceof SectorEntityToken) ? (SectorEntityToken) o2 : null;
				beginPatrolOrbit(station, bayIndex, fleet, currentOrbitTarget);
			}
		}
	}

	private static SectorEntityToken pickNextPatrolOrbitTarget(SectorEntityToken station, SectorEntityToken currentTarget) {
		List<SectorEntityToken> candidates = getPatrolFleetOrbitCandidates(station);
		if (candidates.isEmpty()) return station;

		WeightedRandomPicker<SectorEntityToken> picker = new WeightedRandomPicker<SectorEntityToken>();
		picker.addAll(candidates);
		if (candidates.size() > 1 && currentTarget != null) picker.remove(currentTarget);
		SectorEntityToken picked = picker.pick();
		return picked != null ? picked : station;
	}

	private static void beginPatrolOrbit(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, SectorEntityToken currentTarget) {
		SectorEntityToken target = pickNextPatrolOrbitTarget(station, currentTarget);

		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.ORBIT_AGGRESSIVE, target, PATROL_FLEET_ORBIT_ASSIGNMENT_DURATION_CAP_DAYS,
				"Patrolling near " + target.getName());

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(PATROL_FLEET_ORBIT_TARGET_MEMORY_KEY, bayIndex), target);
		mem.set(bayKey(PATROL_FLEET_ORBIT_DAYS_LEFT_MEMORY_KEY, bayIndex), (int) PATROL_FLEET_ORBIT_DURATION_DAYS);
	}

	private static void deployPatrolFleet(SectorEntityToken station, int bayIndex) {
		List<ShipVariantAPI> loadout = getPatrolFleetLoadout(station, bayIndex);
		if (loadout == null || loadout.isEmpty()) return;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return;

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Patrol Fleet " + (bayIndex + 1), false);
		FleetMemberAPI flagship = null;
		for (ShipVariantAPI variant : loadout) {
			FleetMemberAPI member = buildFreshPatrolShip(variant);
			fleet.getFleetData().addFleetMember(member);
			if (flagship == null || member.getHullSpec().getHullSize() == HullSize.CAPITAL_SHIP) flagship = member;
		}
		if (flagship != null) fleet.getFleetData().setFlagship(flagship);
		injectFleetLogistics(fleet, fleet.getFleetData().getMembersListCopy(), false);

		system.addEntity(fleet);
		refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(PATROL_FLEET_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(PATROL_FLEET_DEPLOYED_MEMORY_KEY, bayIndex), true);
		mem.unset(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_WIPED_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_PERIODIC_RETURN_MEMORY_KEY, bayIndex));
		mem.set(bayKey(PATROL_FLEET_DAYS_UNTIL_PERIODIC_RETURN_MEMORY_KEY, bayIndex), PATROL_FLEET_PERIODIC_RETURN_INTERVAL_DAYS);

		beginPatrolOrbit(station, bayIndex, fleet, null);
		redirectAllPatrolBaysToThreatQueue(station);
	}

	private static void clearPatrolFleetDeployment(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(PATROL_FLEET_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_DEPLOYED_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_ORBIT_TARGET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_ORBIT_DAYS_LEFT_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_DAYS_UNTIL_PERIODIC_RETURN_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_COMBAT_TARGET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_LIMPING_MEMORY_KEY, bayIndex));
	}

	private static boolean isPatrolFleetLimping(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(PATROL_FLEET_LIMPING_MEMORY_KEY, bayIndex));
	}

	private static void sendPatrolFleetToStation(SectorEntityToken station, CampaignFleetAPI fleet) {
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, PATROL_FLEET_ORBIT_ASSIGNMENT_DURATION_CAP_DAYS,
				"Limping back to " + station.getName());
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_FLEET_DO_NOT_GET_SIDETRACKED, true);
	}

	private static void beginPatrolLimp(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(PATROL_FLEET_LIMPING_MEMORY_KEY, bayIndex), true);
		mem.unset(bayKey(PATROL_FLEET_COMBAT_TARGET_MEMORY_KEY, bayIndex));
		sendPatrolFleetToStation(station, fleet);
		Global.getSector().getCampaignUI().addMessage("Patrol Fleet " + (bayIndex + 1)
				+ " took losses and is limping back to the station.", Misc.getNegativeHighlightColor());
	}

	private static void advancePatrolLimp(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		if (fleet.getBattle() != null) return;

		boolean arrived = fleet.getContainingLocation() == station.getContainingLocation()
				&& Misc.getDistance(fleet, station) <= COURIER_FLEET_ARRIVAL_RANGE + station.getRadius();
		if (!arrived) {
			if (fleet.getCurrentAssignment() == null) sendPatrolFleetToStation(station, fleet);
			return;
		}

		List<ShipVariantAPI> loadout = getPatrolFleetLoadout(station, bayIndex);
		List<FleetMemberAPI> survivors = fleet.getFleetData().getMembersListCopy();
		int recoveryDays = Math.max(1, loadout != null ? computeRebuildDaysForLosses(loadout, survivors) : 1);
		int lost = loadout != null ? Math.max(0, loadout.size() - survivors.size()) : 0;

		fleet.despawn();
		clearPatrolFleetDeployment(station, bayIndex);
		station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex), recoveryDays);
		Global.getSector().getCampaignUI().addMessage("Patrol Fleet " + (bayIndex + 1) + " made it back to the station with "
				+ survivors.size() + " ship" + (survivors.size() == 1 ? "" : "s") + " (" + lost + " lost). It redeploys in "
				+ recoveryDays + " day" + (recoveryDays == 1 ? "" : "s") + ".");
	}

	public static void advancePatrolFleetDaily(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_PATROL_FLEET_BAYS; bayIndex++) {
			advancePatrolFleetBayDaily(station, bayIndex);
		}
	}

	private static void advancePatrolFleetBayDaily(SectorEntityToken station, int bayIndex) {
		if (!isPatrolFleetBayBuilt(station, bayIndex)) return;

		if (isPatrolFleetDeployed(station, bayIndex)) {
			CampaignFleetAPI fleet = getPatrolFleet(station, bayIndex);
			List<ShipVariantAPI> loadout = getPatrolFleetLoadout(station, bayIndex);
			int fullSize = loadout != null ? loadout.size() : 0;

			if (fleet == null || !fleet.isAlive() || fleet.getFleetData() == null
					|| fleet.getFleetData().getMembersListCopy().isEmpty()) {
				if (fleet != null && fleet.isAlive()) fleet.despawn();
				clearPatrolFleetDeployment(station, bayIndex);
				station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_WIPED_MEMORY_KEY, bayIndex), true);
				int wipedRebuildDays = loadout != null
						? computeRebuildDaysForLosses(loadout, new ArrayList<FleetMemberAPI>())
						: PATROL_FLEET_WIPED_REBUILD_DAYS;
				station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex), wipedRebuildDays);
				return;
			}

			if (isPatrolFleetLimping(station, bayIndex)) {
				advancePatrolLimp(station, bayIndex, fleet);
				return;
			}

			List<FleetMemberAPI> survivors = fleet.getFleetData().getMembersListCopy();
			topOffFleetSuppliesIfLow(fleet);
			int currentSize = survivors.size();
			if (currentSize < fullSize) {
				if (fleet.getBattle() != null) return;
				beginPatrolLimp(station, bayIndex, fleet);
				return;
			}

			MemoryAPI mem = station.getMemoryWithoutUpdate();
			if (mem.get(bayKey(PATROL_FLEET_COMBAT_TARGET_MEMORY_KEY, bayIndex)) instanceof SectorEntityToken) {
				// Currently rallied to defend a friendly colony under attack -- hold off on the
				// orbit rotation and scheduled-maintenance clocks until the threat clears.
				return;
			}

			int periodicDaysLeft = mem.getInt(bayKey(PATROL_FLEET_DAYS_UNTIL_PERIODIC_RETURN_MEMORY_KEY, bayIndex)) - 1;
			if (periodicDaysLeft <= 0) {
				fleet.despawn();
				clearPatrolFleetDeployment(station, bayIndex);
				mem.set(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex), PATROL_FLEET_PERIODIC_RETURN_COOLDOWN_DAYS);
				mem.set(bayKey(PATROL_FLEET_PERIODIC_RETURN_MEMORY_KEY, bayIndex), true);
				return;
			}
			mem.set(bayKey(PATROL_FLEET_DAYS_UNTIL_PERIODIC_RETURN_MEMORY_KEY, bayIndex), periodicDaysLeft);

			int orbitDaysLeft = mem.getInt(bayKey(PATROL_FLEET_ORBIT_DAYS_LEFT_MEMORY_KEY, bayIndex)) - 1;
			if (orbitDaysLeft <= 0) {
				Object o = mem.get(bayKey(PATROL_FLEET_ORBIT_TARGET_MEMORY_KEY, bayIndex));
				SectorEntityToken currentTarget = (o instanceof SectorEntityToken) ? (SectorEntityToken) o : null;
				beginPatrolOrbit(station, bayIndex, fleet, currentTarget);
			} else {
				mem.set(bayKey(PATROL_FLEET_ORBIT_DAYS_LEFT_MEMORY_KEY, bayIndex), orbitDaysLeft);
			}
			return;
		}

		int daysLeft = getPatrolFleetCooldownDaysLeft(station, bayIndex) - 1;
		if (daysLeft <= 0) {
			deployPatrolFleet(station, bayIndex);
		} else {
			station.getMemoryWithoutUpdate().set(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex), daysLeft);
		}
	}

	private static void clearPatrolFleetMemory(SectorEntityToken station, int bayIndex) {
		clearPatrolFleetDeployment(station, bayIndex);
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(PATROL_FLEET_LOADOUT_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_CREW_COST_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_COOLDOWN_DAYS_LEFT_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_WIPED_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(PATROL_FLEET_PERIODIC_RETURN_MEMORY_KEY, bayIndex));
	}

	private static void disbandPatrolFleetBayInto(SectorEntityToken station, int bayIndex, CargoAPI destination, String factionId) {
		if (!isPatrolFleetBayBuilt(station, bayIndex)) return;

		List<ShipVariantAPI> loadout = getPatrolFleetLoadout(station, bayIndex);

		CampaignFleetAPI fleet = getPatrolFleet(station, bayIndex);
		if (fleet != null) fleet.despawn();

		if (destination != null && loadout != null) {
			destination.initMothballedShips(factionId);
			FleetDataAPI mothballed = destination.getMothballedShips();
			if (mothballed != null) {
				for (ShipVariantAPI variant : loadout) {
					mothballed.addFleetMember(buildReturnedPatrolShip(variant));
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(PATROL_FLEET_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) {
				destination.addCrew(crewCost);
			}
		}

		clearPatrolFleetMemory(station, bayIndex);
	}

	private static void disbandAllPatrolFleetBaysInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		for (int bayIndex = 0; bayIndex < MAX_PATROL_FLEET_BAYS; bayIndex++) {
			disbandPatrolFleetBayInto(station, bayIndex, destination, factionId);
		}
		station.getMemoryWithoutUpdate().unset(PATROL_FLEET_THREAT_QUEUE_MEMORY_KEY);
	}

	public static void uninstallPatrolFleetBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		if (bayIndex < 0 || bayIndex >= MAX_PATROL_FLEET_BAYS) return;
		disbandPatrolFleetBayInto(station, bayIndex, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
	}

	public static boolean canDisbandFleetHQ(SectorEntityToken station) {
		return hasFleetHQBuilt(station)
				&& getTrainingExpeditionBayCount(station) == 0
				&& !hasResupplyBayBuilt(station)
				&& getCourierBayCount(station) == 0
				&& !hasTradeFleetBuilt(station)
				&& getPatrolFleetBayCount(station) == 0
				&& getMiningFleetBayCount(station) == 0
				&& getSalvageFleetBayCount(station) == 0;
	}

	public static void handleLogisticFleetLostInBattle(SectorEntityToken station, CampaignFleetAPI fleet, String cause) {
		if (station == null || fleet == null) return;

		for (int bayIndex = 0; bayIndex < MAX_TRAINING_EXPEDITION_BAYS; bayIndex++) {
			if (fleet == getTouringFleet(station, bayIndex)) {
				markLogisticFleetDestroyed(station, "Expedition Fleet " + (bayIndex + 1), getCommittedShips(station, bayIndex), cause,
						bayKey(TRAINING_EXPEDITIONS_SHIPS_MEMORY_KEY, bayIndex), bayKey(TRAINING_EXPEDITIONS_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
						bayKey(TRAINING_EXPEDITIONS_DESTROYED_MEMORY_KEY, bayIndex), bayKey(TRAINING_EXPEDITIONS_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
						bayKey(TRAINING_EXPEDITIONS_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
				clearTouringState(station, bayIndex);
				return;
			}
		}

		for (int bayIndex = 0; bayIndex < MAX_MINING_FLEET_BAYS; bayIndex++) {
			if (fleet == getMiningTouringFleet(station, bayIndex)) {
				markLogisticFleetDestroyed(station, "Mining Fleet " + (bayIndex + 1), getMiningFleetCommittedShips(station, bayIndex), cause,
						bayKey(MINING_FLEET_SHIPS_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
						bayKey(MINING_FLEET_DESTROYED_MEMORY_KEY, bayIndex), bayKey(MINING_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
						bayKey(MINING_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
				clearMiningTouringState(station, bayIndex);
				return;
			}
		}

		for (int bayIndex = 0; bayIndex < MAX_SALVAGE_FLEET_BAYS; bayIndex++) {
			if (fleet == getSalvageTouringFleet(station, bayIndex)) {
				markLogisticFleetDestroyed(station, "Salvage Fleet " + (bayIndex + 1), getSalvageFleetCommittedShips(station, bayIndex), cause,
						bayKey(SALVAGE_FLEET_SHIPS_MEMORY_KEY, bayIndex), bayKey(SALVAGE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
						bayKey(SALVAGE_FLEET_DESTROYED_MEMORY_KEY, bayIndex), bayKey(SALVAGE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
						bayKey(SALVAGE_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
				clearSalvageTouringState(station, bayIndex);
				return;
			}
		}

		for (int bayIndex = 0; bayIndex < MAX_COURIER_BAYS; bayIndex++) {
			if (fleet == getCourierTouringFleet(station, bayIndex)) {
				markLogisticFleetDestroyed(station, "Courier Fleet " + (bayIndex + 1), getCourierBayCommittedShips(station, bayIndex), cause,
						bayKey(COURIER_BAY_SHIPS_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
						bayKey(COURIER_BAY_DESTROYED_MEMORY_KEY, bayIndex), bayKey(COURIER_BAY_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
						bayKey(COURIER_BAY_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
				clearCourierTouringState(station, bayIndex);
				return;
			}
		}

		if (fleet == getResupplyTouringFleet(station)) {
			handleResupplyFleetFoundDestroyed(station, cause);
			return;
		}

		if (fleet == getTradeTouringFleet(station)) {
			markLogisticFleetDestroyed(station, "Trade Fleet", getTradeFleetCommittedShips(station), cause,
					TRADE_FLEET_SHIPS_MEMORY_KEY, TRADE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY,
					TRADE_FLEET_DESTROYED_MEMORY_KEY, TRADE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY,
					TRADE_FLEET_DESTROYED_CAUSE_MEMORY_KEY);
			clearTradeFleetTouringState(station);
		}
	}

	public static final int MAX_SALVAGE_FLEET_BAYS = 2;
	public static final int SALVAGE_FLEET_TANKERS_REQUIRED = 2;
	public static final int SALVAGE_FLEET_FREIGHTERS_REQUIRED = 4;
	public static final int SALVAGE_FLEET_GANTRY_SHIPS_REQUIRED = 4;
	public static final int SALVAGE_FLEET_MAX_RECOVERED_SHIPS = 10;
	public static final int SALVAGE_FLEET_RELAUNCH_COOLDOWN_DAYS = 4;

	private static final int SALVAGE_WRECK_WORK_DAYS = 1;
	private static final int SALVAGE_DEBRIS_WORK_DAYS = 2;
	private static final float SALVAGE_CARGO_FULL_FRACTION = 0.97f;
	private static final float SALVAGE_MIN_DEBRIS_DENSITY_FRACTION = 0.2f;
	private static final float SALVAGE_ARRIVAL_RANGE = 300f;
	private static final float SALVAGE_ORBIT_DAYS = 60f;
	private static final float SALVAGE_ORBIT_RADIUS = 200f;
	private static final float SALVAGE_ASSIGNMENT_DURATION_CAP_DAYS = 999f;
	private static final String SALVAGE_GANTRY_HULLMOD_ID = "repair_gantry";
	private static final String SALVAGE_GANTRY_HULLMOD_NAME = "Salvage Gantry";

	private static final String SALVAGE_STATE_OUTBOUND = "outbound";
	private static final String SALVAGE_STATE_WORKING = "working";
	private static final String SALVAGE_STATE_RETURNING = "returning";

	public static final String SALVAGE_FLEET_SHIPS_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_ships";
	public static final String SALVAGE_FLEET_CREW_COST_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_crewcost";
	public static final String SALVAGE_FLEET_COOLDOWN_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_cooldown";
	public static final String SALVAGE_FLEET_TOURING_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_touring";
	public static final String SALVAGE_FLEET_FLEET_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_fleet";
	public static final String SALVAGE_FLEET_STATE_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_state";
	public static final String SALVAGE_FLEET_TARGET_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_target";
	public static final String SALVAGE_FLEET_WORK_DAYS_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_workdays";
	public static final String SALVAGE_FLEET_HAUL_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_haul";
	public static final String SALVAGE_FLEET_RECOVERED_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_recovered";
	public static final String SALVAGE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_respawnmanifest";
	public static final String SALVAGE_FLEET_DESTROYED_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_destroyed";
	public static final String SALVAGE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_respawndaysleft";
	public static final String SALVAGE_FLEET_DESTROYED_CAUSE_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_destroyedcause";
	private static final String SALVAGE_FLEET_HAUL_LOG_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_haullog";
	private static final String SALVAGE_FLEET_SHIPS_LOG_MEMORY_KEY = "$playerhq_module_militaryward_salvagefleet_shipslog";

	private enum SalvageRole { TANKER, FREIGHTER, GANTRY }

	private static boolean hasBuiltInSalvageGantry(FleetMemberAPI m) {
		if (m == null || m.getHullSpec() == null) return false;
		List<String> builtIn = m.getHullSpec().getBuiltInMods();
		if (builtIn == null) return false;
		for (String id : builtIn) {
			if (SALVAGE_GANTRY_HULLMOD_ID.equals(id)) return true;
			HullModSpecAPI spec = Global.getSettings().getHullModSpec(id);
			if (spec != null && SALVAGE_GANTRY_HULLMOD_NAME.equalsIgnoreCase(spec.getDisplayName())) return true;
		}
		return false;
	}

	private static SalvageRole classifySalvageShip(FleetMemberAPI m) {
		if (m == null || m.getHullSpec() == null) return null;
		if (isAutomatedShipBlocked(m)) return null;
		if (!isPristine(m)) return null;
		if (hasBuiltInSalvageGantry(m)) return SalvageRole.GANTRY;
		LogisticShipRole role = classifyLogisticShip(m, false);
		if (role == LogisticShipRole.TANKER) return SalvageRole.TANKER;
		if (role == LogisticShipRole.FREIGHTER) return SalvageRole.FREIGHTER;
		return null;
	}

	public static boolean isValidSalvageFleetComposition(List<FleetMemberAPI> chosen) {
		if (chosen == null) return false;
		int tankers = 0;
		int freighters = 0;
		int gantry = 0;
		for (FleetMemberAPI m : chosen) {
			SalvageRole role = classifySalvageShip(m);
			if (role == null) return false;
			if (role == SalvageRole.TANKER) tankers++;
			else if (role == SalvageRole.FREIGHTER) freighters++;
			else gantry++;
		}
		return tankers == SALVAGE_FLEET_TANKERS_REQUIRED && freighters == SALVAGE_FLEET_FREIGHTERS_REQUIRED
				&& gantry == SALVAGE_FLEET_GANTRY_SHIPS_REQUIRED;
	}

	public static List<FleetMemberAPI> getSalvageFleetCandidates(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		List<FleetMemberAPI> result = new ArrayList<FleetMemberAPI>();
		if (playerFleet.getFleetData() != null) {
			for (FleetMemberAPI m : playerFleet.getFleetData().getMembersListCopy()) {
				if (m.isFlagship()) continue;
				if (classifySalvageShip(m) != null) result.add(m);
			}
		}
		addSalvageCandidatesFrom(playerFleet.getCargo(), playerFleet.getFaction().getId(), result);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) addSalvageCandidatesFrom(storage, playerFleet.getFaction().getId(), result);
		return result;
	}

	private static void addSalvageCandidatesFrom(CargoAPI cargo, String factionId, List<FleetMemberAPI> out) {
		if (cargo == null) return;
		cargo.initMothballedShips(factionId);
		FleetDataAPI mothballed = cargo.getMothballedShips();
		if (mothballed == null) return;
		for (FleetMemberAPI m : mothballed.getMembersListCopy()) {
			if (classifySalvageShip(m) != null) out.add(m);
		}
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getSalvageFleetCommittedShips(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(SALVAGE_FLEET_SHIPS_MEMORY_KEY, bayIndex));
		return (o instanceof List) ? (List<FleetMemberAPI>) o : null;
	}

	public static boolean isSalvageFleetBayDestroyed(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(SALVAGE_FLEET_DESTROYED_MEMORY_KEY, bayIndex));
	}

	public static boolean isSalvageFleetBayBuilt(SectorEntityToken station, int bayIndex) {
		return getSalvageFleetCommittedShips(station, bayIndex) != null || isSalvageFleetBayDestroyed(station, bayIndex);
	}

	public static int getSalvageFleetBayCount(SectorEntityToken station) {
		int count = 0;
		for (int i = 0; i < MAX_SALVAGE_FLEET_BAYS; i++) {
			if (isSalvageFleetBayBuilt(station, i)) count++;
		}
		return count;
	}

	public static void buildSalvageFleetBayWithShips(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex, List<FleetMemberAPI> chosen) {
		if (!MiningHangarModule.isBuilt(station)) return;
		if (bayIndex < 0 || bayIndex >= MAX_SALVAGE_FLEET_BAYS || isSalvageFleetBayBuilt(station, bayIndex)) return;
		if (!isValidSalvageFleetComposition(chosen)) return;

		int crewNeeded = getRequiredCrewForShips(chosen);
		if (PlayerHQUtils.getStationCrew(station) < crewNeeded) return;

		for (FleetMemberAPI m : chosen) {
			removeShipFromWhereverItIs(station, playerFleet, m);
		}
		PlayerHQUtils.removeStationCrew(station, crewNeeded);
		station.getMemoryWithoutUpdate().set(bayKey(SALVAGE_FLEET_SHIPS_MEMORY_KEY, bayIndex), new ArrayList<FleetMemberAPI>(chosen));
		station.getMemoryWithoutUpdate().set(bayKey(SALVAGE_FLEET_CREW_COST_MEMORY_KEY, bayIndex), crewNeeded);
	}

	public static boolean isSalvageFleetBayTouring(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getBoolean(bayKey(SALVAGE_FLEET_TOURING_MEMORY_KEY, bayIndex));
	}

	private static CampaignFleetAPI getSalvageTouringFleet(SectorEntityToken station, int bayIndex) {
		return station.getMemoryWithoutUpdate().getFleet(bayKey(SALVAGE_FLEET_FLEET_MEMORY_KEY, bayIndex));
	}

	private static String getSalvageFleetState(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(SALVAGE_FLEET_STATE_MEMORY_KEY, bayIndex));
		return (o instanceof String) ? (String) o : null;
	}

	private static SectorEntityToken getSalvageFleetTarget(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(SALVAGE_FLEET_TARGET_MEMORY_KEY, bayIndex));
		return (o instanceof SectorEntityToken) ? (SectorEntityToken) o : null;
	}

	private static int getSalvageFleetCooldownDays(SectorEntityToken station, int bayIndex) {
		return Math.max(0, station.getMemoryWithoutUpdate().getInt(bayKey(SALVAGE_FLEET_COOLDOWN_MEMORY_KEY, bayIndex)));
	}

	private static CargoAPI getSalvageFleetHaul(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(SALVAGE_FLEET_HAUL_MEMORY_KEY, bayIndex));
		if (o instanceof CargoAPI) return (CargoAPI) o;
		CargoAPI haul = Global.getFactory().createCargo(true);
		station.getMemoryWithoutUpdate().set(bayKey(SALVAGE_FLEET_HAUL_MEMORY_KEY, bayIndex), haul);
		return haul;
	}

	@SuppressWarnings("unchecked")
	private static List<FleetMemberAPI> getSalvageFleetRecovered(SectorEntityToken station, int bayIndex) {
		Object o = station.getMemoryWithoutUpdate().get(bayKey(SALVAGE_FLEET_RECOVERED_MEMORY_KEY, bayIndex));
		if (o instanceof List) return (List<FleetMemberAPI>) o;
		List<FleetMemberAPI> list = new ArrayList<FleetMemberAPI>();
		station.getMemoryWithoutUpdate().set(bayKey(SALVAGE_FLEET_RECOVERED_MEMORY_KEY, bayIndex), list);
		return list;
	}

	private static boolean isSalvageWreck(SectorEntityToken e) {
		return e != null && e.getCustomPlugin() instanceof DerelictShipEntityPlugin;
	}

	private static DebrisFieldTerrainPlugin getSalvageDebrisPlugin(SectorEntityToken e) {
		if (!(e instanceof CampaignTerrainAPI)) return null;
		CampaignTerrainPlugin plugin = ((CampaignTerrainAPI) e).getPlugin();
		return (plugin instanceof DebrisFieldTerrainPlugin) ? (DebrisFieldTerrainPlugin) plugin : null;
	}

	private static boolean isGuardedWreck(SectorEntityToken e) {
		MemoryAPI mem = e.getMemoryWithoutUpdate();
		if (mem.getBoolean("$hasDefenders") || mem.contains("$defenderFleet") || mem.contains(MemFlags.SALVAGE_DEFENDER_OVERRIDE)) return true;
		try {
			SalvageEntityGenDataSpec spec = SalvageEntityGeneratorOld.getSalvageSpec(e.getCustomEntityType());
			if (spec != null && spec.getProbDefenders() > 0f) return true;
		} catch (Throwable t) {
		}
		return false;
	}

	private static boolean isUsableWreck(SectorEntityToken e) {
		if (!isSalvageWreck(e) || !e.isAlive() || e.isExpired()) return false;
		if (isGuardedWreck(e)) return false;
		Object special = e.getMemoryWithoutUpdate().get(MemFlags.SALVAGE_SPECIAL_DATA);
		return special == null || special instanceof ShipRecoverySpecial.ShipRecoverySpecialData;
	}

	private static boolean isBoardableShipData(ShipRecoverySpecial.PerShipData data) {
		if (data == null) return false;
		try {
			ShipVariantAPI variant = data.variant != null ? data.variant
					: (data.variantId != null ? Global.getSettings().getVariant(data.variantId) : null);
			if (variant == null || variant.getHullSpec() == null) return false;
			if (variant.hasTag(Tags.VARIANT_UNBOARDABLE)) return false;
			return !Misc.isUnboardable(variant.getHullSpec());
		} catch (Throwable t) {
			return false;
		}
	}

	private static List<ShipRecoverySpecial.PerShipData> getRecoverableWreckShips(SectorEntityToken e) {
		List<ShipRecoverySpecial.PerShipData> ships = new ArrayList<ShipRecoverySpecial.PerShipData>();
		if (!isUsableWreck(e) || e.hasTag(Tags.UNRECOVERABLE)) return ships;
		Object special = e.getMemoryWithoutUpdate().get(MemFlags.SALVAGE_SPECIAL_DATA);
		if (special instanceof ShipRecoverySpecial.ShipRecoverySpecialData) {
			for (ShipRecoverySpecial.PerShipData data : ((ShipRecoverySpecial.ShipRecoverySpecialData) special).ships) {
				if (isBoardableShipData(data)) ships.add(data);
			}
		}
		return ships;
	}

	private static int getWreckShipCount(SectorEntityToken e) {
		Object special = e.getMemoryWithoutUpdate().get(MemFlags.SALVAGE_SPECIAL_DATA);
		if (special instanceof ShipRecoverySpecial.ShipRecoverySpecialData) {
			return ((ShipRecoverySpecial.ShipRecoverySpecialData) special).ships.size();
		}
		return 1;
	}

	private static boolean hasSalvageDrops(SectorEntityToken e) {
		return (e.getDropValue() != null && !e.getDropValue().isEmpty())
				|| (e.getDropRandom() != null && !e.getDropRandom().isEmpty());
	}

	private static boolean isUsableDebrisField(SectorEntityToken e) {
		DebrisFieldTerrainPlugin debris = getSalvageDebrisPlugin(e);
		if (debris == null || !e.isAlive() || e.isExpired()) return false;
		DebrisFieldTerrainPlugin.DebrisFieldParams params = debris.getParams();
		if (params == null || params.baseDensity <= 0f) return false;
		if (params.defenderProb > 0f) return false;
		return params.density / params.baseDensity >= SALVAGE_MIN_DEBRIS_DENSITY_FRACTION;
	}

	private static boolean isValidSalvageTarget(SectorEntityToken e, int slotsLeft) {
		if (e == null || !e.isAlive()) return false;
		if (isSalvageWreck(e)) {
			if (!isUsableWreck(e)) return false;
			List<ShipRecoverySpecial.PerShipData> ships = getRecoverableWreckShips(e);
			if (ships.size() > slotsLeft) return false;
			return !ships.isEmpty() || hasSalvageDrops(e);
		}
		return isUsableDebrisField(e);
	}

	private static Set<SectorEntityToken> getClaimedSalvageTargets(SectorEntityToken station, int exceptBay) {
		Set<SectorEntityToken> claimed = new HashSet<SectorEntityToken>();
		for (int i = 0; i < MAX_SALVAGE_FLEET_BAYS; i++) {
			if (i == exceptBay) continue;
			SectorEntityToken t = getSalvageFleetTarget(station, i);
			if (t != null) claimed.add(t);
		}
		return claimed;
	}

	private static SectorEntityToken pickNearestSalvageTarget(SectorEntityToken from, int slotsLeft, Set<SectorEntityToken> claimed) {
		Vector2f fromHyper = from.getLocationInHyperspace();
		SectorEntityToken best = null;
		float bestKey = Float.MAX_VALUE;
		for (LocationAPI loc : Global.getSector().getAllLocations()) {
			if (loc == null) continue;
			for (SectorEntityToken e : loc.getAllEntities()) {
				boolean wreck = isSalvageWreck(e);
				if (!wreck && !(e instanceof CampaignTerrainAPI)) continue;
				if (claimed.contains(e)) continue;
				if (!isValidSalvageTarget(e, slotsLeft)) continue;

				float key = Misc.getDistance(fromHyper, e.getLocationInHyperspace());
				if (from.getContainingLocation() == loc) {
					key += 0.1f * Misc.getDistance(from.getLocation(), e.getLocation());
				} else {
					key += 0.1f * e.getLocation().length();
				}
				if (key < bestKey) {
					bestKey = key;
					best = e;
				}
			}
		}
		return best;
	}

	private static String describeSalvageTarget(SectorEntityToken target) {
		if (target == null) return "its target";
		String where = (target.getContainingLocation() instanceof StarSystemAPI)
				? "the " + ((StarSystemAPI) target.getContainingLocation()).getBaseName() + " system" : "hyperspace";
		return (isSalvageWreck(target) ? "a derelict ship in " : "a debris field in ") + where;
	}

	public static String getSalvageFleetBayStatusText(SectorEntityToken station, int bayIndex) {
		if (isSalvageFleetBayDestroyed(station, bayIndex)) {
			int daysLeft = Math.max(station.getMemoryWithoutUpdate().getInt(bayKey(SALVAGE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex)), 0);
			Object cause = station.getMemoryWithoutUpdate().get(bayKey(SALVAGE_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			return "destroyed by " + (cause instanceof String ? cause : "unknown causes") + " -- rebuilding, ready again in "
					+ daysLeft + " day" + (daysLeft == 1 ? "" : "s");
		}
		if (!isSalvageFleetBayTouring(station, bayIndex)) {
			int cooldown = getSalvageFleetCooldownDays(station, bayIndex);
			if (cooldown > 0) {
				return "docked at the station, relaunching in " + cooldown + " day" + (cooldown == 1 ? "" : "s");
			}
			return "docked at the station, ready to launch";
		}
		String state = getSalvageFleetState(station, bayIndex);
		int recovered = getSalvageFleetRecovered(station, bayIndex).size();
		String progress = " (" + recovered + "/" + SALVAGE_FLEET_MAX_RECOVERED_SHIPS + " ships recovered)";
		if (SALVAGE_STATE_RETURNING.equals(state)) return "returning to the station" + progress;
		SectorEntityToken target = getSalvageFleetTarget(station, bayIndex);
		if (SALVAGE_STATE_WORKING.equals(state)) return "salvaging " + describeSalvageTarget(target) + progress;
		return "moving to " + describeSalvageTarget(target) + progress;
	}

	public static void launchSalvageFleetsIfReady(SectorEntityToken station) {
		if (!MiningHangarModule.isBuilt(station)) return;
		for (int bayIndex = 0; bayIndex < MAX_SALVAGE_FLEET_BAYS; bayIndex++) {
			launchSalvageBay(station, bayIndex);
		}
	}

	private static void launchSalvageBay(SectorEntityToken station, int bayIndex) {
		if (isSalvageFleetBayTouring(station, bayIndex)) return;
		if (isSalvageFleetBayDestroyed(station, bayIndex)) return;
		if (getSalvageFleetCooldownDays(station, bayIndex) > 0) return;
		List<FleetMemberAPI> ships = getSalvageFleetCommittedShips(station, bayIndex);
		if (ships == null || ships.isEmpty()) return;

		StarSystemAPI system = station.getStarSystem();
		if (system == null) return;

		SectorEntityToken target = pickNearestSalvageTarget(station, SALVAGE_FLEET_MAX_RECOVERED_SHIPS,
				getClaimedSalvageTargets(station, bayIndex));
		if (target == null) return;

		outfitFleetShips(station, ships, false);

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER,
				"Salvage Fleet " + (bayIndex + 1), false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		markAsNonInteractiveTraffic(fleet, SALVAGE_ASSIGNMENT_DURATION_CAP_DAYS * 2f);
		injectFleetLogistics(fleet, ships);
		system.addEntity(fleet);
		refreshFleetCR(fleet);
		fleet.setLocation(station.getLocation().x, station.getLocation().y);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(SALVAGE_FLEET_FLEET_MEMORY_KEY, bayIndex), fleet);
		mem.set(bayKey(SALVAGE_FLEET_TOURING_MEMORY_KEY, bayIndex), true);
		mem.set(bayKey(SALVAGE_FLEET_HAUL_MEMORY_KEY, bayIndex), Global.getFactory().createCargo(true));
		mem.set(bayKey(SALVAGE_FLEET_RECOVERED_MEMORY_KEY, bayIndex), new ArrayList<FleetMemberAPI>());
		sendSalvageFleetToTarget(station, bayIndex, fleet, target);
	}

	private static void sendSalvageFleetToTarget(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, SectorEntityToken target) {
		fleet.setOrbit(null);
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, target, SALVAGE_ASSIGNMENT_DURATION_CAP_DAYS,
				"Traveling to salvage " + describeSalvageTarget(target));
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(SALVAGE_FLEET_TARGET_MEMORY_KEY, bayIndex), target);
		mem.set(bayKey(SALVAGE_FLEET_STATE_MEMORY_KEY, bayIndex), SALVAGE_STATE_OUTBOUND);
		mem.unset(bayKey(SALVAGE_FLEET_WORK_DAYS_MEMORY_KEY, bayIndex));
	}

	private static void beginSalvageFleetReturn(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		fleet.setOrbit(null);
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, SALVAGE_ASSIGNMENT_DURATION_CAP_DAYS,
				"Returning to the station");
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(bayKey(SALVAGE_FLEET_STATE_MEMORY_KEY, bayIndex), SALVAGE_STATE_RETURNING);
		mem.unset(bayKey(SALVAGE_FLEET_TARGET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(SALVAGE_FLEET_WORK_DAYS_MEMORY_KEY, bayIndex));
	}

	private static float getSalvageFleetFuelCapacity(SectorEntityToken station, int bayIndex) {
		float total = 0f;
		List<FleetMemberAPI> ships = getSalvageFleetCommittedShips(station, bayIndex);
		if (ships != null) {
			for (FleetMemberAPI m : ships) total += getBaseFuelCapacity(m);
		}
		return total;
	}

	private static boolean isSalvageFleetFull(SectorEntityToken station, int bayIndex) {
		if (getSalvageFleetRecovered(station, bayIndex).size() >= SALVAGE_FLEET_MAX_RECOVERED_SHIPS) return true;
		float capacity = getTradeFleetTotalCargoCapacity(getSalvageFleetCommittedShips(station, bayIndex));
		if (capacity <= 0f) return true;
		return getSalvageFleetHaul(station, bayIndex).getSpaceUsed() >= capacity * SALVAGE_CARGO_FULL_FRACTION;
	}

	private static void assignNextSalvageTarget(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		if (isSalvageFleetFull(station, bayIndex)) {
			beginSalvageFleetReturn(station, bayIndex, fleet);
			return;
		}
		int slotsLeft = SALVAGE_FLEET_MAX_RECOVERED_SHIPS - getSalvageFleetRecovered(station, bayIndex).size();
		SectorEntityToken next = pickNearestSalvageTarget(fleet, slotsLeft, getClaimedSalvageTargets(station, bayIndex));
		if (next == null) {
			beginSalvageFleetReturn(station, bayIndex, fleet);
			return;
		}
		sendSalvageFleetToTarget(station, bayIndex, fleet, next);
	}

	public static void advanceSalvageFleetsRealtime(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_SALVAGE_FLEET_BAYS; bayIndex++) {
			advanceSalvageBayRealtime(station, bayIndex);
		}
	}

	private static void advanceSalvageBayRealtime(SectorEntityToken station, int bayIndex) {
		if (!isSalvageFleetBayTouring(station, bayIndex)) return;
		String state = getSalvageFleetState(station, bayIndex);
		if (state == null) return;

		CampaignFleetAPI fleet = getSalvageTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) return;

		if (SALVAGE_STATE_OUTBOUND.equals(state)) {
			SectorEntityToken target = getSalvageFleetTarget(station, bayIndex);
			int slotsLeft = SALVAGE_FLEET_MAX_RECOVERED_SHIPS - getSalvageFleetRecovered(station, bayIndex).size();
			if (!isValidSalvageTarget(target, slotsLeft)) {
				assignNextSalvageTarget(station, bayIndex, fleet);
				return;
			}
			if (fleet.getContainingLocation() != target.getContainingLocation()) return;
			if (Misc.getDistance(fleet, target) <= SALVAGE_ARRIVAL_RANGE) {
				fleet.clearAssignments();
				fleet.setCircularOrbitPointingDown(target, (float) (Math.random() * 360f), SALVAGE_ORBIT_RADIUS, SALVAGE_ORBIT_DAYS);
				MemoryAPI mem = station.getMemoryWithoutUpdate();
				mem.set(bayKey(SALVAGE_FLEET_STATE_MEMORY_KEY, bayIndex), SALVAGE_STATE_WORKING);
				mem.set(bayKey(SALVAGE_FLEET_WORK_DAYS_MEMORY_KEY, bayIndex),
						isSalvageWreck(target) ? SALVAGE_WRECK_WORK_DAYS : SALVAGE_DEBRIS_WORK_DAYS);
			}
			return;
		}

		if (SALVAGE_STATE_RETURNING.equals(state)) {
			if (fleet.getContainingLocation() != station.getContainingLocation()) return;
			if (Misc.getDistance(fleet, station) > SALVAGE_ARRIVAL_RANGE) return;
			recallSalvageFleet(station, bayIndex);
		}
	}

	public static void advanceSalvageFleetsDaily(SectorEntityToken station) {
		for (int bayIndex = 0; bayIndex < MAX_SALVAGE_FLEET_BAYS; bayIndex++) {
			advanceSalvageBayDaily(station, bayIndex);
		}
	}

	private static void advanceSalvageBayDaily(SectorEntityToken station, int bayIndex) {
		if (isSalvageFleetBayDestroyed(station, bayIndex)) {
			advanceLogisticFleetRespawn(station,
					bayKey(SALVAGE_FLEET_SHIPS_MEMORY_KEY, bayIndex), bayKey(SALVAGE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(SALVAGE_FLEET_DESTROYED_MEMORY_KEY, bayIndex), bayKey(SALVAGE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(SALVAGE_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			return;
		}
		if (!isSalvageFleetBayTouring(station, bayIndex)) {
			int cooldown = getSalvageFleetCooldownDays(station, bayIndex);
			if (cooldown > 0) station.getMemoryWithoutUpdate().set(bayKey(SALVAGE_FLEET_COOLDOWN_MEMORY_KEY, bayIndex), cooldown - 1);
			return;
		}

		CampaignFleetAPI fleet = getSalvageTouringFleet(station, bayIndex);
		if (fleet == null || !fleet.isAlive()) {
			markLogisticFleetDestroyed(station, "Salvage Fleet " + (bayIndex + 1), getSalvageFleetCommittedShips(station, bayIndex),
					"unknown causes",
					bayKey(SALVAGE_FLEET_SHIPS_MEMORY_KEY, bayIndex), bayKey(SALVAGE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex),
					bayKey(SALVAGE_FLEET_DESTROYED_MEMORY_KEY, bayIndex), bayKey(SALVAGE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex),
					bayKey(SALVAGE_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
			clearSalvageTouringState(station, bayIndex);
			return;
		}
		topOffFleetSuppliesIfLow(fleet);

		if (SALVAGE_STATE_WORKING.equals(getSalvageFleetState(station, bayIndex))) {
			int daysLeft = station.getMemoryWithoutUpdate().getInt(bayKey(SALVAGE_FLEET_WORK_DAYS_MEMORY_KEY, bayIndex)) - 1;
			if (daysLeft > 0) {
				station.getMemoryWithoutUpdate().set(bayKey(SALVAGE_FLEET_WORK_DAYS_MEMORY_KEY, bayIndex), daysLeft);
				return;
			}
			completeSalvageTarget(station, bayIndex, fleet);
		}
	}

	private static void completeSalvageTarget(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet) {
		SectorEntityToken target = getSalvageFleetTarget(station, bayIndex);
		int slotsLeft = SALVAGE_FLEET_MAX_RECOVERED_SHIPS - getSalvageFleetRecovered(station, bayIndex).size();
		if (isValidSalvageTarget(target, slotsLeft)) {
			try {
				if (isSalvageWreck(target)) {
					recoverWreck(station, bayIndex, fleet, target);
				} else {
					salvageDebrisField(station, bayIndex, fleet, target);
				}
			} catch (Throwable t) {
				Global.getLogger(MilitaryWardModule.class).warn("Player HQ: salvage fleet failed on a target", t);
				if (isSalvageWreck(target)) Misc.fadeAndExpire(target, 1f);
			}
		}
		assignNextSalvageTarget(station, bayIndex, fleet);
	}

	private static void recoverWreck(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, SectorEntityToken wreck) {
		List<ShipRecoverySpecial.PerShipData> ships = getRecoverableWreckShips(wreck);
		List<FleetMemberAPI> recovered = getSalvageFleetRecovered(station, bayIndex);
		java.util.Random random = new java.util.Random();
		int recoveredHere = 0;
		for (ShipRecoverySpecial.PerShipData data : ships) {
			if (recovered.size() >= SALVAGE_FLEET_MAX_RECOVERED_SHIPS) break;
			FleetMemberAPI member = buildRecoveredWreckShip(data, random);
			if (member != null) {
				recovered.add(member);
				recoveredHere++;
			}
		}
		if (recoveredHere < getWreckShipCount(wreck)) {
			addSalvageLoot(station, bayIndex, fleet, wreck, 1f);
		}
		Misc.fadeAndExpire(wreck, 1f);
	}

	private static FleetMemberAPI buildRecoveredWreckShip(ShipRecoverySpecial.PerShipData data, java.util.Random random) {
		if (data == null || (data.variantId == null && data.variant == null)) return null;
		FleetMemberAPI member;
		try {
			member = data.variantId != null
					? Global.getFactory().createFleetMember(FleetMemberType.SHIP, data.variantId)
					: Global.getFactory().createFleetMember(FleetMemberType.SHIP, data.variant);
		} catch (Throwable t) {
			return null;
		}
		if (Misc.isUnboardable(member)) return null;
		if (data.shipName != null) member.setShipName(data.shipName);

		ShipRecoverySpecial.ShipCondition condition = data.condition != null ? data.condition : ShipRecoverySpecial.ShipCondition.AVERAGE;
		int dmods;
		float hull;
		float retain;
		switch (condition) {
		case PRISTINE: dmods = 0; hull = 1f; retain = 1f; break;
		case GOOD: dmods = 1; hull = 0.6f + random.nextFloat() * 0.2f; retain = 0.67f; break;
		case AVERAGE: dmods = 1 + random.nextInt(2); hull = 0.4f + random.nextFloat() * 0.2f; retain = 0.5f; break;
		case BATTERED: dmods = 2 + random.nextInt(2); hull = 0.2f + random.nextFloat() * 0.2f; retain = 0.33f; break;
		default: dmods = 3 + random.nextInt(2); hull = random.nextFloat() * 0.1f; retain = 0.2f; break;
		}

		member.getStatus().setHullFraction(hull);
		member.getRepairTracker().setCR(0f);

		ShipVariantAPI variant = member.getVariant().clone();
		variant.setOriginalVariant(null);
		dmods = Math.max(0, dmods - DModManager.getNumDMods(variant));
		if (dmods > 0 && data.addDmods) DModManager.setDHull(variant);
		member.setVariant(variant, false, true);
		if (dmods > 0 && data.addDmods) DModManager.addDMods(member, true, dmods, random);

		if (data.pruneWeapons) {
			FleetEncounterContext.prepareShipForRecovery(member, false, false, false, retain, retain, random);
			member.getVariant().autoGenerateWeaponGroups();
		}
		return member;
	}

	private static float getSalvageSkillBonus(CampaignFleetAPI playerFleet) {
		float bonus = 0f;
		for (com.fs.starfarer.api.combat.MutableStat.StatMod mod : playerFleet.getStats().getDynamic()
				.getStat(Stats.SALVAGE_VALUE_MULT_FLEET_INCLUDES_RARE).getFlatMods().values()) {
			bonus += mod.value;
		}
		for (com.fs.starfarer.api.combat.MutableStat.StatMod mod : playerFleet.getStats().getDynamic()
				.getStat(Stats.SALVAGE_VALUE_MULT_FLEET_NOT_RARE).getFlatMods().values()) {
			bonus += mod.value;
		}
		return bonus;
	}

	private static void salvageDebrisField(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, SectorEntityToken field) {
		DebrisFieldTerrainPlugin debris = getSalvageDebrisPlugin(field);
		if (debris == null) return;
		DebrisFieldTerrainPlugin.DebrisFieldParams params = debris.getParams();

		float overallMult = params.baseDensity > 0f ? params.density / params.baseDensity : 0f;
		if (overallMult < 0.01f) overallMult = 0.01f;

		addSalvageLoot(station, bayIndex, fleet, field, overallMult);

		params.density -= overallMult;
		if (params.density < 0f) params.density = 0f;
		debris.setScavenged(true);
	}

	private static void addSalvageLoot(SectorEntityToken station, int bayIndex, CampaignFleetAPI fleet, SectorEntityToken source, float overallMult) {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		float gantryBonus = RepairGantry.getAdjustedGantryModifier(fleet, null, 0f);
		float skillBonus = playerFleet != null ? getSalvageSkillBonus(playerFleet) : 0f;
		float valueMult = 1f + gantryBonus + skillBonus;
		float rareMult = playerFleet != null
				? playerFleet.getStats().getDynamic().getValue(Stats.SALVAGE_VALUE_MULT_FLEET_INCLUDES_RARE) : 1f;
		float fuelMult = playerFleet != null
				? playerFleet.getStats().getDynamic().getValue(Stats.FUEL_SALVAGE_VALUE_MULT_FLEET) : 1f;

		CargoAPI loot = SalvageEntity.generateSalvage(new java.util.Random(), valueMult, rareMult, overallMult, fuelMult,
				new ArrayList<SalvageEntityGenDataSpec.DropData>(source.getDropValue()),
				new ArrayList<SalvageEntityGenDataSpec.DropData>(source.getDropRandom()));

		if (loot != null && !loot.isEmpty()) {
			CargoAPI haul = getSalvageFleetHaul(station, bayIndex);
			float fuelRoom = Math.max(0f, getSalvageFleetFuelCapacity(station, bayIndex) - haul.getFuel());
			if (loot.getFuel() > fuelRoom) loot.removeFuel(loot.getFuel() - fuelRoom);
			haul.addAll(loot);
		}
	}

	private static void recallSalvageFleet(SectorEntityToken station, int bayIndex) {
		depositSalvageHaul(station, bayIndex);
		despawnSalvageFleet(station, bayIndex);
		station.getMemoryWithoutUpdate().set(bayKey(SALVAGE_FLEET_COOLDOWN_MEMORY_KEY, bayIndex), SALVAGE_FLEET_RELAUNCH_COOLDOWN_DAYS);
	}

	@SuppressWarnings("unchecked")
	private static void depositSalvageHaul(SectorEntityToken station, int bayIndex) {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		MemoryAPI mem = station.getMemoryWithoutUpdate();

		CargoAPI haul = getSalvageFleetHaul(station, bayIndex);
		Object logObj = mem.get(SALVAGE_FLEET_HAUL_LOG_MEMORY_KEY);
		Map<String, Float> log = (logObj instanceof Map) ? (Map<String, Float>) logObj : new LinkedHashMap<String, Float>();
		for (CargoStackAPI stack : haul.getStacksCopy()) {
			if (stack == null || stack.isNull()) continue;
			float size = stack.getSize();
			if (size <= 0f) continue;
			String name = stack.getDisplayName();
			Float existing = log.get(name);
			log.put(name, (existing != null ? existing : 0f) + size);
		}
		storage.addAll(haul);
		mem.set(SALVAGE_FLEET_HAUL_LOG_MEMORY_KEY, log);

		List<FleetMemberAPI> recovered = getSalvageFleetRecovered(station, bayIndex);
		if (!recovered.isEmpty()) {
			storage.initMothballedShips(Global.getSector().getPlayerFaction().getId());
			FleetDataAPI mothballed = storage.getMothballedShips();
			if (mothballed != null) {
				for (FleetMemberAPI m : recovered) {
					mothballed.addFleetMember(m);
				}
			}
			mem.set(SALVAGE_FLEET_SHIPS_LOG_MEMORY_KEY, mem.getInt(SALVAGE_FLEET_SHIPS_LOG_MEMORY_KEY) + recovered.size());
		}
	}

	@SuppressWarnings("unchecked")
	public static List<String> getSalvageFleetHaulThisMonth(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		List<String> result = new ArrayList<String>();
		int ships = mem.getInt(SALVAGE_FLEET_SHIPS_LOG_MEMORY_KEY);
		if (ships > 0) result.add(ships + " recovered ship" + (ships == 1 ? "" : "s"));
		Object o = mem.get(SALVAGE_FLEET_HAUL_LOG_MEMORY_KEY);
		if (o instanceof Map) {
			for (Map.Entry<String, Float> entry : ((Map<String, Float>) o).entrySet()) {
				result.add((int) (float) entry.getValue() + "x " + entry.getKey());
			}
		}
		return result;
	}

	public static void clearSalvageFleetHaulThisMonth(SectorEntityToken station) {
		station.getMemoryWithoutUpdate().unset(SALVAGE_FLEET_HAUL_LOG_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(SALVAGE_FLEET_SHIPS_LOG_MEMORY_KEY);
	}

	private static void despawnSalvageFleet(SectorEntityToken station, int bayIndex) {
		CampaignFleetAPI fleet = getSalvageTouringFleet(station, bayIndex);
		if (fleet != null) {
			List<FleetMemberAPI> ships = getSalvageFleetCommittedShips(station, bayIndex);
			if (ships != null) {
				for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(ships)) {
					fleet.getFleetData().removeFleetMember(m);
				}
			}
			fleet.despawn();
		}
		clearSalvageTouringState(station, bayIndex);
	}

	private static void clearSalvageTouringState(SectorEntityToken station, int bayIndex) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(bayKey(SALVAGE_FLEET_TOURING_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(SALVAGE_FLEET_FLEET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(SALVAGE_FLEET_TARGET_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(SALVAGE_FLEET_STATE_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(SALVAGE_FLEET_WORK_DAYS_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(SALVAGE_FLEET_HAUL_MEMORY_KEY, bayIndex));
		mem.unset(bayKey(SALVAGE_FLEET_RECOVERED_MEMORY_KEY, bayIndex));
	}

	private static void clearSalvageBayMemory(SectorEntityToken station, int bayIndex) {
		clearSalvageTouringState(station, bayIndex);
		station.getMemoryWithoutUpdate().unset(bayKey(SALVAGE_FLEET_SHIPS_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(SALVAGE_FLEET_CREW_COST_MEMORY_KEY, bayIndex));
		station.getMemoryWithoutUpdate().unset(bayKey(SALVAGE_FLEET_COOLDOWN_MEMORY_KEY, bayIndex));
		clearLogisticFleetDestroyedState(station,
				bayKey(SALVAGE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex), bayKey(SALVAGE_FLEET_DESTROYED_MEMORY_KEY, bayIndex),
				bayKey(SALVAGE_FLEET_RESPAWN_DAYS_LEFT_MEMORY_KEY, bayIndex), bayKey(SALVAGE_FLEET_DESTROYED_CAUSE_MEMORY_KEY, bayIndex));
	}

	private static void disbandSalvageBayInto(SectorEntityToken station, int bayIndex, CargoAPI destination, String factionId) {
		if (bayIndex < 0 || bayIndex >= MAX_SALVAGE_FLEET_BAYS || !isSalvageFleetBayBuilt(station, bayIndex)) return;

		if (isSalvageFleetBayTouring(station, bayIndex)) {
			despawnSalvageFleet(station, bayIndex);
		}

		if (destination != null) {
			destination.initMothballedShips(factionId);
			List<FleetMemberAPI> ships = getReturnableShips(station, getSalvageFleetCommittedShips(station, bayIndex),
					bayKey(SALVAGE_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex));
			if (ships != null && !ships.isEmpty() && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(SALVAGE_FLEET_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) {
				destination.addCrew(crewCost);
			}
		}

		clearSalvageBayMemory(station, bayIndex);
	}

	private static void disbandAllSalvageBaysInto(SectorEntityToken station, CargoAPI destination, String factionId) {
		for (int bayIndex = 0; bayIndex < MAX_SALVAGE_FLEET_BAYS; bayIndex++) {
			disbandSalvageBayInto(station, bayIndex, destination, factionId);
		}
	}

	public static void uninstallSalvageFleetBay(SectorEntityToken station, CampaignFleetAPI playerFleet, int bayIndex) {
		disbandSalvageBayInto(station, bayIndex, PlayerHQUtils.getStationStorageCargo(station), playerFleet.getFaction().getId());
	}

	private static void disbandMiningBayInto(SectorEntityToken station, int bayIndex, CargoAPI destination, String factionId) {
		if (!isMiningFleetBayBuilt(station, bayIndex)) return;

		if (isMiningFleetBayTouring(station, bayIndex)) {
			despawnMiningFleet(station, bayIndex);
		}

		if (destination != null) {
			destination.initMothballedShips(factionId);
			List<FleetMemberAPI> ships = getReturnableShips(station, getMiningFleetCommittedShips(station, bayIndex),
					bayKey(MINING_FLEET_RESPAWN_MANIFEST_MEMORY_KEY, bayIndex));
			if (ships != null && !ships.isEmpty() && destination.getMothballedShips() != null) {
				FleetDataAPI mothballed = destination.getMothballedShips();
				for (FleetMemberAPI m : ships) {
					stripAutoAssignedOfficer(m);
					mothballed.addFleetMember(m);
				}
			}
			int crewCost = station.getMemoryWithoutUpdate().getInt(bayKey(MINING_FLEET_CREW_COST_MEMORY_KEY, bayIndex));
			if (crewCost > 0) {
				destination.addCrew(crewCost);
			}
		}

		clearMiningBayMemory(station, bayIndex);
	}

	private static final int LEGACY_MINING_FLEET_BAYS = 4;

	private static void disbandRetiredMiningBays(SectorEntityToken station) {
		List<Integer> disbanded = new ArrayList<Integer>();
		for (int bayIndex = MAX_MINING_FLEET_BAYS; bayIndex < LEGACY_MINING_FLEET_BAYS; bayIndex++) {
			if (!isMiningFleetBayBuilt(station, bayIndex)) continue;
			disbandMiningBayInto(station, bayIndex, PlayerHQUtils.getStationStorageCargo(station),
					Global.getSector().getPlayerFaction().getId());
			disbanded.add(bayIndex + 1);
		}
		if (!disbanded.isEmpty()) {
			Global.getSector().getCampaignUI().addMessage(
					"Mining Fleet bay" + (disbanded.size() == 1 ? " " : "s ") + Misc.getAndJoined(toStringList(disbanded))
							+ " " + (disbanded.size() == 1 ? "was" : "were") + " retired. The ships and Crew were returned to the station's inventory.",
					Misc.getHighlightColor());
		}
	}

	private static List<String> toStringList(List<Integer> numbers) {
		List<String> result = new ArrayList<String>();
		for (Integer n : numbers) result.add("" + n);
		return result;
	}
}
