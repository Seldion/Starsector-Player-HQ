package playerhq.modules;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.PlayerMarketTransaction;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SubmarketPlugin.TransferAction;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class BlackMarketSubmarketPlugin extends BaseSubmarketPlugin {

	public static final int HULLMOD_TYPES = 2;
	public static final int BLUEPRINT_TYPES = 1;
	public static final int MIN_WING_TYPES = 1;
	public static final int MAX_WING_TYPES = 5;
	public static final int WEAPON_TYPES = 12;
	private static final int MIN_SHIP_DMODS = 1;
	private static final int MAX_SHIP_DMODS = 4;
	private static final int RARE_SHIP_DMODS = 4;
	private static final int CEILING_RAMP_MONTHS = 96;
	private static final int MIN_BAND_POOL = 4;

	private static final float HULLMOD_CHANCE = 0.25f;
	private static final float BLUEPRINT_CHANCE = 0.25f;

	private static final int MAX_STACK_SIZE = 10;

	private static final float BLUEPRINT_VALUE_MULT = 2f;

	private static final float RARITY_VALUE_FLOOR = 100f;

	private enum Kind { WEAPON, FIGHTER, HULLMOD, SHIP_BP, WEAPON_BP, FIGHTER_BP }

	private static class StockEntry {
		final Kind kind;
		final String id;
		final int quantity;
		StockEntry(Kind kind, String id, int quantity) {
			this.kind = kind;
			this.id = id;
			this.quantity = quantity;
		}
	}

	private static final int STOCK_FILTER_VERSION = 5;

	private int lastRestockMonthIndex = Integer.MIN_VALUE;
	private int stockFilterVersion = 0;
	private int firstShipRestockMonthIndex = 0;
	private java.util.HashMap<String, Integer> rareLastMonth;
	private java.util.HashMap<String, String> rareLastHull;

	@Override
	public void init(SubmarketAPI submarket) {
		super.init(submarket);
	}

	@Override
	public String getName() {
		return "Exchange";
	}

	@Override
	public boolean isBlackMarket() {
		return true;
	}

	@Override
	public float getTariff() {
		return 0f;
	}

	@Override
	public boolean isParticipatesInEconomy() {
		return false;
	}

	@Override
	public boolean isIllegalOnSubmarket(CargoStackAPI stack, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) return true;
		return super.isIllegalOnSubmarket(stack, action);
	}

	@Override
	public boolean isIllegalOnSubmarket(FleetMemberAPI member, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) return true;
		return super.isIllegalOnSubmarket(member, action);
	}

	@Override
	public String getIllegalTransferText(CargoStackAPI stack, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "This market doesn't buy from you -- deposit items at the Agora instead";
		}
		return super.getIllegalTransferText(stack, action);
	}

	@Override
	public String getIllegalTransferText(FleetMemberAPI member, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "This market doesn't buy from you -- deposit items at the Agora instead";
		}
		return super.getIllegalTransferText(member, action);
	}

	@Override
	public void reportPlayerMarketTransaction(PlayerMarketTransaction transaction) {
		float spent = -transaction.getCreditValue();
		if (spent <= 0f) return;
		SectorEntityToken entity = market.getPrimaryEntity();
		if (entity != null) {
			MarketPlaceModule.addExchangeSpend(entity, spent);
		}
	}

	@Override
	public void updateCargoPrePlayerInteraction() {
		sinceLastCargoUpdate = 0f;

		int monthIndex = Global.getSector().getClock().getCycle() * 12 + Global.getSector().getClock().getMonth();
		if (monthIndex == lastRestockMonthIndex && stockFilterVersion == STOCK_FILTER_VERSION) return;
		lastRestockMonthIndex = monthIndex;
		stockFilterVersion = STOCK_FILTER_VERSION;

		CargoAPI cargo = getCargo();
		cargo.clear();
		if (cargo.getMothballedShips() != null) {
			cargo.getMothballedShips().clear();
		}

		List<StockEntry> entries = new ArrayList<StockEntry>();

		if (itemGenRandom.nextFloat() < HULLMOD_CHANCE) {
			WeightedRandomPicker<HullModSpecAPI> hullModPicker = buildHullModPicker();
			for (int i = 0; i < HULLMOD_TYPES && !hullModPicker.isEmpty(); i++) {
				HullModSpecAPI spec = hullModPicker.pickAndRemove();
				if (spec != null) entries.add(new StockEntry(Kind.HULLMOD, spec.getId(), 1));
			}
		}

		if (itemGenRandom.nextFloat() < BLUEPRINT_CHANCE) {
			for (int i = 0; i < BLUEPRINT_TYPES; i++) {
				StockEntry blueprint = pickOneBlueprint();
				if (blueprint != null) entries.add(blueprint);
			}
		}

		WeightedRandomPicker<FighterWingSpecAPI> fighterPicker = buildFighterPicker();
		int wingTypesThisMonth = MIN_WING_TYPES + itemGenRandom.nextInt(MAX_WING_TYPES - MIN_WING_TYPES + 1);
		for (int i = 0; i < wingTypesThisMonth && !fighterPicker.isEmpty(); i++) {
			FighterWingSpecAPI spec = fighterPicker.pickAndRemove();
			if (spec != null) entries.add(new StockEntry(Kind.FIGHTER, spec.getId(), randomStackSize()));
		}

		WeightedRandomPicker<WeaponSpecAPI> weaponPicker = buildWeaponPicker();
		for (int i = 0; i < WEAPON_TYPES && !weaponPicker.isEmpty(); i++) {
			WeaponSpecAPI spec = weaponPicker.pickAndRemove();
			if (spec != null) entries.add(new StockEntry(Kind.WEAPON, spec.getWeaponId(), randomStackSize()));
		}

		for (StockEntry e : entries) {
			switch (e.kind) {
			case WEAPON:
				cargo.addWeapons(e.id, e.quantity);
				break;
			case FIGHTER:
				cargo.addFighters(e.id, e.quantity);
				break;
			case HULLMOD:
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.TAG_MODSPEC, e.id), e.quantity);
				break;
			case SHIP_BP:
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SHIP_BP, e.id), e.quantity);
				break;
			case WEAPON_BP:
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.WEAPON_BP, e.id), e.quantity);
				break;
			case FIGHTER_BP:
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.FIGHTER_BP, e.id), e.quantity);
				break;
			}
		}

		stockShips(cargo, monthIndex);

		cargo.sort();

		StringBuilder stocked = new StringBuilder();
		for (StockEntry e : entries) stocked.append(e.kind).append(':').append(e.id).append(" x").append(e.quantity).append("; ");
		if (cargo.getMothballedShips() != null) {
			for (FleetMemberAPI m : cargo.getMothballedShips().getMembersListCopy()) {
				stocked.append("SHIP:").append(m.getVariant().getHullVariantId()).append("; ");
			}
		}
		Global.getLogger(BlackMarketSubmarketPlugin.class).info("PlayerHQ Exchange restocked: " + stocked);

		SectorEntityToken exchangeStation = market != null ? market.getPrimaryEntity() : null;
		playerhq.shopping.ShoppingListEngine.autoBuyAtExchange(exchangeStation, submarket);
	}

	private static class SlotSpec {
		final HullSize size;
		final float chance;
		final float minValue;
		final float maxStart;
		final float maxEnd;
		final String rareKey;
		final int guaranteeMonths;
		final int fixedDmods;

		SlotSpec(HullSize size, float chance, float minValue, float maxStart, float maxEnd,
				String rareKey, int guaranteeMonths, int fixedDmods) {
			this.size = size;
			this.chance = chance;
			this.minValue = minValue;
			this.maxStart = maxStart;
			this.maxEnd = maxEnd;
			this.rareKey = rareKey;
			this.guaranteeMonths = guaranteeMonths;
			this.fixedDmods = fixedDmods;
		}
	}

	private static class HullEntry {
		final String hullId;
		final String variantId;
		final HullSize size;
		final float value;

		HullEntry(String hullId, String variantId, HullSize size, float value) {
			this.hullId = hullId;
			this.variantId = variantId;
			this.size = size;
			this.value = value;
		}
	}

	private static final float UNCAPPED = Float.MAX_VALUE;

	private static final List<SlotSpec> SHIP_SLOTS = buildShipSlots();

	private static List<SlotSpec> buildShipSlots() {
		List<SlotSpec> list = new ArrayList<SlotSpec>();
		list.add(new SlotSpec(HullSize.CAPITAL_SHIP, 0f, 0f, UNCAPPED, UNCAPPED, "CAPITAL", 6, 0));

		list.add(new SlotSpec(HullSize.CRUISER, 0.50f, 0f, 90000f, 110000f, null, 0, 0));
		list.add(new SlotSpec(HullSize.CRUISER, 0.25f, 90000f, 120000f, 170000f, null, 0, 0));
		list.add(new SlotSpec(HullSize.CRUISER, 0.25f, 90000f, 120000f, 170000f, null, 0, 0));
		list.add(new SlotSpec(HullSize.CRUISER, 0.05f, 170000f, UNCAPPED, UNCAPPED, "CRUISER_RARE", 4, RARE_SHIP_DMODS));

		for (int i = 0; i < 3; i++) list.add(new SlotSpec(HullSize.DESTROYER, 0.50f, 0f, 30000f, 40000f, null, 0, 0));
		for (int i = 0; i < 2; i++) list.add(new SlotSpec(HullSize.DESTROYER, 0.50f, 30000f, 40000f, 60000f, null, 0, 0));
		list.add(new SlotSpec(HullSize.DESTROYER, 0.10f, 60000f, UNCAPPED, UNCAPPED, "DESTROYER_RARE", 3, RARE_SHIP_DMODS));

		for (int i = 0; i < 4; i++) list.add(new SlotSpec(HullSize.FRIGATE, 0.50f, 0f, 10000f, 18000f, null, 0, 0));
		for (int i = 0; i < 3; i++) list.add(new SlotSpec(HullSize.FRIGATE, 0.50f, 10000f, 20000f, 40000f, null, 0, 0));
		list.add(new SlotSpec(HullSize.FRIGATE, 0.15f, 40000f, UNCAPPED, UNCAPPED, "FRIGATE_RARE", 2, RARE_SHIP_DMODS));
		return list;
	}

	private void stockShips(CargoAPI cargo, int monthIndex) {
		if (rareLastMonth == null) rareLastMonth = new java.util.HashMap<String, Integer>();
		if (rareLastHull == null) rareLastHull = new java.util.HashMap<String, String>();
		if (firstShipRestockMonthIndex == 0) firstShipRestockMonthIndex = monthIndex;

		List<HullEntry> pool = buildHullPool();
		if (pool.isEmpty()) return;

		float progress = Math.min(1f, Math.max(0f, (monthIndex - firstShipRestockMonthIndex) / (float) CEILING_RAMP_MONTHS));
		cargo.initMothballedShips(Factions.PLAYER);

		for (SlotSpec slot : SHIP_SLOTS) {
			boolean fill;
			if (slot.rareKey != null) {
				Integer last = rareLastMonth.get(slot.rareKey);
				if (last == null) {
					last = monthIndex;
					rareLastMonth.put(slot.rareKey, last);
				}
				fill = monthIndex - last >= slot.guaranteeMonths
						|| (slot.chance > 0f && itemGenRandom.nextFloat() < slot.chance);
			} else {
				fill = itemGenRandom.nextFloat() < slot.chance;
			}
			if (!fill) continue;

			float maxValue = slot.maxEnd == UNCAPPED ? UNCAPPED
					: slot.maxStart + (slot.maxEnd - slot.maxStart) * progress;
			String exclude = slot.rareKey != null ? rareLastHull.get(slot.rareKey) : null;
			HullEntry entry = pickHull(pool, slot, maxValue, exclude);
			if (entry == null) continue;

			String variantId = AssemblyBayModule.getFirstVariantId(entry.hullId);
			if (variantId == null) variantId = entry.variantId;
			FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, variantId);
			int dmods = slot.fixedDmods > 0 ? slot.fixedDmods
					: MIN_SHIP_DMODS + itemGenRandom.nextInt(MAX_SHIP_DMODS - MIN_SHIP_DMODS + 1);
			DModManager.addDMods(member.getVariant(), false, dmods, itemGenRandom);
			cargo.getMothballedShips().addFleetMember(member);

			if (slot.rareKey != null) {
				rareLastMonth.put(slot.rareKey, monthIndex);
				rareLastHull.put(slot.rareKey, entry.hullId);
			}
		}
	}

	private HullEntry pickHull(List<HullEntry> pool, SlotSpec slot, float maxValue, String excludeHullId) {
		float floor = slot.minValue;
		List<HullEntry> candidates;
		while (true) {
			candidates = new ArrayList<HullEntry>();
			for (HullEntry e : pool) {
				if (e.size != slot.size) continue;
				if (e.value < floor || e.value > maxValue) continue;
				if (excludeHullId != null && excludeHullId.equals(e.hullId)) continue;
				candidates.add(e);
			}
			if (candidates.size() >= MIN_BAND_POOL || floor <= 0f) break;
			floor = floor < 1000f ? 0f : floor * 0.8f;
		}
		if (candidates.isEmpty()) return null;
		WeightedRandomPicker<HullEntry> picker = new WeightedRandomPicker<HullEntry>(itemGenRandom);
		for (HullEntry e : candidates) picker.add(e, rarityWeight(e.value));
		return picker.pick();
	}

	private List<HullEntry> buildHullPool() {
		java.util.Map<String, HullEntry> byHull = new java.util.LinkedHashMap<String, HullEntry>();
		for (String variantId : Global.getSettings().getAllVariantIds()) {
			ShipVariantAPI variant = Global.getSettings().getVariant(variantId);
			if (variant == null) continue;
			ShipHullSpecAPI hull = variant.getHullSpec();
			if (!isSellableHull(hull)) continue;
			String hullId = hull.getHullId();
			if (byHull.containsKey(hullId)) continue;
			byHull.put(hullId, new HullEntry(hullId, variantId, hull.getHullSize(), hull.getBaseValue()));
		}
		return new ArrayList<HullEntry>(byHull.values());
	}

	private static boolean isSellableHull(ShipHullSpecAPI hull) {
		if (hull == null || hull.isDHull()) return false;
		if (hull.getBaseValue() <= 0f) return false;
		if (!isSellableHullSize(hull.getHullSize())) return false;
		if (hull.hasTag(Tags.RESTRICTED) || hull.hasTag(Tags.NO_BP_DROP) || hull.hasTag(Tags.MODULE_UNSELECTABLE)) return false;
		java.util.EnumSet<ShipHullSpecAPI.ShipTypeHints> hints = hull.getHints();
		if (hints.contains(ShipHullSpecAPI.ShipTypeHints.MODULE)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.STATION)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.UNDER_PARENT)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.HIDE_IN_CODEX)
				|| hints.contains(ShipHullSpecAPI.ShipTypeHints.UNBOARDABLE)
				|| hull.hasTag("no_dealer")) return false;
		if (ExchangeBlacklist.isBlacklisted(hull.getHullId())) return false;
		return true;
	}

	private static boolean isSellableWeaponType(com.fs.starfarer.api.combat.WeaponAPI.WeaponType type) {
		return type == com.fs.starfarer.api.combat.WeaponAPI.WeaponType.BALLISTIC
				|| type == com.fs.starfarer.api.combat.WeaponAPI.WeaponType.ENERGY
				|| type == com.fs.starfarer.api.combat.WeaponAPI.WeaponType.MISSILE;
	}

	private static boolean isSellableHullSize(HullSize size) {
		return size == HullSize.FRIGATE || size == HullSize.DESTROYER
				|| size == HullSize.CRUISER || size == HullSize.CAPITAL_SHIP;
	}

	private int randomStackSize() {
		return 1 + itemGenRandom.nextInt(MAX_STACK_SIZE);
	}

	private StockEntry pickOneBlueprint() {
		WeightedRandomPicker<String> bpTypePicker = new WeightedRandomPicker<String>();
		bpTypePicker.add("ship", 50f);
		bpTypePicker.add("weapon", 30f);
		bpTypePicker.add("fighter", 20f);
		String bpType = bpTypePicker.pick();
		if (bpType == null) return null;

		if (bpType.equals("ship")) {
			ShipHullSpecAPI spec = buildShipBlueprintPicker().pick();
			if (spec == null) return null;
			return new StockEntry(Kind.SHIP_BP, spec.getHullId(), 1);
		} else if (bpType.equals("weapon")) {
			WeaponSpecAPI spec = buildWeaponPicker().pick();
			if (spec == null) return null;
			return new StockEntry(Kind.WEAPON_BP, spec.getWeaponId(), 1);
		} else {
			FighterWingSpecAPI spec = buildFighterPicker().pick();
			if (spec == null) return null;
			return new StockEntry(Kind.FIGHTER_BP, spec.getId(), 1);
		}
	}

	private WeightedRandomPicker<WeaponSpecAPI> buildWeaponPicker() {
		WeightedRandomPicker<WeaponSpecAPI> picker = new WeightedRandomPicker<WeaponSpecAPI>();
		for (WeaponSpecAPI spec : Global.getSettings().getAllWeaponSpecs()) {
			if (spec.getBaseValue() <= 0f) continue;
			if (spec.hasTag(Tags.WEAPON_NO_SELL) || spec.hasTag(Tags.NO_DROP) || spec.hasTag(Tags.RESTRICTED)) continue;
			if (!isSellableWeaponType(spec.getType())) continue;
			if (spec.getAIHints().contains(com.fs.starfarer.api.combat.WeaponAPI.AIHints.SYSTEM)) continue;
			if (ExchangeBlacklist.isBlacklisted(spec.getWeaponId())) continue;
			picker.add(spec, rarityWeight(spec.getBaseValue()));
		}
		return picker;
	}

	private WeightedRandomPicker<FighterWingSpecAPI> buildFighterPicker() {
		WeightedRandomPicker<FighterWingSpecAPI> picker = new WeightedRandomPicker<FighterWingSpecAPI>();
		for (FighterWingSpecAPI spec : Global.getSettings().getAllFighterWingSpecs()) {
			if (!spec.isRegularFighter()) continue;
			if (spec.getBaseValue() <= 0f) continue;
			if (spec.hasTag(Tags.WING_NO_DROP) || spec.hasTag(Tags.WING_NO_SELL) || spec.hasTag(Tags.RESTRICTED)) continue;
			if (ExchangeBlacklist.isBlacklisted(spec.getId())) continue;
			picker.add(spec, rarityWeight(spec.getBaseValue()));
		}
		return picker;
	}

	private WeightedRandomPicker<ShipHullSpecAPI> buildShipBlueprintPicker() {
		WeightedRandomPicker<ShipHullSpecAPI> picker = new WeightedRandomPicker<ShipHullSpecAPI>();
		for (ShipHullSpecAPI spec : Global.getSettings().getAllShipHullSpecs()) {
			if (!spec.isBaseHull()) continue;
			if (spec.getBaseValue() <= 0f) continue;
			if (spec.hasTag(Tags.NO_BP_DROP) || spec.hasTag(Tags.RESTRICTED)) continue;
			java.util.EnumSet<ShipHullSpecAPI.ShipTypeHints> bpHints = spec.getHints();
			if (bpHints.contains(ShipHullSpecAPI.ShipTypeHints.MODULE)
					|| bpHints.contains(ShipHullSpecAPI.ShipTypeHints.STATION)
					|| bpHints.contains(ShipHullSpecAPI.ShipTypeHints.UNDER_PARENT)
					|| bpHints.contains(ShipHullSpecAPI.ShipTypeHints.HIDE_IN_CODEX)
					|| bpHints.contains(ShipHullSpecAPI.ShipTypeHints.UNBOARDABLE)
					|| spec.hasTag("no_dealer")) continue;
			if (ExchangeBlacklist.isBlacklisted(spec.getHullId())) continue;
			picker.add(spec, rarityWeight(spec.getBaseValue() * BLUEPRINT_VALUE_MULT));
		}
		return picker;
	}

	private WeightedRandomPicker<HullModSpecAPI> buildHullModPicker() {
		WeightedRandomPicker<HullModSpecAPI> picker = new WeightedRandomPicker<HullModSpecAPI>();
		for (HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
			if (spec.isHidden() || spec.isAlwaysUnlocked()) continue;
			if (spec.getBaseValue() <= 0f) continue;
			if (spec.hasTag(Tags.HULLMOD_NO_DROP) || spec.hasTag(Tags.RESTRICTED)) continue;
			if (ExchangeBlacklist.isBlacklisted(spec.getId())) continue;
			picker.add(spec, rarityWeight(spec.getBaseValue()));
		}
		return picker;
	}

	private static float rarityWeight(float value) {
		return 1f / Math.max(value, RARITY_VALUE_FLOOR);
	}
}
