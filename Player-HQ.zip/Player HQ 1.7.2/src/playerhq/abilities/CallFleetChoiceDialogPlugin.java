package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import playerhq.modules.MilitaryWardModule;

import java.util.Map;

public class CallFleetChoiceDialogPlugin implements InteractionDialogPlugin {

	private static final String OPTION_RESUPPLY = "playerhq_call_fleet_resupply";
	private static final String OPTION_COURIER = "playerhq_call_fleet_courier";
	private static final String OPTION_CANCEL = "playerhq_call_fleet_cancel";

	private final SectorEntityToken station;

	private InteractionDialogAPI dialog;

	public CallFleetChoiceDialogPlugin(SectorEntityToken station) {
		this.station = station;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		TextPanelAPI text = dialog.getTextPanel();
		OptionPanelAPI options = dialog.getOptionPanel();

		dialog.setPromptText("Call Fleet");
		text.addPara("Choose which fleet to call out to you.");

		boolean resupplyActive = MilitaryWardModule.isResupplyFleetActive(station);
		boolean resupplyReady = MilitaryWardModule.hasResupplyBayBuilt(station) && !resupplyActive;
		options.addOption("Resupply Fleet", OPTION_RESUPPLY, resupplyReady
				? "Brings Supplies, Fuel, and Crew from the Player HQ's storage for you to take."
				: resupplyActive
						? "Currently " + MilitaryWardModule.getResupplyFleetStatusText(station) + "."
						: "Requires a Resupply Bay to be crewed in the Player HQ's Fleet HQ.");
		options.setEnabled(OPTION_RESUPPLY, resupplyReady);

		boolean courierActive = MilitaryWardModule.isCourierPickupFleetActive(station);
		boolean courierReady = MilitaryWardModule.hasCourierBayAvailableForPickup(station) && !courierActive;
		options.addOption("Courier Fleet", OPTION_COURIER, courierReady
				? "Comes to escort you -- hand it cargo and it'll be deposited into the Player HQ's storage "
						+ "as soon as the window closes."
				: courierActive
						? "Currently " + MilitaryWardModule.getCourierPickupStatusText(station) + "."
						: "Requires a Courier Bay to be crewed and idle in the Player HQ's Fleet HQ.");
		options.setEnabled(OPTION_COURIER, courierReady);

		options.addOption("Cancel", OPTION_CANCEL);
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();

		if (OPTION_RESUPPLY.equals(optionData)) {
			if (MilitaryWardModule.dispatchResupplyFleet(station, playerFleet)) {
				Global.getSector().getCampaignUI().addMessage("The Resupply Fleet departs the Player HQ and starts "
						+ "heading your way.");
			}
			dialog.dismiss();
			return;
		}

		if (OPTION_COURIER.equals(optionData)) {
			if (MilitaryWardModule.dispatchCourierPickupFleet(station, playerFleet)) {
				Global.getSector().getCampaignUI().addMessage("The Courier Fleet departs the Player HQ and starts "
						+ "heading your way.");
			}
			dialog.dismiss();
			return;
		}

		dialog.dismissAsCancel();
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
