package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoPickerListener;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.util.Map;

public class CourierPickupTransferDialogPlugin implements InteractionDialogPlugin {

	private final SectorEntityToken station;
	private final CampaignFleetAPI courierFleet;
	private final Runnable onDismiss;
	private final CargoAPI pending = Global.getFactory().createCargo(true);

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;

	public CourierPickupTransferDialogPlugin(SectorEntityToken station, CampaignFleetAPI courierFleet, Runnable onDismiss) {
		this.station = station;
		this.courierFleet = courierFleet;
		this.onDismiss = onDismiss;
	}

	private static final String OPTION_DONE = "playerhq_courier_pickup_done";
	private static final String OPTION_CONFIRM_YES = "playerhq_courier_pickup_confirm_yes";
	private static final String OPTION_CONFIRM_NO = "playerhq_courier_pickup_confirm_no";

	private boolean pickerShown = false;

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		this.text = dialog.getTextPanel();

		text.addPara("Hand off cargo to the Courier Fleet -- it'll be deposited into the Player HQ's storage "
				+ "as soon as this window closes, even past the station's storage limits. Crew and marines "
				+ "over the station's limit are sold at their base price.");
		dialog.getOptionPanel().addOption("Done", OPTION_DONE);
		dialog.setOptionOnEscape("Done", OPTION_DONE);
	}

	private void showPicker() {
		final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		CargoAPI offer = Global.getFactory().createCargo(false);
		for (CargoStackAPI stack : playerFleet.getCargo().getStacksCopy()) {
			if (stack == null || stack.isNull()) continue;
			offer.addFromStack(stack);
		}
		if (playerFleet.getCargo().getCrew() > 0) offer.addCrew(playerFleet.getCargo().getCrew());
		if (playerFleet.getCargo().getMarines() > 0) offer.addMarines(playerFleet.getCargo().getMarines());
		offer.sort();

		dialog.showCargoPickerDialog("Your Fleet", "Give", "Done", true, 310f, offer, new CargoPickerListener() {
			@Override
			public void pickedCargo(CargoAPI picked) {
				CargoAPI fitted = fitToCourier(picked);
				for (CargoStackAPI stack : fitted.getStacksCopy()) {
					if (stack == null || stack.isNull()) continue;
					playerFleet.getCargo().removeItems(stack.getType(), stack.getData(), stack.getSize());
				}
				if (fitted.getCrew() > 0) playerFleet.getCargo().removeCrew(fitted.getCrew());
				if (fitted.getMarines() > 0) playerFleet.getCargo().removeMarines(fitted.getMarines());
				pending.addAll(fitted);

				text.addPara("Transfer complete.");
				askToFinish();
			}

			@Override
			public void cancelledCargoSelection() {
				askToFinish();
			}

			@Override
			public void recreateTextPanel(TooltipMakerAPI panel, CargoAPI cargo, CargoStackAPI pickedUp,
					boolean pickedUpFromSource, CargoAPI combined) {
				float free = playerhq.modules.MilitaryWardModule.getPickupHandoffRoom(courierFleet, pending);
				float used = 0f;
				for (CargoStackAPI st : combined.getStacksCopy()) {
					if (st == null || st.isNull() || st.isFuelStack()) continue;
					used += st.getCargoSpace();
				}
				boolean over = used > free + 0.01f;
				panel.addPara("Hand off cargo to the Courier Fleet. It'll be deposited into the Player HQ's storage "
						+ "as soon as this window closes, even past the station's storage limits. Crew and marines "
						+ "over the station's limit are sold at their base price.", 0f);
				panel.addPara("Cargo space: %s / %s", 10f,
						over ? Misc.getNegativeHighlightColor() : Misc.getHighlightColor(),
						"" + (int) used, "" + (int) free);
				if (over) {
					panel.addPara("Anything over the Courier Fleet's free space will stay with you.", 3f,
							Misc.getNegativeHighlightColor(), "stay with you");
				}
			}
		});
	}

	private void askToFinish() {
		dialog.getOptionPanel().clearOptions();
		text.addPara("Are you sure? Once you accept, this window will close and the Courier Fleet will head "
				+ "back to the HQ.");
		dialog.getOptionPanel().addOption("Yes, send the Courier Fleet back", OPTION_CONFIRM_YES);
		dialog.getOptionPanel().addOption("No, go back", OPTION_CONFIRM_NO);
		dialog.setOptionOnEscape("No, go back", OPTION_CONFIRM_NO);
	}

	private CargoAPI fitToCourier(CargoAPI picked) {
		return playerhq.modules.MilitaryWardModule.fitPickupHandoff(station, courierFleet, picked, pending);
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (OPTION_DONE.equals(optionData)) {
			askToFinish();
		} else if (OPTION_CONFIRM_YES.equals(optionData)) {
			playerhq.modules.MilitaryWardModule.depositPickupHandoff(station, pending);
			dialog.dismiss();
			if (onDismiss != null) onDismiss.run();
		} else if (OPTION_CONFIRM_NO.equals(optionData)) {
			dialog.getOptionPanel().clearOptions();
			dialog.getOptionPanel().addOption("Done", OPTION_DONE);
			dialog.setOptionOnEscape("Done", OPTION_DONE);
			pickerShown = false;
		}
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) {
		if (!pickerShown) {
			pickerShown = true;
			showPicker();
		}
	}

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
