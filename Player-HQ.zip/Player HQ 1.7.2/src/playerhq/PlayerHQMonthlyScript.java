package playerhq;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignClockAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MonthlyReport;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.MarketPlaceModule;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;
import playerhq.util.PlayerHQUtils;

public class PlayerHQMonthlyScript implements EveryFrameScript {

	private int lastCheckedDay = -1;
	private int lastProductionCheckDay = -1;

	private boolean done = false;

	@Override
	public boolean isDone() {
		return done;
	}

	@Override
	public boolean runWhilePaused() {
		return false;
	}

	@Override
	public void advance(float amount) {
		SectorEntityToken station = PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
		if (station == null) {
			done = true;
			return;
		}

		MilitaryWardModule.advanceResupplyFleetRealtime(station);
		MilitaryWardModule.advanceMiningFleetsRealtime(station);
		MilitaryWardModule.advanceSalvageFleetsRealtime(station);
		MilitaryWardModule.advanceTrainingExpeditionsRealtime(station);
		MilitaryWardModule.advanceCourierFleetsRealtime(station);
		MilitaryWardModule.advanceCourierPickupFleetRealtime(station);
		MilitaryWardModule.advanceTradeFleetRealtime(station);

		CampaignClockAPI clock = Global.getSector().getClock();
		int day = clock.getDay();

		if (day != lastProductionCheckDay) {
			AssemblyBayModule.advanceProduction(station);
			MilitaryWardModule.enforceCap(station);
			MilitaryWardModule.advanceTrainingExpeditionDaily(station);
			MilitaryWardModule.advanceMiningFleetsDaily(station);
			MilitaryWardModule.advanceSalvageFleetsDaily(station);
			MilitaryWardModule.advanceCourierFleetsDaily(station);
			MilitaryWardModule.advanceCourierPickupFleetDaily(station);
			MilitaryWardModule.advancePatrolFleetDaily(station);
			MilitaryWardModule.advanceResupplyFleetDaily(station);
			MilitaryWardModule.advanceTradeFleetDaily(station);
			MilitaryWardModule.launchTradeFleetIfDue(station);
			// Expedition bays now redeploy as soon as they're idle (rather than waiting for the
			// start of the month), so an Expedition Fleet that returns early can head right back out.
			MilitaryWardModule.launchTrainingExpeditionIfDue(station);
			MilitaryWardModule.launchMiningFleetsIfReady(station);
			MilitaryWardModule.launchSalvageFleetsIfReady(station);
			lastProductionCheckDay = day;
		}

		if (day == 1 && lastCheckedDay != 1) {
			runMonthlyTick(station);
		}

		lastCheckedDay = day;
	}

	private void runMonthlyTick(SectorEntityToken station) {
		RecreationalHubModule.payFusionLampUpkeep(station);
		HydroponicsHubModule.payLampUpkeep(station);

		MiningHangarModule.MiningResult miningResult = null;
		if (MiningHangarModule.isBuilt(station)) {
			miningResult = MiningHangarModule.collectResources(station);
		}

		IndustrialHubModule.IndustrialHubResult industrialResult = null;
		if (IndustrialHubModule.isBuilt(station)) {
			industrialResult = IndustrialHubModule.process(station);
		}

		HydroponicsHubModule.HydroponicsResult hydroponicsResult = null;
		if (HydroponicsHubModule.isBuilt(station)) {
			hydroponicsResult = HydroponicsHubModule.produce(station);
		}

		if (AssemblyBayModule.isBuilt(station)) {
			AssemblyBayModule.accumulateMonthly(station);
		}

		float crewStipend = 0f;
		float marineStipend = 0f;
		float[] stipends = MilitaryWardModule.isBuilt(station)
				? MilitaryWardModule.accumulateMonthly(station)
				: MilitaryWardModule.computeStipends(station);
		crewStipend = stipends[0];
		marineStipend = stipends[1];

		playerhq.modules.StoredShipRestoration.runMonthly(station);

		float upkeepCharged = ConstructPlayerHQAbility.chargeMonthlyUpkeep(station);

		float recreationIncome = 0f;
		if (RecreationalHubModule.isBuilt(station)) {
			recreationIncome = RecreationalHubModule.collectIncome(station);
		}

		float marketPlaceIncome = 0f;
		String soldShipName = null;
		float shipSaleIncome = 0f;
		if (MarketPlaceModule.isBuilt(station)) {
			if (station.getMarket() != null && station.getMarket().hasSubmarket(MarketPlaceModule.BLACKMARKET_SUBMARKET_ID)) {
				try {
					station.getMarket().getSubmarket(MarketPlaceModule.BLACKMARKET_SUBMARKET_ID).getPlugin().updateCargoPrePlayerInteraction();
				} catch (Throwable t) {
					Global.getLogger(PlayerHQMonthlyScript.class).warn("Exchange monthly restock failed", t);
				}
			}
			marketPlaceIncome = MarketPlaceModule.collectMerchantIncome(station);

			MarketPlaceModule.RandomShipSaleResult shipSale = MarketPlaceModule.sellRandomStoredShip(station);
			if (shipSale != null) {
				shipSaleIncome = shipSale.credits;
				soldShipName = shipSale.shipName;
				marketPlaceIncome += shipSaleIncome;
			}
		}

		reportToIncomeTab(recreationIncome + marketPlaceIncome, upkeepCharged, crewStipend, marineStipend);

		java.util.List<String> deliveredShips = AssemblyBayModule.getDeliveredShipsThisMonth(station);
		java.util.List<String> deliveredWeapons = AssemblyBayModule.getDeliveredWeaponsThisMonth(station);
		java.util.List<String> deliveredWings = AssemblyBayModule.getDeliveredWingsThisMonth(station);
		java.util.List<String> trainingExpeditionLoot = MilitaryWardModule.getTrainingExpeditionLootThisMonth(station);
		java.util.List<String> miningFleetHaul = MilitaryWardModule.getMiningFleetHaulThisMonth(station);
		java.util.List<String> salvageFleetHaul = MilitaryWardModule.getSalvageFleetHaulThisMonth(station);

		float traderEarned = MilitaryWardModule.getTraderEarnedThisMonth(station);
		java.util.List<String> traderBought = MilitaryWardModule.getTraderBoughtThisMonth(station);

		PlayerHQMonthlyReportIntel.report(station, miningResult, industrialResult, hydroponicsResult,
				recreationIncome, marketPlaceIncome, upkeepCharged, deliveredShips, deliveredWeapons, deliveredWings,
				trainingExpeditionLoot, miningFleetHaul, salvageFleetHaul, soldShipName, shipSaleIncome,
				traderEarned, traderBought);

		MilitaryWardModule.clearTraderLogThisMonth(station);

		AssemblyBayModule.clearDeliveredThisMonth(station);
		MilitaryWardModule.clearTrainingExpeditionLootThisMonth(station);
		MilitaryWardModule.clearMiningFleetHaulThisMonth(station);
		MilitaryWardModule.clearSalvageFleetHaulThisMonth(station);

		MilitaryWardModule.launchTrainingExpeditionIfDue(station);
		MilitaryWardModule.updateMiningLaunchGate(station);
	}

	private void reportToIncomeTab(float income, float expense, float crewStipend, float marineStipend) {
		if (income <= 0f && expense <= 0f && crewStipend <= 0f && marineStipend <= 0f) return;

		MonthlyReport report = SharedData.getData().getCurrentReport();
		MonthlyReport.FDNode fleetNode = report.getNode(MonthlyReport.FLEET);
		if (fleetNode.name == null) {
			fleetNode.name = "Fleet";
			fleetNode.custom = MonthlyReport.FLEET;
			fleetNode.tooltipCreator = report.getMonthlyReportTooltip();
		}

		MonthlyReport.FDNode phqNode = report.getNode(fleetNode, "node_id_playerhq");
		phqNode.name = "Player HQ";
		phqNode.icon = Global.getSettings().getSpriteName("income_report", "generic_income");
		phqNode.tooltipCreator = new com.fs.starfarer.api.ui.TooltipMakerAPI.TooltipCreator() {
			@Override
			public boolean isTooltipExpandable(Object tooltipParam) {
				return false;
			}

			@Override
			public float getTooltipWidth(Object tooltipParam) {
				return 450f;
			}

			@Override
			public void createTooltip(com.fs.starfarer.api.ui.TooltipMakerAPI tooltip, boolean expanded, Object tooltipParam) {
				tooltip.addPara("Player HQ's income and expenses", 0f);
			}
		};
		phqNode.income += income;
		phqNode.upkeep += expense;

		reportStipendNode(report, phqNode, "node_id_playerhq_crew", "Crew", crewStipend,
				"Monthly stipend paid for the Crew stored at the station.");
		reportStipendNode(report, phqNode, "node_id_playerhq_marines", "Marines", marineStipend,
				"Monthly stipend paid for the Marines stored at the station.");
	}

	private void reportStipendNode(MonthlyReport report, MonthlyReport.FDNode parent, String id, String name,
			float amount, final String description) {
		if (amount <= 0f) return;

		MonthlyReport.FDNode node = report.getNode(parent, id);
		node.name = name;
		node.icon = Global.getSettings().getSpriteName("income_report", "generic_income");
		node.tooltipCreator = new com.fs.starfarer.api.ui.TooltipMakerAPI.TooltipCreator() {
			@Override
			public boolean isTooltipExpandable(Object tooltipParam) {
				return false;
			}

			@Override
			public float getTooltipWidth(Object tooltipParam) {
				return 450f;
			}

			@Override
			public void createTooltip(com.fs.starfarer.api.ui.TooltipMakerAPI tooltip, boolean expanded, Object tooltipParam) {
				tooltip.addPara(description, 0f);
			}
		};
		node.upkeep += amount;
	}
}
