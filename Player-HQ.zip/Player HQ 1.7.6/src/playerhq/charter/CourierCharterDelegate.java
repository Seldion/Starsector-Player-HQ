package playerhq.charter;

import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.PositionAPI;
import com.fs.starfarer.api.ui.TextFieldAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CourierCharterDelegate extends BaseCustomUIPanelPlugin implements CustomDialogDelegate {

	public interface Listener {
		void onFinished();
	}

	public static final float WIDTH = 980f;
	public static final float HEIGHT = 640f;

	private static final String FONT = "graphics/fonts/victor14.fnt";
	private static final int MAX_RESULTS = 80;

	private static final int V_MAIN = 0;
	private static final int V_PICK_SOURCE = 1;
	private static final int V_PICK_DEST = 2;
	private static final int V_EDITOR = 3;

	private abstract static class Action {
		abstract void run();
	}

	private static class AmountRow {
		TextFieldAPI field;
		String last;
		CharterItem item;
	}

	private final SectorEntityToken station;
	private final Listener listener;
	private CustomPanelAPI panel;
	private PositionAPI panelPosition;
	private boolean finished = false;

	private int view = V_MAIN;
	private CourierRequest editing;
	private CourierRequest copySource;
	private String category = CharterCatalog.RESOURCE;
	private String lastQuery = "";

	private CustomPanelAPI viewHolder;
	private CustomPanelAPI leftHolder;
	private CustomPanelAPI rightHolder;
	private CustomPanelAPI allHolder;

	private final Map<ButtonAPI, Action> viewActions = new LinkedHashMap<ButtonAPI, Action>();
	private final Map<ButtonAPI, Action> leftActions = new LinkedHashMap<ButtonAPI, Action>();
	private final Map<ButtonAPI, Action> rightActions = new LinkedHashMap<ButtonAPI, Action>();
	private final Map<ButtonAPI, String> catButtons = new LinkedHashMap<ButtonAPI, String>();
	private final Map<ButtonAPI, Action> allActions = new LinkedHashMap<ButtonAPI, Action>();
	private final List<AmountRow> amountRows = new ArrayList<AmountRow>();

	private TextFieldAPI searchField;
	private String pendingSource;

	public CourierCharterDelegate(SectorEntityToken station, Listener listener) {
		this.station = station;
		this.listener = listener;
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		this.panel = panel;
		showMain();
	}

	private Color base() { return Misc.getBasePlayerColor(); }
	private Color dark() { return Misc.getDarkPlayerColor(); }
	private Color bright() { return Misc.getBrightPlayerColor(); }

	private ButtonAPI label(TooltipMakerAPI t, String text, float w, float h, float pad) {
		ButtonAPI b = t.addAreaCheckbox(text, null, base(), dark(), bright(), w, h, pad);
		b.setClickable(false);
		return b;
	}

	private ButtonAPI button(TooltipMakerAPI t, String text, float w, float h, float pad, Map<ButtonAPI, Action> map, Action action) {
		ButtonAPI b = t.addAreaCheckbox(text, null, base(), dark(), bright(), w, h, pad);
		map.put(b, action);
		return b;
	}

	private void clearView() {
		if (viewHolder != null) panel.removeComponent(viewHolder);
		if (leftHolder != null) panel.removeComponent(leftHolder);
		if (rightHolder != null) panel.removeComponent(rightHolder);
		if (allHolder != null) panel.removeComponent(allHolder);
		viewHolder = null;
		leftHolder = null;
		rightHolder = null;
		allHolder = null;
		viewActions.clear();
		leftActions.clear();
		rightActions.clear();
		catButtons.clear();
		allActions.clear();
		amountRows.clear();
		searchField = null;
	}

	private String marketLabel(String marketId) {
		MarketAPI m = CourierCharterData.getMarket(marketId);
		return m == null ? "Unavailable colony" : CourierCharterData.describeMarket(m, station);
	}

	private List<String> wrap(String text, int max) {
		List<String> lines = new ArrayList<String>();
		String[] parts = text.split(", ");
		StringBuilder line = new StringBuilder();
		for (int i = 0; i < parts.length; i++) {
			String piece = parts[i] + (i < parts.length - 1 ? "," : "");
			if (line.length() > 0 && line.length() + 1 + piece.length() > max) {
				lines.add(line.toString());
				line = new StringBuilder();
			}
			if (line.length() > 0) line.append(" ");
			line.append(piece);
		}
		if (line.length() > 0) lines.add(line.toString());
		if (lines.size() > 3) {
			List<String> cut = new ArrayList<String>(lines.subList(0, 3));
			cut.set(2, cut.get(2) + " ...");
			return cut;
		}
		return lines;
	}

	private void showMain() {
		clearView();
		view = V_MAIN;
		pendingSource = null;
		copySource = null;
		final CourierCharterState state = CourierCharterData.getState();
		float w = WIDTH - 20f;
		float h = HEIGHT - 20f;
		float listTop = 96f;
		float listH = h - listTop - 50f;

		viewHolder = panel.createCustomPanel(w, h, new BaseCustomUIPanelPlugin());

		TooltipMakerAPI header = viewHolder.createUIElement(w, 90f, false);
		header.addSectionHeading("Courier Charters", Alignment.MID, 0f);
		header.addPara("Each line sends a Courier Fleet to collect from a pickup location and deliver to a drop-off location. "
				+ "Whenever a Courier Fleet is free, and once every day, the first line that has something to move is run. "
				+ "A line already being worked by a Courier Fleet is skipped. Click the box in front of a line to mark it "
				+ "with an X and suspend it.", 6f);
		viewHolder.addUIElement(header).inTL(0f, 0f);

		TooltipMakerAPI list = viewHolder.createUIElement(w, listH, true);
		list.addSectionHeading("Charter Lines (" + state.requests.size() + ")", Alignment.MID, 0f);
		if (state.requests.isEmpty()) {
			list.addPara("No lines yet. Add a line, choose where to pick up and where to deliver, then choose what to move.",
					Misc.getGrayColor(), 8f);
		}
		ButtonAPI prev = null;
		for (final CourierRequest r : new ArrayList<CourierRequest>(state.requests)) {
			String status = r.suspended ? "Suspended" : (r.inTransit ? "Courier Fleet out" : (r.status == null ? "" : r.status));
			ButtonAPI x = button(list, r.suspended ? "X" : " ", 28f, 28f, 8f, viewActions, new Action() {
				void run() {
					r.suspended = !r.suspended;
					r.status = r.suspended ? "Suspended" : "Resumed";
					showMain();
				}
			});
			if (prev != null) x.getPosition().belowLeft(prev, 10f);
			ButtonAPI name = label(list, "Moving goods from " + marketLabel(r.sourceMarketId) + " to " + marketLabel(r.destMarketId)
					+ "   [" + status + "]", w - 410f, 28f, 0f);
			name.getPosition().rightOfMid(x, 6f);
			prev = x;
			ButtonAPI edit = button(list, "Edit", 60f, 28f, 0f, viewActions, new Action() {
				void run() {
					showEditor(r);
				}
			});
			edit.getPosition().rightOfMid(name, 6f);
			ButtonAPI copy = button(list, "Copy", 60f, 28f, 0f, viewActions, new Action() {
				void run() {
					copySource = r;
					showMarketList(true);
				}
			});
			copy.getPosition().rightOfMid(edit, 4f);
			ButtonAPI up = button(list, "Up", 40f, 28f, 0f, viewActions, new Action() {
				void run() {
					CourierCharterData.move(r, -1);
					showMain();
				}
			});
			up.getPosition().rightOfMid(copy, 4f);
			ButtonAPI down = button(list, "Down", 52f, 28f, 0f, viewActions, new Action() {
				void run() {
					CourierCharterData.move(r, 1);
					showMain();
				}
			});
			down.getPosition().rightOfMid(up, 3f);
			ButtonAPI rm = button(list, "Remove", 76f, 28f, 0f, viewActions, new Action() {
				void run() {
					CourierCharterData.getState().requests.remove(r);
					showMain();
				}
			});
			rm.getPosition().rightOfMid(down, 4f);
			for (String line : wrap(CourierCharterData.summarize(r), 120)) {
				ButtonAPI l = label(list, line, w - 60f, 22f, 0f);
				l.getPosition().belowLeft(prev, 2f);
				prev = l;
			}
		}
		viewHolder.addUIElement(list).inTL(0f, listTop);

		TooltipMakerAPI add = viewHolder.createUIElement(w, 34f, false);
		button(add, "Add Line", 160f, 28f, 2f, viewActions, new Action() {
			void run() {
				showMarketList(true);
			}
		});
		viewHolder.addUIElement(add).inTL(0f, h - 40f);

		panel.addComponent(viewHolder).inTL(10f, 10f);
	}

	private void showMarketList(final boolean pickingSource) {
		clearView();
		view = pickingSource ? V_PICK_SOURCE : V_PICK_DEST;
		float w = WIDTH - 20f;
		float h = HEIGHT - 20f;

		viewHolder = panel.createCustomPanel(w, h, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI header = viewHolder.createUIElement(w, 70f, false);
		String copying = copySource == null ? "" : "Copying the line from " + marketLabel(copySource.sourceMarketId)
				+ " to " + marketLabel(copySource.destMarketId) + ". ";
		header.addSectionHeading(pickingSource ? "Choose the Pickup Location" : "Choose the Drop-off Location", Alignment.MID, 0f);
		header.addPara(pickingSource
				? copying + "Select the location the Courier Fleet should collect goods from."
				: copying + "Moving goods from " + marketLabel(pendingSource) + ". Select the location the goods should be delivered to.", 6f);
		viewHolder.addUIElement(header).inTL(0f, 0f);

		final List<MarketAPI> available = new ArrayList<MarketAPI>();
		for (MarketAPI m : CourierCharterData.getCandidateMarkets(station)) {
			if (!pickingSource && m.getId().equals(pendingSource)) continue;
			available.add(m);
		}

		TooltipMakerAPI list = viewHolder.createUIElement(560f, h - 140f, true);
		if (available.isEmpty()) {
			list.addPara("No more locations are available.", Misc.getGrayColor(), 8f);
		}
		ButtonAPI prev = null;
		for (final MarketAPI m : available) {
			ButtonAPI b = button(list, CourierCharterData.describeMarket(m, station), 520f, 28f, 4f, viewActions, new Action() {
				void run() {
					if (pickingSource) {
						pendingSource = m.getId();
						showMarketList(false);
					} else {
						CourierRequest r = CourierCharterData.createRequest(pendingSource, m.getId());
						if (copySource != null) {
							for (CharterItem item : copySource.items) r.items.add(item.copy());
							r.allWeapons = copySource.allWeapons;
							r.allWings = copySource.allWings;
							r.allSpecials = copySource.allSpecials;
							r.allShips = copySource.allShips;
							r.allResources = copySource.allResources;
							r.allHullmods = copySource.allHullmods;
							copySource = null;
						}
						showEditor(r);
					}
				}
			});
			if (prev != null) b.getPosition().belowLeft(prev, 4f);
			prev = b;
		}
		viewHolder.addUIElement(list).inTL(0f, 80f);

		TooltipMakerAPI foot = viewHolder.createUIElement(w, 34f, false);
		button(foot, "Back", 120f, 28f, 2f, viewActions, new Action() {
			void run() {
				if (pickingSource) showMain();
				else showMarketList(true);
			}
		});
		viewHolder.addUIElement(foot).inTL(0f, h - 40f);

		panel.addComponent(viewHolder).inTL(10f, 10f);
	}

	private void showEditor(CourierRequest request) {
		clearView();
		view = V_EDITOR;
		editing = request;
		category = CharterCatalog.RESOURCE;
		lastQuery = "";

		float w = WIDTH - 20f;
		float h = HEIGHT - 20f;
		viewHolder = panel.createCustomPanel(w, h, new BaseCustomUIPanelPlugin());

		TooltipMakerAPI header = viewHolder.createUIElement(w, 60f, false);
		header.addSectionHeading("Moving goods from " + marketLabel(request.sourceMarketId) + " to " + marketLabel(request.destMarketId), Alignment.MID, 0f);
		header.addPara("Pick what should be moved and how many of each the drop-off location should hold. Couriers carry as much as they can fit on every trip until the amount is reached or the pickup has no more.", 6f);
		viewHolder.addUIElement(header).inTL(0f, 0f);

		TooltipMakerAPI search = viewHolder.createUIElement(440f, 34f, false);
		searchField = search.addTextField(300f, 28f, FONT, 4f);
		searchField.setMaxChars(40);
		viewHolder.addUIElement(search).inTL(0f, 70f);

		TooltipMakerAPI cats = viewHolder.createUIElement(450f, 34f, false);
		ButtonAPI prev = null;
		for (final String cat : CharterCatalog.CATEGORIES) {
			ButtonAPI b = cats.addAreaCheckbox(cat, null, base(), dark(), bright(), 70f, 26f, prev == null ? 4f : 0f);
			if (prev != null) b.getPosition().rightOfMid(prev, 4f);
			b.setChecked(cat.equals(category));
			catButtons.put(b, cat);
			prev = b;
		}
		viewHolder.addUIElement(cats).inTL(0f, 106f);

		TooltipMakerAPI foot = viewHolder.createUIElement(w, 34f, false);
		button(foot, "Back", 120f, 28f, 2f, viewActions, new Action() {
			void run() {
				showMain();
			}
		});
		viewHolder.addUIElement(foot).inTL(0f, h - 40f);

		panel.addComponent(viewHolder).inTL(10f, 10f);
		buildAllRow();
		buildLeftList();
		buildRightList();
		if (searchField != null) searchField.grabFocus();
	}

	private String allLabel() {
		if (CharterCatalog.WEAPON.equals(category)) return "All Weapons";
		if (CharterCatalog.WING.equals(category)) return "All Wings";
		if (CharterCatalog.SPECIAL.equals(category)) return "All Special Items";
		if (CharterCatalog.SHIP.equals(category)) return "All Ships";
		if (CharterCatalog.RESOURCE.equals(category)) return "All Resources";
		if (CharterCatalog.HULLMOD.equals(category)) return "All Hullmods";
		return null;
	}

	private boolean allFlag() {
		if (CharterCatalog.WEAPON.equals(category)) return editing.allWeapons;
		if (CharterCatalog.WING.equals(category)) return editing.allWings;
		if (CharterCatalog.SHIP.equals(category)) return editing.allShips;
		if (CharterCatalog.RESOURCE.equals(category)) return editing.allResources;
		if (CharterCatalog.HULLMOD.equals(category)) return editing.allHullmods;
		return editing.allSpecials;
	}

	private void setAllFlag(boolean value) {
		if (CharterCatalog.WEAPON.equals(category)) editing.allWeapons = value;
		else if (CharterCatalog.WING.equals(category)) editing.allWings = value;
		else if (CharterCatalog.SPECIAL.equals(category)) editing.allSpecials = value;
		else if (CharterCatalog.SHIP.equals(category)) editing.allShips = value;
		else if (CharterCatalog.RESOURCE.equals(category)) editing.allResources = value;
		else if (CharterCatalog.HULLMOD.equals(category)) editing.allHullmods = value;
	}

	private void buildAllRow() {
		if (allHolder != null) panel.removeComponent(allHolder);
		allHolder = null;
		allActions.clear();
		String text = allLabel();
		if (text == null) return;
		float w = 440f;
		allHolder = panel.createCustomPanel(w, 34f, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI t = allHolder.createUIElement(w, 34f, false);
		String caption = allFlag()
				? text + " added (everything held at the pickup location)"
				: "Add " + text + " (everything held at the pickup location)";
		button(t, caption, w - 10f, 28f, 2f, allActions, new Action() {
			void run() {
				setAllFlag(true);
				buildAllRow();
				buildRightList();
			}
		});
		allHolder.addUIElement(t).inTL(0f, 0f);
		panel.addComponent(allHolder).inTL(10f + 0f, 10f + 140f);
	}

	private void buildLeftList() {
		if (leftHolder != null) panel.removeComponent(leftHolder);
		leftActions.clear();
		float h = HEIGHT - 20f;
		float top = 180f;
		float listH = h - top - 50f;
		float w = 440f;
		leftHolder = panel.createCustomPanel(w, listH, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI t = leftHolder.createUIElement(w, listH, true);

		int[] total = new int[1];
		List<CharterCatalog.Entry> results = CharterCatalog.search(category, lastQuery, MAX_RESULTS, total);
		if (results.isEmpty()) {
			t.addPara("No matches.", Misc.getGrayColor(), 6f);
		} else if (total[0] > results.size()) {
			t.addPara("Showing " + results.size() + " of " + total[0] + ". Type in the search box to narrow the list.", Misc.getGrayColor(), 4f);
		}
		ButtonAPI prev = null;
		for (final CharterCatalog.Entry e : results) {
			ButtonAPI name = label(t, e.name, 330f, 28f, 4f);
			if (prev != null) name.getPosition().belowLeft(prev, 4f);
			prev = name;
			ButtonAPI add = button(t, "Add", 64f, 28f, 0f, leftActions, new Action() {
				void run() {
					addEntry(e);
				}
			});
			add.getPosition().rightOfMid(name, 6f);
		}
		leftHolder.addUIElement(t).inTL(0f, 0f);
		panel.addComponent(leftHolder).inTL(10f, 10f + top);
	}

	private void addEntry(CharterCatalog.Entry e) {
		for (CharterItem it : editing.items) {
			if (it.type.equals(e.type) && it.id.equals(e.id) && eq(it.data, e.data)) return;
		}
		int amount = CharterCatalog.RESOURCE.equals(e.category) ? 100 : 1;
		editing.items.add(e.toItem(amount));
		buildRightList();
	}

	private boolean eq(String a, String b) {
		return a == null ? b == null : a.equals(b);
	}

	private void buildRightList() {
		if (rightHolder != null) panel.removeComponent(rightHolder);
		rightActions.clear();
		amountRows.clear();
		float h = HEIGHT - 20f;
		float x = 470f;
		float top = 70f;
		float w = WIDTH - 20f - x;
		float listH = h - top - 50f;
		rightHolder = panel.createCustomPanel(w, listH, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI t = rightHolder.createUIElement(w, listH, true);
		t.addSectionHeading("Items to Move", Alignment.MID, 0f);
		boolean any = false;
		ButtonAPI prev = null;

		String[] flagNames = { "All Weapons", "All Wings", "All Special Items", "All Ships", "All Resources", "All Hullmods" };
		boolean[] flags = { editing.allWeapons, editing.allWings, editing.allSpecials, editing.allShips, editing.allResources, editing.allHullmods };
		for (int i = 0; i < flagNames.length; i++) {
			if (!flags[i]) continue;
			any = true;
			final int which = i;
			ButtonAPI name = label(t, flagNames[i], 260f, 28f, 6f);
			if (prev != null) name.getPosition().belowLeft(prev, 4f);
			prev = name;
			ButtonAPI rm = button(t, "Remove", 76f, 28f, 0f, rightActions, new Action() {
				void run() {
					if (which == 0) editing.allWeapons = false;
					else if (which == 1) editing.allWings = false;
					else if (which == 2) editing.allSpecials = false;
					else if (which == 3) editing.allShips = false;
					else if (which == 4) editing.allResources = false;
					else editing.allHullmods = false;
					buildAllRow();
					buildRightList();
				}
			});
			rm.getPosition().rightOfMid(name, 6f);
		}

		for (final CharterItem it : new ArrayList<CharterItem>(editing.items)) {
			any = true;
			ButtonAPI name = label(t, it.name, 150f, 28f, 6f);
			if (prev != null) name.getPosition().belowLeft(prev, 4f);
			prev = name;
			final AmountRow ar = new AmountRow();
			ar.item = it;
			ButtonAPI m10 = button(t, "-10", 38f, 28f, 0f, rightActions, new Action() {
				void run() {
					adjust(ar, -10);
				}
			});
			m10.getPosition().rightOfMid(name, 6f);
			ButtonAPI m1 = button(t, "-1", 30f, 28f, 0f, rightActions, new Action() {
				void run() {
					adjust(ar, -1);
				}
			});
			m1.getPosition().rightOfMid(m10, 3f);
			ar.field = t.addTextField(58f, 28f, FONT, 0f);
			ar.field.setMaxChars(6);
			ar.field.setText(String.valueOf(it.amount));
			ar.last = String.valueOf(it.amount);
			ar.field.getPosition().rightOfMid(m1, 3f);
			ButtonAPI p1 = button(t, "+1", 30f, 28f, 0f, rightActions, new Action() {
				void run() {
					adjust(ar, 1);
				}
			});
			p1.getPosition().rightOfMid(ar.field, 3f);
			ButtonAPI p10 = button(t, "+10", 40f, 28f, 0f, rightActions, new Action() {
				void run() {
					adjust(ar, 10);
				}
			});
			p10.getPosition().rightOfMid(p1, 3f);
			ButtonAPI p100 = button(t, "+100", 48f, 28f, 0f, rightActions, new Action() {
				void run() {
					adjust(ar, 100);
				}
			});
			p100.getPosition().rightOfMid(p10, 3f);
			ButtonAPI rm = button(t, "X", 30f, 28f, 0f, rightActions, new Action() {
				void run() {
					editing.items.remove(it);
					buildRightList();
				}
			});
			rm.getPosition().rightOfMid(p100, 6f);
			amountRows.add(ar);
		}
		if (!any) {
			t.addPara("No items chosen yet. Add items from the list on the left.", Misc.getGrayColor(), 8f);
		}
		rightHolder.addUIElement(t).inTL(0f, 0f);
		panel.addComponent(rightHolder).inTL(10f + x, 10f + top);
	}

	private void adjust(AmountRow ar, int delta) {
		ar.item.amount = Math.max(1, Math.min(999999, ar.item.amount + delta));
		ar.last = String.valueOf(ar.item.amount);
		ar.field.setText(ar.last);
	}

	private boolean poll(Map<ButtonAPI, Action> actions) {
		ButtonAPI hit = null;
		for (ButtonAPI b : actions.keySet()) {
			if (b.isChecked()) {
				hit = b;
				break;
			}
		}
		if (hit == null) return false;
		Action a = actions.get(hit);
		hit.setChecked(false);
		a.run();
		return true;
	}

	@Override
	public void advance(float amount) {
		if (panel == null) return;

		if (view == V_EDITOR) {
			for (AmountRow ar : amountRows) {
				String text = ar.field.getText() == null ? "" : ar.field.getText();
				if (!text.equals(ar.last)) {
					String digits = text.replaceAll("[^0-9]", "");
					if (!digits.equals(text)) ar.field.setText(digits);
					ar.last = digits;
					if (!digits.isEmpty()) {
						if (digits.length() > 6) digits = digits.substring(0, 6);
						ar.item.amount = Math.max(1, Integer.parseInt(digits));
					}
				}
			}
			if (searchField != null) {
				String q = searchField.getText() == null ? "" : searchField.getText();
				if (!q.equals(lastQuery)) {
					lastQuery = q;
					buildLeftList();
					return;
				}
			}
		}

		if (view == V_EDITOR) {
			for (Map.Entry<ButtonAPI, String> e : catButtons.entrySet()) {
				boolean selected = e.getValue().equals(category);
				if (e.getKey().isChecked() && !selected) {
					category = e.getValue();
					for (Map.Entry<ButtonAPI, String> o : catButtons.entrySet()) {
						o.getKey().setChecked(o.getValue().equals(category));
					}
					buildAllRow();
					buildLeftList();
					return;
				}
				if (!e.getKey().isChecked() && selected) e.getKey().setChecked(true);
			}
			if (poll(allActions)) return;
		}

		if (poll(viewActions)) return;
		if (poll(leftActions)) return;
		poll(rightActions);
	}

	@Override
	public void positionChanged(PositionAPI position) {
		this.panelPosition = position;
	}

	@Override
	public void renderBelow(float alphaMult) {
		if (panelPosition == null) return;
		Misc.renderQuad(panelPosition.getX(), panelPosition.getY(), panelPosition.getWidth(), panelPosition.getHeight(),
				Color.BLACK, 0.92f * alphaMult);
	}

	@Override
	public boolean hasCancelButton() {
		return false;
	}

	@Override
	public String getConfirmText() {
		return "Done";
	}

	@Override
	public String getCancelText() {
		return "Done";
	}

	private void finish() {
		if (finished) return;
		finished = true;
		if (view == V_EDITOR && editing != null && !editing.hasAnything()) {
			editing.status = "No items chosen yet";
		}
		playerhq.modules.CourierCharterEngine.dispatchAvailable(station);
		listener.onFinished();
	}

	@Override
	public void customDialogConfirm() {
		finish();
	}

	@Override
	public void customDialogCancel() {
		finish();
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return this;
	}
}
