package playerhq.charter;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;

import playerhq.shopping.CatalogItem;
import playerhq.shopping.ShopListCatalog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CharterCatalog {

	public static final String RESOURCE = "Resource";
	public static final String WEAPON = "Weapon";
	public static final String WING = "Wing";
	public static final String HULLMOD = "Hull Mod";
	public static final String SHIP = "Ship";
	public static final String SPECIAL = "Special";

	public static final String[] CATEGORIES = { RESOURCE, WEAPON, WING, HULLMOD, SHIP, SPECIAL };

	public static class Entry {
		public final String category;
		public final String type;
		public final String id;
		public final String data;
		public final String name;
		public final String searchKey;

		Entry(String category, String type, String id, String data, String name) {
			this.category = category;
			this.type = type;
			this.id = id;
			this.data = data;
			this.name = name;
			this.searchKey = name.toLowerCase();
		}

		public CharterItem toItem(int amount) {
			return new CharterItem(type, id, data, name, amount);
		}
	}

	private static List<Entry> cache = null;

	private static List<Entry> getAll() {
		if (cache != null) return cache;
		List<Entry> list = new ArrayList<Entry>();

		for (CommoditySpecAPI spec : Global.getSettings().getAllCommoditySpecs()) {
			if (spec == null || spec.isMeta()) continue;
			list.add(new Entry(RESOURCE, CargoAPI.CargoItemType.RESOURCES.name(), spec.getId(), null, spec.getName()));
		}

		for (CatalogItem item : ShopListCatalog.getAll()) {
			if (CatalogItem.WEAPON.equals(item.category)) {
				list.add(new Entry(WEAPON, CargoAPI.CargoItemType.WEAPONS.name(), item.id, null, item.name));
			} else if (CatalogItem.WING.equals(item.category)) {
				list.add(new Entry(WING, CargoAPI.CargoItemType.FIGHTER_CHIP.name(), item.id, null, item.name));
			} else if (CatalogItem.HULLMOD.equals(item.category)) {
				list.add(new Entry(HULLMOD, CargoAPI.CargoItemType.SPECIAL.name(), "modspec", item.id, item.name));
			} else if (CatalogItem.SHIP.equals(item.category)) {
				list.add(new Entry(SHIP, CharterItem.SHIP, item.id, null, item.name));
			}
		}

		for (SpecialItemSpecAPI spec : Global.getSettings().getAllSpecialItemSpecs()) {
			if (spec == null || spec.getId() == null) continue;
			String id = spec.getId();
			if (id.equals("modspec") || id.contains("_bp") || id.equals("tag_bp")) continue;
			if (spec.getName() == null || spec.getName().isEmpty()) continue;
			list.add(new Entry(SPECIAL, CargoAPI.CargoItemType.SPECIAL.name(), id, null, spec.getName()));
		}

		Collections.sort(list, new Comparator<Entry>() {
			public int compare(Entry a, Entry b) {
				return a.name.compareToIgnoreCase(b.name);
			}
		});
		cache = list;
		return list;
	}

	public static List<Entry> search(String category, String query, int max, int[] totalOut) {
		List<Entry> result = new ArrayList<Entry>();
		String[] tokens = query == null ? new String[0] : query.toLowerCase().trim().split("\\s+");
		int total = 0;
		for (Entry e : getAll()) {
			if (category != null && !category.equals(e.category)) continue;
			boolean ok = true;
			for (String token : tokens) {
				if (token.length() > 0 && !e.searchKey.contains(token)) {
					ok = false;
					break;
				}
			}
			if (!ok) continue;
			total++;
			if (result.size() < max) result.add(e);
		}
		if (totalOut != null && totalOut.length > 0) totalOut[0] = total;
		return result;
	}
}
