package playerhq.charter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CourierRequest implements Serializable {

	public int id;
	public String sourceMarketId;
	public String destMarketId;
	public List<CharterItem> items = new ArrayList<CharterItem>();
	public boolean allWeapons = false;
	public boolean allWings = false;
	public boolean allSpecials = false;
	public boolean allShips = false;
	public boolean allResources = false;
	public boolean allHullmods = false;
	public boolean suspended = false;
	public int daysLeft = 0;
	public boolean inTransit = false;
	public int runs = 0;
	public String status = "New line";

	public CourierRequest(int id, String sourceMarketId, String destMarketId) {
		this.id = id;
		this.sourceMarketId = sourceMarketId;
		this.destMarketId = destMarketId;
	}

	public boolean hasAnything() {
		return !items.isEmpty() || allWeapons || allWings || allSpecials || allShips || allResources || allHullmods;
	}
}
