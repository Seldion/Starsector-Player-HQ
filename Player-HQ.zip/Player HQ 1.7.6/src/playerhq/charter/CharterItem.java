package playerhq.charter;

import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;

import java.io.Serializable;

public class CharterItem implements Serializable {

	public static final String SHIP = "SHIP";

	public String type;
	public String id;
	public String data;
	public String name;
	public int amount;

	public CharterItem(String type, String id, String data, String name, int amount) {
		this.type = type;
		this.id = id;
		this.data = data;
		this.name = name;
		this.amount = amount;
	}

	public CharterItem copy() {
		return new CharterItem(type, id, data, name, amount);
	}

	public boolean isShip() {
		return SHIP.equals(type);
	}

	public CargoAPI.CargoItemType cargoType() {
		try {
			return CargoAPI.CargoItemType.valueOf(type);
		} catch (Throwable t) {
			return null;
		}
	}

	public Object cargoData() {
		if (isShip()) return null;
		if (CargoAPI.CargoItemType.SPECIAL.name().equals(type)) return new SpecialItemData(id, data);
		return id;
	}
}
