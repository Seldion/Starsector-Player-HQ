package playerhq.charter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CourierCharter implements Serializable {

	public static final int MIN_INTERVAL_DAYS = 10;
	public static final int DEFAULT_INTERVAL_DAYS = 10;

	public int id;
	public List<String> sourceMarketIds = new ArrayList<String>();
	public String destMarketId;
	public List<CharterItem> items = new ArrayList<CharterItem>();
	public boolean repeat = false;
	public boolean topUp = false;
	public int intervalDays = DEFAULT_INTERVAL_DAYS;
	public int daysLeft = 0;
	public boolean inTransit = false;
	public boolean done = false;
	public int runs = 0;
	public String status = "New charter";

	public CourierCharter(int id) {
		this.id = id;
	}
}
