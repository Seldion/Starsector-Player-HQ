package playerhq.charter;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;

import playerhq.modules.MilitaryWardModule;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class CourierCharterData {

	private static final String OLD_KEY = "$playerhq_courier_charters";
	private static final String OLD_NEXT_ID_KEY = "$playerhq_courier_charters_nextid";
	private static final String STATE_KEY = "$playerhq_courier_charter_state";

	public static CourierCharterState getState() {
		Map<String, Object> data = Global.getSector().getPersistentData();
		data.remove(OLD_KEY);
		data.remove(OLD_NEXT_ID_KEY);
		Object o = data.get(STATE_KEY);
		if (o instanceof CourierCharterState) {
			CourierCharterState existing = (CourierCharterState) o;
			migrate(existing);
			return existing;
		}
		CourierCharterState state = new CourierCharterState();
		data.put(STATE_KEY, state);
		return state;
	}

	private static void migrate(CourierCharterState state) {
		boolean needs = false;
		for (CourierRequest r : state.requests) {
			if (r.sourceMarketId == null) {
				needs = true;
				break;
			}
		}
		if (!needs) return;
		List<CourierRequest> converted = new ArrayList<CourierRequest>();
		for (CourierRequest old : state.requests) {
			if (old.sourceMarketId != null) {
				converted.add(old);
				continue;
			}
			for (String supplyId : state.supplyMarketIds) {
				if (supplyId == null || supplyId.equals(old.destMarketId)) continue;
				CourierRequest line = new CourierRequest(state.nextId++, supplyId, old.destMarketId);
				for (CharterItem item : old.items) line.items.add(item.copy());
				line.allWeapons = old.allWeapons;
				line.allWings = old.allWings;
				line.allSpecials = old.allSpecials;
				line.allShips = old.allShips;
				line.allResources = old.allResources;
				line.allHullmods = old.allHullmods;
				line.suspended = old.suspended || (state.suspendedSupplyIds != null && state.suspendedSupplyIds.contains(supplyId));
				converted.add(line);
			}
		}
		state.requests = converted;
		state.supplyMarketIds = new ArrayList<String>();
		if (state.suspendedSupplyIds != null) state.suspendedSupplyIds.clear();
	}

	public static boolean isSupplySuspended(String marketId) {
		CourierCharterState s = getState();
		return s.suspendedSupplyIds != null && s.suspendedSupplyIds.contains(marketId);
	}

	public static void setSupplySuspended(String marketId, boolean suspended) {
		CourierCharterState s = getState();
		if (s.suspendedSupplyIds == null) s.suspendedSupplyIds = new ArrayList<String>();
		s.suspendedSupplyIds.remove(marketId);
		if (suspended) s.suspendedSupplyIds.add(marketId);
	}

	public static CourierRequest findRequest(int id) {
		for (CourierRequest r : getState().requests) {
			if (r.id == id) return r;
		}
		return null;
	}

	public static CourierRequest createRequest(String sourceMarketId, String destMarketId) {
		CourierCharterState s = getState();
		CourierRequest r = new CourierRequest(s.nextId++, sourceMarketId, destMarketId);
		s.requests.add(r);
		return r;
	}

	public static void move(CourierRequest r, int delta) {
		List<CourierRequest> list = getState().requests;
		int i = list.indexOf(r);
		int j = i + delta;
		if (i < 0 || j < 0 || j >= list.size()) return;
		list.remove(i);
		list.add(j, r);
	}

	public static MarketAPI getMarket(String marketId) {
		if (marketId == null) return null;
		MarketAPI found = null;
		try {
			found = Global.getSector().getEconomy().getMarket(marketId);
		} catch (Throwable t) {
		}
		if (found != null) return found;
		try {
			SectorEntityToken station = playerhq.util.PlayerHQUtils.findFirstEntityWithTagAnywhere(playerhq.Ids.TAG_STATION);
			if (station != null && station.getMarket() != null && marketId.equals(station.getMarket().getId())) {
				return station.getMarket();
			}
		} catch (Throwable t) {
		}
		SectorEntityToken settlement = MilitaryWardModule.getRatSettlementEntity();
		if (settlement != null && settlement.getMarket() != null && marketId.equals(settlement.getMarket().getId())) {
			return settlement.getMarket();
		}
		return null;
	}

	public static boolean isUsableMarket(MarketAPI market, SectorEntityToken station) {
		if (market == null || market.getPrimaryEntity() == null) return false;
		if (market.getPrimaryEntity().getContainingLocation() == null) return false;
		if (station != null && station.getMarket() == market) return true;
		SectorEntityToken settlement = MilitaryWardModule.getRatSettlementEntity();
		if (settlement != null && settlement.getMarket() == market) return true;
		return market.isPlayerOwned();
	}

	public static List<MarketAPI> getCandidateMarkets(final SectorEntityToken station) {
		List<MarketAPI> result = new ArrayList<MarketAPI>();
		if (station != null && station.getMarket() != null) result.add(station.getMarket());
		for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
			if (market == null || !market.isPlayerOwned()) continue;
			if (market.getPrimaryEntity() == null || result.contains(market)) continue;
			result.add(market);
		}
		SectorEntityToken settlement = MilitaryWardModule.getRatSettlementEntity();
		if (settlement != null && settlement.getMarket() != null && !result.contains(settlement.getMarket())) {
			result.add(settlement.getMarket());
		}
		final MarketAPI hq = station != null ? station.getMarket() : null;
		Collections.sort(result, new Comparator<MarketAPI>() {
			public int compare(MarketAPI a, MarketAPI b) {
				if (a == hq) return b == hq ? 0 : -1;
				if (b == hq) return 1;
				return a.getName().compareToIgnoreCase(b.getName());
			}
		});
		return result;
	}

	public static String describeMarket(MarketAPI market, SectorEntityToken station) {
		if (market == null) return "Unavailable colony";
		String name = market.getName();
		if (station != null && station.getMarket() == market) name = "Player HQ";
		String where = "";
		if (market.getPrimaryEntity() != null && market.getPrimaryEntity().getContainingLocation() instanceof StarSystemAPI) {
			where = " (" + ((StarSystemAPI) market.getPrimaryEntity().getContainingLocation()).getBaseName() + ")";
		}
		return name + where;
	}

	public static String summarize(CourierRequest r) {
		StringBuilder sb = new StringBuilder();
		if (r.allWeapons) sb.append("All Weapons");
		if (r.allWings) {
			if (sb.length() > 0) sb.append(", ");
			sb.append("All Wings");
		}
		if (r.allSpecials) {
			if (sb.length() > 0) sb.append(", ");
			sb.append("All Special Items");
		}
		if (r.allShips) {
			if (sb.length() > 0) sb.append(", ");
			sb.append("All Ships");
		}
		if (r.allResources) {
			if (sb.length() > 0) sb.append(", ");
			sb.append("All Resources");
		}
		if (r.allHullmods) {
			if (sb.length() > 0) sb.append(", ");
			sb.append("All Hullmods");
		}
		for (CharterItem it : r.items) {
			if (sb.length() > 0) sb.append(", ");
			sb.append(it.name).append(" ").append(it.amount);
		}
		return sb.length() == 0 ? "No items chosen yet" : sb.toString();
	}
}
