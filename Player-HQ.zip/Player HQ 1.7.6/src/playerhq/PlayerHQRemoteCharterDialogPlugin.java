package playerhq;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import playerhq.charter.CourierCharterDelegate;
import playerhq.modules.MilitaryWardModule;

import java.util.Map;

public class PlayerHQRemoteCharterDialogPlugin implements InteractionDialogPlugin {

	private static final String OPTION_DONE = "playerhq_remote_charter_done";

	private final SectorEntityToken station;

	private InteractionDialogAPI dialog;

	public PlayerHQRemoteCharterDialogPlugin(SectorEntityToken station) {
		this.station = station;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		if (station == null || !station.isAlive() || MilitaryWardModule.getCourierBayCount(station) < 1) {
			dialog.getTextPanel().addPara("Courier Charters are not available.");
			dialog.getOptionPanel().addOption("Continue", OPTION_DONE);
			return;
		}
		dialog.showCustomDialog(CourierCharterDelegate.WIDTH, CourierCharterDelegate.HEIGHT,
				new CourierCharterDelegate(station, new CourierCharterDelegate.Listener() {
					public void onFinished() {
						PlayerHQRemoteCharterDialogPlugin.this.dialog.dismiss();
					}
				}));
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (OPTION_DONE.equals(optionData)) {
			dialog.dismiss();
		}
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
