package playerhq.shiplist;

import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ShipListDelegate extends BaseCustomUIPanelPlugin implements CustomDialogDelegate {

	public interface Listener {
		void onClosed();
	}

	public static final float WIDTH = 520f;
	public static final float HEIGHT = 640f;

	private static final float HEADER_H = 96f;
	private static final float FILTER_H = 36f;
	private static final float FOOTER_H = 56f;

	private static final String FILTER_ALL = "all";
	private static final String FILTER_FRIGATE = "frigate";
	private static final String FILTER_DESTROYER = "destroyer";
	private static final String FILTER_CRUISER = "cruiser";

	private final String title;
	private final String note;
	private final List<ShipHullSpecAPI> hulls;
	private final Listener listener;

	private CustomPanelAPI panel;
	private CustomPanelAPI listHolder;
	private String filter = FILTER_ALL;
	private String lastBuiltFilter = null;
	private boolean closed = false;
	private final Map<String, ButtonAPI> filterButtons = new LinkedHashMap<String, ButtonAPI>();

	public ShipListDelegate(String title, String note, List<ShipHullSpecAPI> hulls, Listener listener) {
		this.title = title;
		this.note = note;
		this.hulls = hulls;
		this.listener = listener;
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		this.panel = panel;
		Color base = Misc.getBasePlayerColor();
		Color dark = Misc.getDarkPlayerColor();
		Color bright = Misc.getBrightPlayerColor();

		TooltipMakerAPI header = panel.createUIElement(WIDTH - 20f, HEADER_H, false);
		header.addSectionHeading(title, Alignment.MID, 0f);
		header.addPara(note, 6f);
		panel.addUIElement(header).inTL(10f, 8f);

		TooltipMakerAPI filters = panel.createUIElement(WIDTH - 20f, FILTER_H, false);
		String[][] defs = {
				{ FILTER_ALL, "All" },
				{ FILTER_FRIGATE, "Frigates" },
				{ FILTER_DESTROYER, "Destroyers" },
				{ FILTER_CRUISER, "Cruisers" } };
		ButtonAPI prev = null;
		for (String[] def : defs) {
			ButtonAPI b = filters.addAreaCheckbox(def[1], def[0], base, dark, bright, 110f, 26f, prev == null ? 4f : 0f);
			if (prev != null) b.getPosition().rightOfMid(prev, 8f);
			b.setChecked(def[0].equals(filter));
			filterButtons.put(def[0], b);
			prev = b;
		}
		panel.addUIElement(filters).inTL(10f, HEADER_H + 6f);

		rebuildList();
	}

	private boolean matches(ShipHullSpecAPI hull) {
		HullSize size = hull.getHullSize();
		if (FILTER_FRIGATE.equals(filter)) return size == HullSize.FRIGATE;
		if (FILTER_DESTROYER.equals(filter)) return size == HullSize.DESTROYER;
		if (FILTER_CRUISER.equals(filter)) return size == HullSize.CRUISER;
		return true;
	}

	private void rebuildList() {
		if (panel == null) return;
		if (listHolder != null) panel.removeComponent(listHolder);

		float top = HEADER_H + FILTER_H + 14f;
		float h = HEIGHT - top - FOOTER_H;
		CustomPanelAPI holder = panel.createCustomPanel(WIDTH - 20f, h, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI list = holder.createUIElement(WIDTH - 20f, h, true);

		List<String> names = new ArrayList<String>();
		for (ShipHullSpecAPI hull : hulls) {
			if (matches(hull)) names.add(hull.getHullNameWithDashClass());
		}
		if (names.isEmpty()) {
			list.addPara("No ships match this filter.", Misc.getGrayColor(), 6f);
		} else {
			list.addPara(names.size() + (names.size() == 1 ? " ship" : " ships"), Misc.getGrayColor(), 4f);
			for (String name : names) {
				list.addPara(name, 3f);
			}
		}

		holder.addUIElement(list).inTL(0f, 0f);
		panel.addComponent(holder).inTL(10f, top);
		listHolder = holder;
		lastBuiltFilter = filter;
	}

	@Override
	public void advance(float amount) {
		if (filterButtons.isEmpty()) return;
		String changedTo = null;
		for (Map.Entry<String, ButtonAPI> e : filterButtons.entrySet()) {
			if (e.getValue().isChecked() && !e.getKey().equals(filter)) {
				changedTo = e.getKey();
				break;
			}
		}
		if (changedTo != null) filter = changedTo;
		for (Map.Entry<String, ButtonAPI> e : filterButtons.entrySet()) {
			e.getValue().setChecked(e.getKey().equals(filter));
		}
		if (lastBuiltFilter == null || !lastBuiltFilter.equals(filter)) rebuildList();
	}

	@Override
	public boolean hasCancelButton() {
		return false;
	}

	@Override
	public String getConfirmText() {
		return "Back";
	}

	@Override
	public String getCancelText() {
		return "Back";
	}

	private void finish() {
		if (closed) return;
		closed = true;
		if (listener != null) listener.onClosed();
	}

	@Override
	public void customDialogConfirm() {
		finish();
	}

	@Override
	public void customDialogCancel() {
		finish();
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return this;
	}
}
