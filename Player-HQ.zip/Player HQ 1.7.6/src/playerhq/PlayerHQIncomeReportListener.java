package playerhq;

import com.fs.starfarer.api.campaign.listeners.EconomyTickListener;

// Superseded by PlayerHQMonthlyScript.reportToIncomeTab(), which reports Player HQ as a single line
// under the "Fleet" node of the Income tab instead of as its own standalone top-level entry. This
// class is kept around (rather than deleted, and no longer registered from PlayerHQModPlugin) only so
// that old saves which already serialized an instance of it don't fail to load; its methods do nothing.
public class PlayerHQIncomeReportListener implements EconomyTickListener {

	@Override
	public void reportEconomyTick(int iterIndex) {
	}

	@Override
	public void reportEconomyMonthEnd() {
	}
}
