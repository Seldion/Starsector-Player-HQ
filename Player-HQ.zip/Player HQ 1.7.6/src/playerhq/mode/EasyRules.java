package playerhq.mode;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.MarketPlaceModule;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;
import playerhq.modules.StationItemsModule;
import playerhq.util.PlayerHQUtils;

public class EasyRules {

	public static final float PRICE_HIGH = 75000f;
	public static final float PRICE_MEDIUM = 50000f;
	public static final float PRICE_LOW = 25000f;

	public static final float UPKEEP_RATE = 0.05f;

	public static final String MOD_MINING = "mining";
	public static final String MOD_MANUFACTORIUM = "manufactorium";
	public static final String MOD_BIODOME = "biodome";
	public static final String MOD_ASSEMBLY = "assembly";
	public static final String MOD_MILITARY = "military";
	public static final String MOD_RESORT = "resort";
	public static final String MOD_ACCESS = "access";
	public static final String MOD_MARKET = "market";

	public static final String CORE_KEY_PREFIX = "$playerhq_easy_core_";
	public static final String SPOOL_KEY = "$playerhq_easy_spool";
	public static final String CORE_MODULE_KEY = "$playerhq_easy_core_pending_module";

	public static final float[] MINING_AI_BONUS = { 0.05f, 0.10f, 0.15f };
	public static final float[] ASSEMBLY_AI_DISCOUNT = { 0.05f, 0.10f, 0.15f };
	public static final float[] RESORT_AI_BONUS = { 0.05f, 0.10f, 0.15f };
	public static final float[] ACCESS_AI_BONUS = { 5f, 10f, 15f };
	public static final float[] MARKET_AI_FINDS = { 0.05f, 0.10f, 0.15f };
	public static final float[] BIODOME_AI_BONUS = { 25f, 50f, 150f };

	public static final float ASSEMBLY_CORRUPTED_DISCOUNT = 0.10f;
	public static final float ASSEMBLY_PRISTINE_DISCOUNT = 0.20f;

	public static final float MARKET_HOLOSUITE_DISCOUNT = 0.15f;

	public static final float ELEVATOR_ACCESS_BONUS = 50f;
	public static final float SHUTTLES_ACCESS_BONUS = 25f;
	public static final float SPOOL_ACCESS_BONUS = 15f;

	public static final float MANUFACTORIUM_BASE_COST_MULT = 4f;
	public static final float MANUFACTORIUM_CAP_NONE = 50f;
	public static final float MANUFACTORIUM_CAP_CORRUPTED = 100f;
	public static final float MANUFACTORIUM_CAP_PRISTINE = 200f;
	public static final float MANUFACTORIUM_CAP_REFINING = 1000f;
	public static final float MANUFACTORIUM_ORE_RATIO = 5f;

	public static boolean on() {
		try {
			return Global.getSector() != null && HQMode.isEasy();
		} catch (Throwable t) {
			return false;
		}
	}

	public static boolean canAfford(CampaignFleetAPI fleet, float amount) {
		return fleet != null && fleet.getCargo().getCredits().get() >= amount;
	}

	public static void pay(CampaignFleetAPI fleet, float amount) {
		if (fleet == null || amount <= 0f) return;
		fleet.getCargo().getCredits().subtract(amount);
	}

	public static void refundCredits(float price) {
		CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();
		if (fleet == null || price <= 0f) return;
		fleet.getCargo().getCredits().add(price * ConstructPlayerHQAbility.REFUND_FRACTION);
	}

	public static String getCore(SectorEntityToken station, String module) {
		return station.getMemoryWithoutUpdate().getString(CORE_KEY_PREFIX + module);
	}

	public static boolean hasCore(SectorEntityToken station, String module) {
		return getCore(station, module) != null;
	}

	public static int tier(String coreId) {
		if (Commodities.GAMMA_CORE.equals(coreId)) return 0;
		if (Commodities.BETA_CORE.equals(coreId)) return 1;
		if (Commodities.ALPHA_CORE.equals(coreId)) return 2;
		return -1;
	}

	public static int coreTier(SectorEntityToken station, String module) {
		return tier(getCore(station, module));
	}

	public static String coreName(String coreId) {
		if (Commodities.ALPHA_CORE.equals(coreId)) return "Alpha Core";
		if (Commodities.BETA_CORE.equals(coreId)) return "Beta Core";
		if (Commodities.GAMMA_CORE.equals(coreId)) return "Gamma Core";
		return "AI Core";
	}

	public static boolean hasCoreAvailable(SectorEntityToken station, CampaignFleetAPI fleet, String coreId) {
		return PlayerHQUtils.getCombinedCommodityQuantity(station, fleet, coreId) >= 1f;
	}

	public static boolean installCore(SectorEntityToken station, CampaignFleetAPI fleet, String module, String coreId) {
		if (tier(coreId) < 0 || hasCore(station, module)) return false;
		if (!hasCoreAvailable(station, fleet, coreId)) return false;
		PlayerHQUtils.removeCombinedCommodity(station, fleet, coreId, 1f);
		station.getMemoryWithoutUpdate().set(CORE_KEY_PREFIX + module, coreId);
		return true;
	}

	public static void removeCore(SectorEntityToken station, String module) {
		String core = getCore(station, module);
		if (core == null) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) storage.addCommodity(core, 1f);
		station.getMemoryWithoutUpdate().unset(CORE_KEY_PREFIX + module);
	}

	public static void returnCore(SectorEntityToken station, String module, CargoAPI cargo) {
		String core = getCore(station, module);
		if (core == null) return;
		if (cargo != null) cargo.addCommodity(core, 1f);
		station.getMemoryWithoutUpdate().unset(CORE_KEY_PREFIX + module);
	}

	public static String moduleLabel(String module) {
		if (MOD_MINING.equals(module)) return "Materials Acquisition Hub";
		if (MOD_MANUFACTORIUM.equals(module)) return "Manufactorium";
		if (MOD_BIODOME.equals(module)) return "Bio-Dome";
		if (MOD_ASSEMBLY.equals(module)) return "Strategic Assembly";
		if (MOD_MILITARY.equals(module)) return "Military Paradigm";
		if (MOD_RESORT.equals(module)) return "Resort";
		if (MOD_ACCESS.equals(module)) return "station access";
		if (MOD_MARKET.equals(module)) return "Market Place";
		return module;
	}

	public static String coreEffectText(String module, int tier) {
		if (tier < 0 || tier > 2) return "";
		if (MOD_MINING.equals(module)) return "Raises everything the hub gathers by " + Math.round(MINING_AI_BONUS[tier] * 100f) + "%.";
		if (MOD_MANUFACTORIUM.equals(module)) {
			int mult = tier == 0 ? 3 : tier == 1 ? 2 : 1;
			return "Lowers the cost of production to " + mult + "x the base amounts.";
		}
		if (MOD_BIODOME.equals(module)) return "Adds " + (int) BIODOME_AI_BONUS[tier] + " food and " + (int) BIODOME_AI_BONUS[tier] + " organics each month.";
		if (MOD_ASSEMBLY.equals(module)) return "Lowers ship, weapon and fighter costs by " + Math.round(ASSEMBLY_AI_DISCOUNT[tier] * 100f) + "%.";
		if (MOD_RESORT.equals(module)) return "Raises Resort income by " + Math.round(RESORT_AI_BONUS[tier] * 100f) + "%.";
		if (MOD_ACCESS.equals(module)) return "Adds " + (int) ACCESS_AI_BONUS[tier] + "% accessibility.";
		if (MOD_MARKET.equals(module)) return "Raises the Exchange's chances for better finds by " + Math.round(MARKET_AI_FINDS[tier] * 100f) + "%.";
		return "";
	}

	public static float miningMult(SectorEntityToken station) {
		if (!on()) return 1f;
		int t = coreTier(station, MOD_MINING);
		return t < 0 ? 1f : 1f + MINING_AI_BONUS[t];
	}

	public static float biodomeBonus(SectorEntityToken station) {
		if (!on()) return 0f;
		int t = coreTier(station, MOD_BIODOME);
		return t < 0 ? 0f : BIODOME_AI_BONUS[t];
	}

	public static float assemblyDiscount(SectorEntityToken station) {
		float d = 0f;
		if (AssemblyBayModule.hasNanoforgeInstalled(station)) {
			String id = station.getMemoryWithoutUpdate().getString(AssemblyBayModule.NANOFORGE_ITEM_KEY);
			d += com.fs.starfarer.api.impl.campaign.ids.Items.PRISTINE_NANOFORGE.equals(id)
					? ASSEMBLY_PRISTINE_DISCOUNT : ASSEMBLY_CORRUPTED_DISCOUNT;
		}
		int t = coreTier(station, MOD_ASSEMBLY);
		if (t >= 0) d += ASSEMBLY_AI_DISCOUNT[t];
		return Math.min(1f, d);
	}

	public static float resortAiBonus(SectorEntityToken station) {
		int t = coreTier(station, MOD_RESORT);
		return t < 0 ? 0f : RESORT_AI_BONUS[t];
	}

	public static float accessExtra(SectorEntityToken station) {
		float b = 0f;
		int t = coreTier(station, MOD_ACCESS);
		if (t >= 0) b += ACCESS_AI_BONUS[t];
		if (StationItemsModule.hasSpaceElevatorInstalled(station) && station.getMemoryWithoutUpdate().getBoolean(SPOOL_KEY)) {
			b += SPOOL_ACCESS_BONUS;
		}
		return b;
	}

	public static float marketFinds(SectorEntityToken station) {
		if (!on()) return 0f;
		int t = coreTier(station, MOD_MARKET);
		return t < 0 ? 0f : MARKET_AI_FINDS[t];
	}

	public static float marketDiscount(SectorEntityToken station) {
		if (!on()) return 0f;
		return station.getMemoryWithoutUpdate().getBoolean(MarketPlaceModule.EASY_HOLOSUITE_KEY) ? MARKET_HOLOSUITE_DISCOUNT : 0f;
	}

	public static float manufactoriumCostMult(SectorEntityToken station) {
		int t = coreTier(station, MOD_MANUFACTORIUM);
		if (t == 0) return 3f;
		if (t == 1) return 2f;
		if (t == 2) return 1f;
		return MANUFACTORIUM_BASE_COST_MULT;
	}

	public static float manufactoriumCap(SectorEntityToken station) {
		if (IndustrialHubModule.isPristineNanoforgeInstalled(station)) return MANUFACTORIUM_CAP_PRISTINE;
		if (IndustrialHubModule.isCorruptedNanoforgeInstalled(station)) return MANUFACTORIUM_CAP_CORRUPTED;
		return MANUFACTORIUM_CAP_NONE;
	}

	public static float moduleCostsTotal(SectorEntityToken station) {
		float total = 0f;
		if (MiningHangarModule.isBuilt(station)) total += PRICE_LOW;
		if (IndustrialHubModule.isBuilt(station)) total += PRICE_HIGH;
		if (HydroponicsHubModule.isBuilt(station)) total += PRICE_LOW;
		if (AssemblyBayModule.isBuilt(station)) total += PRICE_HIGH;
		if (MilitaryWardModule.isBuilt(station)) {
			total += PRICE_MEDIUM;
			if (MilitaryWardModule.hasFleetHQBuilt(station)) total += PRICE_MEDIUM;
		}
		if (RecreationalHubModule.isBuilt(station)) {
			total += PRICE_MEDIUM;
			if (RecreationalHubModule.hasFusionLampInstalled(station) || RecreationalHubModule.hasWinterResortInstalled(station)) {
				total += PRICE_LOW;
			}
		}
		if (StationItemsModule.hasPublicShuttlesInstalled(station)) total += PRICE_MEDIUM;
		if (StationItemsModule.hasSpaceElevatorInstalled(station)) total += PRICE_MEDIUM;
		if (MarketPlaceModule.isBuilt(station)) total += PRICE_LOW;
		return total;
	}

	public static float monthlyUpkeep(SectorEntityToken station) {
		if (!on()) return 0f;
		return moduleCostsTotal(station) * UPKEEP_RATE;
	}

	public static float chargeUpkeep(SectorEntityToken station) {
		float upkeep = monthlyUpkeep(station);
		if (upkeep <= 0f) return 0f;
		CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();
		if (fleet == null) return 0f;
		fleet.getCargo().getCredits().subtract(upkeep);
		return upkeep;
	}
}
