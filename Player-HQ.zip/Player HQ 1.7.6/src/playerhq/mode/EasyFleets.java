package playerhq.mode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI.ShipTypeHints;
import com.fs.starfarer.api.combat.ShipVariantAPI;

public class EasyFleets {

	public static final int PATROL_SIZE = 30;
	public static final long PATROL_COST = 1000000L;
	public static final float SELL_RETURN = 0.5f;
	public static final float TRADE_SALE_FRACTION = 0.5f;

	public static final String[][] LOGISTICS_HULLS = { { "colossus", "3" }, { "starliner", "3" }, { "phaeton", "3" } };
	public static final String[][] TRADE_HULLS = { { "colossus", "6" }, { "phaeton", "2" } };

	private static final Random RANDOM = new Random();

	private static void group(Map<String, List<String>> map, ShipHullSpecAPI h, String variantId) {
		List<String> l = map.get(h.getHullId());
		if (l == null) {
			l = new ArrayList<String>();
			map.put(h.getHullId(), l);
		}
		l.add(variantId);
	}

	private static String pick(Map<String, List<String>> map) {
		if (map.isEmpty()) return null;
		List<List<String>> all = new ArrayList<List<String>>(map.values());
		List<String> variants = all.get(RANDOM.nextInt(all.size()));
		return variants.get(RANDOM.nextInt(variants.size()));
	}

	public static List<ShipVariantAPI> rollPatrol() {
		Set<String> known = Global.getSector().getPlayerFaction().getKnownShips();
		Map<String, List<String>> capital = new HashMap<String, List<String>>();
		Map<String, List<String>> cruiser = new HashMap<String, List<String>>();
		Map<String, List<String>> destroyer = new HashMap<String, List<String>>();
		Map<String, List<String>> frigate = new HashMap<String, List<String>>();
		for (String id : Global.getSettings().getAllVariantIds()) {
			if (id.endsWith("_Hull")) continue;
			ShipVariantAPI v;
			try {
				v = Global.getSettings().getVariant(id);
			} catch (Throwable t) {
				continue;
			}
			if (v == null) continue;
			ShipHullSpecAPI h = v.getHullSpec();
			if (h == null || !known.contains(h.getHullId())) continue;
			if (h.isDHull() || h.isCivilianNonCarrier()) continue;
			if (h.getHints().contains(ShipTypeHints.STATION) || h.getHints().contains(ShipTypeHints.MODULE)) continue;
			HullSize size = h.getHullSize();
			if (size == HullSize.CAPITAL_SHIP) group(capital, h, id);
			else if (size == HullSize.CRUISER) group(cruiser, h, id);
			else if (size == HullSize.DESTROYER) group(destroyer, h, id);
			else if (size == HullSize.FRIGATE) group(frigate, h, id);
		}
		List<String> ids = new ArrayList<String>();
		String cap = pick(capital);
		if (cap != null) ids.add(cap);
		for (int i = 0; i < 6; i++) {
			String s = pick(cruiser);
			if (s != null) ids.add(s);
		}
		if (!destroyer.isEmpty() || !frigate.isEmpty()) {
			while (ids.size() < PATROL_SIZE) {
				Map<String, List<String>> pool = destroyer.isEmpty() ? frigate : frigate.isEmpty() ? destroyer
						: (RANDOM.nextBoolean() ? destroyer : frigate);
				ids.add(pick(pool));
			}
		}
		List<ShipVariantAPI> out = new ArrayList<ShipVariantAPI>();
		for (String id : ids) {
			try {
				out.add(Global.getSettings().getVariant(id).clone());
			} catch (Throwable t) {
			}
		}
		return out;
	}
}
