package playerhq.mode;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import playerhq.Ids;
import playerhq.util.PlayerHQUtils;

public class HQMode {

	public static final String KEY_DIFFICULTY = "$playerhq_mode_difficulty";
	public static final String KEY_STYLE = "$playerhq_mode_style";

	public static final String EASY = "easy";
	public static final String STARFARER = "starfarer";
	public static final String TEXT = "text";
	public static final String COLONY = "colony";

	public static final boolean COLONY_AVAILABLE = false;

	private static MemoryAPI mem() {
		return Global.getSector().getMemoryWithoutUpdate();
	}

	public static boolean isChosen() {
		return mem().contains(KEY_DIFFICULTY) && mem().contains(KEY_STYLE);
	}

	public static String difficulty() {
		String d = mem().getString(KEY_DIFFICULTY);
		return EASY.equals(d) ? EASY : STARFARER;
	}

	public static String style() {
		String s = mem().getString(KEY_STYLE);
		return COLONY.equals(s) ? COLONY : TEXT;
	}

	public static boolean isEasy() {
		return EASY.equals(difficulty());
	}

	public static boolean isStarfarer() {
		return STARFARER.equals(difficulty());
	}

	public static boolean isColony() {
		return COLONY.equals(style());
	}

	public static boolean isText() {
		return TEXT.equals(style());
	}

	public static void lockIn(String difficulty, String style) {
		if (isChosen()) return;
		mem().set(KEY_DIFFICULTY, EASY.equals(difficulty) ? EASY : STARFARER);
		mem().set(KEY_STYLE, COLONY.equals(style) ? COLONY : TEXT);
	}

	public static void migrateOldSaves() {
		if (isChosen()) return;
		if (PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION) == null) return;
		lockIn(STARFARER, TEXT);
	}

	public static String difficultyLabel(String difficulty) {
		return EASY.equals(difficulty) ? "Easy Mode" : "Starfarer Mode";
	}

	public static String styleLabel(String style) {
		return COLONY.equals(style) ? "Visual" : "Text";
	}

	public static String describe() {
		return difficultyLabel(difficulty()) + ", " + styleLabel(style());
	}
}
