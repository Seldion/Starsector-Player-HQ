package playerhq.modules;

import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CoreUIAPI;
import com.fs.starfarer.api.campaign.SubmarketPlugin.TransferAction;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;

public class ExpeditionFindsSubmarketPlugin extends BaseSubmarketPlugin {

	@Override
	public void init(SubmarketAPI submarket) {
		super.init(submarket);
	}

	@Override
	public String getName() {
		return "Expedition Finds";
	}

	@Override
	public void updateCargoPrePlayerInteraction() {
	}

	@Override
	public boolean isParticipatesInEconomy() {
		return false;
	}

	@Override
	public float getTariff() {
		return 0f;
	}

	@Override
	public boolean isFreeTransfer() {
		return true;
	}

	@Override
	public boolean isBlackMarket() {
		return false;
	}

	@Override
	public boolean isOpenMarket() {
		return false;
	}

	@Override
	public boolean isEnabled(CoreUIAPI ui) {
		return true;
	}

	@Override
	public String getTooltipAppendix(CoreUIAPI ui) {
		return "Finds from your Expedition Fleets are delivered here. You can only take items out.";
	}

	@Override
	public String getBuyVerb() {
		return "Take";
	}

	@Override
	public String getSellVerb() {
		return "Store";
	}

	@Override
	public boolean isIllegalOnSubmarket(CargoStackAPI stack, TransferAction action) {
		return action == TransferAction.PLAYER_SELL;
	}

	@Override
	public boolean isIllegalOnSubmarket(String commodityId, TransferAction action) {
		return action == TransferAction.PLAYER_SELL;
	}

	@Override
	public String getIllegalTransferText(CargoStackAPI stack, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "Expedition Finds is withdraw-only";
		}
		return super.getIllegalTransferText(stack, action);
	}

	@Override
	public String getIllegalTransferText(FleetMemberAPI member, TransferAction action) {
		if (action == TransferAction.PLAYER_SELL) {
			return "Expedition Finds is withdraw-only";
		}
		return super.getIllegalTransferText(member, action);
	}

	@Override
	public boolean isIllegalOnSubmarket(FleetMemberAPI member, TransferAction action) {
		return action == TransferAction.PLAYER_SELL;
	}
}
