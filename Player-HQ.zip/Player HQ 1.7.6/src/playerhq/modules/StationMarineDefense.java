package playerhq.modules;

import java.awt.Color;
import java.util.Random;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.Misc;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.util.PlayerHQUtils;

public class StationMarineDefense {

	public static final String DEFENSE_MOD_ID = "playerhq_station_marines";
	public static final String NEXERELIN_MOD_ID = "nexerelin";

	public static final float MIN_RAID_CASUALTY_FRACTION = 0.05f;
	public static final float MAX_RAID_CASUALTY_FRACTION = 0.15f;

	private static final String KEY_MARKET = "$playerhq_marineDefenseMarket";
	private static final String KEY_VALUE = "$playerhq_marineDefenseValue";
	private static final String KEY_RAID_TS = "$playerhq_marineDefenseRaidTs";

	private static final Random random = new Random();
	private static boolean nexFailed = false;
	private static java.lang.reflect.Method nexAdvance = null;

	public static void advance(SectorEntityToken station) {
		MemoryAPI stationMem = station.getMemoryWithoutUpdate();

		MarketAPI market = null;
		if (MilitaryWardModule.isBuilt(station)) {
			market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
			if (market != null && !market.isPlayerOwned()) market = null;
		}

		String previousId = stationMem.getString(KEY_MARKET);
		if (previousId != null && (market == null || !previousId.equals(market.getId()))) {
			MarketAPI previous = Global.getSector().getEconomy().getMarket(previousId);
			if (previous != null) {
				previous.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(DEFENSE_MOD_ID);
			}
			stationMem.unset(KEY_MARKET);
			stationMem.unset(KEY_VALUE);
			stationMem.unset(KEY_RAID_TS);
		}
		if (market == null) return;

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		int marines = storage == null ? 0 : storage.getMarines();

		int applied = stationMem.contains(KEY_VALUE) ? (int) stationMem.getLong(KEY_VALUE) : -1;
		if (applied != marines || (marines > 0 && !marketHasMod(market))) {
			if (marines > 0) {
				market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyFlat(
						DEFENSE_MOD_ID, marines, "Marines stationed at Player HQ");
			} else {
				market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(DEFENSE_MOD_ID);
			}
			stationMem.set(KEY_VALUE, (long) marines);
			stationMem.set(KEY_MARKET, market.getId());
		}

		long raidTs = market.getMemoryWithoutUpdate().contains(Misc.LAST_RAIDED_AT)
				? market.getMemoryWithoutUpdate().getLong(Misc.LAST_RAIDED_AT) : -1L;
		if (!stationMem.contains(KEY_RAID_TS)) {
			stationMem.set(KEY_RAID_TS, raidTs);
		} else if (stationMem.getLong(KEY_RAID_TS) != raidTs) {
			stationMem.set(KEY_RAID_TS, raidTs);
			if (raidTs != -1L) applyRaidCasualties(market, storage);
		}

		if (!nexFailed && Global.getSettings().getModManager().isModEnabled(NEXERELIN_MOD_ID)) {
			try {
				if (nexAdvance == null) {
					nexAdvance = Class.forName("playerhq.nex.NexMarineDefense").getMethod("advance",
							SectorEntityToken.class, MarketAPI.class, CargoAPI.class);
				}
				nexAdvance.invoke(null, station, market, storage);
			} catch (Throwable t) {
				nexFailed = true;
				Global.getLogger(StationMarineDefense.class).warn("Nexerelin marine defense support disabled", t);
			}
		}
	}

	private static boolean marketHasMod(MarketAPI market) {
		return market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).getFlatBonus(DEFENSE_MOD_ID) != null;
	}

	private static void applyRaidCasualties(MarketAPI market, CargoAPI storage) {
		if (storage == null) return;
		int marines = storage.getMarines();
		if (marines <= 0) return;

		float fraction = MIN_RAID_CASUALTY_FRACTION
				+ random.nextFloat() * (MAX_RAID_CASUALTY_FRACTION - MIN_RAID_CASUALTY_FRACTION);
		int lost = Math.max(1, Math.round(marines * fraction));
		lost = Math.min(lost, marines);

		storage.removeMarines(lost);
		sendMessage(lost + (lost == 1 ? " marine" : " marines") + " stationed at Player HQ died defending "
				+ market.getName() + " from a raid.", Misc.getNegativeHighlightColor());
	}

	public static void sendMessage(String text, Color color) {
		Global.getSector().getCampaignUI().addMessage(text, color);
	}
}
