package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.mode.EasyRules;
import playerhq.util.PlayerHQUtils;

public class RecreationalHubModule {

	public static final String MEMORY_KEY = "$playerhq_module_recreation";
	public static final String HOLOSUITE_MEMORY_KEY = "$playerhq_module_recreation_holosuite";
	public static final String FUSION_LAMP_MEMORY_KEY = "$playerhq_module_recreation_fusionlamp";
	public static final String FUSION_LAMP_UNPOWERED_MEMORY_KEY = "$playerhq_module_recreation_fusionlamp_unpowered";
	public static final float FUSION_LAMP_VOLATILES_UPKEEP = 2f;
	public static final String WINTER_RESORT_MEMORY_KEY = "$playerhq_module_recreation_winterresort";

	public static final float CREDIT_COST = 40000f;
	public static final float METALS_COST = 900f;
	public static final float TRANSPLUTONICS_COST = 90f;
	public static final float VOLATILES_COST = 40f;
	public static final float HEAVY_MACHINERY_COST = 200f;
	public static final int CREW_COST = 500;

	public static final float BEACH_RESORT_ORGANICS_COST = 1000f;
	public static final float BEACH_RESORT_CREDIT_COST = 5000f;

	private static final float[] BASE_INCOME_BY_SIZE = {
			8000f, 16000f, 28000f, 42000f, 62000f, 84000f, 108000f, 134000f, 166000f, 200000f
	};

	public static final float HOLOSUITE_BONUS = 0.10f;
	public static final float FUSION_LAMP_BONUS = 0.10f;
	public static final float FUSION_LAMP_COLD_BONUS = 0.20f;
	public static final float FUSION_LAMP_VERY_COLD_BONUS = 0.30f;
	public static final float FUSION_LAMP_AIRLESS_COLD_BONUS = 0.50f;
	public static final float WINTER_RESORT_BONUS = 0.10f;
	public static final float WINTER_RESORT_HOT_BONUS = 0.20f;
	public static final float WINTER_RESORT_VERY_HOT_BONUS = 0.30f;

	public static final String[] IMAGE_PATHS = {
			"graphics/modules/recreational_hub.jpg",
			"graphics/modules/recreational_hub_2.jpg",
			"graphics/modules/recreational_hub_3.jpg",
			"graphics/modules/recreational_hub_4.jpg",
			"graphics/modules/recreational_hub_5.jpg",
			"graphics/modules/recreational_hub_6.jpg",
			"graphics/modules/recreational_hub_7.jpg",
	};

	public static String getRandomImagePath() {
		int index = (int) (Math.random() * IMAGE_PATHS.length);
		if (index >= IMAGE_PATHS.length) index = IMAGE_PATHS.length - 1;
		return IMAGE_PATHS[index];
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean canBuild(SectorEntityToken station) {
		return ConstructPlayerHQAbility.isOrbitingColonizedPlanet(station);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) return EasyRules.canAfford(playerFleet, EasyRules.PRICE_MEDIUM);
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= VOLATILES_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST
				&& PlayerHQUtils.getStationCrew(station) >= CREW_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) {
			EasyRules.pay(playerFleet, EasyRules.PRICE_MEDIUM);
			station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
			return;
		}
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, VOLATILES_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);
		PlayerHQUtils.removeStationCrew(station, CREW_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		refund(station, playerFleet, playerFleet.getCargo());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI cargo) {
		if (!isBuilt(station)) return;

		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_MEDIUM);
			EasyRules.returnCore(station, EasyRules.MOD_RESORT, cargo);
			if (hasHolosuiteInstalled(station)) {
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
			}
			if (hasFusionLampInstalled(station)) {
				EasyRules.refundCredits(EasyRules.PRICE_LOW);
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null), 1);
			}
			if (hasWinterResortInstalled(station)) {
				EasyRules.refundCredits(EasyRules.PRICE_LOW);
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null), 1);
			}
			return;
		}

		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);
		cargo.addCrew(CREW_COST);

		if (hasHolosuiteInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.DEALMAKER_HOLOSUITE, null), 1);
		}
		if (hasFusionLampInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null), 1);
			cargo.addCommodity(Commodities.ORGANICS, BEACH_RESORT_ORGANICS_COST * fraction);
		}
		if (hasWinterResortInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.CRYOARITHMETIC_ENGINE, null), 1);
		}
	}

	public static boolean hasHolosuiteInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasHolosuiteAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE);
	}

	public static void installHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().set(HOLOSUITE_MEMORY_KEY, true);
	}

	public static void uninstallHolosuite(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasHolosuiteInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.DEALMAKER_HOLOSUITE, 1);
		station.getMemoryWithoutUpdate().unset(HOLOSUITE_MEMORY_KEY);
	}

	public static boolean hasFusionLampInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(FUSION_LAMP_MEMORY_KEY);
	}

	public static boolean hasBeachResortCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) {
			return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.ORBITAL_FUSION_LAMP)
					&& EasyRules.canAfford(playerFleet, EasyRules.PRICE_LOW);
		}
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.ORBITAL_FUSION_LAMP)
				&& playerFleet.getCargo().getCredits().get() >= BEACH_RESORT_CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ORGANICS) >= BEACH_RESORT_ORGANICS_COST;
	}

	public static void installFusionLamp(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) {
			PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.ORBITAL_FUSION_LAMP, 1);
			EasyRules.pay(playerFleet, EasyRules.PRICE_LOW);
			station.getMemoryWithoutUpdate().set(FUSION_LAMP_MEMORY_KEY, true);
			return;
		}
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.ORBITAL_FUSION_LAMP, 1);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.ORGANICS, BEACH_RESORT_ORGANICS_COST);
		playerFleet.getCargo().getCredits().subtract(BEACH_RESORT_CREDIT_COST);
		station.getMemoryWithoutUpdate().set(FUSION_LAMP_MEMORY_KEY, true);
		station.getMemoryWithoutUpdate().unset(FUSION_LAMP_UNPOWERED_MEMORY_KEY);
	}

	public static void uninstallFusionLamp(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasFusionLampInstalled(station)) return;
		if (EasyRules.on()) EasyRules.refundCredits(EasyRules.PRICE_LOW);
		PlayerHQUtils.addToStationInventory(station, Items.ORBITAL_FUSION_LAMP, 1);
		station.getMemoryWithoutUpdate().unset(FUSION_LAMP_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(FUSION_LAMP_UNPOWERED_MEMORY_KEY);
	}

	public static boolean isFusionLampActive(SectorEntityToken station) {
		if (EasyRules.on()) return hasFusionLampInstalled(station);
		return hasFusionLampInstalled(station) && !station.getMemoryWithoutUpdate().getBoolean(FUSION_LAMP_UNPOWERED_MEMORY_KEY);
	}

	public static void payFusionLampUpkeep(SectorEntityToken station) {
		if (EasyRules.on()) return;
		if (!isBuilt(station) || !hasFusionLampInstalled(station)) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null && storage.getCommodityQuantity(Commodities.VOLATILES) >= FUSION_LAMP_VOLATILES_UPKEEP) {
			storage.removeCommodity(Commodities.VOLATILES, FUSION_LAMP_VOLATILES_UPKEEP);
			station.getMemoryWithoutUpdate().unset(FUSION_LAMP_UNPOWERED_MEMORY_KEY);
		} else {
			station.getMemoryWithoutUpdate().set(FUSION_LAMP_UNPOWERED_MEMORY_KEY, true);
			Global.getSector().getCampaignUI().addMessage("The Beach Resort's Fusion Lamp had no Volatiles to run on this month, "
					+ "so its income bonus is off.");
		}
	}

	public static boolean hasWinterResortInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(WINTER_RESORT_MEMORY_KEY);
	}

	public static boolean hasWinterResortCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) {
			return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CRYOARITHMETIC_ENGINE)
					&& EasyRules.canAfford(playerFleet, EasyRules.PRICE_LOW);
		}
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CRYOARITHMETIC_ENGINE);
	}

	public static void installWinterResort(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) EasyRules.pay(playerFleet, EasyRules.PRICE_LOW);
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.CRYOARITHMETIC_ENGINE, 1);
		station.getMemoryWithoutUpdate().set(WINTER_RESORT_MEMORY_KEY, true);
	}

	public static void uninstallWinterResort(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasWinterResortInstalled(station)) return;
		if (EasyRules.on()) EasyRules.refundCredits(EasyRules.PRICE_LOW);
		PlayerHQUtils.addToStationInventory(station, Items.CRYOARITHMETIC_ENGINE, 1);
		station.getMemoryWithoutUpdate().unset(WINTER_RESORT_MEMORY_KEY);
	}

	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasHolosuiteInstalled(station) && !hasFusionLampInstalled(station)
				&& !hasWinterResortInstalled(station);
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet, PlayerHQUtils.getRefundCargo(station, playerFleet));
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	private static int getColonySize(SectorEntityToken station) {
		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return 0;
		return market.getSize();
	}

	public static float getBaseIncome(SectorEntityToken station) {
		return getBaseIncomeForSize(getColonySize(station));
	}

	private static float getBaseIncomeForSize(int size) {
		if (size < 1) return 0f;
		int index = Math.min(size, BASE_INCOME_BY_SIZE.length) - 1;
		return BASE_INCOME_BY_SIZE[index];
	}

	public static float getExpectedIncomeForMarket(MarketAPI market) {
		if (market == null) return 0f;
		return getBaseIncomeForSize(market.getSize());
	}

	public static float getHolosuiteBonus(SectorEntityToken station) {
		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return HOLOSUITE_BONUS;
		return Math.max(HOLOSUITE_BONUS, market.getHazardValue() - 1f);
	}

	public static int getOrbitHazardPercent(SectorEntityToken station) {
		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return 0;
		return Math.round(market.getHazardValue() * 100f);
	}

	public static float getFusionLampBonus(SectorEntityToken station) {
		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return FUSION_LAMP_BONUS;
		boolean cold = market.hasCondition(Conditions.COLD);
		boolean veryCold = market.hasCondition(Conditions.VERY_COLD);
		boolean noAtmosphere = market.hasCondition(Conditions.NO_ATMOSPHERE);
		if (noAtmosphere && (cold || veryCold)) return FUSION_LAMP_AIRLESS_COLD_BONUS;
		if (veryCold) return FUSION_LAMP_VERY_COLD_BONUS;
		if (cold) return FUSION_LAMP_COLD_BONUS;
		return FUSION_LAMP_BONUS;
	}

	public static float getWinterResortBonus(SectorEntityToken station) {
		MarketAPI market = ConstructPlayerHQAbility.getColonizedOrbitMarket(station);
		if (market == null) return WINTER_RESORT_BONUS;
		if (market.hasCondition(Conditions.VERY_HOT)) return WINTER_RESORT_VERY_HOT_BONUS;
		if (market.hasCondition(Conditions.HOT)) return WINTER_RESORT_HOT_BONUS;
		return WINTER_RESORT_BONUS;
	}

	public static float getIncomeMultiplier(SectorEntityToken station) {
		float mult = 1f;
		if (EasyRules.on()) mult += EasyRules.resortAiBonus(station);
		if (hasHolosuiteInstalled(station)) mult += getHolosuiteBonus(station);
		if (isFusionLampActive(station)) mult += getFusionLampBonus(station);
		if (hasWinterResortInstalled(station)) mult += getWinterResortBonus(station);
		return mult;
	}

	public static float getFinalIncome(SectorEntityToken station) {
		float base = getBaseIncome(station);
		if (base <= 0f) return 0f;
		return base * getIncomeMultiplier(station) * StationItemsModule.getAccessibilityMultiplier(station);
	}

	public static float collectIncome(SectorEntityToken station) {
		if (!isBuilt(station)) return 0f;
		float income = getFinalIncome(station);
		if (income <= 0f) return 0f;

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return 0f;
		playerFleet.getCargo().getCredits().add(income);
		return income;
	}
}
