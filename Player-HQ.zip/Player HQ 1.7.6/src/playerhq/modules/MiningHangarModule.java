package playerhq.modules;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.mode.EasyRules;
import playerhq.util.PlayerHQUtils;

public class MiningHangarModule {

	public static final String MEMORY_KEY = "$playerhq_module_mining";

	public static final float METALS_COST = 1500f;
	public static final float TRANSPLUTONICS_COST = 600f;
	public static final float VOLATILES_COST = 320f;
	public static final float HEAVY_MACHINERY_COST = 700f;

	public static final float EFFICIENCY_BASE = 0.20f;

	public static final float MAX_STORED_RESOURCES = 15000f;
	public static final float RAISED_STORAGE_CAP = 20000f;

	public static float getStorageCap(String commodityId) {
		if (Commodities.ORE.equals(commodityId) || Commodities.RARE_ORE.equals(commodityId)
				|| Commodities.ORGANICS.equals(commodityId) || Commodities.FOOD.equals(commodityId)
				|| Commodities.VOLATILES.equals(commodityId) || Commodities.METALS.equals(commodityId)
				|| Commodities.RARE_METALS.equals(commodityId)) {
			return RAISED_STORAGE_CAP;
		}
		return MAX_STORED_RESOURCES;
	}

	public static final int ECON_UNIT_VALUE = 400;

	public static final String IMAGE_PATH = "graphics/modules/mining_hangar.jpg";

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && MilitaryWardModule.getMiningFleetBayCount(station) == 0
				&& MilitaryWardModule.getSalvageFleetBayCount(station) == 0;
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet, PlayerHQUtils.getRefundCargo(station, playerFleet));
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	private static PlanetAPI getOrbitedPlanet(SectorEntityToken station) {
		SectorEntityToken focus = station.getOrbitFocus();
		return (focus instanceof PlanetAPI) ? (PlanetAPI) focus : null;
	}

	private static boolean isOrbitingBeltOrField(SectorEntityToken station) {
		SectorEntityToken focus = station.getOrbitFocus();
		return focus != null && !(focus instanceof PlanetAPI);
	}

	public static float getEfficiency(SectorEntityToken station) {
		return EFFICIENCY_BASE;
	}

	public static float getCombinedEfficiency(SectorEntityToken station) {
		return getEfficiency(station);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) return EasyRules.canAfford(playerFleet, EasyRules.PRICE_LOW);
		return PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= VOLATILES_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) {
			EasyRules.pay(playerFleet, EasyRules.PRICE_LOW);
			station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
			return;
		}
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, VOLATILES_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		refund(station, playerFleet, playerFleet.getCargo());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI cargo) {
		if (!isBuilt(station)) return;

		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_LOW);
			EasyRules.returnCore(station, EasyRules.MOD_MINING, cargo);
			return;
		}

		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);
	}

	public static boolean hasOreDeposit(PlanetAPI planet) {
		MarketAPI market = planet != null ? planet.getMarket() : null;
		return market != null && tierIndexOre(market, Conditions.ORE_SPARSE, Conditions.ORE_MODERATE,
				Conditions.ORE_ABUNDANT, Conditions.ORE_RICH, Conditions.ORE_ULTRARICH) > 0;
	}

	public static boolean hasRareOreDeposit(PlanetAPI planet) {
		MarketAPI market = planet != null ? planet.getMarket() : null;
		return market != null && tierIndexOre(market, Conditions.RARE_ORE_SPARSE, Conditions.RARE_ORE_MODERATE,
				Conditions.RARE_ORE_ABUNDANT, Conditions.RARE_ORE_RICH, Conditions.RARE_ORE_ULTRARICH) > 0;
	}

	public static boolean hasVolatilesDeposit(PlanetAPI planet) {
		MarketAPI market = planet != null ? planet.getMarket() : null;
		return market != null && tierIndexFour(market, Conditions.VOLATILES_TRACE, Conditions.VOLATILES_DIFFUSE,
				Conditions.VOLATILES_ABUNDANT, Conditions.VOLATILES_PLENTIFUL) > 0;
	}

	public static boolean hasOrganicsDeposit(PlanetAPI planet) {
		MarketAPI market = planet != null ? planet.getMarket() : null;
		return market != null && tierIndexFour(market, Conditions.ORGANICS_TRACE, Conditions.ORGANICS_COMMON,
				Conditions.ORGANICS_ABUNDANT, Conditions.ORGANICS_PLENTIFUL) > 0;
	}

	private static final String[] ORE_TIER_NAMES = { "none", "sparse", "moderate", "abundant", "rich", "ultrarich" };
	private static final String[] FOUR_TIER_NAMES = { "none", "trace/low", "diffuse/common", "abundant", "plentiful" };

	private static int tierIndexOre(MarketAPI market, String sparse, String moderate, String abundant, String rich, String ultrarich) {
		if (market.hasCondition(ultrarich)) return 5;
		if (market.hasCondition(rich)) return 4;
		if (market.hasCondition(abundant)) return 3;
		if (market.hasCondition(moderate)) return 2;
		if (market.hasCondition(sparse)) return 1;
		return 0;
	}

	private static int tierIndexFour(MarketAPI market, String lowest, String low, String high, String highest) {
		if (market.hasCondition(highest)) return 4;
		if (market.hasCondition(high)) return 3;
		if (market.hasCondition(low)) return 2;
		if (market.hasCondition(lowest)) return 1;
		return 0;
	}

	private static final int[] ORE_TIER_MODIFIERS = { 0, -1, 0, 1, 2, 3 };
	private static final int[] FOUR_TIER_MODIFIERS = { 0, -1, 0, 1, 2 };

	private static class EconTotals {
		int oreUnits;
		int rareOreUnits;
		int volatilesUnits;
		int organicsUnits;
		final List<String> contributingPlanets = new ArrayList<String>();
	}

	private static EconTotals computeEconTotalsForPlanet(PlanetAPI planet) {
		EconTotals totals = new EconTotals();
		if (planet == null) return totals;
		MarketAPI market = planet.getMarket();
		if (market == null) return totals;

		boolean contributed = false;

		int oreTier = tierIndexOre(market, Conditions.ORE_SPARSE, Conditions.ORE_MODERATE,
				Conditions.ORE_ABUNDANT, Conditions.ORE_RICH, Conditions.ORE_ULTRARICH);
		if (oreTier > 0) {
			totals.oreUnits = Math.max(1, ORE_TIER_MODIFIERS[oreTier]);
			contributed = true;
		}

		int rareOreTier = tierIndexOre(market, Conditions.RARE_ORE_SPARSE, Conditions.RARE_ORE_MODERATE,
				Conditions.RARE_ORE_ABUNDANT, Conditions.RARE_ORE_RICH, Conditions.RARE_ORE_ULTRARICH);
		if (rareOreTier > 0) {
			totals.rareOreUnits = Math.max(1, ORE_TIER_MODIFIERS[rareOreTier]);
			contributed = true;
		}

		int volatilesTier = tierIndexFour(market, Conditions.VOLATILES_TRACE, Conditions.VOLATILES_DIFFUSE,
				Conditions.VOLATILES_ABUNDANT, Conditions.VOLATILES_PLENTIFUL);
		if (volatilesTier > 0) {
			totals.volatilesUnits = Math.max(1, FOUR_TIER_MODIFIERS[volatilesTier]);
			contributed = true;
		}

		int organicsTier = tierIndexFour(market, Conditions.ORGANICS_TRACE, Conditions.ORGANICS_COMMON,
				Conditions.ORGANICS_ABUNDANT, Conditions.ORGANICS_PLENTIFUL);
		if (organicsTier > 0) {
			totals.organicsUnits = Math.max(1, FOUR_TIER_MODIFIERS[organicsTier]);
			contributed = true;
		}

		if (contributed) {
			totals.contributingPlanets.add(planet.getName());
		}

		return totals;
	}

	private static EconTotals computeEconTotalsForBeltOrField(String label) {
		EconTotals totals = new EconTotals();
		totals.oreUnits = 1;
		totals.rareOreUnits = 1;
		totals.volatilesUnits = 1;
		totals.contributingPlanets.add(label);
		return totals;
	}

	private static EconTotals computeEconTotals(SectorEntityToken station) {
		PlanetAPI planet = getOrbitedPlanet(station);
		if (planet != null) return computeEconTotalsForPlanet(planet);
		if (isOrbitingBeltOrField(station)) return computeEconTotalsForBeltOrField("the asteroid belt/field the station orbits");
		return new EconTotals();
	}

	private static EconTotals computeEconTotalsPreview(CampaignFleetAPI playerFleet) {
		PlanetAPI planet = PlayerHQUtils.getPreviewOrbitPlanet(playerFleet);
		if (planet != null) return computeEconTotalsForPlanet(planet);
		if (PlayerHQUtils.isPreviewOrbitBeltOrField(playerFleet)) return computeEconTotalsForBeltOrField("the asteroid belt/field");
		return new EconTotals();
	}

	public static class MiningResult {
		public float ore;
		public float rareOre;
		public float volatiles;
		public float organics;
		public float oreLostToCap;
		public float rareOreLostToCap;
		public float volatilesLostToCap;
		public float organicsLostToCap;
		public final List<String> contributingPlanets = new ArrayList<String>();
	}

	public static MiningResult collectResources(SectorEntityToken station) {
		MiningResult result = new MiningResult();

		EconTotals totals = computeEconTotals(station);
		result.contributingPlanets.addAll(totals.contributingPlanets);

		if (station.getMarket() == null) return result;
		float efficiency = getCombinedEfficiency(station);
		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		float aiMult = EasyRules.miningMult(station);
		float attemptedOre = totals.oreUnits * ECON_UNIT_VALUE * efficiency;
		float attemptedRareOre = totals.rareOreUnits * ECON_UNIT_VALUE * efficiency;
		float attemptedVolatiles = totals.volatilesUnits * ECON_UNIT_VALUE * efficiency;
		float attemptedOrganics = totals.organicsUnits * ECON_UNIT_VALUE * efficiency;
		if (aiMult != 1f) {
			attemptedOre = (float) Math.floor(attemptedOre * aiMult);
			attemptedRareOre = (float) Math.floor(attemptedRareOre * aiMult);
			attemptedVolatiles = (float) Math.floor(attemptedVolatiles * aiMult);
			attemptedOrganics = (float) Math.floor(attemptedOrganics * aiMult);
		}

		result.ore = addCapped(storage, Commodities.ORE, attemptedOre);
		result.rareOre = addCapped(storage, Commodities.RARE_ORE, attemptedRareOre);
		result.volatiles = addCapped(storage, Commodities.VOLATILES, attemptedVolatiles);
		result.organics = addCapped(storage, Commodities.ORGANICS, attemptedOrganics);

		result.oreLostToCap = attemptedOre - result.ore;
		result.rareOreLostToCap = attemptedRareOre - result.rareOre;
		result.volatilesLostToCap = attemptedVolatiles - result.volatiles;
		result.organicsLostToCap = attemptedOrganics - result.organics;

		return result;
	}

	private static float addCapped(CargoAPI storage, String commodityId, float amount) {
		if (amount <= 0f) return 0f;
		float space = getStorageCap(commodityId) - storage.getCommodityQuantity(commodityId);
		if (space <= 0f) return 0f;
		float toAdd = Math.min(amount, space);
		storage.addCommodity(commodityId, toAdd);
		return toAdd;
	}

	public static List<String> getExpectedMonthlyHarvest(SectorEntityToken station) {
		return formatExpectedHarvest(computeEconTotals(station), getCombinedEfficiency(station) * EasyRules.miningMult(station));
	}

	public static List<String> getExpectedMonthlyHarvestForFleet(CampaignFleetAPI playerFleet) {
		return formatExpectedHarvest(computeEconTotalsPreview(playerFleet), EFFICIENCY_BASE);
	}

	private static List<String> formatExpectedHarvest(EconTotals totals, float efficiency) {
		List<String> lines = new ArrayList<String>();

		float ore = totals.oreUnits * ECON_UNIT_VALUE * efficiency;
		float rareOre = totals.rareOreUnits * ECON_UNIT_VALUE * efficiency;
		float volatiles = totals.volatilesUnits * ECON_UNIT_VALUE * efficiency;
		float organics = totals.organicsUnits * ECON_UNIT_VALUE * efficiency;

		if (ore <= 0f && rareOre <= 0f && volatiles <= 0f && organics <= 0f) {
			lines.add("No mineable resource deposits detected here.");
			return lines;
		}

		lines.add(String.format("Expected monthly harvest: ~%s ore, ~%s rare ore, ~%s volatiles, ~%s organics.",
				(int) ore, (int) rareOre, (int) volatiles, (int) organics));
		return lines;
	}
}
