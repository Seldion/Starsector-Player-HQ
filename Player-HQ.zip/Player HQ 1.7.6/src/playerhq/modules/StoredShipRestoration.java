package playerhq.modules;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.skills.FieldRepairsScript;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import playerhq.util.PlayerHQUtils;

public class StoredShipRestoration {

	public static final float MONTHLY_DMOD_REMOVAL_CHANCE = 0.05f;

	private static final Random random = new Random();

	public static boolean hasHullRestorationSkill() {
		return Global.getSector().getPlayerStats() != null
				&& Global.getSector().getPlayerStats().getSkillLevel(Skills.HULL_RESTORATION) > 0;
	}

	public static void runMonthly(SectorEntityToken station) {
		if (!hasHullRestorationSkill()) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null || storage.getMothballedShips() == null) return;

		for (FleetMemberAPI member : new ArrayList<FleetMemberAPI>(storage.getMothballedShips().getMembersListCopy())) {
			if (member == null) continue;
			ShipVariantAPI variant = member.getVariant();
			if (variant == null || variant.isStockVariant()) continue;
			if (member.getHullSpec().hasTag(Tags.HULL_UNRESTORABLE) || variant.hasTag(Tags.VARIANT_UNRESTORABLE)) continue;
			if (random.nextFloat() >= MONTHLY_DMOD_REMOVAL_CHANCE) continue;

			List<String> removable = new ArrayList<String>();
			for (String id : variant.getHullMods()) {
				HullModSpecAPI spec = DModManager.getMod(id);
				if (spec == null || !spec.hasTag(Tags.HULLMOD_DMOD)) continue;
				if (variant.getHullSpec().getBuiltInMods().contains(id)) continue;
				removable.add(id);
			}
			if (removable.isEmpty()) continue;

			String picked = removable.get(random.nextInt(removable.size()));
			DModManager.removeDMod(variant, picked);
			if (DModManager.getNumNonBuiltInDMods(variant) <= 0) {
				FieldRepairsScript.restoreToNonDHull(variant);
			}

			Global.getSector().getCampaignUI().addMessage("Player HQ: " + member.getShipName() + " - repaired "
					+ DModManager.getMod(picked).getDisplayName() + " (Hull Restoration).");
		}
	}
}
