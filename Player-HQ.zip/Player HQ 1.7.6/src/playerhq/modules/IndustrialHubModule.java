package playerhq.modules;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.mode.EasyRules;
import playerhq.util.PlayerHQUtils;

public class IndustrialHubModule {

	public static final String MEMORY_KEY = "$playerhq_module_industrial";
	public static final String NANOFORGE_MEMORY_KEY = "$playerhq_module_industrial_nanoforge";
	public static final String NANOFORGE_ITEM_KEY = "$playerhq_module_industrial_nanoforge_item";
	public static final String BIOFACTORY_MEMORY_KEY = "$playerhq_module_industrial_biofactory";
	public static final String CATALYTIC_CORE_MEMORY_KEY = "$playerhq_module_industrial_catalyticcore";
	public static final String SYNCHROTRON_CORE_MEMORY_KEY = "$playerhq_module_industrial_synchrotroncore";

	public static final float CREDIT_COST = 45000f;
	public static final float METALS_COST = 3000f;
	public static final float TRANSPLUTONICS_COST = 600f;
	public static final float VOLATILES_COST = 480f;
	public static final float HEAVY_MACHINERY_COST = 2500f;

	public static final float ORE_PER_METAL = 5f;
	public static final float RARE_ORE_PER_TRANSPLUTONIC = 5f;
	public static final float METALS_OUTPUT_PER_BATCH_BASE = 1f;
	public static final float TRANSPLUTONICS_OUTPUT_PER_BATCH_BASE = 1f;

	public static final float CATALYTIC_CORE_ORE_REDUCTION = 2f;
	public static final float CATALYTIC_CORE_METAL_OUTPUT_BONUS = 2f;
	public static final float CATALYTIC_CORE_RARE_ORE_REDUCTION = 2f;
	public static final float CATALYTIC_CORE_TRANSPLUTONICS_OUTPUT_BONUS = 2f;

	public static final float VOLATILES_PER_FUEL_BATCH = 1f;
	public static final float FUEL_PER_BATCH = 10f;

	public static final float HEAVY_MACHINERY_METALS_COST = 10f;
	public static final float HEAVY_MACHINERY_TRANSPLUTONICS_COST = 5f;
	public static final float HEAVY_MACHINERY_BATCH_OUTPUT = 10f;

	public static final float SUPPLIES_BATCH_ORGANICS_COST = 1f;
	public static final float SUPPLIES_BATCH_METALS_COST = 1f;
	public static final float SUPPLIES_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float SUPPLIES_BATCH_VOLATILES_COST = 1f;
	public static final float SUPPLIES_BATCH_FOOD_COST = 1f;
	public static final float SUPPLIES_BATCH_OUTPUT = 15f;

	public static final float HEAVY_ARMAMENTS_BATCH_METALS_COST = 10f;
	public static final float HEAVY_ARMAMENTS_BATCH_TRANSPLUTONICS_COST = 10f;
	public static final float HEAVY_ARMAMENTS_BATCH_VOLATILES_COST = 5f;
	public static final float HEAVY_ARMAMENTS_BATCH_OUTPUT = 10f;

	public static final float DRUGS_BATCH_ORGANICS_COST = 3f;
	public static final float DRUGS_BATCH_METALS_COST = 1f;
	public static final float DRUGS_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float DRUGS_BATCH_OUTPUT = 15f;

	public static final float ORGANS_BATCH_ORGANICS_COST = 10f;
	public static final float ORGANS_BATCH_OUTPUT = 5f;

	public static final float DOMESTIC_GOODS_BATCH_METALS_COST = 1f;
	public static final float DOMESTIC_GOODS_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float DOMESTIC_GOODS_BATCH_ORGANICS_COST = 1f;
	public static final float DOMESTIC_GOODS_BATCH_OUTPUT = 10f;

	public static final float LUXURY_GOODS_BATCH_METALS_COST = 2f;
	public static final float LUXURY_GOODS_BATCH_TRANSPLUTONICS_COST = 1f;
	public static final float LUXURY_GOODS_BATCH_ORGANICS_COST = 2f;
	public static final float LUXURY_GOODS_BATCH_DRUGS_COST = 1f;
	public static final float LUXURY_GOODS_BATCH_OUTPUT = 10f;

	public static final float MAX_STORED_RESOURCES = 15000f;

	public static final float MAX_ORE_REFINED_PER_MONTH = 500f;
	public static final float MAX_RARE_ORE_REFINED_PER_MONTH = 500f;
	public static final float CATALYTIC_CORE_MAX_ORE_REFINED_PER_MONTH = 2000f;
	public static final float CATALYTIC_CORE_MAX_RARE_ORE_REFINED_PER_MONTH = 2000f;

	public static final float MAX_OUTPUT_PER_MONTH = 200f;
	public static final float MAX_OUTPUT_PER_MONTH_NO_ITEM = 50f;

	public static final float NO_ITEM_COST_MULTIPLIER = 2f;
	public static final float NO_NANOFORGE_COST_MULTIPLIER = 3f;

	public static final String IMAGE_PATH = "graphics/modules/industrial_hub.jpg";

	public static final String PRODUCTION_OFF_KEY_PREFIX = "$playerhq_module_industrial_off_";

	public static final String PRODUCT_METALS = "metals";
	public static final String PRODUCT_TRANSPLUTONICS = "transplutonics";
	public static final String PRODUCT_HEAVY_MACHINERY = "heavyMachinery";
	public static final String PRODUCT_SUPPLIES = "supplies";
	public static final String PRODUCT_FUEL = "fuel";
	public static final String PRODUCT_DRUGS = "drugs";
	public static final String PRODUCT_ORGANS = "organs";
	public static final String PRODUCT_DOMESTIC_GOODS = "domesticGoods";
	public static final String PRODUCT_LUXURY_GOODS = "luxuryGoods";
	public static final String PRODUCT_HEAVY_ARMAMENTS = "heavyArmaments";

	public static final String[] PRODUCT_KEYS = {
		PRODUCT_METALS, PRODUCT_TRANSPLUTONICS, PRODUCT_HEAVY_MACHINERY, PRODUCT_SUPPLIES, PRODUCT_FUEL,
		PRODUCT_DRUGS, PRODUCT_ORGANS, PRODUCT_DOMESTIC_GOODS, PRODUCT_LUXURY_GOODS, PRODUCT_HEAVY_ARMAMENTS
	};

	public static String getProductName(String key) {
		if (PRODUCT_METALS.equals(key)) return "Metals";
		if (PRODUCT_TRANSPLUTONICS.equals(key)) return "Transplutonics";
		if (PRODUCT_HEAVY_MACHINERY.equals(key)) return "Heavy Machinery";
		if (PRODUCT_SUPPLIES.equals(key)) return "Supplies";
		if (PRODUCT_FUEL.equals(key)) return "Fuel";
		if (PRODUCT_DRUGS.equals(key)) return "Drugs";
		if (PRODUCT_ORGANS.equals(key)) return "Organs";
		if (PRODUCT_DOMESTIC_GOODS.equals(key)) return "Domestic Goods";
		if (PRODUCT_LUXURY_GOODS.equals(key)) return "Luxury Goods";
		if (PRODUCT_HEAVY_ARMAMENTS.equals(key)) return "Heavy Armaments";
		return key;
	}

	public static boolean isProductAvailable(SectorEntityToken station, String key) {
		return true;
	}

	public static boolean isProductionEnabled(SectorEntityToken station, String key) {
		return !station.getMemoryWithoutUpdate().getBoolean(PRODUCTION_OFF_KEY_PREFIX + key);
	}

	public static boolean toggleProduction(SectorEntityToken station, String key) {
		boolean nowEnabled = !isProductionEnabled(station, key);
		if (nowEnabled) {
			station.getMemoryWithoutUpdate().unset(PRODUCTION_OFF_KEY_PREFIX + key);
		} else {
			station.getMemoryWithoutUpdate().set(PRODUCTION_OFF_KEY_PREFIX + key, true);
		}
		return nowEnabled;
	}

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) return EasyRules.canAfford(playerFleet, EasyRules.PRICE_HIGH);
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.VOLATILES) >= VOLATILES_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) {
			EasyRules.pay(playerFleet, EasyRules.PRICE_HIGH);
			station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
			return;
		}
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.RARE_METALS, TRANSPLUTONICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.VOLATILES, VOLATILES_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		refund(station, playerFleet, playerFleet.getCargo());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI cargo) {
		if (!isBuilt(station)) return;

		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_HIGH);
			EasyRules.returnCore(station, EasyRules.MOD_MANUFACTORIUM, cargo);
			if (hasNanoforgeInstalled(station)) {
				String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
				if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
			}
			return;
		}

		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.RARE_METALS, TRANSPLUTONICS_COST * fraction);
		cargo.addCommodity(Commodities.VOLATILES, VOLATILES_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);

		if (hasNanoforgeInstalled(station)) {
			String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
			if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(itemId, null), 1);
		}
		if (hasBiofactoryInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.BIOFACTORY_EMBRYO, null), 1);
		}
		if (hasCatalyticCoreInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.CATALYTIC_CORE, null), 1);
		}
		if (hasSynchrotronCoreInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SYNCHROTRON, null), 1);
		}
	}

	public static boolean hasNanoforgeInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(NANOFORGE_MEMORY_KEY);
	}

	public static boolean hasNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CORRUPTED_NANOFORGE)
				|| PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	public static boolean hasCorruptedNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CORRUPTED_NANOFORGE);
	}

	public static boolean hasPristineNanoforgeAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	public static void installCorruptedNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		installNanoforgeTier(station, playerFleet, Items.CORRUPTED_NANOFORGE);
	}

	public static void installPristineNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		installNanoforgeTier(station, playerFleet, Items.PRISTINE_NANOFORGE);
	}

	private static void installNanoforgeTier(SectorEntityToken station, CampaignFleetAPI playerFleet, String itemId) {
		if (!PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, itemId)) return;

		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, itemId, 1);
		station.getMemoryWithoutUpdate().set(NANOFORGE_ITEM_KEY, itemId);
		station.getMemoryWithoutUpdate().set(NANOFORGE_MEMORY_KEY, true);
	}

	public static void uninstallNanoforge(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasNanoforgeInstalled(station)) return;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		if (itemId == null) itemId = Items.CORRUPTED_NANOFORGE;
		PlayerHQUtils.addToStationInventory(station, itemId, 1);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(NANOFORGE_ITEM_KEY);
	}

	public static String getInstalledNanoforgeId(SectorEntityToken station) {
		if (!hasNanoforgeInstalled(station)) return null;
		String itemId = station.getMemoryWithoutUpdate().getString(NANOFORGE_ITEM_KEY);
		return itemId != null ? itemId : Items.CORRUPTED_NANOFORGE;
	}

	public static boolean isCorruptedNanoforgeInstalled(SectorEntityToken station) {
		return Items.CORRUPTED_NANOFORGE.equals(getInstalledNanoforgeId(station));
	}

	public static boolean isPristineNanoforgeInstalled(SectorEntityToken station) {
		return Items.PRISTINE_NANOFORGE.equals(getInstalledNanoforgeId(station));
	}

	public static final float CORRUPTED_NANOFORGE_RESOURCE_MULTIPLIER = 2f;

	public static float getNanoforgeResourceMultiplier(SectorEntityToken station) {
		if (!hasNanoforgeInstalled(station)) return NO_NANOFORGE_COST_MULTIPLIER;
		return isCorruptedNanoforgeInstalled(station) ? CORRUPTED_NANOFORGE_RESOURCE_MULTIPLIER : 1f;
	}

	public static float getSynchrotronResourceMultiplier(SectorEntityToken station) {
		return hasSynchrotronCoreInstalled(station) ? 1f : NO_ITEM_COST_MULTIPLIER;
	}

	public static float getBiofactoryResourceMultiplier(SectorEntityToken station) {
		return hasBiofactoryInstalled(station) ? 1f : NO_ITEM_COST_MULTIPLIER;
	}

	private static float getOutputCap(boolean itemInstalled) {
		return itemInstalled ? MAX_OUTPUT_PER_MONTH : MAX_OUTPUT_PER_MONTH_NO_ITEM;
	}

	private static float[] scaled(float[] amounts, float multiplier) {
		if (multiplier == 1f) return amounts;
		float[] out = new float[amounts.length];
		for (int i = 0; i < amounts.length; i++) out[i] = amounts[i] * multiplier;
		return out;
	}

	public static boolean hasBiofactoryInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(BIOFACTORY_MEMORY_KEY);
	}

	public static boolean hasBiofactoryAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.BIOFACTORY_EMBRYO);
	}

	public static void installBiofactory(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.BIOFACTORY_EMBRYO, 1);
		station.getMemoryWithoutUpdate().set(BIOFACTORY_MEMORY_KEY, true);
	}

	public static void uninstallBiofactory(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasBiofactoryInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.BIOFACTORY_EMBRYO, 1);
		station.getMemoryWithoutUpdate().unset(BIOFACTORY_MEMORY_KEY);
	}

	public static boolean hasCatalyticCoreInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(CATALYTIC_CORE_MEMORY_KEY);
	}

	public static boolean hasCatalyticCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.CATALYTIC_CORE);
	}

	public static void installCatalyticCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.CATALYTIC_CORE, 1);
		station.getMemoryWithoutUpdate().set(CATALYTIC_CORE_MEMORY_KEY, true);
	}

	public static void uninstallCatalyticCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasCatalyticCoreInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.CATALYTIC_CORE, 1);
		station.getMemoryWithoutUpdate().unset(CATALYTIC_CORE_MEMORY_KEY);
	}

	public static boolean hasSynchrotronCoreInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(SYNCHROTRON_CORE_MEMORY_KEY);
	}

	public static boolean hasSynchrotronCoreAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.SYNCHROTRON);
	}

	public static void installSynchrotronCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.SYNCHROTRON, 1);
		station.getMemoryWithoutUpdate().set(SYNCHROTRON_CORE_MEMORY_KEY, true);
	}

	public static void uninstallSynchrotronCore(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasSynchrotronCoreInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.SYNCHROTRON, 1);
		station.getMemoryWithoutUpdate().unset(SYNCHROTRON_CORE_MEMORY_KEY);
	}

	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasNanoforgeInstalled(station) && !hasBiofactoryInstalled(station)
				&& !hasCatalyticCoreInstalled(station) && !hasSynchrotronCoreInstalled(station);
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet, PlayerHQUtils.getRefundCargo(station, playerFleet));
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	public static float getOrePerMetal(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station) ? ORE_PER_METAL - CATALYTIC_CORE_ORE_REDUCTION : ORE_PER_METAL;
	}

	public static float getRareOrePerTransplutonic(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station) ? RARE_ORE_PER_TRANSPLUTONIC - CATALYTIC_CORE_RARE_ORE_REDUCTION : RARE_ORE_PER_TRANSPLUTONIC;
	}

	public static float getMetalsOutputPerBatch(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station)
				? METALS_OUTPUT_PER_BATCH_BASE + CATALYTIC_CORE_METAL_OUTPUT_BONUS : METALS_OUTPUT_PER_BATCH_BASE;
	}

	public static float getTransplutonicsOutputPerBatch(SectorEntityToken station) {
		return hasCatalyticCoreInstalled(station)
				? TRANSPLUTONICS_OUTPUT_PER_BATCH_BASE + CATALYTIC_CORE_TRANSPLUTONICS_OUTPUT_BONUS : TRANSPLUTONICS_OUTPUT_PER_BATCH_BASE;
	}

	public static class IndustrialHubResult {
		public float metals;
		public float transplutonics;
		public float heavyMachinery;
		public float supplies;
		public float drugs;
		public float organs;
		public float domesticGoods;
		public float luxuryGoods;
		public float heavyArmaments;
		public float fuel;
	}

	private static float convert(CargoAPI storage, String[] inputIds, float[] inputAmounts,
			String outputId, float outputAmount, float maxStorage, float maxBatchesThisRun) {
		float maxBatches = maxBatchesThisRun;
		for (int i = 0; i < inputIds.length; i++) {
			float available = storage.getCommodityQuantity(inputIds[i]);
			float batchesForInput = available / inputAmounts[i];
			if (batchesForInput < maxBatches) maxBatches = batchesForInput;
		}

		float space = maxStorage - storage.getCommodityQuantity(outputId);
		if (space <= 0f) return 0f;
		float batchesForOutput = space / outputAmount;
		if (batchesForOutput < maxBatches) maxBatches = batchesForOutput;

		float batches = (float) Math.floor(maxBatches);
		if (batches <= 0f) return 0f;

		for (int i = 0; i < inputIds.length; i++) {
			storage.removeCommodity(inputIds[i], batches * inputAmounts[i]);
		}
		storage.addCommodity(outputId, batches * outputAmount);
		return batches * outputAmount;
	}

	// Same as convert, but the monthly cap is expressed in refined output units rather than batches.
	private static float convertCappedOutput(CargoAPI storage, String inputId, float inputAmount,
			String outputId, float outputAmount, float maxStorage, float maxOutputThisRun) {
		float available = storage.getCommodityQuantity(inputId);
		float space = maxStorage - storage.getCommodityQuantity(outputId);
		if (space <= 0f) return 0f;
		float out = maxOutputThisRun;
		float outFromInput = (float) Math.floor(available / inputAmount) * outputAmount;
		if (outFromInput < out) out = outFromInput;
		if (space < out) out = space;
		out = (float) Math.floor(out);
		if (out <= 0f) return 0f;
		storage.removeCommodity(inputId, out / outputAmount * inputAmount);
		storage.addCommodity(outputId, out);
		return out;
	}

	public static IndustrialHubResult process(SectorEntityToken station) {
		if (!isBuilt(station)) return new IndustrialHubResult();
		if (station.getMarket() == null) return new IndustrialHubResult();

		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
		return runConversions(storage, station);
	}

	public static IndustrialHubResult previewMonthlyProduction(SectorEntityToken station) {
		if (!isBuilt(station)) return new IndustrialHubResult();
		if (station.getMarket() == null) return new IndustrialHubResult();

		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();
		return runConversions(storage.createCopy(), station);
	}

	private static final String[][] EASY_INPUTS = {
		{ Commodities.ORE },
		{ Commodities.RARE_ORE },
		{ Commodities.METALS, Commodities.RARE_METALS },
		{ Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES, Commodities.FOOD },
		{ Commodities.VOLATILES },
		{ Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS },
		{ Commodities.ORGANICS },
		{ Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS },
		{ Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS, Commodities.DRUGS },
		{ Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES }
	};
	private static final float[][] EASY_AMOUNTS = {
		{ 5f },
		{ 5f },
		{ 10f, 5f },
		{ 1f, 1f, 1f, 1f, 1f },
		{ 1f },
		{ 3f, 1f, 1f },
		{ 10f },
		{ 1f, 1f, 1f },
		{ 2f, 1f, 2f, 1f },
		{ 10f, 10f, 5f }
	};
	private static final String[] EASY_OUTPUTS = {
		Commodities.METALS, Commodities.RARE_METALS, Commodities.HEAVY_MACHINERY, Commodities.SUPPLIES, Commodities.FUEL,
		Commodities.DRUGS, Commodities.ORGANS, Commodities.DOMESTIC_GOODS, Commodities.LUXURY_GOODS, Commodities.HAND_WEAPONS
	};
	private static final float[] EASY_OUT_PER_BATCH = { 1f, 1f, 10f, 15f, 10f, 15f, 5f, 10f, 10f, 10f };
	private static final String[] EASY_KEYS = {
		PRODUCT_METALS, PRODUCT_TRANSPLUTONICS, PRODUCT_HEAVY_MACHINERY, PRODUCT_SUPPLIES, PRODUCT_FUEL,
		PRODUCT_DRUGS, PRODUCT_ORGANS, PRODUCT_DOMESTIC_GOODS, PRODUCT_LUXURY_GOODS, PRODUCT_HEAVY_ARMAMENTS
	};

	public static float getEasyInputPerBatch(SectorEntityToken station, int index, int input) {
		boolean refining = index < 2;
		return refining ? EASY_AMOUNTS[index][input] : EASY_AMOUNTS[index][input] * EasyRules.manufactoriumCostMult(station);
	}

	public static String[] getEasyInputs(int index) {
		return EASY_INPUTS[index];
	}

	public static String getEasyOutput(int index) {
		return EASY_OUTPUTS[index];
	}

	public static String getEasyKey(int index) {
		return EASY_KEYS[index];
	}

	public static float getEasyOutputPerBatch(int index) {
		return EASY_OUT_PER_BATCH[index];
	}

	private static float convertEasy(CargoAPI storage, String[] inputs, float[] perBatch, String output,
			float outPerBatch, float maxOutput) {
		float maxOut = maxOutput;
		for (int i = 0; i < inputs.length; i++) {
			float avail = storage.getCommodityQuantity(inputs[i]);
			float o = avail / perBatch[i] * outPerBatch;
			if (o < maxOut) maxOut = o;
		}
		float space = MiningHangarModule.getStorageCap(output) - storage.getCommodityQuantity(output);
		if (space < maxOut) maxOut = space;
		int out = (int) Math.floor(maxOut);
		while (out > 0) {
			boolean ok = true;
			for (int i = 0; i < inputs.length; i++) {
				float need = (float) Math.ceil(out / outPerBatch * perBatch[i]);
				if (need > storage.getCommodityQuantity(inputs[i])) {
					ok = false;
					break;
				}
			}
			if (ok) break;
			out--;
		}
		if (out <= 0) return 0f;
		for (int i = 0; i < inputs.length; i++) {
			float need = (float) Math.ceil(out / outPerBatch * perBatch[i]);
			storage.removeCommodity(inputs[i], need);
		}
		storage.addCommodity(output, out);
		return out;
	}

	private static IndustrialHubResult runConversionsEasy(CargoAPI storage, SectorEntityToken station) {
		IndustrialHubResult result = new IndustrialHubResult();
		float cap = EasyRules.manufactoriumCap(station);
		float[] made = new float[EASY_KEYS.length];
		for (int i = 0; i < EASY_KEYS.length; i++) {
			if (!isProductionEnabled(station, EASY_KEYS[i])) continue;
			float[] per = new float[EASY_INPUTS[i].length];
			for (int j = 0; j < per.length; j++) per[j] = getEasyInputPerBatch(station, i, j);
			made[i] = convertEasy(storage, EASY_INPUTS[i], per, EASY_OUTPUTS[i], EASY_OUT_PER_BATCH[i],
					i < 2 ? EasyRules.MANUFACTORIUM_CAP_REFINING : cap);
		}
		result.metals = made[0];
		result.transplutonics = made[1];
		result.heavyMachinery = made[2];
		result.supplies = made[3];
		result.fuel = made[4];
		result.drugs = made[5];
		result.organs = made[6];
		result.domesticGoods = made[7];
		result.luxuryGoods = made[8];
		result.heavyArmaments = made[9];
		return result;
	}

	private static IndustrialHubResult runConversions(CargoAPI storage, SectorEntityToken station) {
		if (EasyRules.on()) return runConversionsEasy(storage, station);
		IndustrialHubResult result = new IndustrialHubResult();

		if (isProductionEnabled(station, PRODUCT_METALS)) {
			result.metals = convertCappedOutput(storage, Commodities.ORE, getOrePerMetal(station),
					Commodities.METALS, getMetalsOutputPerBatch(station), MiningHangarModule.getStorageCap(Commodities.METALS),
					hasCatalyticCoreInstalled(station) ? CATALYTIC_CORE_MAX_ORE_REFINED_PER_MONTH : MAX_ORE_REFINED_PER_MONTH);
		}
		if (isProductionEnabled(station, PRODUCT_TRANSPLUTONICS)) {
			result.transplutonics = convertCappedOutput(storage, Commodities.RARE_ORE, getRareOrePerTransplutonic(station),
					Commodities.RARE_METALS, getTransplutonicsOutputPerBatch(station), MiningHangarModule.getStorageCap(Commodities.RARE_METALS),
					hasCatalyticCoreInstalled(station) ? CATALYTIC_CORE_MAX_RARE_ORE_REFINED_PER_MONTH : MAX_RARE_ORE_REFINED_PER_MONTH);
		}

		if (isProductionEnabled(station, PRODUCT_HEAVY_MACHINERY)) {
			result.heavyMachinery = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS },
					new float[] { HEAVY_MACHINERY_METALS_COST, HEAVY_MACHINERY_TRANSPLUTONICS_COST },
					Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					MAX_OUTPUT_PER_MONTH / HEAVY_MACHINERY_BATCH_OUTPUT);
		}
		if (isProductionEnabled(station, PRODUCT_SUPPLIES)) {
			result.supplies = convert(storage,
					new String[] { Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES, Commodities.FOOD },
					new float[] { SUPPLIES_BATCH_ORGANICS_COST, SUPPLIES_BATCH_METALS_COST, SUPPLIES_BATCH_TRANSPLUTONICS_COST,
							SUPPLIES_BATCH_VOLATILES_COST, SUPPLIES_BATCH_FOOD_COST },
					Commodities.SUPPLIES, SUPPLIES_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					MAX_OUTPUT_PER_MONTH / SUPPLIES_BATCH_OUTPUT);
		}

		if (isProductionEnabled(station, PRODUCT_FUEL)) {
			float cap = getOutputCap(hasSynchrotronCoreInstalled(station));
			result.fuel = convert(storage, new String[] { Commodities.VOLATILES },
					scaled(new float[] { VOLATILES_PER_FUEL_BATCH }, getSynchrotronResourceMultiplier(station)),
					Commodities.FUEL, FUEL_PER_BATCH, MAX_STORED_RESOURCES,
					cap / FUEL_PER_BATCH);
		}

		float biofactoryMult = getBiofactoryResourceMultiplier(station);
		float biofactoryCap = getOutputCap(hasBiofactoryInstalled(station));
		if (isProductionEnabled(station, PRODUCT_DRUGS)) {
			result.drugs = convert(storage,
					new String[] { Commodities.ORGANICS, Commodities.METALS, Commodities.RARE_METALS },
					scaled(new float[] { DRUGS_BATCH_ORGANICS_COST, DRUGS_BATCH_METALS_COST, DRUGS_BATCH_TRANSPLUTONICS_COST }, biofactoryMult),
					Commodities.DRUGS, DRUGS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					biofactoryCap / DRUGS_BATCH_OUTPUT);
		}
		if (isProductionEnabled(station, PRODUCT_ORGANS)) {
			result.organs = convert(storage,
					new String[] { Commodities.ORGANICS },
					scaled(new float[] { ORGANS_BATCH_ORGANICS_COST }, biofactoryMult),
					Commodities.ORGANS, ORGANS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					biofactoryCap / ORGANS_BATCH_OUTPUT);
		}

		float nanoforgeMult = getNanoforgeResourceMultiplier(station);
		float nanoforgeCap = getOutputCap(hasNanoforgeInstalled(station));
		if (isProductionEnabled(station, PRODUCT_DOMESTIC_GOODS)) {
			result.domesticGoods = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS },
					scaled(new float[] { DOMESTIC_GOODS_BATCH_METALS_COST, DOMESTIC_GOODS_BATCH_TRANSPLUTONICS_COST, DOMESTIC_GOODS_BATCH_ORGANICS_COST }, nanoforgeMult),
					Commodities.DOMESTIC_GOODS, DOMESTIC_GOODS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					nanoforgeCap / DOMESTIC_GOODS_BATCH_OUTPUT);
		}
		if (isProductionEnabled(station, PRODUCT_LUXURY_GOODS)) {
			result.luxuryGoods = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.ORGANICS, Commodities.DRUGS },
					scaled(new float[] { LUXURY_GOODS_BATCH_METALS_COST, LUXURY_GOODS_BATCH_TRANSPLUTONICS_COST,
							LUXURY_GOODS_BATCH_ORGANICS_COST, LUXURY_GOODS_BATCH_DRUGS_COST }, nanoforgeMult),
					Commodities.LUXURY_GOODS, LUXURY_GOODS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					nanoforgeCap / LUXURY_GOODS_BATCH_OUTPUT);
		}
		if (isProductionEnabled(station, PRODUCT_HEAVY_ARMAMENTS)) {
			result.heavyArmaments = convert(storage,
					new String[] { Commodities.METALS, Commodities.RARE_METALS, Commodities.VOLATILES },
					scaled(new float[] { HEAVY_ARMAMENTS_BATCH_METALS_COST, HEAVY_ARMAMENTS_BATCH_TRANSPLUTONICS_COST,
							HEAVY_ARMAMENTS_BATCH_VOLATILES_COST }, nanoforgeMult),
					Commodities.HAND_WEAPONS, HEAVY_ARMAMENTS_BATCH_OUTPUT, MAX_STORED_RESOURCES,
					nanoforgeCap / HEAVY_ARMAMENTS_BATCH_OUTPUT);
		}

		return result;
	}
}
