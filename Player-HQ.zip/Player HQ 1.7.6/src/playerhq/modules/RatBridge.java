package playerhq.modules;

import assortment_of_things.frontiers.FrontiersUtils;
import assortment_of_things.frontiers.SettlementData;
import com.fs.starfarer.api.campaign.SectorEntityToken;

final class RatBridge {

	private RatBridge() { }

	static SectorEntityToken getSettlementEntity() {
		FrontiersUtils utils = FrontiersUtils.INSTANCE;
		if (!utils.hasSettlement()) return null;
		SettlementData data = utils.getSettlementData();
		if (data == null) return null;
		return data.getSettlementEntity();
	}
}
