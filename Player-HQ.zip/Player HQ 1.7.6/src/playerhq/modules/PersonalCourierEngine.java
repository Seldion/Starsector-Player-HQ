package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.util.Misc;
import playerhq.abilities.CourierPickupTransferDialogPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PersonalCourierEngine {

	public static final String REQUIRED_MOD_ID = "humbles_mods";

	private static final String STATE_KEY = "$playerhq_personalcourier_state";
	private static final String FLEET_KEY = "$playerhq_personalcourier_fleet";
	private static final String LOCKED_KEY = "$playerhq_personalcourier_locked";
	private static final String SPAWN_TIME_KEY = "$playerhq_personalcourier_spawntime";

	private static final String STATE_OUTBOUND = "outbound";
	private static final String STATE_RETURNING = "returning";

	private static final float SPAWN_DISTANCE = 700f;
	private static final float ARRIVAL_RANGE = 300f;
	private static final float REARM_RANGE = 800f;
	private static final float ASSIGNMENT_DAYS = 999f;
	private static final float MAX_LIFETIME_DAYS = 90f;

	public static boolean isModPresent() {
		try {
			return Global.getSettings().getModManager().isModEnabled(REQUIRED_MOD_ID);
		} catch (Throwable t) {
			return false;
		}
	}

	public static boolean isActive(SectorEntityToken station) {
		return station != null && station.getMemoryWithoutUpdate().getString(STATE_KEY) != null;
	}

	private static CampaignFleetAPI getFleet(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getFleet(FLEET_KEY);
	}

	static int findCrewedCourierBay(SectorEntityToken station) {
		for (int i = 0; i < MilitaryWardModule.MAX_COURIER_BAYS; i++) {
			if (!MilitaryWardModule.isCourierBayBuilt(station, i) || MilitaryWardModule.isCourierBayDestroyed(station, i)) continue;
			List<FleetMemberAPI> ships = MilitaryWardModule.getCourierBayCommittedShips(station, i);
			if (ships != null && !ships.isEmpty()) return i;
		}
		return -1;
	}

	public static boolean hasCrewedCourierBay(SectorEntityToken station) {
		return station != null && findCrewedCourierBay(station) >= 0;
	}

	public static boolean canCall(SectorEntityToken station) {
		return isModPresent() && !isActive(station) && hasCrewedCourierBay(station);
	}

	public static String notReadyReason(SectorEntityToken station) {
		if (isActive(station)) return "Currently " + getStatusText(station) + ".";
		if (!hasCrewedCourierBay(station)) return "Requires a Courier Bay to be crewed in the Player HQ's Fleet HQ.";
		return "Calls a Personal Courier.";
	}

	public static String getStatusText(SectorEntityToken station) {
		String state = station.getMemoryWithoutUpdate().getString(STATE_KEY);
		if (STATE_OUTBOUND.equals(state)) return "heading to your fleet";
		if (STATE_RETURNING.equals(state)) return "returning to the station";
		return "unavailable";
	}

	public static boolean call(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canCall(station) || playerFleet == null) return false;
		LocationAPI loc = playerFleet.getContainingLocation();
		if (loc == null) return false;
		int bayIndex = findCrewedCourierBay(station);
		if (bayIndex < 0) return false;
		List<FleetMemberAPI> source = MilitaryWardModule.getCourierBayCommittedShips(station, bayIndex);
		List<FleetMemberAPI> ships = MilitaryWardModule.createFreshShipCopies(source);
		if (ships.isEmpty()) return false;

		CampaignFleetAPI fleet = Global.getFactory().createEmptyFleet(Factions.PLAYER, "Personal Courier", false);
		for (FleetMemberAPI m : ships) {
			fleet.getFleetData().addFleetMember(m);
		}
		fleet.getFleetData().setFlagship(ships.get(0));
		MilitaryWardModule.markAsNonInteractiveTraffic(fleet, ASSIGNMENT_DAYS * 2f);
		fleet.getMemoryWithoutUpdate().set(MemFlags.DO_NOT_TRY_TO_AVOID_NEARBY_FLEETS, true);
		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_FLEET_DO_NOT_GET_SIDETRACKED, true);
		MilitaryWardModule.applyRushBurn(fleet);
		MilitaryWardModule.injectFleetLogistics(fleet, ships);
		loc.addEntity(fleet);
		MilitaryWardModule.refreshFleetCR(fleet);

		float angle = new Random().nextFloat() * 360f;
		float x = playerFleet.getLocation().x + (float) Math.cos(Math.toRadians(angle)) * SPAWN_DISTANCE;
		float y = playerFleet.getLocation().y + (float) Math.sin(Math.toRadians(angle)) * SPAWN_DISTANCE;
		fleet.setLocation(x, y);

		MilitaryWardModule.rushTowardsPlayer(fleet, playerFleet, ASSIGNMENT_DAYS);

		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(STATE_KEY, STATE_OUTBOUND);
		mem.set(FLEET_KEY, fleet);
		mem.set(SPAWN_TIME_KEY, Global.getSector().getClock().getTimestamp());
		mem.unset(LOCKED_KEY);
		return true;
	}

	private static void clear(SectorEntityToken station) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.unset(STATE_KEY);
		mem.unset(FLEET_KEY);
		mem.unset(LOCKED_KEY);
		mem.unset(SPAWN_TIME_KEY);
	}

	private static void despawn(SectorEntityToken station, CampaignFleetAPI fleet) {
		if (fleet != null && fleet.isAlive()) {
			for (FleetMemberAPI m : new ArrayList<FleetMemberAPI>(fleet.getFleetData().getMembersListCopy())) {
				fleet.getFleetData().removeFleetMember(m);
			}
			fleet.despawn();
		}
		clear(station);
	}

	public static void advanceRealtime(SectorEntityToken station) {
		if (!isActive(station)) return;
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		String state = mem.getString(STATE_KEY);
		CampaignFleetAPI fleet = getFleet(station);
		if (fleet == null || !fleet.isAlive()) {
			clear(station);
			return;
		}
		if (mem.contains(SPAWN_TIME_KEY)
				&& Global.getSector().getClock().getElapsedDaysSince(mem.getLong(SPAWN_TIME_KEY)) > MAX_LIFETIME_DAYS) {
			despawn(station, fleet);
			return;
		}
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return;

		if (STATE_RETURNING.equals(state)) {
			if (MilitaryWardModule.courierHasArrived(fleet, station, ARRIVAL_RANGE, ASSIGNMENT_DAYS)) {
				despawn(station, fleet);
			}
			return;
		}

		if (fleet.getContainingLocation() != playerFleet.getContainingLocation()) {
			MilitaryWardModule.rushTowardsPlayer(fleet, playerFleet, ASSIGNMENT_DAYS);
			return;
		}

		float dist = Misc.getDistance(fleet, playerFleet);
		boolean locked = mem.getBoolean(LOCKED_KEY);
		if (dist > ARRIVAL_RANGE) {
			MilitaryWardModule.rushTowardsPlayer(fleet, playerFleet, ASSIGNMENT_DAYS);
			if (locked && dist > REARM_RANGE) mem.unset(LOCKED_KEY);
			return;
		}
		if (locked) return;
		if (Global.getSector().getCampaignUI().isShowingDialog() || Global.getSector().getCampaignUI().isShowingMenu()) return;

		mem.set(LOCKED_KEY, true);
		fleet.clearAssignments();
		openDialog(station, fleet, playerFleet);
	}

	private static void openDialog(final SectorEntityToken station, final CampaignFleetAPI fleet, CampaignFleetAPI playerFleet) {
		Runnable onDismiss = new Runnable() {
			@Override
			public void run() {
				if (fleet != null && fleet.isAlive()) beginReturn(station, fleet);
				else clear(station);
			}
		};
		Global.getSector().getCampaignUI().addMessage("Your Personal Courier meets up with your fleet.");
		Global.getSector().getCampaignUI().showInteractionDialog(
				new CourierPickupTransferDialogPlugin(station, fleet, onDismiss, true), playerFleet);
	}

	private static void beginReturn(SectorEntityToken station, CampaignFleetAPI fleet) {
		fleet.clearAssignments();
		fleet.addAssignment(FleetAssignment.GO_TO_LOCATION, station, ASSIGNMENT_DAYS);
		MemoryAPI mem = station.getMemoryWithoutUpdate();
		mem.set(STATE_KEY, STATE_RETURNING);
		mem.unset(LOCKED_KEY);
	}

	public static String getLocationText(SectorEntityToken station) {
		if (!isActive(station)) return null;
		return MilitaryWardModule.getFleetLocationText(getFleet(station));
	}
}
