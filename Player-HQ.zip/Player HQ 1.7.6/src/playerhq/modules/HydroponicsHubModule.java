package playerhq.modules;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import playerhq.abilities.ConstructPlayerHQAbility;
import playerhq.mode.EasyRules;
import playerhq.util.PlayerHQUtils;

public class HydroponicsHubModule {

	public static final String MEMORY_KEY = "$playerhq_module_hydroponics";
	public static final String NANITES_MEMORY_KEY = "$playerhq_module_hydroponics_nanites";
	public static final String LAMP_MEMORY_KEY = "$playerhq_module_hydroponics_fusionlamp";
	public static final String LAMP_UNPOWERED_MEMORY_KEY = "$playerhq_module_hydroponics_fusionlamp_unpowered";

	public static final float CREDIT_COST = 20000f;
	public static final float METALS_COST = 1000f;
	public static final float ORGANICS_COST = 2000f;
	public static final float HEAVY_MACHINERY_COST = 100f;

	public static final float FOOD_BASE = 100f;
	public static final float ORGANICS_BASE = 50f;
	public static final float NANITES_BONUS = 250f;
	public static final float NANITES_ORGANICS_BONUS = 150f;
	public static final float LAMP_FOOD_BONUS = 450f;
	public static final float LAMP_ORGANICS_BONUS = 300f;
	public static final float LAMP_VOLATILES_UPKEEP = 4f;

	public static final float MAX_STORED_RESOURCES = 15000f;

	public static final String IMAGE_PATH = "graphics/modules/hydroponics_hub.jpg";

	public static boolean isBuilt(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(MEMORY_KEY);
	}

	public static boolean hasCost(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) return EasyRules.canAfford(playerFleet, EasyRules.PRICE_LOW);
		return playerFleet.getCargo().getCredits().get() >= CREDIT_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.METALS) >= METALS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.ORGANICS) >= ORGANICS_COST
				&& PlayerHQUtils.getCombinedCommodityQuantity(station, playerFleet, Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_COST;
	}

	public static void build(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (EasyRules.on()) {
			EasyRules.pay(playerFleet, EasyRules.PRICE_LOW);
			station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
			return;
		}
		playerFleet.getCargo().getCredits().subtract(CREDIT_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.METALS, METALS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.ORGANICS, ORGANICS_COST);
		PlayerHQUtils.removeCombinedCommodity(station, playerFleet, Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST);

		station.getMemoryWithoutUpdate().set(MEMORY_KEY, true);
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		refund(station, playerFleet, playerFleet.getCargo());
	}

	public static void refund(SectorEntityToken station, CampaignFleetAPI playerFleet, CargoAPI cargo) {
		if (!isBuilt(station)) return;

		if (EasyRules.on()) {
			EasyRules.refundCredits(EasyRules.PRICE_LOW);
			EasyRules.returnCore(station, EasyRules.MOD_BIODOME, cargo);
			if (hasNanitesInstalled(station)) {
				cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SOIL_NANITES, null), 1);
			}
			return;
		}

		float fraction = ConstructPlayerHQAbility.REFUND_FRACTION;
		cargo.addCommodity(Commodities.METALS, METALS_COST * fraction);
		cargo.addCommodity(Commodities.ORGANICS, ORGANICS_COST * fraction);
		cargo.addCommodity(Commodities.HEAVY_MACHINERY, HEAVY_MACHINERY_COST * fraction);

		if (hasLampInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.ORBITAL_FUSION_LAMP, null), 1);
		}
		if (hasNanitesInstalled(station)) {
			cargo.addItems(CargoItemType.SPECIAL, new SpecialItemData(Items.SOIL_NANITES, null), 1);
		}
	}

	public static boolean hasNanitesInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(NANITES_MEMORY_KEY);
	}

	public static boolean hasNanitesAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.SOIL_NANITES);
	}

	public static void installNanites(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.SOIL_NANITES, 1);
		station.getMemoryWithoutUpdate().set(NANITES_MEMORY_KEY, true);
	}

	public static void uninstallNanites(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasNanitesInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.SOIL_NANITES, 1);
		station.getMemoryWithoutUpdate().unset(NANITES_MEMORY_KEY);
	}

	public static boolean hasLampInstalled(SectorEntityToken station) {
		return station.getMemoryWithoutUpdate().getBoolean(LAMP_MEMORY_KEY);
	}

	public static boolean hasLampAvailable(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		return PlayerHQUtils.hasCombinedSpecialItem(station, playerFleet, Items.ORBITAL_FUSION_LAMP);
	}

	public static void installLamp(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		PlayerHQUtils.removeCombinedSpecialItem(station, playerFleet, Items.ORBITAL_FUSION_LAMP, 1);
		station.getMemoryWithoutUpdate().set(LAMP_MEMORY_KEY, true);
		station.getMemoryWithoutUpdate().unset(LAMP_UNPOWERED_MEMORY_KEY);
	}

	public static void uninstallLamp(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!hasLampInstalled(station)) return;
		PlayerHQUtils.addToStationInventory(station, Items.ORBITAL_FUSION_LAMP, 1);
		station.getMemoryWithoutUpdate().unset(LAMP_MEMORY_KEY);
		station.getMemoryWithoutUpdate().unset(LAMP_UNPOWERED_MEMORY_KEY);
	}

	public static boolean isLampActive(SectorEntityToken station) {
		return hasLampInstalled(station) && !station.getMemoryWithoutUpdate().getBoolean(LAMP_UNPOWERED_MEMORY_KEY);
	}

	public static void payLampUpkeep(SectorEntityToken station) {
		if (!isBuilt(station) || !hasLampInstalled(station)) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null && storage.getCommodityQuantity(Commodities.VOLATILES) >= LAMP_VOLATILES_UPKEEP) {
			storage.removeCommodity(Commodities.VOLATILES, LAMP_VOLATILES_UPKEEP);
			station.getMemoryWithoutUpdate().unset(LAMP_UNPOWERED_MEMORY_KEY);
		} else {
			station.getMemoryWithoutUpdate().set(LAMP_UNPOWERED_MEMORY_KEY, true);
			Global.getSector().getCampaignUI().addMessage("The Bio-Dome's Fusion Lamp had no Volatiles to run on this month, "
					+ "so its production bonus is off.");
		}
	}

	public static boolean canDismantle(SectorEntityToken station) {
		return isBuilt(station) && !hasNanitesInstalled(station) && !hasLampInstalled(station);
	}

	public static void dismantle(SectorEntityToken station, CampaignFleetAPI playerFleet) {
		if (!canDismantle(station)) return;
		refund(station, playerFleet, PlayerHQUtils.getRefundCargo(station, playerFleet));
		station.getMemoryWithoutUpdate().unset(MEMORY_KEY);
	}

	public static float getFoodPerMonth(SectorEntityToken station) {
		float amount = FOOD_BASE;
		if (hasNanitesInstalled(station)) amount += NANITES_BONUS;
		if (isLampActive(station)) amount += LAMP_FOOD_BONUS;
		amount += EasyRules.biodomeBonus(station);
		return amount;
	}

	public static float getOrganicsPerMonth(SectorEntityToken station) {
		float amount = ORGANICS_BASE;
		if (hasNanitesInstalled(station)) amount += NANITES_ORGANICS_BONUS;
		if (isLampActive(station)) amount += LAMP_ORGANICS_BONUS;
		amount += EasyRules.biodomeBonus(station);
		return amount;
	}

	public static class HydroponicsResult {
		public float food;
		public float organics;
		public float foodLostToCap;
		public float organicsLostToCap;
	}

	public static HydroponicsResult produce(SectorEntityToken station) {
		HydroponicsResult result = new HydroponicsResult();
		if (!isBuilt(station)) return result;
		if (station.getMarket() == null) return result;

		CargoAPI storage = station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo();

		float attemptedFood = getFoodPerMonth(station);
		float attemptedOrganics = getOrganicsPerMonth(station);

		result.food = addCapped(storage, Commodities.FOOD, attemptedFood);
		result.organics = addCapped(storage, Commodities.ORGANICS, attemptedOrganics);

		result.foodLostToCap = attemptedFood - result.food;
		result.organicsLostToCap = attemptedOrganics - result.organics;

		return result;
	}

	private static float addCapped(CargoAPI storage, String commodityId, float amount) {
		if (amount <= 0f) return 0f;
		float space = MiningHangarModule.getStorageCap(commodityId) - storage.getCommodityQuantity(commodityId);
		if (space <= 0f) return 0f;
		float toAdd = Math.min(amount, space);
		storage.addCommodity(commodityId, toAdd);
		return toAdd;
	}
}
