package playerhq.abilities;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;

public class CourierCrewGuard implements EveryFrameScript {

	private final int expectedCrew;
	private final int expectedMarines;
	private float secondsLeft;
	private boolean done = false;

	public CourierCrewGuard(int expectedCrew, int expectedMarines, float seconds) {
		this.expectedCrew = expectedCrew;
		this.expectedMarines = expectedMarines;
		this.secondsLeft = seconds;
	}

	public static void restore(int expectedCrew, int expectedMarines, String where) {
		CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();
		if (fleet == null) return;
		int crew = fleet.getCargo().getCrew();
		int marines = fleet.getCargo().getMarines();
		if (expectedCrew >= 0 && crew < expectedCrew) {
			fleet.getCargo().addCrew(expectedCrew - crew);
			Global.getLogger(CourierCrewGuard.class).info("Courier handoff: restored " + (expectedCrew - crew)
					+ " crew that was removed outside the hand-over (" + where + ")");
		}
		if (expectedMarines >= 0 && marines < expectedMarines) {
			fleet.getCargo().addMarines(expectedMarines - marines);
			Global.getLogger(CourierCrewGuard.class).info("Courier handoff: restored " + (expectedMarines - marines)
					+ " marines that were removed outside the hand-over (" + where + ")");
		}
	}

	@Override
	public void advance(float amount) {
		restore(expectedCrew, expectedMarines, "after the hand-over screen closed");
		secondsLeft -= Math.max(amount, 0.0001f);
		if (secondsLeft <= 0f) done = true;
	}

	@Override
	public boolean isDone() {
		return done;
	}

	@Override
	public boolean runWhilePaused() {
		return true;
	}
}
