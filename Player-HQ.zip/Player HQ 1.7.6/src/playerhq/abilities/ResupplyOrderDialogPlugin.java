package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoPickerListener;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import playerhq.modules.MilitaryWardModule;
import playerhq.util.PlayerHQUtils;

import java.util.Map;

public class ResupplyOrderDialogPlugin implements InteractionDialogPlugin {

	private static final String OPTION_DISPATCH = "playerhq_resupply_order_dispatch";
	private static final String OPTION_CHANGE = "playerhq_resupply_order_change";
	private static final String OPTION_CANCEL = "playerhq_resupply_order_cancel";

	private final SectorEntityToken station;

	private InteractionDialogAPI dialog;
	private float capCargo;
	private float capFuel;
	private int capCrew;
	private float orderSupplies;
	private float orderFuel;
	private int orderCrew;

	public ResupplyOrderDialogPlugin(SectorEntityToken station) {
		this.station = station;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		dialog.getTextPanel().clear();
		dialog.getOptionPanel().clearOptions();
		dialog.setPromptText("Resupply Fleet");

		float[] cap = MilitaryWardModule.getResupplyFleetCapacity(station);
		capCargo = cap[0];
		capFuel = cap[1];
		capCrew = (int) cap[2];

		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null || (storage.getSupplies() <= 0f && storage.getFuel() <= 0f && storage.getCrew() <= 0)) {
			dialog.getTextPanel().addPara("The Player HQ's storage has no Supplies, Fuel or Crew to send.");
			dialog.getOptionPanel().addOption("Cancel", OPTION_CANCEL);
			return;
		}

		dialog.getTextPanel().addPara("Choose what the Resupply Fleet should carry. It can hold up to " + (int) capCargo
				+ " Supplies, " + (int) capFuel + " Fuel and " + capCrew + " Crew, and what you order is taken out of the "
				+ "Player HQ's storage when it launches.");
		showPicker();
	}

	private void showPicker() {
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		CargoAPI offer = Global.getFactory().createCargo(true);
		if (storage != null) {
			offer.addSupplies(storage.getSupplies());
			offer.addFuel(storage.getFuel());
			offer.addCrew(storage.getCrew());
		}

		dialog.getOptionPanel().clearOptions();
		dialog.showCargoPickerDialog("Resupply Fleet Order", "Order", "Cancel", false, 400f, offer, new CargoPickerListener() {
			@Override
			public void pickedCargo(CargoAPI picked) {
				orderSupplies = Math.min(picked.getSupplies(), capCargo);
				orderFuel = Math.min(picked.getFuel(), capFuel);
				orderCrew = Math.min(picked.getCrew(), capCrew);
				boolean clamped = picked.getSupplies() > capCargo || picked.getFuel() > capFuel || picked.getCrew() > capCrew;
				showSummary(clamped);
			}

			@Override
			public void cancelledCargoSelection() {
				dialog.dismiss();
			}

			@Override
			public void recreateTextPanel(TooltipMakerAPI panel, CargoAPI cargo, CargoStackAPI pickedUp,
					boolean pickedUpFromSource, CargoAPI combined) {
				panel.addPara("Resupply Fleet capacity: " + (int) capCargo + " Supplies, " + (int) capFuel + " Fuel, "
						+ capCrew + " Crew. Anything picked beyond that is left in storage.", 0f);
			}
		});
	}

	private void showSummary(boolean clamped) {
		TextPanelAPI text = dialog.getTextPanel();
		OptionPanelAPI options = dialog.getOptionPanel();
		options.clearOptions();
		text.addPara("Order: " + (int) orderSupplies + " Supplies, " + (int) orderFuel + " Fuel, " + orderCrew + " Crew.");
		if (clamped) {
			text.addPara("Some of your selection exceeded the fleet's holds and was cut down to fit.");
		}
		options.addOption("Send the Resupply Fleet", OPTION_DISPATCH);
		options.setEnabled(OPTION_DISPATCH, orderSupplies > 0f || orderFuel > 0f || orderCrew > 0);
		options.addOption("Change Order", OPTION_CHANGE);
		options.addOption("Cancel", OPTION_CANCEL);
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (OPTION_DISPATCH.equals(optionData)) {
			CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
			if (MilitaryWardModule.dispatchResupplyFleet(station, playerFleet, orderSupplies, orderFuel, orderCrew)) {
				Global.getSector().getCampaignUI().addMessage("The Resupply Fleet departs the Player HQ with your order "
						+ "and starts heading your way.");
			}
			dialog.dismiss();
			return;
		}
		if (OPTION_CHANGE.equals(optionData)) {
			showPicker();
			return;
		}
		dialog.dismiss();
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
