package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import playerhq.mode.HQMode;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;
import playerhq.util.PlayerHQUtils;

import java.util.Map;

public class PlayerHQBuildChoiceDialogPlugin implements InteractionDialogPlugin {

	private static final String OPTION_LOWTECH = "playerhq_build_lowtech";
	private static final String OPTION_HIGHTECH = "playerhq_build_hightech";
	private static final String OPTION_EASYBUILD = "playerhq_build_easy";
	private static final String OPTION_CANCEL = "playerhq_build_cancel";
	private static final String OPTION_EASY = "playerhq_mode_easy";
	private static final String OPTION_STARFARER = "playerhq_mode_starfarer";
	private static final String OPTION_TEXT = "playerhq_style_text";
	private static final String OPTION_COLONY = "playerhq_style_colony";
	private static final String OPTION_MODE_BACK = "playerhq_mode_back";

	private String pickedDifficulty = null;
	private String pickedStyle = null;

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;
	private OptionPanelAPI options;

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		this.text = dialog.getTextPanel();
		this.options = dialog.getOptionPanel();

		HQMode.migrateOldSaves();
		if (!HQMode.isChosen()) {
			showDifficulty();
			return;
		}
		showDesign();
	}

	private void showDifficulty() {
		options.clearOptions();
		text.addPara("Choose how Player HQ plays. This choice is locked for this save once the station is built.");
		text.addPara("Easy Mode: A simplified version of the Player HQ, costing only credits after initial build costs.");
		text.addPara("Starfarer Mode: A more in-depth version of the Player HQ requiring resources as well as credits to build, "
				+ "allowing more feature to be used as well as more customization for the fleets.");
		options.addOption("Easy Mode", OPTION_EASY, "Credits-only modules and fleets, simple production, no build times, 5% monthly upkeep.");
		options.addOption("Starfarer Mode", OPTION_STARFARER, "The full Player HQ.");
		options.addOption("Cancel", OPTION_CANCEL);
		dialog.setPromptText("Build Player HQ");
	}

	private void showStyle() {
		options.clearOptions();
		text.addPara(HQMode.difficultyLabel(pickedDifficulty) + " selected. Now choose how the station is run. "
				+ "This choice is locked for this save once the station is built.");
		text.addPara("Text: modules are built and managed from the station's text menu.");
		text.addPara("Visual: modules are structures built from the Colonies screen, like a colony.");
		options.addOption("Text", OPTION_TEXT, "Build and manage modules from the station's text menu.");
		options.addOption("Visual", OPTION_COLONY, HQMode.COLONY_AVAILABLE
				? "Build modules as structures from the Colonies screen."
				: "Not available in this build yet.");
		options.setEnabled(OPTION_COLONY, HQMode.COLONY_AVAILABLE);
		options.addOption("Back", OPTION_MODE_BACK);
		options.addOption("Cancel", OPTION_CANCEL);
		dialog.setPromptText("Build Player HQ");
	}

	private void showDesign() {
		options.clearOptions();
		boolean easyDesign = HQMode.isChosen() ? HQMode.isEasy() : HQMode.EASY.equals(pickedDifficulty);
		if (easyDesign) {
			text.addPara("Construct the Player HQ station. One Gamma Core is needed to complete construction.");
		} else {
			text.addPara("Choose a design for the Player HQ station. Both designs share the same base "
					+ "cost, including one Gamma Core to complete construction.");
		}

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		CargoAPI cargo = playerFleet.getCargo();

		boolean easyShown = HQMode.isChosen() ? HQMode.isEasy() : HQMode.EASY.equals(pickedDifficulty);
		if (easyShown) {
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics and %s volatiles, and needs %s heavy machinery on hand.",
					(int) ConstructPlayerHQAbility.EASY_CREDIT_COST, (int) ConstructPlayerHQAbility.EASY_METALS_COST,
					(int) ConstructPlayerHQAbility.EASY_TRANSPLUTONICS_COST, (int) ConstructPlayerHQAbility.EASY_VOLATILES_COST,
					(int) ConstructPlayerHQAbility.EASY_HEAVY_MACHINERY_REQUIRED));
		} else {
			text.addPara(String.format("Costs %s credits, %s metals, %s transplutonics and %s volatiles, and needs %s heavy machinery on hand.",
					(int) ConstructPlayerHQAbility.CREDIT_COST, (int) ConstructPlayerHQAbility.METALS_COST,
					(int) ConstructPlayerHQAbility.TRANSPLUTONICS_COST, (int) ConstructPlayerHQAbility.VOLATILES_COST,
					(int) ConstructPlayerHQAbility.HEAVY_MACHINERY_REQUIRED));
		}

		addBenefitsPreview(playerFleet);

		boolean hasGamma = ConstructPlayerHQAbility.hasCore(cargo, Commodities.GAMMA_CORE);

		if (easyDesign) {
			options.addOption("Build Player HQ", OPTION_EASYBUILD, "Requires one Gamma Core in addition to the base cost.");
			options.setEnabled(OPTION_EASYBUILD, hasGamma);
			options.addOption("Cancel", OPTION_CANCEL);
			dialog.setPromptText("Construct Player HQ");
			return;
		}

		options.addOption("Build Low-Tech HQ", OPTION_LOWTECH, "Requires one Gamma Core in addition to the base cost.");
		options.setEnabled(OPTION_LOWTECH, hasGamma);

		options.addOption("Build High-Tech HQ", OPTION_HIGHTECH, "Requires one Gamma Core in addition to the base cost.");
		options.setEnabled(OPTION_HIGHTECH, hasGamma);

		options.addOption("Cancel", OPTION_CANCEL);

		dialog.setPromptText("Construct Player HQ");
	}

	private void addBenefitsPreview(CampaignFleetAPI playerFleet) {
		StarSystemAPI system = playerFleet.getStarSystem();
		if (system == null) return;

		boolean hasAnyBenefit = false;

		java.util.List<String> miningLines = MiningHangarModule.getExpectedMonthlyHarvestForFleet(playerFleet);
		MarketAPI orbitMarket = PlayerHQUtils.getPreviewOrbitMarket(playerFleet);
		float recIncome = RecreationalHubModule.getExpectedIncomeForMarket(orbitMarket);

		boolean hasMiningBenefit = !miningLines.isEmpty()
				&& !miningLines.get(0).startsWith("No mineable");
		if (hasMiningBenefit || recIncome > 0f) {
			text.addPara("Expected benefits of building here:");
			hasAnyBenefit = true;
		}

		if (hasMiningBenefit) {
			text.addPara("Materials Acquisition Hub (if built): " + miningLines.get(0).replace("Expected monthly harvest: ", ""));
		}

		if (recIncome > 0f) {
			text.addPara(String.format("Resort (if built): ~%s credits/month, from %s.",
					(int) recIncome, orbitMarket.getName()));
		}

		if (!hasAnyBenefit) {
			text.addPara("No mineable resources detected here, and this isn't orbit of a colonized "
					+ "planet, so a Materials Acquisition Hub or Resort wouldn't have much to work with at "
					+ "this location.");
		}
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (OPTION_CANCEL.equals(optionData)) {
			dialog.dismissAsCancel();
			return;
		}
		if (OPTION_EASY.equals(optionData) || OPTION_STARFARER.equals(optionData)) {
			pickedDifficulty = OPTION_EASY.equals(optionData) ? HQMode.EASY : HQMode.STARFARER;
			showStyle();
			return;
		}
		if (OPTION_MODE_BACK.equals(optionData)) {
			showDifficulty();
			return;
		}
		if (OPTION_TEXT.equals(optionData) || OPTION_COLONY.equals(optionData)) {
			pickedStyle = OPTION_COLONY.equals(optionData) ? HQMode.COLONY : HQMode.TEXT;
			showDesign();
			return;
		}

		boolean lowTech = OPTION_LOWTECH.equals(optionData);
		boolean easyBuild = OPTION_EASYBUILD.equals(optionData);
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		CargoAPI cargo = playerFleet.getCargo();

		boolean easyPick = HQMode.isChosen() ? HQMode.isEasy() : HQMode.EASY.equals(pickedDifficulty);
		if (!ConstructPlayerHQAbility.hasSharedCost(cargo, easyPick) || !ConstructPlayerHQAbility.hasCore(cargo, Commodities.GAMMA_CORE)) {
			text.addPara("You no longer have the resources required for this design.");
			if (easyBuild) {
				options.setEnabled(OPTION_EASYBUILD, ConstructPlayerHQAbility.hasCore(cargo, Commodities.GAMMA_CORE));
			} else {
				options.setEnabled(OPTION_LOWTECH, ConstructPlayerHQAbility.hasCore(cargo, Commodities.GAMMA_CORE));
				options.setEnabled(OPTION_HIGHTECH, ConstructPlayerHQAbility.hasCore(cargo, Commodities.GAMMA_CORE));
			}
			return;
		}

		if (!HQMode.isChosen()) HQMode.lockIn(pickedDifficulty, pickedStyle);
		ConstructPlayerHQAbility.buildStation(playerFleet, lowTech);
		text.addPara("Construction of the Player HQ (" + (easyBuild ? "" : (lowTech ? "Low-Tech" : "High-Tech") + ", ") + HQMode.describe() + ") is complete.");
		if (HQMode.isEasy() && GodivaPopup.show(dialog, new GodivaPopup.Listener() {
			public void onClosed() {
				dialog.dismiss();
			}
		})) {
			return;
		}
		dialog.dismiss();
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
