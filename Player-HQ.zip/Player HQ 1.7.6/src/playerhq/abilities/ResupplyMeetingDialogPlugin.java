package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoPickerListener;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import playerhq.modules.MilitaryWardModule;

import java.util.Map;

public class ResupplyMeetingDialogPlugin implements InteractionDialogPlugin {

	private static final String OPTION_ACCEPT = "playerhq_resupply_meeting_accept";
	private static final String OPTION_WAIT = "playerhq_resupply_meeting_wait";
	private static final String OPTION_RETURN = "playerhq_resupply_meeting_return";

	private final SectorEntityToken station;
	private final int meeting;

	private InteractionDialogAPI dialog;

	public ResupplyMeetingDialogPlugin(SectorEntityToken station, int meeting) {
		this.station = station;
		this.meeting = meeting;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		showMenu();
	}

	private void showMenu() {
		TextPanelAPI text = dialog.getTextPanel();
		OptionPanelAPI options = dialog.getOptionPanel();
		options.clearOptions();
		dialog.setPromptText("Resupply Fleet");

		text.addPara("The Resupply Fleet is alongside your fleet, carrying " + (int) MilitaryWardModule.getResupplyFleetLoadSupplies(station)
				+ " Supplies, " + (int) MilitaryWardModule.getResupplyFleetLoadFuel(station) + " Fuel and "
				+ MilitaryWardModule.getResupplyFleetLoadCrew(station) + " Crew.");

		options.addOption("Accept Transfer", OPTION_ACCEPT, "Choose what to take from the Resupply Fleet. The fleet "
				+ "then heads back to the station, and whatever you leave behind goes back into the Player HQ's storage.");
		if (meeting < MilitaryWardModule.RESUPPLY_FLEET_MAX_MEETINGS) {
			options.addOption("Wait", OPTION_WAIT, "The fleet stays close to you for " + MilitaryWardModule.RESUPPLY_FLEET_FOLLOW_DAYS
					+ " days, then asks you again.");
		}
		options.addOption("Return to Base", OPTION_RETURN, "The fleet heads back to the station without handing over "
				+ "anything. Its cargo goes back into the Player HQ's storage.");
	}

	private void showPicker() {
		CargoAPI offer = Global.getFactory().createCargo(true);
		offer.addSupplies(MilitaryWardModule.getResupplyFleetLoadSupplies(station));
		offer.addFuel(MilitaryWardModule.getResupplyFleetLoadFuel(station));
		offer.addCrew(MilitaryWardModule.getResupplyFleetLoadCrew(station));

		dialog.showCargoPickerDialog("Resupply Fleet", "Take", "Back", false, 400f, offer, new CargoPickerListener() {
			@Override
			public void pickedCargo(CargoAPI picked) {
				float supplies = Math.min(picked.getSupplies(), MilitaryWardModule.getResupplyFleetLoadSupplies(station));
				float fuel = Math.min(picked.getFuel(), MilitaryWardModule.getResupplyFleetLoadFuel(station));
				int crew = Math.min(picked.getCrew(), MilitaryWardModule.getResupplyFleetLoadCrew(station));

				if (supplies <= 0f && fuel <= 0f && crew <= 0) {
					dialog.getTextPanel().addPara("You didn't take anything.");
					showMenu();
					return;
				}

				CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
				if (playerFleet != null) {
					if (supplies > 0f) playerFleet.getCargo().addSupplies(supplies);
					if (fuel > 0f) playerFleet.getCargo().addFuel(fuel);
					if (crew > 0) playerFleet.getCargo().addCrew(crew);
				}
				MilitaryWardModule.takeResupplyFleetLoad(station, supplies, fuel, crew);
				MilitaryWardModule.departResupplyFleetAfterMeeting(station);
				Global.getSector().getCampaignUI().addMessage("Transfer complete. The Resupply Fleet heads back to the Player HQ.");
				dialog.dismiss();
			}

			@Override
			public void cancelledCargoSelection() {
				showMenu();
			}

			@Override
			public void recreateTextPanel(TooltipMakerAPI panel, CargoAPI cargo, CargoStackAPI pickedUp,
					boolean pickedUpFromSource, CargoAPI combined) {
				panel.addPara("Take Supplies, Fuel and Crew from the Resupply Fleet. Anything you leave behind goes back "
						+ "into the Player HQ's storage.", 0f);
			}
		});
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (OPTION_ACCEPT.equals(optionData)) {
			dialog.getOptionPanel().clearOptions();
			showPicker();
			return;
		}
		if (OPTION_WAIT.equals(optionData)) {
			MilitaryWardModule.waitResupplyFleetAfterMeeting(station);
			Global.getSector().getCampaignUI().addMessage("The Resupply Fleet stays close to your fleet for "
					+ MilitaryWardModule.RESUPPLY_FLEET_FOLLOW_DAYS + " days.");
			dialog.dismiss();
			return;
		}
		if (OPTION_RETURN.equals(optionData)) {
			MilitaryWardModule.departResupplyFleetAfterMeeting(station);
			Global.getSector().getCampaignUI().addMessage("The Resupply Fleet heads back to the Player HQ.");
			dialog.dismiss();
			return;
		}
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
