package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import playerhq.Ids;
import playerhq.PlayerHQMonthlyReportIntel;
import playerhq.PlayerHQMonthlyScript;
import playerhq.modules.AssemblyBayModule;
import playerhq.modules.HydroponicsHubModule;
import playerhq.modules.IndustrialHubModule;
import playerhq.modules.MarketPlaceModule;
import playerhq.modules.MilitaryWardModule;
import playerhq.modules.MiningHangarModule;
import playerhq.modules.RecreationalHubModule;
import playerhq.modules.StationItemsModule;
import playerhq.util.PlayerHQUtils;

import playerhq.mode.HQMode;

import java.awt.Color;

public class ConstructPlayerHQAbility extends BaseDurationAbility {

	public static final float CREDIT_COST = 40000f;
	public static final float METALS_COST = 5000f;
	public static final float TRANSPLUTONICS_COST = 850f;
	public static final float VOLATILES_COST = 520f;

	public static final float EASY_CREDIT_COST = 50000f;
	public static final float EASY_METALS_COST = 3500f;
	public static final float EASY_TRANSPLUTONICS_COST = 500f;
	public static final float EASY_VOLATILES_COST = 500f;
	public static final float EASY_HEAVY_MACHINERY_REQUIRED = 50f;

	public static final float CORE_COST = 1f;

	public static final float HEAVY_MACHINERY_REQUIRED = 200f;

	public static final float REFUND_FRACTION = 0.5f;

	public static final float POPULATED_ORBIT_UPKEEP = 20000f;

	public static final String TAG_LOWTECH = "playerhq_lowtech";
	public static final String TAG_HIGHTECH = "playerhq_hightech";
	public static final String TAG_EASY = "playerhq_easy";

	@Override
	protected void activateImpl() {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return;

		Global.getSector().getCampaignUI().showInteractionDialog(
				new PlayerHQBuildChoiceDialogPlugin(), playerFleet);
	}

	public static boolean hasSharedCost(CargoAPI cargo) {
		if (HQMode.isChosen()) return hasSharedCost(cargo, HQMode.isEasy());
		return hasSharedCost(cargo, false) || hasSharedCost(cargo, true);
	}

	public static boolean hasSharedCost(CargoAPI cargo, boolean easy) {
		if (easy) {
			return cargo.getCredits().get() >= EASY_CREDIT_COST
					&& cargo.getCommodityQuantity(Commodities.METALS) >= EASY_METALS_COST
					&& cargo.getCommodityQuantity(Commodities.RARE_METALS) >= EASY_TRANSPLUTONICS_COST
					&& cargo.getCommodityQuantity(Commodities.VOLATILES) >= EASY_VOLATILES_COST
					&& cargo.getCommodityQuantity(Commodities.HEAVY_MACHINERY) >= EASY_HEAVY_MACHINERY_REQUIRED;
		}
		return cargo.getCredits().get() >= CREDIT_COST
				&& cargo.getCommodityQuantity(Commodities.METALS) >= METALS_COST
				&& cargo.getCommodityQuantity(Commodities.RARE_METALS) >= TRANSPLUTONICS_COST
				&& cargo.getCommodityQuantity(Commodities.VOLATILES) >= VOLATILES_COST
				&& cargo.getCommodityQuantity(Commodities.HEAVY_MACHINERY) >= HEAVY_MACHINERY_REQUIRED;
	}

	public static final String BUILD_CORE_MEMORY_KEY = "$playerhq_buildCore";

	public static boolean hasCore(CargoAPI cargo, String coreCommodityId) {
		return cargo.getCommodityQuantity(coreCommodityId) >= CORE_COST;
	}

	public static void buildStation(CampaignFleetAPI playerFleet, boolean lowTech) {
		CargoAPI cargo = playerFleet.getCargo();
		boolean easy = HQMode.isEasy();
		cargo.getCredits().subtract(easy ? EASY_CREDIT_COST : CREDIT_COST);
		cargo.removeCommodity(Commodities.METALS, easy ? EASY_METALS_COST : METALS_COST);
		cargo.removeCommodity(Commodities.RARE_METALS, easy ? EASY_TRANSPLUTONICS_COST : TRANSPLUTONICS_COST);
		cargo.removeCommodity(Commodities.VOLATILES, easy ? EASY_VOLATILES_COST : VOLATILES_COST);
		cargo.removeCommodity(Commodities.GAMMA_CORE, CORE_COST);

		StarSystemAPI system = playerFleet.getStarSystem();
		String entityTypeId = easy ? Ids.STATION_ENTITY_EASY : lowTech ? Ids.STATION_ENTITY_LOWTECH : Ids.STATION_ENTITY_HIGHTECH;
		String displayName = easy ? "Player HQ" : "Player HQ (" + (lowTech ? "Low-Tech" : "High-Tech") + ")";
		String entityId = "playerhq_station_" + Misc.genUID();

		SectorEntityToken station = system.addCustomEntity(entityId, displayName, entityTypeId, "neutral");
		PlayerHQUtils.placeStationInOrbit(station, playerFleet);

		station.addTag(Ids.TAG_STATION);
		station.addTag(easy ? TAG_EASY : lowTech ? TAG_LOWTECH : TAG_HIGHTECH);
		station.getMemoryWithoutUpdate().set(BUILD_CORE_MEMORY_KEY, Commodities.GAMMA_CORE);

		Misc.setAbandonedStationMarket("playerhq_market_" + Misc.genUID(), station);
		station.setCustomDescriptionId(Ids.STATION_DESCRIPTION_ID);
		station.getMarket().getSubmarket(Submarkets.SUBMARKET_STORAGE).getCargo().initMothballedShips(Factions.PLAYER);
		station.getMarket().addIndustry(Ids.INDUSTRY_DOCKYARD);

		Global.getSector().addScript(new PlayerHQMonthlyScript());
		PlayerHQMonthlyReportIntel.ensureCreated(station);
	}

	public static MarketAPI getColonizedOrbitMarket(SectorEntityToken station) {
		SectorEntityToken focus = station.getOrbitFocus();
		if (!(focus instanceof PlanetAPI)) return null;

		MarketAPI market = focus.getMarket();
		if (market == null) return null;
		if (market.isPlanetConditionMarketOnly()) return null;
		if (market.getSize() <= 0) return null;

		return market;
	}

	public static boolean isOrbitingColonizedPlanet(SectorEntityToken station) {
		return getColonizedOrbitMarket(station) != null;
	}

	public static boolean isUpkeepApplicable(SectorEntityToken station) {
		MarketAPI market = getColonizedOrbitMarket(station);
		return market != null && !market.isPlayerOwned();
	}

	public static float chargeMonthlyUpkeep(SectorEntityToken station) {
		if (!isUpkeepApplicable(station)) return 0f;

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return 0f;

		playerFleet.getCargo().getCredits().subtract(POPULATED_ORBIT_UPKEEP);
		return POPULATED_ORBIT_UPKEEP;
	}

	public static boolean isExistingStationEasy(SectorEntityToken station) {
		return station.hasTag(TAG_EASY);
	}

	public static boolean isExistingStationLowTech(SectorEntityToken station) {
		return station.hasTag(TAG_LOWTECH);
	}

	public static void dismantleStation(CampaignFleetAPI playerFleet) {
		SectorEntityToken station = PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
		if (station == null) return;

		boolean lowTech = isExistingStationLowTech(station);

		CargoAPI cargo = playerFleet.getCargo();
		boolean easyRefund = HQMode.isEasy();
		cargo.addCommodity(Commodities.METALS, (easyRefund ? EASY_METALS_COST : METALS_COST) * REFUND_FRACTION);
		cargo.addCommodity(Commodities.RARE_METALS, (easyRefund ? EASY_TRANSPLUTONICS_COST : TRANSPLUTONICS_COST) * REFUND_FRACTION);
		cargo.addCommodity(Commodities.VOLATILES, (easyRefund ? EASY_VOLATILES_COST : VOLATILES_COST) * REFUND_FRACTION);
		String paidCore = station.getMemoryWithoutUpdate().getString(BUILD_CORE_MEMORY_KEY);
		if (paidCore == null) paidCore = lowTech ? Commodities.GAMMA_CORE : Commodities.BETA_CORE;
		cargo.addCommodity(paidCore, CORE_COST);

		MiningHangarModule.refund(station, playerFleet);
		RecreationalHubModule.refund(station, playerFleet);
		IndustrialHubModule.refund(station, playerFleet);
		HydroponicsHubModule.refund(station, playerFleet);
		AssemblyBayModule.refund(station, playerFleet);
		MilitaryWardModule.refund(station, playerFleet);
		StationItemsModule.refundSpaceElevator(station, playerFleet);
		StationItemsModule.refundPublicShuttles(station, playerFleet);
		StationItemsModule.refundExpandedSorties(station, playerFleet);
		MarketPlaceModule.refund(station, playerFleet);

		PlayerHQUtils.jettisonStationStorage(station);

		if (station.getMarket() != null) {
			Global.getSector().getEconomy().removeMarket(station.getMarket());
		}

		if (station.getContainingLocation() != null) {
			station.getContainingLocation().removeEntity(station);
		}

		PlayerHQMonthlyReportIntel.removeIfPresent();
	}

	private static boolean canBuildAnywhere() {
		return !PlayerHQUtils.entityWithTagExistsAnywhere(Ids.TAG_STATION);
	}

	@Override
	public boolean isUsable() {
		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return false;

		if (!canBuildAnywhere()) return false;

		StarSystemAPI system = playerFleet.getStarSystem();

		if (system == null || playerFleet.isInHyperspace() || playerFleet.isInHyperspaceTransition()) {
			return false;
		}

		boolean nearValidLocation = PlayerHQUtils.playerFleetInAsteroidBelt(playerFleet)
				|| PlayerHQUtils.playerFleetInAsteroidField(playerFleet)
				|| PlayerHQUtils.playerFleetNearPlanet(playerFleet);
		if (!nearValidLocation) return false;

		if (PlayerHQUtils.playerFleetTooCloseToJumpPoint(playerFleet)) return false;

		if (!hasSharedCost(playerFleet.getCargo())) return false;

		return super.isUsable();
	}

	@Override
	public boolean hasTooltip() {
		return true;
	}

	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
		Color highlight = Misc.getHighlightColor();
		Color bad = Misc.getNegativeHighlightColor();
		float pad = 10f;

		if (!canBuildAnywhere()) {
			tooltip.addTitle("Construct Player HQ");
			tooltip.addPara("A Player HQ station already exists. Fly up to it and interact with it directly "
					+ "to access its inventory, transfer ships, refit at its dockyard, or dismantle it.", pad);
			return;
		}

		tooltip.addTitle("Construct Player HQ");
		tooltip.addPara("Construct a Player HQ station in orbit of a planet or within an asteroid belt or "
				+ "field. Choose between a low-tech and high-tech design. The station is unowned, cannot "
				+ "be attacked or taken over, and does not count as a colony. Only one may exist at a time.",
				pad);
		boolean showEasy = !HQMode.isChosen() || HQMode.isEasy();
		boolean showStarfarer = !HQMode.isChosen() || !HQMode.isEasy();
		if (showStarfarer) {
			tooltip.addPara((showEasy ? "Starfarer Mode: " : "") + "Costs %s credits, %s metals, %s transplutonics, and %s volatiles, plus one Gamma "
					+ "Core. Also requires %s heavy machinery on hand "
					+ "to perform the construction (not consumed).", pad, highlight,
					new String[] { (int) CREDIT_COST + "", (int) METALS_COST + "", (int) TRANSPLUTONICS_COST + "",
							(int) VOLATILES_COST + "", (int) HEAVY_MACHINERY_REQUIRED + "" });
		}
		if (showEasy) {
			tooltip.addPara((showStarfarer ? "Easy Mode: " : "") + "Costs %s credits, %s metals, %s transplutonics, and %s volatiles, plus one Gamma Core. "
					+ "Also requires %s heavy machinery on hand to perform the construction (not consumed).",
					pad, highlight,
					new String[] { (int) EASY_CREDIT_COST + "", (int) EASY_METALS_COST + "", (int) EASY_TRANSPLUTONICS_COST + "",
							(int) EASY_VOLATILES_COST + "", (int) EASY_HEAVY_MACHINERY_REQUIRED + "" });
		}
		tooltip.addPara("If built in orbit of a colonized planet, this grants access to the Resort. If built "
				+ "in orbit of a colony you do not own, a %s credit monthly cost will be applied.",
				pad, highlight, (int) POPULATED_ORBIT_UPKEEP + "");

		CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		if (playerFleet == null) return;
		StarSystemAPI system = playerFleet.getStarSystem();

		if (system == null || playerFleet.isInHyperspace() || playerFleet.isInHyperspaceTransition()) {
			tooltip.addPara("You cannot construct a Player HQ station in hyperspace.", bad, pad);
		} else {
			boolean nearValidLocation = PlayerHQUtils.playerFleetInAsteroidBelt(playerFleet)
					|| PlayerHQUtils.playerFleetInAsteroidField(playerFleet)
					|| PlayerHQUtils.playerFleetNearPlanet(playerFleet);
			if (!nearValidLocation) {
				tooltip.addPara("Your fleet must be in orbit of a planet, or within an asteroid belt "
						+ "or asteroid field, to construct a Player HQ station here.", bad, pad);
			}
			if (PlayerHQUtils.playerFleetTooCloseToJumpPoint(playerFleet)) {
				tooltip.addPara("You cannot construct a Player HQ station so close to a jump point.", bad, pad);
			}
		}

		if (!hasSharedCost(playerFleet.getCargo())) {
			tooltip.addPara("Insufficient credits or resources.", bad, pad);
		}
	}

	@Override
	public boolean isTooltipExpandable() {
		return false;
	}

	@Override
	protected void applyEffect(float amount, float level) { }

	@Override
	protected void deactivateImpl() { }

	@Override
	protected void cleanupImpl() { }
}
