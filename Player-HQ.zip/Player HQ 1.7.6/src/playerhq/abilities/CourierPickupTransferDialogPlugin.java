package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoPickerListener;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FleetMemberPickerListener;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import org.lwjgl.input.Keyboard;
import com.fs.starfarer.api.util.Misc;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.List;
import java.util.Map;

public class CourierPickupTransferDialogPlugin implements InteractionDialogPlugin {

	private final SectorEntityToken station;
	private final CampaignFleetAPI courierFleet;
	private final Runnable onDismiss;
	private final CargoAPI pending = Global.getFactory().createCargo(true);
	private final List<FleetMemberAPI> pendingShips = new ArrayList<FleetMemberAPI>();

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;

	private final boolean unlimited;

	public CourierPickupTransferDialogPlugin(SectorEntityToken station, CampaignFleetAPI courierFleet, Runnable onDismiss) {
		this(station, courierFleet, onDismiss, false);
	}

	public CourierPickupTransferDialogPlugin(SectorEntityToken station, CampaignFleetAPI courierFleet, Runnable onDismiss,
			boolean unlimited) {
		this.station = station;
		this.courierFleet = courierFleet;
		this.onDismiss = onDismiss;
		this.unlimited = unlimited;
	}

	private static final String OPTION_DONE = "playerhq_courier_pickup_done";
	private static final String OPTION_SHIPS = "playerhq_courier_pickup_ships";
	private static final String OPTION_CONFIRM_YES = "playerhq_courier_pickup_confirm_yes";
	private static final String OPTION_CONFIRM_NO = "playerhq_courier_pickup_confirm_no";

	private boolean pickerShown = false;
	private int expectedCrew = -1;
	private int expectedMarines = -1;
	private int trackedCrew = -1;
	private int trackedMarines = -1;

	private static class ItemKey {
		final CargoAPI.CargoItemType type;
		final Object data;

		ItemKey(CargoAPI.CargoItemType type, Object data) {
			this.type = type;
			this.data = data;
		}

		boolean isPersonnel(String commodityId) {
			return type == CargoAPI.CargoItemType.RESOURCES && commodityId.equals(data);
		}

		@Override
		public boolean equals(Object o) {
			if (!(o instanceof ItemKey)) return false;
			ItemKey other = (ItemKey) o;
			return type == other.type && (data == null ? other.data == null : data.equals(other.data));
		}

		@Override
		public int hashCode() {
			return (type == null ? 0 : type.hashCode()) * 31 + (data == null ? 0 : data.hashCode());
		}
	}

	private final Set<ItemKey> takeAll = new LinkedHashSet<ItemKey>();
	private ItemKey heldKey = null;
	private int heldAmount = 0;
	private boolean heldFromSource = false;

	private static boolean ctrlDown() {
		try {
			return Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) || Keyboard.isKeyDown(Keyboard.KEY_RCONTROL);
		} catch (Throwable t) {
			return false;
		}
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		this.text = dialog.getTextPanel();

		if (unlimited) {
			text.addPara("Hand off cargo to your Personal Courier -- it has no capacity limit, and everything is "
					+ "deposited into the Player HQ's storage as soon as this window closes.");
		} else {
			text.addPara("Hand off cargo to the Courier Fleet -- it'll be deposited into the Player HQ's storage "
					+ "as soon as this window closes, even past the station's storage limits. Crew and marines "
					+ "over the station's limit are sold at their base price.");
		}
		dialog.getOptionPanel().addOption("Done", OPTION_DONE);
		dialog.setOptionOnEscape("Done", OPTION_DONE);
	}

	private void showPicker() {
		trackedCrew = -1;
		trackedMarines = -1;
		final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		CargoAPI offer = Global.getFactory().createCargo(false);
		for (CargoStackAPI stack : playerFleet.getCargo().getStacksCopy()) {
			if (stack == null || stack.isNull() || stack.isPersonnelStack()) continue;
			offer.addFromStack(stack);
		}
		if (playerFleet.getCargo().getCrew() > 0) offer.addCrew(playerFleet.getCargo().getCrew());
		if (playerFleet.getCargo().getMarines() > 0) offer.addMarines(playerFleet.getCargo().getMarines());
		offer.sort();

		dialog.showCargoPickerDialog("Your Fleet", "Give", "Done", true, 310f, offer, new CargoPickerListener() {
			@Override
			public void pickedCargo(CargoAPI picked) {
				int fleetCrew = playerFleet.getCargo().getCrew();
				int fleetMarines = playerFleet.getCargo().getMarines();
				Global.getLogger(CourierPickupTransferDialogPlugin.class).info("Courier handoff: picked crew="
						+ picked.getCrew() + " marines=" + picked.getMarines() + ", tracked crew=" + trackedCrew
						+ " marines=" + trackedMarines + ", fleet crew=" + fleetCrew + " marines=" + fleetMarines);
				boolean takeAllCrew = false;
				boolean takeAllMarines = false;
				if (heldKey != null && heldFromSource && heldAmount > 0 && !heldKey.isPersonnel(Commodities.CREW)
						&& !heldKey.isPersonnel(Commodities.MARINES)) {
					int have = (int) picked.getQuantity(heldKey.type, heldKey.data);
					int rm = Math.min(have, heldAmount);
					if (rm > 0) picked.removeItems(heldKey.type, heldKey.data, rm);
				}
				for (ItemKey k : takeAll) {
					if (k.isPersonnel(Commodities.CREW)) {
						takeAllCrew = true;
					} else if (k.isPersonnel(Commodities.MARINES)) {
						takeAllMarines = true;
					} else {
						int have = (int) playerFleet.getCargo().getQuantity(k.type, k.data);
						int now = (int) picked.getQuantity(k.type, k.data);
						if (now > 0) picked.removeItems(k.type, k.data, now);
						if (have > 0) picked.addItems(k.type, k.data, have);
					}
				}
				int crewPicked = Math.min(takeAllCrew ? fleetCrew : picked.getCrew(), fleetCrew);
				int marinesPicked = Math.min(takeAllMarines ? fleetMarines : picked.getMarines(), fleetMarines);
				if (trackedCrew >= 0 && !takeAllCrew) crewPicked = Math.min(crewPicked, trackedCrew);
				if (trackedMarines >= 0 && !takeAllMarines) marinesPicked = Math.min(marinesPicked, trackedMarines);
				int personnelRoom = unlimited ? Integer.MAX_VALUE / 4 : playerhq.modules.MilitaryWardModule.getPickupHandoffPersonnelRoom(courierFleet, pending);
				crewPicked = Math.min(crewPicked, personnelRoom);
				marinesPicked = Math.min(marinesPicked, personnelRoom - crewPicked);
				if (picked.getCrew() > crewPicked) picked.removeCrew(picked.getCrew() - crewPicked);
				if (picked.getMarines() > marinesPicked) picked.removeMarines(picked.getMarines() - marinesPicked);
				if (crewPicked > picked.getCrew()) picked.addCrew(crewPicked - picked.getCrew());
				if (marinesPicked > picked.getMarines()) picked.addMarines(marinesPicked - picked.getMarines());
				takeAll.clear();
				heldKey = null;
				heldAmount = 0;
				CargoAPI fitted = fitToCourier(picked);
				for (CargoStackAPI stack : fitted.getStacksCopy()) {
					if (stack == null || stack.isNull() || stack.isPersonnelStack()) continue;
					playerFleet.getCargo().removeItems(stack.getType(), stack.getData(), stack.getSize());
				}
				if (fitted.getCrew() > 0) playerFleet.getCargo().removeCrew(fitted.getCrew());
				if (fitted.getMarines() > 0) playerFleet.getCargo().removeMarines(fitted.getMarines());
				expectedCrew = playerFleet.getCargo().getCrew();
				expectedMarines = playerFleet.getCargo().getMarines();
				pending.addAll(fitted);

				if (unlimited) {
					text.addPara("Transfer complete. Your Personal Courier took everything you handed over, including "
							+ fitted.getCrew() + " crew and " + fitted.getMarines() + " marines.");
				} else
				text.addPara("Transfer complete. The Courier Fleet took " + fitted.getCrew() + " crew and "
						+ fitted.getMarines() + " marines; anything over the Courier Fleet's crew capacity stayed with you. Crew and "
						+ "marines over the Player HQ's storage limit are sold when the Courier Fleet gets back.");
				askToFinish();
			}

			@Override
			public void cancelledCargoSelection() {
				askToFinish();
			}

			@Override
			public void recreateTextPanel(TooltipMakerAPI panel, CargoAPI cargo, CargoStackAPI pickedUp,
					boolean pickedUpFromSource, CargoAPI combined) {
				heldKey = null;
				heldAmount = 0;
				heldFromSource = false;
				int heldCrew = 0;
				int heldMarines = 0;
				if (pickedUp != null && !pickedUp.isNull()) {
					heldKey = new ItemKey(pickedUp.getType(), pickedUp.getData());
					heldAmount = (int) pickedUp.getSize();
					heldFromSource = pickedUpFromSource;
					if (heldFromSource) {
						if (heldKey.isPersonnel(Commodities.CREW)) heldCrew = heldAmount;
						if (heldKey.isPersonnel(Commodities.MARINES)) heldMarines = heldAmount;
					}
					if (ctrlDown()) {
						if (heldFromSource) takeAll.add(heldKey);
						else takeAll.remove(heldKey);
					}
				}
				trackedCrew = Math.max(0, combined.getCrew() - heldCrew);
				trackedMarines = Math.max(0, combined.getMarines() - heldMarines);
				if (unlimited) {
					panel.addPara("Hand off cargo to your Personal Courier. It has no capacity limit and everything is "
							+ "deposited into the Player HQ's storage as soon as this window closes.", 0f);
					panel.addPara("Hold Ctrl and click an item to give all of it. Stacks you pick up but don't put in the "
							+ "Personal Courier's side are not handed over.", 3f);
					return;
				}
				float free = playerhq.modules.MilitaryWardModule.getPickupHandoffRoom(courierFleet, pending);
				float used = 0f;
				for (CargoStackAPI st : combined.getStacksCopy()) {
					if (st == null || st.isNull() || st.isFuelStack() || st.isPersonnelStack()) continue;
					used += st.getCargoSpace();
				}
				boolean over = used > free + 0.01f;
				panel.addPara("Hand off cargo to the Courier Fleet. It'll be deposited into the Player HQ's storage "
						+ "as soon as this window closes, even past the station's storage limits. Crew and marines "
						+ "over the station's limit are sold at their base price.", 0f);
				panel.addPara("Hold Ctrl and click an item to give all of it, as much as the Courier Fleet has room for. "
						+ "Stacks you pick up but don't put in the Courier Fleet's side are not handed over.", 3f);
				panel.addPara("Cargo space: %s / %s", 10f,
						over ? Misc.getNegativeHighlightColor() : Misc.getHighlightColor(),
						"" + (int) used, "" + (int) free);
				float fuelFree = playerhq.modules.MilitaryWardModule.getPickupHandoffFuelRoom(courierFleet, pending);
				float fuelUsed = combined.getFuel();
				boolean fuelOver = fuelUsed > fuelFree + 0.01f;
				panel.addPara("Fuel: %s / %s", 3f,
						fuelOver ? Misc.getNegativeHighlightColor() : Misc.getHighlightColor(),
						"" + (int) fuelUsed, "" + (int) fuelFree);
				int personnelRoom = playerhq.modules.MilitaryWardModule.getPickupHandoffPersonnelRoom(courierFleet, pending);
				int crewFree = personnelRoom;
				int crewUsed = combined.getCrew();
				boolean crewOver = crewUsed > crewFree;
				panel.addPara("Crew: %s / %s", 3f,
						crewOver ? Misc.getNegativeHighlightColor() : Misc.getHighlightColor(),
						"" + crewUsed, "" + crewFree);
				if (combined.getMarines() > 0) {
					int marinesFree = Math.max(0, personnelRoom - Math.min(crewUsed, crewFree));
					boolean marinesOver = combined.getMarines() > marinesFree;
					crewOver = crewOver || marinesOver;
					panel.addPara("Marines: %s / %s", 3f,
							marinesOver ? Misc.getNegativeHighlightColor() : Misc.getHighlightColor(),
							"" + combined.getMarines(), "" + marinesFree);
				}
				if (over || fuelOver || crewOver) {
					panel.addPara("Anything over the Courier Fleet's free space, fuel or crew capacity, will stay with you. Crew and marines "
							+ "over the Player HQ's storage limit are sold.", 3f, Misc.getNegativeHighlightColor(), "stay with you");
				}
			}
		});
	}

	private void askToFinish() {
		dialog.getOptionPanel().clearOptions();
		text.addPara("Are you sure? Once you accept, this window will close and the "
				+ (unlimited ? "Personal Courier" : "Courier Fleet") + " will head back to the HQ.");
		if (!pendingShips.isEmpty()) {
			StringBuilder names = new StringBuilder();
			for (FleetMemberAPI m : pendingShips) {
				if (names.length() > 0) names.append(", ");
				names.append(m.getShipName()).append(" (").append(m.getHullSpec().getHullName()).append(")");
			}
			text.addPara("Ships on board the Courier Fleet: " + names + ".");
		}
		dialog.getOptionPanel().addOption(unlimited ? "Yes, send the Personal Courier back" : "Yes, send the Courier Fleet back", OPTION_CONFIRM_YES);
		dialog.getOptionPanel().addOption("Hand over ships", OPTION_SHIPS);
		dialog.getOptionPanel().addOption("No, go back", OPTION_CONFIRM_NO);
		dialog.setOptionOnEscape("No, go back", OPTION_CONFIRM_NO);
	}

	private void showShipPicker() {
		final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
		List<FleetMemberAPI> pool = playerhq.modules.MilitaryWardModule.getPickupHandoffShipCandidates(playerFleet);
		if (pool.isEmpty()) {
			text.addPara("You have no ships to hand over. Your flagship stays with you.");
			askToFinish();
			return;
		}
		dialog.showFleetMemberPickerDialog("Choose Ships to Hand to the Courier Fleet", "Confirm", "Cancel",
				6, 6, 64f, true, true, pool, new FleetMemberPickerListener() {
					@Override
					public void pickedFleetMembers(List<FleetMemberAPI> members) {
						int moved = 0;
						if (members != null) {
							for (FleetMemberAPI m : members) {
								if (playerhq.modules.MilitaryWardModule.takeShipForPickup(playerFleet, m)) {
									pendingShips.add(m);
									moved++;
								}
							}
						}
						text.addPara(moved > 0 ? moved + " ship" + (moved == 1 ? "" : "s")
								+ " handed to the Courier Fleet. Their officers stay with you." : "No ships handed over.");
						askToFinish();
					}

					@Override
					public void cancelledFleetMemberPicking() {
						askToFinish();
					}
				});
	}

	private CargoAPI fitToCourier(CargoAPI picked) {
		if (unlimited) return playerhq.modules.MilitaryWardModule.fitPickupHandoffUnlimited(picked);
		return playerhq.modules.MilitaryWardModule.fitPickupHandoff(station, courierFleet, picked, pending);
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (OPTION_DONE.equals(optionData)) {
			askToFinish();
		} else if (OPTION_SHIPS.equals(optionData)) {
			dialog.getOptionPanel().clearOptions();
			showShipPicker();
		} else if (OPTION_CONFIRM_YES.equals(optionData)) {
			if (unlimited) playerhq.modules.MilitaryWardModule.depositPickupHandoffUnlimited(station, pending);
			else playerhq.modules.MilitaryWardModule.depositPickupHandoff(station, pending);
			playerhq.modules.MilitaryWardModule.depositPickupShips(station, pendingShips);
			if (expectedCrew >= 0 || expectedMarines >= 0) {
				playerhq.abilities.CourierCrewGuard.restore(expectedCrew, expectedMarines, "when sending the Courier Fleet back");
				Global.getSector().addScript(new playerhq.abilities.CourierCrewGuard(expectedCrew, expectedMarines, 3f));
			}
			dialog.dismiss();
			if (onDismiss != null) onDismiss.run();
		} else if (OPTION_CONFIRM_NO.equals(optionData)) {
			dialog.getOptionPanel().clearOptions();
			dialog.getOptionPanel().addOption("Done", OPTION_DONE);
			dialog.setOptionOnEscape("Done", OPTION_DONE);
			pickerShown = false;
		}
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) {
		if (expectedCrew >= 0 || expectedMarines >= 0) {
			playerhq.abilities.CourierCrewGuard.restore(expectedCrew, expectedMarines, "while the hand-over screen was open");
		}
		if (!pickerShown) {
			pickerShown = true;
			showPicker();
		}
	}

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
