package playerhq.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomVisualDialogDelegate;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;

import java.awt.Color;
import java.io.IOException;
import java.util.List;

public class GodivaPopup extends BaseCustomUIPanelPlugin implements CustomVisualDialogDelegate {

	public static final String SHOWN_KEY = "$playerhq_godiva_shown";
	public static final String IMAGE_PATH = "graphics/modules/patrol_fleet_3.jpg";
	public static final String LINE = "Godiva watches you with narrowed eyes.";

	private static final float WIDTH = 1100f;
	private static final float HEIGHT = 460f;
	private static final float IMAGE_W = 640f;
	private static final float IMAGE_H = 400f;
	private static final float DURATION = 5f;
	private static final Color ORANGE = new Color(255, 120, 0);

	public interface Listener {
		void onClosed();
	}

	private final Listener listener;
	private float elapsed = 0f;
	private DialogCallbacks callbacks;
	private boolean dismissed = false;

	public GodivaPopup(Listener listener) {
		this.listener = listener;
	}

	public static boolean show(InteractionDialogAPI dialog, Listener listener) {
		if (Global.getSector().getMemoryWithoutUpdate().getBoolean(SHOWN_KEY)) return false;
		Global.getSector().getMemoryWithoutUpdate().set(SHOWN_KEY, true);
		dialog.showCustomVisualDialog(WIDTH, HEIGHT, new GodivaPopup(listener));
		return true;
	}

	@Override
	public void init(CustomPanelAPI panel, DialogCallbacks callbacks) {
		this.callbacks = callbacks;
		try {
			Global.getSettings().loadTexture(IMAGE_PATH);
		} catch (IOException e) { }

		float textW = WIDTH - IMAGE_W - 60f;
		TooltipMakerAPI left = panel.createUIElement(textW, 120f, false);
		left.setParaFontOrbitron();
		left.addPara(LINE, ORANGE, 0f);
		panel.addUIElement(left).inTL(20f, (HEIGHT - 120f) / 2f);

		TooltipMakerAPI right = panel.createUIElement(IMAGE_W, IMAGE_H, false);
		right.addImage(IMAGE_PATH, IMAGE_W, IMAGE_H, 0f);
		panel.addUIElement(right).inTR(20f, (HEIGHT - IMAGE_H) / 2f);
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return this;
	}

	@Override
	public float getNoiseAlpha() {
		return 0f;
	}

	@Override
	public void advance(float amount) {
		if (dismissed) return;
		elapsed += amount;
		if (elapsed >= DURATION) {
			dismissed = true;
			callbacks.dismissDialog();
		}
	}

	@Override
	public void processInput(List<InputEventAPI> events) {
		for (InputEventAPI event : events) {
			event.consume();
		}
	}

	@Override
	public void reportDismissed(int option) {
		if (listener != null) listener.onClosed();
	}
}
