package playerhq;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import playerhq.modules.MarketPlaceModule;
import playerhq.shopping.ShoppingListScreen;

import java.util.Map;

public class PlayerHQRemoteShoppingDialogPlugin implements InteractionDialogPlugin {

	private static final String OPTION_DONE = "playerhq_remote_shopping_done";
	private static final String PREFIX = "playerhq_shopping_";

	private final SectorEntityToken station;

	private InteractionDialogAPI dialog;
	private ShoppingListScreen screen;

	public PlayerHQRemoteShoppingDialogPlugin(SectorEntityToken station) {
		this.station = station;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		TextPanelAPI text = dialog.getTextPanel();
		OptionPanelAPI options = dialog.getOptionPanel();

		if (station == null || !station.isAlive() || !MarketPlaceModule.isBuilt(station)) {
			text.addPara("The Shopping List is not available.");
			options.addOption("Continue", OPTION_DONE);
			return;
		}

		screen = new ShoppingListScreen(dialog, station);
		screen.show();
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (OPTION_DONE.equals(optionData) || ShoppingListScreen.OPT_BACK.equals(optionData)) {
			dialog.dismiss();
			return;
		}
		if (screen == null || !(optionData instanceof String)) return;
		String id = (String) optionData;
		if (!id.startsWith(PREFIX)) return;
		screen.handle(id.substring(PREFIX.length()));
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) { }

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
