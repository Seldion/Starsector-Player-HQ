package playerhq.shopping;

import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.PositionAPI;
import com.fs.starfarer.api.ui.TextFieldAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.Color;

public class SaveNameDelegate extends BaseCustomUIPanelPlugin implements CustomDialogDelegate {

	public interface Listener {
		void onFinished(String name);
	}

	public static final float WIDTH = 520f;
	public static final float HEIGHT = 190f;
	private static final String FONT = "graphics/fonts/victor14.fnt";

	private final Listener listener;
	private final String initialName;
	private TextFieldAPI field;
	private PositionAPI panelPosition;

	public SaveNameDelegate(String initialName, Listener listener) {
		this.initialName = initialName == null ? "" : initialName;
		this.listener = listener;
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		TooltipMakerAPI t = panel.createUIElement(WIDTH - 20f, HEIGHT - 20f, false);
		t.addSectionHeading("Save Shopping List", Alignment.MID, 0f);
		t.addPara("Type a name for this list. Using the name of an existing saved list replaces it.", 8f);
		field = t.addTextField(WIDTH - 60f, 28f, FONT, 10f);
		field.setMaxChars(40);
		field.setText(initialName);
		panel.addUIElement(t).inTL(10f, 8f);
		field.grabFocus();
	}

	@Override
	public void positionChanged(PositionAPI position) {
		this.panelPosition = position;
	}

	@Override
	public void renderBelow(float alphaMult) {
		if (panelPosition == null) return;
		Misc.renderQuad(panelPosition.getX(), panelPosition.getY(), panelPosition.getWidth(), panelPosition.getHeight(),
				Color.BLACK, 0.92f * alphaMult);
	}

	@Override
	public boolean hasCancelButton() {
		return true;
	}

	@Override
	public String getConfirmText() {
		return "Save";
	}

	@Override
	public String getCancelText() {
		return "Cancel";
	}

	@Override
	public void customDialogConfirm() {
		String name = field == null || field.getText() == null ? "" : field.getText().trim();
		listener.onFinished(name.isEmpty() ? null : name);
	}

	@Override
	public void customDialogCancel() {
		listener.onFinished(null);
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return this;
	}
}
