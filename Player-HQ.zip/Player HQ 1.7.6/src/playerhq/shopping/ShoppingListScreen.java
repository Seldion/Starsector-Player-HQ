package playerhq.shopping;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.InteractionDialogImageVisual;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.util.Misc;

import java.util.ArrayList;
import java.util.List;

public class ShoppingListScreen {

	public static final String OPT_OPEN = "playerhq_shopping_open";
	public static final String OPT_ADD = "playerhq_shopping_add";
	public static final String OPT_EDIT = "playerhq_shopping_edit";
	public static final String OPT_SAVE = "playerhq_shopping_save";
	public static final String OPT_LOAD = "playerhq_shopping_load";
	public static final String OPT_EDIT_SAVED = "playerhq_shopping_editsaved";
	public static final String OPT_DELETE = "playerhq_shopping_delete";
	public static final String OPT_CAP = "playerhq_shopping_cap";
	public static final String OPT_CLEAR = "playerhq_shopping_clear";
	public static final String OPT_BACK = "playerhq_shopping_back";

	public static final String IMAGE_PATH = "graphics/modules/shopping_list.jpg";

	private static String pendingNotice = null;

	private final InteractionDialogAPI dialog;
	private final SectorEntityToken station;

	public ShoppingListScreen(InteractionDialogAPI dialog, SectorEntityToken station) {
		this.dialog = dialog;
		this.station = station;
	}

	public void show() {
		TextPanelAPI text = dialog.getTextPanel();
		OptionPanelAPI options = dialog.getOptionPanel();
		text.clear();
		options.clearOptions();
		dialog.setPromptText("Shopping List");
		try {
			Global.getSettings().loadTexture(IMAGE_PATH);
		} catch (java.io.IOException e) { }
		dialog.getVisualPanel().showImageVisual(new InteractionDialogImageVisual(IMAGE_PATH, 480, 300));

		List<ShopEntry> entries = ShopListData.getEntries();
		if (pendingNotice != null) {
			text.addPara(pendingNotice, Misc.getPositiveHighlightColor());
			pendingNotice = null;
		}
		text.addPara("The Shopping List allows you to add weapons, wings, hullmods and ships to it that when your trade fleet is out making it's runs it will search the market for those items and bring them back to the station, your HQ will also keep an eye on the Exchange for anything on the list as well and buy them, you can set a threshold where if buying anything takes you below that it won't purchase it. (0 means no limit)");
		text.addPara("Shopping List (" + entries.size() + " entries)");

		float threshold = ShopListData.getThreshold();
		text.addPara("Purchase if above: " + (threshold <= 0f ? "0" : Misc.getDGSCredits(threshold)));

		options.addOption("Add Entry", OPT_ADD);
		options.addOption("Set purchase threshold", OPT_CAP);
		if (!entries.isEmpty()) {
			options.addOption("Edit List", OPT_EDIT);
			options.addOption("Save Shopping List", OPT_SAVE);
		}
		List<SavedLists.SavedList> saved = SavedLists.readAll();
		if (!saved.isEmpty()) {
			options.addOption("Load a saved list", OPT_LOAD);
			options.addOption("Edit a saved list", OPT_EDIT_SAVED);
			options.addOption("Delete a saved list", OPT_DELETE);
		}
		if (!entries.isEmpty()) {
			options.addOption("Clear all entries", OPT_CLEAR);
		}
		options.addOption("Back", OPT_BACK);
		dialog.setOptionOnEscape("Back", OPT_BACK);
	}

	private void openCustom(float w, float h, com.fs.starfarer.api.campaign.CustomDialogDelegate delegate) {
		dialog.getTextPanel().clear();
		dialog.getOptionPanel().clearOptions();
		dialog.showCustomDialog(w, h, delegate);
	}

	private SavedLists.SavedList find(String name) {
		for (SavedLists.SavedList l : SavedLists.readAll()) {
			if (l.name.equals(name)) return l;
		}
		return null;
	}

	private void openSavedEditor(final String name) {
		SavedLists.SavedList l = find(name);
		if (l == null) {
			show();
			return;
		}
		final List<ShopEntry> working = new ArrayList<ShopEntry>(l.entries);
		openCustom(EditListDelegate.WIDTH, EditListDelegate.HEIGHT,
				new EditListDelegate("Edit Saved List: " + name, working, new EditListDelegate.Listener() {
					public void onFinished(boolean saved) {
						if (saved) {
							pendingNotice = SavedLists.save(name, working) ? "Saved changes to \"" + name + "\"."
									: "Could not write the saved list file.";
						}
						show();
					}
				}));
	}

	private void applyLoad(List<String> names, boolean replace) {
		List<ShopEntry> current = ShopListData.getEntries();
		if (replace) current.clear();
		int added = 0;
		int skipped = 0;
		for (String name : names) {
			SavedLists.SavedList l = find(name);
			if (l == null) continue;
			for (ShopEntry e : l.entries) {
				if (!SavedLists.isKnownItem(e)) {
					skipped++;
					continue;
				}
				ShopEntry existing = null;
				for (ShopEntry c : current) {
					if (c.category.equals(e.category) && c.itemId.equals(e.itemId)) {
						existing = c;
						break;
					}
				}
				if (existing != null) {
					existing.mode = e.mode;
					existing.amount = e.amount;
					existing.acceptDmods = e.acceptDmods;
					existing.includeKnown = e.includeKnown;
					existing.bought = 0;
				} else {
					ShopEntry copy = e.copy();
					copy.bought = 0;
					current.add(copy);
				}
				added++;
			}
		}
		pendingNotice = "Loaded " + names.size() + (names.size() == 1 ? " list" : " lists") + ": " + added + " entries "
				+ (replace ? "now on the list" : "added or updated")
				+ (skipped > 0 ? ", " + skipped + " skipped because the item does not exist in this game" : "") + ".";
	}

	public void handle(String command) {
		if (command == null || "open".equals(command)) {
			show();
		} else if ("add".equals(command)) {
			openCustom(AddEntryDelegate.WIDTH, AddEntryDelegate.HEIGHT, new AddEntryDelegate(new AddEntryDelegate.Listener() {
				public void onFinished(ShopEntry added) {
					if (added != null) {
						if (added.isBlueprint()) {
							for (ShopEntry existing : new java.util.ArrayList<ShopEntry>(ShopListData.getEntries())) {
								if (existing.isBlueprint()) ShopListData.getEntries().remove(existing);
							}
						}
						ShopListData.getEntries().add(added);
					}
					show();
				}
			}));
		} else if ("edit".equals(command)) {
			openCustom(EditListDelegate.WIDTH, EditListDelegate.HEIGHT, new EditListDelegate(new EditListDelegate.Listener() {
				public void onFinished(boolean saved) {
					show();
				}
			}));
		} else if ("save".equals(command)) {
			openCustom(SaveNameDelegate.WIDTH, SaveNameDelegate.HEIGHT, new SaveNameDelegate("", new SaveNameDelegate.Listener() {
				public void onFinished(String name) {
					if (name != null) {
						List<ShopEntry> current = ShopListData.getEntries();
						boolean ok = SavedLists.save(name, current);
						pendingNotice = ok ? "Saved list \"" + name + "\" (" + current.size() + " entries). It will be available in any game."
								: "Could not write the saved list file.";
					}
					show();
				}
			}));
		} else if ("load".equals(command)) {
			openCustom(SavedListsDelegate.WIDTH, SavedListsDelegate.HEIGHT, new SavedListsDelegate(SavedListsDelegate.MODE_LOAD, new SavedListsDelegate.Listener() {
				public void onFinished(List<String> names, boolean replace) {
					if (names != null) applyLoad(names, replace);
					show();
				}
			}));
		} else if ("editsaved".equals(command)) {
			openCustom(SavedListsDelegate.WIDTH, SavedListsDelegate.HEIGHT, new SavedListsDelegate(SavedListsDelegate.MODE_EDIT, new SavedListsDelegate.Listener() {
				public void onFinished(List<String> names, boolean replace) {
					if (names == null || names.isEmpty()) {
						show();
						return;
					}
					openSavedEditor(names.get(0));
				}
			}));
		} else if ("delete".equals(command)) {
			openCustom(SavedListsDelegate.WIDTH, SavedListsDelegate.HEIGHT, new SavedListsDelegate(SavedListsDelegate.MODE_DELETE, new SavedListsDelegate.Listener() {
				public void onFinished(List<String> names, boolean replace) {
					if (names != null) {
						boolean ok = true;
						for (String name : names) ok &= SavedLists.delete(name);
						pendingNotice = ok ? "Deleted " + names.size() + (names.size() == 1 ? " saved list." : " saved lists.")
								: "Could not update the saved list file.";
					}
					show();
				}
			}));
		} else if ("cap".equals(command)) {
			openCustom(CapAmountDelegate.WIDTH, CapAmountDelegate.HEIGHT, new CapAmountDelegate(ShopListData.getThreshold(), new CapAmountDelegate.Listener() {
				public void onFinished(Float amount) {
					if (amount != null) {
						ShopListData.setThreshold(amount);
						pendingNotice = amount <= 0f ? "Purchase threshold removed."
								: "The Shopping List will only buy while you stay above " + Misc.getDGSCredits(amount) + " credits.";
					}
					show();
				}
			}));
		} else if ("clear".equals(command)) {
			ShopListData.getEntries().clear();
			show();
		}
	}
}
