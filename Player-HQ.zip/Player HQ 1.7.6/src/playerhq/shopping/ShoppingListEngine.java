package playerhq.shopping;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.impl.items.BlueprintProviderItem;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SubmarketPlugin;
import com.fs.starfarer.api.campaign.SubmarketPlugin.TransferAction;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.util.Misc;

import playerhq.modules.MarketPlaceModule;
import playerhq.util.PlayerHQUtils;

import java.util.ArrayList;
import java.util.List;

public class ShoppingListEngine {

	public static class Result {
		public float spent;
		public int items;
		public List<String> lines = new ArrayList<String>();
		public java.util.Map<String, Integer> bought = new java.util.LinkedHashMap<String, Integer>();

		public void addBought(String name, int count) {
			Integer prev = bought.get(name);
			bought.put(name, (prev == null ? 0 : prev) + count);
		}
	}

	public static int needed(ShopEntry e) {
		if (e.isBuy()) return Math.max(0, e.amount - e.bought);
		return Math.max(0, e.amount - ShopListData.countOwned(e));
	}

	private static boolean stackMatches(CargoStackAPI st, ShopEntry e) {
		if (st == null || st.isNull()) return false;
		if (CatalogItem.WEAPON.equals(e.category)) {
			return st.isWeaponStack() && st.getWeaponSpecIfWeapon() != null
					&& e.itemId.equals(st.getWeaponSpecIfWeapon().getWeaponId());
		}
		if (CatalogItem.WING.equals(e.category)) {
			return st.isFighterWingStack() && st.getFighterWingSpecIfWing() != null
					&& e.itemId.equals(st.getFighterWingSpecIfWing().getId());
		}
		if (CatalogItem.HULLMOD.equals(e.category)) {
			SpecialItemData sd = st.isSpecialStack() ? st.getSpecialDataIfSpecial() : null;
			return sd != null && "modspec".equals(sd.getId()) && e.itemId.equals(sd.getData());
		}
		return false;
	}

	private static boolean isKnownBlueprint(BlueprintProviderItem bp) {
		FactionAPI faction = Global.getSector().getPlayerFaction();
		int count = 0;
		List<String> ships = bp.getProvidedShips();
		if (ships != null) for (String id : ships) {
			count++;
			if (!faction.knowsShip(id)) return false;
		}
		List<String> weapons = bp.getProvidedWeapons();
		if (weapons != null) for (String id : weapons) {
			count++;
			if (!faction.knowsWeapon(id)) return false;
		}
		List<String> fighters = bp.getProvidedFighters();
		if (fighters != null) for (String id : fighters) {
			count++;
			if (!faction.knowsFighter(id)) return false;
		}
		List<String> industries = bp.getProvidedIndustries();
		if (industries != null) for (String id : industries) {
			count++;
			if (!faction.knowsIndustry(id)) return false;
		}
		return count > 0;
	}

	private static boolean shipAcceptable(FleetMemberAPI m, ShopEntry e) {
		if (!e.itemId.equals(m.getHullId())) return false;
		if (!e.acceptDmods && DModManager.getNumDMods(m.getVariant()) > 0) return false;
		return true;
	}

	private static float spendable() {
		float credits = Global.getSector().getPlayerFleet().getCargo().getCredits().get();
		return Math.max(0f, credits - ShopListData.getThreshold());
	}

	private static boolean pay(float price) {
		if (price <= 0f) return true;
		if (price > spendable()) return false;
		Global.getSector().getPlayerFleet().getCargo().getCredits().subtract(price);
		return true;
	}

	private static float spaceCap = -1f;

	private static float roomIn(CargoAPI dest) {
		if (spaceCap >= 0f) return Math.max(0f, spaceCap - dest.getSpaceUsed());
		return dest.getSpaceLeft();
	}

	public static Result buyFrom(SubmarketAPI sub, CargoAPI dest, boolean checkSpace, String where) {
		Result result = new Result();
		if (sub == null || sub.getCargo() == null || dest == null) return result;
		CargoAPI src = sub.getCargo();
		SubmarketPlugin plugin = sub.getPlugin();
		float tariffMult = 1f + (plugin != null ? plugin.getTariff() : 0f);
		List<ShopEntry> entries = ShopListData.getEntries();

		for (ShopEntry e : new ArrayList<ShopEntry>(entries)) {
			if (e.isBlueprint()) {
				int bought = 0;
				float spentOnBlueprints = 0f;
				for (CargoStackAPI st : new ArrayList<CargoStackAPI>(src.getStacksCopy())) {
					if (st == null || st.isNull() || !st.isSpecialStack()) continue;
					if (!(st.getPlugin() instanceof BlueprintProviderItem)) continue;
					if (!e.includeKnown && isKnownBlueprint((BlueprintProviderItem) st.getPlugin())) continue;
					if (plugin != null && plugin.isIllegalOnSubmarket(st, TransferAction.PLAYER_BUY)) continue;
					float unit = st.getBaseValuePerUnit() * tariffMult;
					int qty = (int) st.getSize();
					if (checkSpace && st.getCargoSpacePerUnit() > 0f) {
						qty = Math.min(qty, (int) Math.floor(roomIn(dest) / st.getCargoSpacePerUnit()));
					}
					if (unit > 0f) {
						qty = Math.min(qty, (int) Math.floor(spendable() / unit));
					}
					if (qty <= 0) continue;
					if (!pay(unit * qty)) continue;
					src.removeItems(st.getType(), st.getData(), qty);
					dest.addItems(st.getType(), st.getData(), qty);
					bought += qty;
					spentOnBlueprints += unit * qty;
				}
				if (bought > 0) {
					result.items += bought;
					result.spent += spentOnBlueprints;
					result.addBought("blueprint(s)", bought);
					result.lines.add(bought + "x blueprint(s) for " + Misc.getDGSCredits(spentOnBlueprints) + " credits");
				}
				continue;
			}
			int need = needed(e);
			if (need <= 0) continue;
			int got = 0;
			float spentOnEntry = 0f;

			if (CatalogItem.SHIP.equals(e.category)) {
				if (src.getMothballedShips() == null) continue;
				for (FleetMemberAPI m : src.getMothballedShips().getMembersListCopy()) {
					if (got >= need) break;
					if (!shipAcceptable(m, e)) continue;
					if (plugin != null && plugin.isIllegalOnSubmarket(m, TransferAction.PLAYER_BUY)) continue;
					float price = m.getBaseBuyValue() * tariffMult;
					if (!pay(price)) continue;
					src.getMothballedShips().removeFleetMember(m);
					dest.initMothballedShips(Factions.PLAYER);
					dest.getMothballedShips().addFleetMember(m);
					got++;
					spentOnEntry += price;
				}
			} else {
				for (CargoStackAPI st : new ArrayList<CargoStackAPI>(src.getStacksCopy())) {
					if (got >= need) break;
					if (!stackMatches(st, e)) continue;
					if (plugin != null && plugin.isIllegalOnSubmarket(st, TransferAction.PLAYER_BUY)) continue;
					float unit = st.getBaseValuePerUnit() * tariffMult;
					int qty = Math.min(need - got, (int) st.getSize());
					if (checkSpace && st.getCargoSpacePerUnit() > 0f) {
						qty = Math.min(qty, (int) Math.floor(roomIn(dest) / st.getCargoSpacePerUnit()));
					}
					if (unit > 0f) {
						qty = Math.min(qty, (int) Math.floor(spendable() / unit));
					}
					if (qty <= 0) continue;
					if (!pay(unit * qty)) continue;
					src.removeItems(st.getType(), st.getData(), qty);
					dest.addItems(st.getType(), st.getData(), qty);
					got += qty;
					spentOnEntry += unit * qty;
				}
			}

			if (got > 0) {
				result.items += got;
				result.spent += spentOnEntry;
				result.addBought(e.name, got);
				result.lines.add(got + "x " + e.name + " for " + Misc.getDGSCredits(spentOnEntry) + " credits");
				if (e.isBuy()) {
					e.bought += got;
					if (e.bought >= e.amount) entries.remove(e);
				}
			}
		}
		return result;
	}

	private static void notifyPlayer(Result r, String where) {
		if (r.items <= 0) return;
		Global.getSector().getCampaignUI().addMessage("Shopping List: bought " + r.items + (r.items == 1 ? " item" : " items")
				+ " from " + where + " for " + Misc.getDGSCredits(r.spent) + " credits.");
	}

	public static void autoBuyAtExchange(SectorEntityToken station, SubmarketAPI exchange) {
		if (station == null || exchange == null) return;
		if (!MarketPlaceModule.isBuilt(station)) return;
		if (ShopListData.getEntries().isEmpty()) return;
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage == null) return;
		Result r = buyFrom(exchange, storage, false, "the Exchange");
		if (r.items > 0) {
			MarketPlaceModule.addExchangeSpend(station, r.spent);
			notifyPlayer(r, "the Exchange");
		}
	}

	public static Result autoBuyAtMarket(SectorEntityToken station, CargoAPI fleetCargo, MarketAPI market, float capacity) {
		spaceCap = capacity;
		try {
			return autoBuyAtMarket(station, fleetCargo, market);
		} finally {
			spaceCap = -1f;
		}
	}

	public static Result autoBuyAtMarket(SectorEntityToken station, CargoAPI fleetCargo, MarketAPI market) {
		Result total = new Result();
		if (station == null || market == null || fleetCargo == null) return total;
		if (!MarketPlaceModule.isBuilt(station)) return total;
		if (ShopListData.getEntries().isEmpty()) return total;
		List<SubmarketAPI> subs = new ArrayList<SubmarketAPI>();
		for (SubmarketAPI sub : market.getSubmarketsCopy()) {
			if (sub == null || sub.getPlugin() == null || sub.getCargo() == null) continue;
			if (Submarkets.SUBMARKET_STORAGE.equals(sub.getSpecId())) continue;
			boolean enabled;
			try {
				enabled = sub.getPlugin().isEnabled(null);
			} catch (Throwable t) {
				enabled = !Submarkets.GENERIC_MILITARY.equals(sub.getSpecId());
			}
			if (!enabled) continue;
			subs.add(sub);
		}
		java.util.Collections.sort(subs, new java.util.Comparator<SubmarketAPI>() {
			public int compare(SubmarketAPI a, SubmarketAPI b) {
				return Float.compare(a.getPlugin().getTariff(), b.getPlugin().getTariff());
			}
		});

		for (SubmarketAPI sub : subs) {
			if (ShopListData.getEntries().isEmpty()) break;
			try {
				sub.getPlugin().updateCargoPrePlayerInteraction();
			} catch (Throwable t) { }
			Result r = buyFrom(sub, fleetCargo, true, market.getName());
			total.items += r.items;
			total.spent += r.spent;
			total.lines.addAll(r.lines);
			for (java.util.Map.Entry<String, Integer> b : r.bought.entrySet()) total.addBought(b.getKey(), b.getValue());
		}
		notifyPlayer(total, market.getName());
		return total;
	}
}
