package playerhq.shopping;

import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.PositionAPI;
import com.fs.starfarer.api.ui.TextFieldAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class EditListDelegate extends BaseCustomUIPanelPlugin implements CustomDialogDelegate {

	public interface Listener {
		void onFinished(boolean saved);
	}

	public static final float WIDTH = 960f;
	public static final float HEIGHT = 560f;

	private static final float HEADER_H = 70f;
	private static final String FONT = "graphics/fonts/victor14.fnt";

	private static class Row {
		ShopEntry entry;
		ButtonAPI name;
		int owned;
		ButtonAPI buy;
		ButtonAPI keep;
		ButtonAPI remove;
		ButtonAPI dmods;
		ButtonAPI known;
		ButtonAPI minus1;
		ButtonAPI plus1;
		ButtonAPI plus10;
		TextFieldAPI field;
		String lastText;
	}

	private final Listener listener;
	private final String title;
	private final List<ShopEntry> source;
	private final List<ShopEntry> working = new ArrayList<ShopEntry>();
	private final List<Row> rows = new ArrayList<Row>();
	private CustomPanelAPI panel;
	private PositionAPI panelPosition;
	private CustomPanelAPI listHolder;

	public EditListDelegate(Listener listener) {
		this("Edit Shopping List", ShopListData.getEntries(), listener);
	}

	public EditListDelegate(String title, List<ShopEntry> source, Listener listener) {
		this.listener = listener;
		this.title = title;
		this.source = source;
		for (ShopEntry e : source) working.add(e.copy());
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		this.panel = panel;
		TooltipMakerAPI header = panel.createUIElement(WIDTH - 20f, HEADER_H, false);
		header.addSectionHeading(title, Alignment.MID, 0f);
		header.addPara("Switch Buy/Keep, change the amount, or remove entries. Nothing changes until you press Save.", 6f);
		panel.addUIElement(header).inTL(10f, 8f);
		rebuild();
	}

	private void rebuild() {
		if (listHolder != null) panel.removeComponent(listHolder);
		rows.clear();

		float h = HEIGHT - HEADER_H - 12f;
		CustomPanelAPI holder = panel.createCustomPanel(WIDTH - 20f, h, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI t = holder.createUIElement(WIDTH - 20f, h, true);
		Color base = Misc.getBasePlayerColor();
		Color dark = Misc.getDarkPlayerColor();
		Color bright = Misc.getBrightPlayerColor();

		if (working.isEmpty()) {
			t.addPara("The list is empty.", Misc.getGrayColor(), 10f);
		}
		ButtonAPI previousName = null;
		for (ShopEntry e : working) {
			Row row = new Row();
			row.entry = e;
			int owned = ShopListData.countOwned(e);
			ButtonAPI name = t.addAreaCheckbox(labelFor(e, owned), null, base, dark, bright, 250f, 28f, 4f);
			row.name = name;
			row.owned = owned;
			name.setClickable(false);
			if (previousName != null) name.getPosition().belowLeft(previousName, 4f);
			previousName = name;
			if (e.isBlueprint()) {
				row.known = t.addAreaCheckbox("Include Known", "known", base, dark, bright, 130f, 28f, 0f);
				row.known.getPosition().rightOfMid(name, 10f);
				row.known.setChecked(e.includeKnown);
				row.remove = t.addAreaCheckbox("Remove", "remove", base, dark, bright, 90f, 28f, 0f);
				row.remove.getPosition().rightOfMid(row.known, 10f);
				rows.add(row);
				continue;
			}
			row.buy = t.addAreaCheckbox("Buy X", "buy", base, dark, bright, 80f, 28f, 0f);
			row.buy.getPosition().rightOfMid(name, 10f);
			row.keep = t.addAreaCheckbox("Keep X", "keep", base, dark, bright, 80f, 28f, 0f);
			row.keep.getPosition().rightOfMid(row.buy, 4f);
			row.buy.setChecked(e.isBuy());
			row.keep.setChecked(!e.isBuy());
			row.field = t.addTextField(80f, 28f, FONT, 0f);
			row.field.setMaxChars(4);
			row.field.setText(String.valueOf(e.amount));
			row.field.getPosition().rightOfMid(row.keep, 10f);
			row.lastText = String.valueOf(e.amount);
			row.minus1 = t.addAreaCheckbox("-1", "m1", base, dark, bright, 46f, 28f, 0f);
			row.minus1.getPosition().rightOfMid(row.field, 6f);
			row.plus1 = t.addAreaCheckbox("+1", "p1", base, dark, bright, 46f, 28f, 0f);
			row.plus1.getPosition().rightOfMid(row.minus1, 4f);
			row.plus10 = t.addAreaCheckbox("+10", "p10", base, dark, bright, 52f, 28f, 0f);
			row.plus10.getPosition().rightOfMid(row.plus1, 4f);
			row.remove = t.addAreaCheckbox("Remove", "remove", base, dark, bright, 90f, 28f, 0f);
			row.remove.getPosition().rightOfMid(row.plus10, 10f);
			if (CatalogItem.SHIP.equals(e.category)) {
				row.dmods = t.addAreaCheckbox("Accept D-Mods", "dmods", base, dark, bright, 118f, 28f, 0f);
				row.dmods.getPosition().rightOfMid(row.remove, 6f);
				row.dmods.setChecked(e.acceptDmods);
			}
			rows.add(row);
		}
		holder.addUIElement(t).inTL(0f, 0f);
		panel.addComponent(holder).inTL(10f, HEADER_H + 10f);
		listHolder = holder;
	}

	private static String labelFor(ShopEntry e, int owned) {
		if (e.isBlueprint()) return e.name;
		if (e.isBuy()) return e.name;
		return e.name + "  " + owned + "/" + e.amount;
	}

	@Override
	public void advance(float amountTime) {
		Row removed = null;
		for (Row row : rows) {
			ShopEntry e = row.entry;
			if (row.remove.isChecked()) {
				removed = row;
				break;
			}
			if (row.known != null) {
				if (row.known.isChecked() != e.includeKnown) e.includeKnown = row.known.isChecked();
				String blueprintLabel = labelFor(e, row.owned);
				if (!blueprintLabel.equals(row.name.getText())) row.name.setText(blueprintLabel);
				continue;
			}
			if (row.buy.isChecked() && !e.isBuy()) {
				e.mode = ShopEntry.MODE_BUY;
				e.bought = 0;
			} else if (row.keep.isChecked() && e.isBuy()) {
				e.mode = ShopEntry.MODE_KEEP;
				e.bought = 0;
			}
			row.buy.setChecked(e.isBuy());
			row.keep.setChecked(!e.isBuy());
			if (row.dmods != null && row.dmods.isChecked() != e.acceptDmods) e.acceptDmods = row.dmods.isChecked();

			int delta = 0;
			if (row.minus1.isChecked()) delta = -1;
			if (row.plus1.isChecked()) delta = 1;
			if (row.plus10.isChecked()) delta = 10;
			row.minus1.setChecked(false);
			row.plus1.setChecked(false);
			row.plus10.setChecked(false);
			if (delta != 0) {
				e.amount = Math.max(1, Math.min(9999, e.amount + delta));
				row.lastText = String.valueOf(e.amount);
				row.field.setText(row.lastText);
			}

			String text = row.field.getText() == null ? "" : row.field.getText();
			if (!text.equals(row.lastText)) {
				String digits = text.replaceAll("[^0-9]", "");
				if (!digits.equals(text)) row.field.setText(digits);
				row.lastText = digits;
				if (!digits.isEmpty()) e.amount = Math.max(1, Integer.parseInt(digits));
			}
			String label = labelFor(e, row.owned);
			if (!label.equals(row.name.getText())) row.name.setText(label);
		}
		if (removed != null) {
			working.remove(removed.entry);
			rebuild();
		}
	}

	@Override
	public void positionChanged(PositionAPI position) {
		this.panelPosition = position;
	}

	@Override
	public void renderBelow(float alphaMult) {
		if (panelPosition == null) return;
		Misc.renderQuad(panelPosition.getX(), panelPosition.getY(), panelPosition.getWidth(), panelPosition.getHeight(),
				Color.BLACK, 0.92f * alphaMult);
	}

	@Override
	public boolean hasCancelButton() {
		return true;
	}

	@Override
	public String getConfirmText() {
		return "Save";
	}

	@Override
	public String getCancelText() {
		return "Cancel";
	}

	@Override
	public void customDialogConfirm() {
		for (Row row : rows) {
			if (row.field == null) continue;
			String text = row.field.getText() == null ? "" : row.field.getText().replaceAll("[^0-9]", "");
			if (!text.isEmpty()) row.entry.amount = Math.max(1, Integer.parseInt(text));
		}
		source.clear();
		source.addAll(working);
		listener.onFinished(true);
	}

	@Override
	public void customDialogCancel() {
		listener.onFinished(false);
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return this;
	}
}
