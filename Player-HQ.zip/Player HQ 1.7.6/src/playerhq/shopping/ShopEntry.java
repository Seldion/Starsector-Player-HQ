package playerhq.shopping;

import java.io.Serializable;

public class ShopEntry implements Serializable {

	public static final String MODE_BUY = "BUY";
	public static final String MODE_KEEP = "KEEP";

	public String category;
	public String itemId;
	public String name;
	public String mode;
	public int amount;
	public int bought;
	public boolean acceptDmods;
	public boolean includeKnown;

	public ShopEntry(String category, String itemId, String name, String mode, int amount) {
		this.category = category;
		this.itemId = itemId;
		this.name = name;
		this.mode = mode;
		this.amount = amount;
	}

	public ShopEntry copy() {
		ShopEntry c = new ShopEntry(category, itemId, name, mode, amount);
		c.bought = bought;
		c.acceptDmods = acceptDmods;
		c.includeKnown = includeKnown;
		return c;
	}

	public boolean isBlueprint() {
		return CatalogItem.BLUEPRINT.equals(category);
	}

	public boolean isBuy() {
		return MODE_BUY.equals(mode);
	}
}
