package playerhq.shopping;

import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.PositionAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class SavedListsDelegate extends BaseCustomUIPanelPlugin implements CustomDialogDelegate {

	public interface Listener {
		void onFinished(List<String> names, boolean replace);
	}

	public static final float WIDTH = 900f;
	public static final float HEIGHT = 560f;

	private static final float HEADER_H = 66f;
	private static final float LIST_W = 380f;
	private static final float PREVIEW_W = 480f;
	private static final float FOOTER_H = 50f;

	private final Listener listener;
	public static final int MODE_LOAD = 0;
	public static final int MODE_DELETE = 1;
	public static final int MODE_EDIT = 2;

	private final int mode;
	private final List<SavedLists.SavedList> lists;
	private final List<ButtonAPI> rowButtons = new ArrayList<ButtonAPI>();
	private ButtonAPI replaceButton;
	private ButtonAPI addButton;
	private CustomPanelAPI panel;
	private PositionAPI panelPosition;
	private CustomPanelAPI previewHolder;
	private boolean[] selected;
	private ButtonAPI selectAllButton;
	private ButtonAPI clearButton;
	private boolean replace = true;

	public SavedListsDelegate(int mode, Listener listener) {
		this.mode = mode;
		this.listener = listener;
		this.lists = SavedLists.readAll();
		this.selected = new boolean[lists.size()];
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		this.panel = panel;
		Color base = Misc.getBasePlayerColor();
		Color dark = Misc.getDarkPlayerColor();
		Color bright = Misc.getBrightPlayerColor();

		TooltipMakerAPI header = panel.createUIElement(WIDTH - 20f, HEADER_H, false);
		String headTitle = mode == MODE_DELETE ? "Delete Saved List" : (mode == MODE_EDIT ? "Edit Saved List" : "Load Saved List");
		String headText = mode == MODE_DELETE
				? "Select one or more saved lists and press Delete. This cannot be undone."
				: (mode == MODE_EDIT ? "Select a saved list and press Edit to change its entries."
						: "Select one or more saved lists to preview them, choose how to load them, then press Load.");
		header.addSectionHeading(headTitle, Alignment.MID, 0f);
		header.addPara(headText, 6f);
		panel.addUIElement(header).inTL(10f, 8f);

		float listH = HEIGHT - HEADER_H - FOOTER_H - 20f;
		CustomPanelAPI listHolder = panel.createCustomPanel(LIST_W, listH, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI t = listHolder.createUIElement(LIST_W, listH, true);
		for (int i = 0; i < lists.size(); i++) {
			SavedLists.SavedList l = lists.get(i);
			ButtonAPI b = t.addAreaCheckbox(l.name + "  (" + l.entries.size() + ")", "list" + i, base, dark, bright,
					LIST_W - 24f, 30f, 4f);
			b.setChecked(false);
			rowButtons.add(b);
		}
		listHolder.addUIElement(t).inTL(0f, 0f);
		panel.addComponent(listHolder).inTL(10f, HEADER_H + 14f);

		if (mode != MODE_EDIT) {
		TooltipMakerAPI footer = panel.createUIElement(WIDTH - 20f, 34f, false);
		selectAllButton = footer.addAreaCheckbox("Select all", "all", base, dark, bright, 130f, 28f, 2f);
		selectAllButton.setChecked(false);
		clearButton = footer.addAreaCheckbox("Clear selection", "none", base, dark, bright, 150f, 28f, 0f);
		clearButton.getPosition().rightOfMid(selectAllButton, 8f);
		clearButton.setChecked(false);
		if (mode == MODE_LOAD) {
			replaceButton = footer.addAreaCheckbox("Replace current list", "replace", base, dark, bright, 210f, 28f, 0f);
			replaceButton.getPosition().rightOfMid(clearButton, 40f);
			replaceButton.setChecked(true);
			addButton = footer.addAreaCheckbox("Add to current list", "add", base, dark, bright, 210f, 28f, 0f);
			addButton.getPosition().rightOfMid(replaceButton, 8f);
			addButton.setChecked(false);
		}
		panel.addUIElement(footer).inTL(10f, HEIGHT - FOOTER_H);
		}
		rebuildPreview();
	}

	private void rebuildPreview() {
		if (previewHolder != null) panel.removeComponent(previewHolder);
		float h = HEIGHT - HEADER_H - FOOTER_H - 20f;
		CustomPanelAPI holder = panel.createCustomPanel(PREVIEW_W, h, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI t = holder.createUIElement(PREVIEW_W, h, true);
		if (lists.isEmpty()) {
			t.addPara("There are no saved lists.", Misc.getGrayColor(), 10f);
		} else if (countSelected() == 0) {
			t.addPara("Select saved lists to preview them here.", Misc.getGrayColor(), 10f);
		} else {
			for (int li = 0; li < lists.size(); li++) {
				if (!selected[li]) continue;
				SavedLists.SavedList l = lists.get(li);
				t.addTitle(l.name);
				t.addPara(l.entries.size() + " entries", Misc.getGrayColor(), 4f);
				for (int i = 0; i < l.entries.size(); i++) {
					ShopEntry e = l.entries.get(i);
					boolean known = SavedLists.isKnownItem(e);
					t.addPara((i + 1) + ". " + e.name + " (" + e.category + ")   " + (e.isBlueprint() ? (e.includeKnown ? "unknown and known" : "unknown only") : (e.isBuy() ? "Buy " : "Keep ") + e.amount)
							+ (known ? "" : "   -- not in this game, skipped on load"),
							known ? Misc.getTextColor() : Misc.getNegativeHighlightColor(), 4f);
				}
			}
		}
		holder.addUIElement(t).inTL(0f, 0f);
		panel.addComponent(holder).inTL(LIST_W + 30f, HEADER_H + 14f);
		previewHolder = holder;
	}

	private int countSelected() {
		int n = 0;
		for (boolean b : selected) if (b) n++;
		return n;
	}

	@Override
	public void advance(float amountTime) {
		boolean changed = false;
		if (mode == MODE_EDIT) {
			int keep = -1;
			for (int i = 0; i < rowButtons.size(); i++) {
				if (rowButtons.get(i).isChecked() && !selected[i]) keep = i;
			}
			if (keep >= 0) {
				for (int i = 0; i < rowButtons.size(); i++) rowButtons.get(i).setChecked(i == keep);
			}
		}
		if (selectAllButton != null && selectAllButton.isChecked()) {
			selectAllButton.setChecked(false);
			for (int i = 0; i < selected.length; i++) rowButtons.get(i).setChecked(true);
		}
		if (clearButton != null && clearButton.isChecked()) {
			clearButton.setChecked(false);
			for (int i = 0; i < selected.length; i++) rowButtons.get(i).setChecked(false);
		}
		for (int i = 0; i < rowButtons.size(); i++) {
			boolean now = rowButtons.get(i).isChecked();
			if (now != selected[i]) {
				selected[i] = now;
				changed = true;
			}
		}
		if (changed) rebuildPreview();

		if (replaceButton != null) {
			if (addButton.isChecked() && replace) replace = false;
			else if (replaceButton.isChecked() && !replace) replace = true;
			replaceButton.setChecked(replace);
			addButton.setChecked(!replace);
		}
	}

	@Override
	public void positionChanged(PositionAPI position) {
		this.panelPosition = position;
	}

	@Override
	public void renderBelow(float alphaMult) {
		if (panelPosition == null) return;
		Misc.renderQuad(panelPosition.getX(), panelPosition.getY(), panelPosition.getWidth(), panelPosition.getHeight(),
				Color.BLACK, 0.92f * alphaMult);
	}

	@Override
	public boolean hasCancelButton() {
		return true;
	}

	@Override
	public String getConfirmText() {
		return mode == MODE_DELETE ? "Delete" : (mode == MODE_EDIT ? "Edit" : "Load");
	}

	@Override
	public String getCancelText() {
		return "Cancel";
	}

	@Override
	public void customDialogConfirm() {
		List<String> names = new ArrayList<String>();
		for (int i = 0; i < lists.size(); i++) {
			if (selected[i]) names.add(lists.get(i).name);
		}
		listener.onFinished(names.isEmpty() ? null : names, replace);
	}

	@Override
	public void customDialogCancel() {
		listener.onFinished(null, replace);
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return this;
	}
}
