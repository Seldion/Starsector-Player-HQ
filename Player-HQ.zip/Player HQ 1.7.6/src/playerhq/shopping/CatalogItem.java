package playerhq.shopping;

public class CatalogItem {

	public static final String SHIP = "Ship";
	public static final String WEAPON = "Weapon";
	public static final String WING = "Wing";
	public static final String HULLMOD = "Hull Mod";
	public static final String BLUEPRINT = "Blueprint";
	public static final String BLUEPRINT_ID = "blueprints";

	public final String category;
	public final String id;
	public final String name;
	public final String detail;
	public final String spriteName;
	public final float baseValue;
	public final String filterA;
	public final String filterB;
	public final String searchKey;

	public CatalogItem(String category, String id, String name, String detail, String spriteName, float baseValue) {
		this(category, id, name, detail, spriteName, baseValue, null, null);
	}

	public CatalogItem(String category, String id, String name, String detail, String spriteName, float baseValue,
			String filterA, String filterB) {
		this.filterA = filterA;
		this.filterB = filterB;
		this.category = category;
		this.id = id;
		this.name = name;
		this.detail = detail;
		this.spriteName = spriteName;
		this.baseValue = baseValue;
		this.searchKey = (name + " " + detail + " " + category).toLowerCase();
	}
}
