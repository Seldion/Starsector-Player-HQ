package playerhq.shopping;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

import playerhq.Ids;
import playerhq.util.PlayerHQUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShopListData {

	private static final String KEY = "$playerhq_shoppinglist_entries";
	private static final String THRESHOLD_KEY = "$playerhq_shoppinglist_threshold";

	@SuppressWarnings("unchecked")
	public static List<ShopEntry> getEntries() {
		Map<String, Object> data = Global.getSector().getPersistentData();
		Object o = data.get(KEY);
		if (o instanceof List) return (List<ShopEntry>) o;
		List<ShopEntry> list = new ArrayList<ShopEntry>();
		data.put(KEY, list);
		return list;
	}

	public static float getThreshold() {
		Object o = Global.getSector().getPersistentData().get(THRESHOLD_KEY);
		return o instanceof Float ? (Float) o : 0f;
	}

	public static void setThreshold(float threshold) {
		Global.getSector().getPersistentData().put(THRESHOLD_KEY, Math.max(0f, threshold));
	}

	public static int countOwned(ShopEntry entry) {
		return countOwned(entry.category, entry.itemId);
	}

	public static int countOwned(String category, String itemId) {
		int n = countIn(Global.getSector().getPlayerFleet().getCargo(), category, itemId);
		for (FleetMemberAPI m : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
			if (CatalogItem.SHIP.equals(category) && itemId.equals(m.getHullId())) n++;
		}
		SectorEntityToken station = PlayerHQUtils.findFirstEntityWithTagAnywhere(Ids.TAG_STATION);
		CargoAPI storage = PlayerHQUtils.getStationStorageCargo(station);
		if (storage != null) n += countIn(storage, category, itemId);
		return n;
	}

	private static int countIn(CargoAPI cargo, String category, String itemId) {
		if (cargo == null) return 0;
		if (CatalogItem.WEAPON.equals(category)) return cargo.getNumWeapons(itemId);
		if (CatalogItem.WING.equals(category)) return cargo.getNumFighters(itemId);
		if (CatalogItem.SHIP.equals(category)) {
			int n = 0;
			if (cargo.getMothballedShips() != null) {
				for (FleetMemberAPI m : cargo.getMothballedShips().getMembersListCopy()) {
					if (itemId.equals(m.getHullId())) n++;
				}
			}
			return n;
		}
		int n = 0;
		for (CargoStackAPI stack : cargo.getStacksCopy()) {
			if (stack.isSpecialStack() && stack.getSpecialDataIfSpecial() != null
					&& "modspec".equals(stack.getSpecialDataIfSpecial().getId())
					&& itemId.equals(stack.getSpecialDataIfSpecial().getData())) {
				n += (int) stack.getSize();
			}
		}
		return n;
	}
}
