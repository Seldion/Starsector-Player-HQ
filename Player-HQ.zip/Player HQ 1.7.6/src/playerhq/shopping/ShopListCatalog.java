package playerhq.shopping;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ShopListCatalog {

	private static List<CatalogItem> cache = null;
	private static final Set<String> HULLMOD_BLACKLIST = new HashSet<String>();

	public static List<CatalogItem> getAll() {
		if (cache != null) return cache;
		List<CatalogItem> items = new ArrayList<CatalogItem>();
		addShips(items);
		addWeapons(items);
		addWings(items);
		addHullMods(items);
		items.add(new CatalogItem(CatalogItem.BLUEPRINT, CatalogItem.BLUEPRINT_ID, "Blueprints",
				"buys every blueprint you do not know yet", null, 0f));
		Collections.sort(items, new Comparator<CatalogItem>() {
			public int compare(CatalogItem a, CatalogItem b) {
				return a.name.compareToIgnoreCase(b.name);
			}
		});
		cache = items;
		return items;
	}

	public static List<CatalogItem> search(String category, Set<String> filterA, Set<String> filterB, String query, int max, int[] totalOut) {
		List<CatalogItem> result = new ArrayList<CatalogItem>();
		String[] tokens = query == null ? new String[0] : query.toLowerCase().trim().split("\\s+");
		int total = 0;
		for (CatalogItem item : getAll()) {
			if (category != null && !category.equals(item.category)) continue;
			if (filterA != null && !filterA.isEmpty() && !filterA.contains(item.filterA)) continue;
			if (filterB != null && !filterB.isEmpty() && !filterB.contains(item.filterB)) continue;
			boolean ok = true;
			for (String token : tokens) {
				if (token.length() > 0 && !item.searchKey.contains(token)) {
					ok = false;
					break;
				}
			}
			if (!ok) continue;
			total++;
			if (result.size() < max) result.add(item);
		}
		if (totalOut != null && totalOut.length > 0) totalOut[0] = total;
		return result;
	}

	private static void addShips(List<CatalogItem> items) {
		Set<String> seen = new HashSet<String>();
		for (ShipHullSpecAPI hull : Global.getSettings().getAllShipHullSpecs()) {
			if (hull.isDHull() || hull.hasTag(Tags.NO_DROP)) continue;
			if (hull.getHullSize() == HullSize.FIGHTER || hull.getHullSize() == HullSize.DEFAULT) continue;
			java.util.EnumSet<ShipHullSpecAPI.ShipTypeHints> hints = hull.getHints();
			if (hints != null && (hints.contains(ShipHullSpecAPI.ShipTypeHints.MODULE)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.STATION)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.UNDER_PARENT)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.UNBOARDABLE)
					|| hints.contains(ShipHullSpecAPI.ShipTypeHints.HIDE_IN_CODEX))) continue;
			if (!seen.add(hull.getHullId())) continue;
			String role = hull.isPhase() ? "PHASE" : (hull.isCarrier() ? "CARRIER" : (hull.isCivilianNonCarrier() ? "CIVILIAN" : "WARSHIP"));
			String size = hull.getHullSize().name().toLowerCase().replace("_ship", "");
			String detail = size + " | " + (hull.getDesignation() == null ? "" : hull.getDesignation())
					+ (hull.getManufacturer() == null ? "" : " | " + hull.getManufacturer());
			items.add(new CatalogItem(CatalogItem.SHIP, hull.getHullId(), hull.getHullName(), detail,
					hull.getSpriteName(), hull.getBaseValue(), hull.getHullSize().name(), role));
		}
	}

	private static void addWeapons(List<CatalogItem> items) {
		for (WeaponSpecAPI spec : Global.getSettings().getAllWeaponSpecs()) {
			if (spec.hasTag(Tags.NO_DROP)) continue;
			if (spec.getAIHints() != null && spec.getAIHints().contains(WeaponAPI.AIHints.SYSTEM)) continue;
			WeaponAPI.WeaponType type = spec.getType();
			if (type != WeaponAPI.WeaponType.BALLISTIC && type != WeaponAPI.WeaponType.ENERGY
					&& type != WeaponAPI.WeaponType.MISSILE) continue;
			String sprite = spec.getTurretSpriteName() != null ? spec.getTurretSpriteName() : spec.getHardpointSpriteName();
			String detail = spec.getSize().getDisplayName().toLowerCase() + " " + type.name().toLowerCase()
					+ (spec.getManufacturer() == null ? "" : " | " + spec.getManufacturer());
			items.add(new CatalogItem(CatalogItem.WEAPON, spec.getWeaponId(), spec.getWeaponName(), detail, sprite,
					spec.getBaseValue(), type.name(), spec.getSize().name()));
		}
	}

	private static void addWings(List<CatalogItem> items) {
		for (FighterWingSpecAPI spec : Global.getSettings().getAllFighterWingSpecs()) {
			if (!spec.isRegularFighter() || spec.hasTag(Tags.NO_DROP)) continue;
			String sprite = null;
			try {
				sprite = spec.getVariant().getHullSpec().getSpriteName();
			} catch (Throwable t) { }
			String detail = (spec.getRoleDesc() == null ? "" : spec.getRoleDesc() + " | ") + spec.getNumFighters() + " fighters";
			items.add(new CatalogItem(CatalogItem.WING, spec.getId(), spec.getWingName(), detail, sprite,
					spec.getBaseValue()));
		}
	}

	private static void addHullMods(List<CatalogItem> items) {
		for (HullModSpecAPI spec : Global.getSettings().getAllHullModSpecs()) {
			if (spec.isHidden() || spec.isHiddenEverywhere() || spec.isAlwaysUnlocked()) continue;
			if (spec.hasTag(Tags.HULLMOD_NO_DROP) || spec.hasTag(Tags.HULLMOD_NO_DROP_SALVAGE) || spec.hasTag(Tags.HULLMOD_DMOD)) continue;
			if (HULLMOD_BLACKLIST.contains(spec.getId())) continue;
			String detail = spec.getManufacturer() == null || spec.getManufacturer().isEmpty() ? "hull modification"
					: "hull modification | " + spec.getManufacturer();
			items.add(new CatalogItem(CatalogItem.HULLMOD, spec.getId(), spec.getDisplayName(), detail,
					spec.getSpriteName(), 0f));
		}
	}
}
