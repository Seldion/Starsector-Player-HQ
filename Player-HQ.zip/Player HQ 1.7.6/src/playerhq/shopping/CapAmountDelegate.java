package playerhq.shopping;

import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.PositionAPI;
import com.fs.starfarer.api.ui.TextFieldAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.Color;

public class CapAmountDelegate extends BaseCustomUIPanelPlugin implements CustomDialogDelegate {

	public interface Listener {
		void onFinished(Float amount);
	}

	public static final float WIDTH = 520f;
	public static final float HEIGHT = 210f;
	private static final String FONT = "graphics/fonts/victor14.fnt";

	private final Listener listener;
	private final String initialText;
	private TextFieldAPI field;
	private PositionAPI panelPosition;

	public CapAmountDelegate(float currentCap, Listener listener) {
		this.initialText = currentCap > 0f ? String.valueOf((long) currentCap) : "0";
		this.listener = listener;
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		TooltipMakerAPI t = panel.createUIElement(WIDTH - 20f, HEIGHT - 20f, false);
		t.addSectionHeading("Purchase Threshold", Alignment.MID, 0f);
		t.addPara("Type the credit balance to stay above. Anything that would take you below it will not be purchased. Type 0 for no limit.", 8f);
		field = t.addTextField(WIDTH - 60f, 28f, FONT, 10f);
		field.setMaxChars(12);
		field.setText(initialText);
		panel.addUIElement(t).inTL(10f, 8f);
		field.grabFocus();
	}

	@Override
	public void positionChanged(PositionAPI position) {
		this.panelPosition = position;
	}

	@Override
	public void renderBelow(float alphaMult) {
		if (panelPosition == null) return;
		Misc.renderQuad(panelPosition.getX(), panelPosition.getY(), panelPosition.getWidth(), panelPosition.getHeight(),
				Color.BLACK, 0.92f * alphaMult);
	}

	@Override
	public boolean hasCancelButton() {
		return true;
	}

	@Override
	public String getConfirmText() {
		return "Set";
	}

	@Override
	public String getCancelText() {
		return "Cancel";
	}

	@Override
	public void customDialogConfirm() {
		String raw = field == null || field.getText() == null ? "" : field.getText();
		String digits = raw.replaceAll("[^0-9]", "");
		if (digits.isEmpty()) {
			listener.onFinished(raw.trim().isEmpty() ? Float.valueOf(0f) : null);
			return;
		}
		if (digits.length() > 10) digits = digits.substring(0, 10);
		listener.onFinished(Float.valueOf(Float.parseFloat(digits)));
	}

	@Override
	public void customDialogCancel() {
		listener.onFinished(null);
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return this;
	}
}
