package playerhq.shopping;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCustomUIPanelPlugin;
import com.fs.starfarer.api.campaign.CustomDialogDelegate;
import com.fs.starfarer.api.campaign.CustomUIPanelPlugin;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.ButtonAPI;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.PositionAPI;
import com.fs.starfarer.api.ui.TextFieldAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AddEntryDelegate extends BaseCustomUIPanelPlugin implements CustomDialogDelegate {

	public interface Listener {
		void onFinished(ShopEntry added);
	}

	public static final float WIDTH = 960f;
	public static final float HEIGHT = 690f;

	private static final float HEADER_H = 168f;
	private static final float FOOTER_H = 130f;
	private static final float RESULTS_W = 560f;
	private static final float PREVIEW_W = 350f;
	private static final int COLS = 6;
	private static final int ROWS = 4;
	private static final float CELL = 84f;
	private static final float GAP = 8f;
	private static final float BAR_W = 12f;
	private static final float GRID_W = COLS * CELL + (COLS - 1) * GAP;
	private static final float GRID_H = ROWS * (CELL + GAP);
	private static final String FONT = "graphics/fonts/victor14.fnt";

	private final Listener listener;
	private CustomPanelAPI panel;
	private PositionAPI panelPosition;

	private TextFieldAPI searchField;
	private String lastQuery = "";
	private String category = CatalogItem.SHIP;
	private int maskA = 0;
	private int maskB = 0;
	private String lastFilterCategory = null;
	private ButtonAPI[] groupA = new ButtonAPI[0];
	private ButtonAPI[] groupB = new ButtonAPI[0];
	private CustomPanelAPI filterHolder;
	private ButtonAPI dmodButton = null;
	private boolean acceptDmods = false;
	private boolean includeKnown = false;
	private ButtonAPI knownButton = null;
	private String mode = ShopEntry.MODE_BUY;
	private int amount = 1;
	private CatalogItem selected = null;
	private CatalogItem pendingSelection = null;

	private final Map<String, ButtonAPI> categoryButtons = new LinkedHashMap<String, ButtonAPI>();
	private final Map<String, ButtonAPI> modeButtons = new LinkedHashMap<String, ButtonAPI>();
	private final Map<ButtonAPI, Integer> amountButtons = new LinkedHashMap<ButtonAPI, Integer>();
	private final Map<ButtonAPI, CatalogItem> resultButtons = new LinkedHashMap<ButtonAPI, CatalogItem>();
	private TextFieldAPI amountField;
	private String lastAmountText = "1";
	private LabelAPI selectionInfo;
	private LabelAPI modeInfo;
	private CustomPanelAPI resultsHolder;
	private LabelAPI countLabel;
	private List<CatalogItem> foundItems = new ArrayList<CatalogItem>();
	private int totalFound = 0;
	private int totalRows = 0;
	private int scrollRow = 0;
	private int pendingScrollRow = -1;
	private boolean dragging = false;
	private float dragGrabOffset = 0f;
	private CatalogItem hovered = null;
	private String lastInfo = "";
	private final List<Cell> cells = new ArrayList<Cell>();
	private CustomPanelAPI previewHolder;

	public AddEntryDelegate(Listener listener) {
		this.listener = listener;
	}

	@Override
	public void createCustomDialog(CustomPanelAPI panel, CustomDialogCallback callback) {
		this.panel = panel;
		Color base = Misc.getBasePlayerColor();
		Color dark = Misc.getDarkPlayerColor();
		Color bright = Misc.getBrightPlayerColor();

		TooltipMakerAPI header = panel.createUIElement(WIDTH - 20f, HEADER_H, false);
		header.addSectionHeading("Add Shopping List Entry", Alignment.MID, 0f);
		header.addPara("Search by name (as shown in the Codex), optionally filter by category, then pick an item.", 6f);
		searchField = header.addTextField(420f, 28f, FONT, 8f);
		searchField.setMaxChars(40);
		String[] cats = { CatalogItem.SHIP, CatalogItem.WEAPON, CatalogItem.WING, CatalogItem.HULLMOD, CatalogItem.BLUEPRINT };
		ButtonAPI prev = null;
		for (String cat : cats) {
			ButtonAPI b = header.addAreaCheckbox(cat, cat, base, dark, bright, 100f, 26f, prev == null ? 8f : 0f);
			if (prev != null) b.getPosition().rightOfMid(prev, 8f);
			b.setChecked(cat.equals(category));
			categoryButtons.put(cat, b);
			prev = b;
		}
		panel.addUIElement(header).inTL(10f, 8f);
		searchField.grabFocus();

		float footerTop = HEIGHT - FOOTER_H;
		TooltipMakerAPI controls = panel.createUIElement(WIDTH - 20f, 34f, false);
		ButtonAPI buy = controls.addAreaCheckbox("Buy X", ShopEntry.MODE_BUY, base, dark, bright, 110f, 28f, 2f);
		buy.setChecked(true);
		ButtonAPI keep = controls.addAreaCheckbox("Keep X", ShopEntry.MODE_KEEP, base, dark, bright, 110f, 28f, 0f);
		keep.getPosition().rightOfMid(buy, 8f);
		modeButtons.put(ShopEntry.MODE_BUY, buy);
		modeButtons.put(ShopEntry.MODE_KEEP, keep);

		int[] deltas = { -10, -5, -1 };
		ButtonAPI last = keep;
		for (int d : deltas) {
			ButtonAPI b = controls.addAreaCheckbox(String.valueOf(d), d, base, dark, bright, 52f, 28f, 0f);
			b.getPosition().rightOfMid(last, last == keep ? 30f : 4f);
			amountButtons.put(b, d);
			last = b;
		}
		amountField = controls.addTextField(90f, 28f, FONT, 0f);
		amountField.setMaxChars(4);
		amountField.setText(String.valueOf(amount));
		amountField.getPosition().rightOfMid(last, 4f);
		ButtonAPI prevUp = null;
		int[] ups = { 1, 5, 10 };
		for (int d : ups) {
			ButtonAPI b = controls.addAreaCheckbox("+" + d, d, base, dark, bright, 52f, 28f, 0f);
			b.getPosition().rightOfMid(prevUp == null ? amountField : prevUp, 4f);
			amountButtons.put(b, d);
			prevUp = b;
		}
		panel.addUIElement(controls).inTL(10f, footerTop + 36f);

		TooltipMakerAPI info = panel.createUIElement(WIDTH - 20f, 50f, false);
		selectionInfo = info.addPara("No item selected. Click an icon to select it.", Misc.getHighlightColor(), 2f);
		modeInfo = info.addPara(modeText(), Misc.getGrayColor(), 4f);
		panel.addUIElement(info).inTL(10f, footerTop + 76f);

		TooltipMakerAPI countEl = panel.createUIElement(RESULTS_W, 26f, false);
		countLabel = countEl.addPara("", Misc.getGrayColor(), 2f);
		panel.addUIElement(countEl).inTL(10f, HEADER_H + 4f + GRID_H + 6f);

		buildFilterRow();
		refreshSearch();
		rebuildPreview();
	}

	private String modeText() {
		return ShopEntry.MODE_BUY.equals(mode)
				? "Buy: the fleet buys this many in total, then the entry is removed from the list."
				: "Keep: the fleet buys whenever the station holds fewer than this many. The entry stays on the list.";
	}

	private int maxScrollRow() {
		return Math.max(0, totalRows - ROWS);
	}

	private void refreshSearch() {
		int[] total = new int[1];
		foundItems = ShopListCatalog.search(category, filterKeys(true), filterKeys(false), lastQuery, 100000, total);
		totalFound = total[0];
		totalRows = (foundItems.size() + COLS - 1) / COLS;
		scrollRow = 0;
		dragging = false;
		rebuildGrid();
	}

	private void rebuildGrid() {
		if (resultsHolder != null) panel.removeComponent(resultsHolder);
		cells.clear();
		if (scrollRow > maxScrollRow()) scrollRow = maxScrollRow();
		if (scrollRow < 0) scrollRow = 0;

		CustomPanelAPI holder = panel.createCustomPanel(GRID_W, GRID_H, new BaseCustomUIPanelPlugin());
		int start = scrollRow * COLS;
		for (int i = 0; i < COLS * ROWS && start + i < foundItems.size(); i++) {
			CatalogItem item = foundItems.get(start + i);
			Cell cell = new Cell(item);
			CustomPanelAPI cellPanel = holder.createCustomPanel(CELL, CELL, cell);
			int col = i % COLS;
			int row = i / COLS;
			holder.addComponent(cellPanel).inTL(col * (CELL + GAP), row * (CELL + GAP));
			cells.add(cell);
		}
		panel.addComponent(holder).inTL(10f, HEADER_H + 4f);
		resultsHolder = holder;

		if (countLabel != null) {
			countLabel.setText(totalFound == 0 ? "No matches"
					: totalFound + " items found   (scroll with the mouse wheel or drag the bar)");
		}
	}

	// ---- scrollbar geometry (screen coordinates) ----
	private float gridLeft() { return panelPosition.getX() + 10f; }
	private float gridTop() { return panelPosition.getY() + panelPosition.getHeight() - (HEADER_H + 4f); }
	private float barX() { return gridLeft() + RESULTS_W - BAR_W; }
	private float thumbH() {
		if (totalRows <= ROWS) return GRID_H;
		return Math.max(24f, GRID_H * ROWS / totalRows);
	}
	private float thumbTop() {
		if (totalRows <= ROWS) return gridTop();
		float frac = scrollRow / (float) maxScrollRow();
		return gridTop() - frac * (GRID_H - thumbH());
	}

	private void scrollToThumbTop(float newTop) {
		if (maxScrollRow() <= 0) return;
		float range = GRID_H - thumbH();
		float frac = (gridTop() - newTop) / range;
		frac = Math.max(0f, Math.min(1f, frac));
		pendingScrollRow = Math.round(frac * maxScrollRow());
	}

	private void rebuildPreview() {
		if (previewHolder != null) panel.removeComponent(previewHolder);
		float h = ROWS * (CELL + GAP);
		CustomPanelAPI holder = panel.createCustomPanel(PREVIEW_W, h, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI t = holder.createUIElement(PREVIEW_W, h, false);
		if (selected == null) {
			t.addPara("Select an item from the list to preview it here.", Misc.getGrayColor(), 10f);
		} else {
			t.addTitle(selected.name);
			t.addPara(selected.category + " | " + selected.detail, 6f);
			if (CatalogItem.BLUEPRINT.equals(selected.category)) {
				t.addPara("Whenever the fleet or the Exchange has blueprints you do not know yet, they are bought. Tick Include Known Blueprints to buy the ones you already know as well.", Misc.getHighlightColor(), 6f);
			} else {
				int owned = ShopListData.countOwned(selected.category, selected.id);
				t.addPara("You currently have: " + owned, Misc.getHighlightColor(), 6f);
			}
			if (selected.baseValue > 0f) {
				t.addPara("Base value: " + Misc.getDGSCredits(selected.baseValue), 6f);
			}
			addSprite(t, selected.spriteName);
		}
		holder.addUIElement(t).inTL(0f, 0f);
		panel.addComponent(holder).inTL(RESULTS_W + 30f, HEADER_H + 4f);
		previewHolder = holder;

	}

	private void addSprite(TooltipMakerAPI t, String spriteName) {
		if (spriteName == null || spriteName.isEmpty()) return;
		try {
			Global.getSettings().loadTexture(spriteName);
			SpriteAPI sprite = Global.getSettings().getSprite(spriteName);
			float w = sprite.getWidth();
			float h = sprite.getHeight();
			if (w <= 0f || h <= 0f) return;
			float scale = Math.min(1f, Math.min(200f / w, 200f / h));
			if (w < 64f && h < 64f) scale = Math.min(3f, 96f / Math.max(w, h));
			t.addImage(spriteName, w * scale, h * scale, 14f);
		} catch (Throwable ex) { }
	}

	@Override
	public void advance(float amountTime) {
		if (searchField == null) return;

		String query = searchField.getText();
		if (query == null) query = "";
		boolean rebuild = false;
		if (!query.equals(lastQuery)) {
			lastQuery = query;
			rebuild = true;
		}

		String newCategory = pollRadio(categoryButtons, category);
		if (newCategory != null) {
			category = newCategory;
			maskA = 0;
			maskB = 0;
			rebuild = true;
		}
		String catKey = category;
		if (lastFilterCategory == null || !catKey.equals(lastFilterCategory)) {
			lastFilterCategory = catKey;
			maskA = 0;
			maskB = 0;
			buildFilterRow();
		}
		int newA = readMask(groupA);
		if (newA != maskA) {
			maskA = newA;
			rebuild = true;
		}
		int newB = readMask(groupB);
		if (newB != maskB) {
			maskB = newB;
			rebuild = true;
		}
		if (dmodButton != null && dmodButton.isChecked() != acceptDmods) {
			acceptDmods = dmodButton.isChecked();
		}
		if (knownButton != null && knownButton.isChecked() != includeKnown) {
			includeKnown = knownButton.isChecked();
		}

		String newMode = pollRadio(modeButtons, mode);
		if (newMode != null) {
			mode = newMode;
			modeInfo.setText(modeText());
		}

		String fieldText = amountField.getText() == null ? "" : amountField.getText();
		if (!fieldText.equals(lastAmountText)) {
			String digits = fieldText.replaceAll("[^0-9]", "");
			if (!digits.equals(fieldText)) amountField.setText(digits);
			lastAmountText = digits;
			if (!digits.isEmpty()) amount = Math.max(1, Integer.parseInt(digits));
		}
		for (Map.Entry<ButtonAPI, Integer> e : amountButtons.entrySet()) {
			if (e.getKey().isChecked()) {
				e.getKey().setChecked(false);
				amount = Math.max(1, Math.min(9999, amount + e.getValue()));
				lastAmountText = String.valueOf(amount);
				amountField.setText(lastAmountText);
			}
		}

		if (pendingSelection != null) {
			selected = pendingSelection;
			pendingSelection = null;
			rebuildPreview();
		}

		CatalogItem hoveredNow = null;
		for (Cell c : cells) {
			if (c.hover) {
				hoveredNow = c.item;
				break;
			}
		}
		hovered = hoveredNow;
		String info;
		if (hovered != null) {
			info = "Hovering: " + hovered.name + "   |   " + hovered.category + " | " + hovered.detail;
		} else if (selected != null) {
			info = CatalogItem.BLUEPRINT.equals(selected.category)
					? "Selected: " + selected.name
					: "Selected: " + selected.name + "   |   you currently have "
							+ ShopListData.countOwned(selected.category, selected.id);
		} else {
			info = "No item selected. Click an icon to select it.";
		}
		if (!info.equals(lastInfo)) {
			lastInfo = info;
			selectionInfo.setText(info);
		}

		if (rebuild) {
			pendingScrollRow = -1;
			refreshSearch();
		} else if (pendingScrollRow >= 0) {
			int target = Math.max(0, Math.min(maxScrollRow(), pendingScrollRow));
			pendingScrollRow = -1;
			if (target != scrollRow) {
				scrollRow = target;
				rebuildGrid();
			}
		}
	}

	private static String[] labelsA(String cat) {
		if (CatalogItem.WEAPON.equals(cat)) return new String[] { "Ballistic", "Energy", "Missile" };
		if (CatalogItem.SHIP.equals(cat)) return new String[] { "Frigate", "Destroyer", "Cruiser", "Capital" };
		return new String[0];
	}

	private static String[] labelsB(String cat) {
		if (CatalogItem.WEAPON.equals(cat)) return new String[] { "Small", "Medium", "Large" };
		if (CatalogItem.SHIP.equals(cat)) return new String[] { "Civilian", "Warship", "Carrier", "Phase" };
		return new String[0];
	}

	private static final String[] KEYS_WEAPON_A = { "BALLISTIC", "ENERGY", "MISSILE" };
	private static final String[] KEYS_WEAPON_B = { "SMALL", "MEDIUM", "LARGE" };
	private static final String[] KEYS_SHIP_A = { "FRIGATE", "DESTROYER", "CRUISER", "CAPITAL_SHIP" };
	private static final String[] KEYS_SHIP_B = { "CIVILIAN", "WARSHIP", "CARRIER", "PHASE" };

	private Set<String> filterKeys(boolean first) {
		String[] keys = null;
		if (CatalogItem.WEAPON.equals(category)) keys = first ? KEYS_WEAPON_A : KEYS_WEAPON_B;
		else if (CatalogItem.SHIP.equals(category)) keys = first ? KEYS_SHIP_A : KEYS_SHIP_B;
		int mask = first ? maskA : maskB;
		Set<String> result = new HashSet<String>();
		if (keys == null) return result;
		for (int k = 0; k < keys.length; k++) {
			if ((mask & (1 << k)) != 0) result.add(keys[k]);
		}
		return result;
	}

	private int readMask(ButtonAPI[] buttons) {
		int mask = 0;
		for (int k = 0; k < buttons.length; k++) {
			if (buttons[k] != null && buttons[k].isChecked()) mask |= (1 << k);
		}
		return mask;
	}

	private void buildFilterRow() {
		if (filterHolder != null) panel.removeComponent(filterHolder);
		filterHolder = null;
		dmodButton = null;
		knownButton = null;
		String cat = category == null ? "" : category;
		String[] la = labelsA(cat);
		String[] lb = labelsB(cat);
		groupA = new ButtonAPI[la.length];
		groupB = new ButtonAPI[lb.length];
		if (CatalogItem.BLUEPRINT.equals(category)) {
			CustomPanelAPI bpHolder = panel.createCustomPanel(WIDTH - 20f, 30f, new BaseCustomUIPanelPlugin());
			TooltipMakerAPI bpRow = bpHolder.createUIElement(WIDTH - 20f, 30f, false);
			ButtonAPI k = bpRow.addAreaCheckbox("Include Known Blueprints", "known", Misc.getBasePlayerColor(),
					Misc.getDarkPlayerColor(), Misc.getBrightPlayerColor(), 190f, 26f, 2f);
			k.setChecked(includeKnown);
			knownButton = k;
			bpHolder.addUIElement(bpRow).inTL(0f, 0f);
			panel.addComponent(bpHolder).inTL(10f, HEADER_H - 30f);
			filterHolder = bpHolder;
			return;
		}
		if (la.length == 0 && lb.length == 0) return;

		Color base = Misc.getBasePlayerColor();
		Color dark = Misc.getDarkPlayerColor();
		Color bright = Misc.getBrightPlayerColor();
		CustomPanelAPI holder = panel.createCustomPanel(WIDTH - 20f, 30f, new BaseCustomUIPanelPlugin());
		TooltipMakerAPI row = holder.createUIElement(WIDTH - 20f, 30f, false);
		ButtonAPI last = null;
		for (int k = 0; k < la.length; k++) {
			ButtonAPI b = row.addAreaCheckbox(la[k], "fa" + k, base, dark, bright, 92f, 26f, 2f);
			if (last != null) b.getPosition().rightOfMid(last, 4f);
			b.setChecked(false);
			groupA[k] = b;
			last = b;
		}
		for (int k = 0; k < lb.length; k++) {
			ButtonAPI b = row.addAreaCheckbox(lb[k], "fb" + k, base, dark, bright, 92f, 26f, 2f);
			if (last != null) b.getPosition().rightOfMid(last, k == 0 ? 28f : 4f);
			b.setChecked(false);
			groupB[k] = b;
			last = b;
		}
		if (CatalogItem.SHIP.equals(category) && last != null) {
			ButtonAPI d = row.addAreaCheckbox("Accept D-Mods", "dmods", base, dark, bright, 112f, 26f, 2f);
			d.getPosition().rightOfMid(last, 12f);
			d.setChecked(acceptDmods);
			dmodButton = d;
		}
		holder.addUIElement(row).inTL(0f, 0f);
		panel.addComponent(holder).inTL(10f, HEADER_H - 30f);
		filterHolder = holder;
	}

	private String pollRadio(Map<String, ButtonAPI> buttons, String current) {
		String changedTo = null;
		for (Map.Entry<String, ButtonAPI> e : buttons.entrySet()) {
			if (e.getValue().isChecked() && !e.getKey().equals(current)) {
				changedTo = e.getKey();
				break;
			}
		}
		String active = changedTo != null ? changedTo : current;
		for (Map.Entry<String, ButtonAPI> e : buttons.entrySet()) {
			e.getValue().setChecked(e.getKey().equals(active));
		}
		return changedTo;
	}

	@Override
	public void positionChanged(PositionAPI position) {
		this.panelPosition = position;
	}

	@Override
	public void renderBelow(float alphaMult) {
		if (panelPosition == null) return;
		Misc.renderQuad(panelPosition.getX(), panelPosition.getY(), panelPosition.getWidth(), panelPosition.getHeight(),
				Color.BLACK, 0.92f * alphaMult);
	}

	@Override
	public void render(float alphaMult) {
		if (panelPosition == null || totalRows <= ROWS) return;
		float x = barX();
		Misc.renderQuad(x, gridTop() - GRID_H, BAR_W, GRID_H, Misc.getDarkPlayerColor(), 0.7f * alphaMult);
		Color thumb = dragging ? Misc.getBrightPlayerColor() : Misc.getBasePlayerColor();
		float th = thumbH();
		Misc.renderQuad(x + 1f, thumbTop() - th + 1f, BAR_W - 2f, th - 2f, thumb, alphaMult);
	}

	@Override
	public void processInput(List<InputEventAPI> events) {
		for (Cell c : cells) c.processInput(events);
		if (panelPosition == null || totalRows <= ROWS) return;

		float left = gridLeft();
		float top = gridTop();
		float bottom = top - GRID_H;
		float bx = barX();

		for (InputEventAPI e : events) {
			if (e.isConsumed()) continue;
			float mx = e.getX();
			float my = e.getY();
			boolean inResults = mx >= left && mx <= left + RESULTS_W && my >= bottom && my <= top;

			if (e.isMouseScrollEvent() && inResults) {
				int base = pendingScrollRow >= 0 ? pendingScrollRow : scrollRow;
				int dir = e.getEventValue() > 0 ? -1 : 1;
				pendingScrollRow = Math.max(0, Math.min(maxScrollRow(), base + dir));
				e.consume();
				continue;
			}
			if (e.isLMBDownEvent() && mx >= bx && mx <= bx + BAR_W && my >= bottom && my <= top) {
				float tt = thumbTop();
				float th = thumbH();
				if (my <= tt && my >= tt - th) {
					dragging = true;
					dragGrabOffset = tt - my;
				} else {
					int base = pendingScrollRow >= 0 ? pendingScrollRow : scrollRow;
					int dir = my > tt ? -1 : 1;
					pendingScrollRow = Math.max(0, Math.min(maxScrollRow(), base + dir * ROWS));
				}
				e.consume();
				continue;
			}
			if (dragging && e.isMouseEvent()) {
				if (e.isLMBUpEvent()) {
					dragging = false;
				} else {
					scrollToThumbTop(my + dragGrabOffset);
				}
				e.consume();
			}
		}
	}

	@Override
	public boolean hasCancelButton() {
		return true;
	}

	@Override
	public String getConfirmText() {
		return "Add to List";
	}

	@Override
	public String getCancelText() {
		return "Cancel";
	}

	@Override
	public void customDialogConfirm() {
		ShopEntry entry = null;
		String finalText = amountField.getText() == null ? "" : amountField.getText().replaceAll("[^0-9]", "");
		if (!finalText.isEmpty()) amount = Math.max(1, Integer.parseInt(finalText));
		if (selected != null) {
			entry = new ShopEntry(selected.category, selected.id, selected.name, mode, amount);
			entry.acceptDmods = CatalogItem.SHIP.equals(selected.category) && acceptDmods;
			if (CatalogItem.BLUEPRINT.equals(selected.category)) {
				entry.includeKnown = includeKnown;
				entry.mode = ShopEntry.MODE_KEEP;
			}
		}
		listener.onFinished(entry);
	}

	@Override
	public void customDialogCancel() {
		listener.onFinished(null);
	}

	@Override
	public CustomUIPanelPlugin getCustomPanelPlugin() {
		return this;
	}

	private class Cell extends BaseCustomUIPanelPlugin {
		final CatalogItem item;
		PositionAPI pos;
		boolean hover = false;
		SpriteAPI sprite;

		Cell(CatalogItem item) {
			this.item = item;
			if (item.spriteName != null && !item.spriteName.isEmpty()) {
				try {
					Global.getSettings().loadTexture(item.spriteName);
					sprite = Global.getSettings().getSprite(item.spriteName);
				} catch (Throwable t) {
					sprite = null;
				}
			}
		}

		@Override
		public void positionChanged(PositionAPI position) {
			this.pos = position;
		}

		@Override
		public void renderBelow(float alphaMult) {
			if (pos == null) return;
			boolean isSelected = item == selected;
			Color base = Misc.getBasePlayerColor();
			Color border = isSelected ? Misc.getBrightPlayerColor() : (hover ? base : Misc.getDarkPlayerColor());
			float x = pos.getX();
			float y = pos.getY();
			float w = pos.getWidth();
			float h = pos.getHeight();
			Misc.renderQuad(x, y, w, h, border, alphaMult * (isSelected ? 1f : 0.9f));
			Color fill = isSelected ? Misc.getDarkPlayerColor() : new Color(8, 14, 20);
			Misc.renderQuad(x + 2f, y + 2f, w - 4f, h - 4f, fill, alphaMult);
		}

		@Override
		public void render(float alphaMult) {
			if (pos == null || sprite == null) return;
			float sw = sprite.getWidth();
			float sh = sprite.getHeight();
			if (sw <= 0f || sh <= 0f) return;
			float box = pos.getWidth() - 14f;
			float scale = Math.min(box / sw, box / sh);
			if (sw < 48f && sh < 48f) scale = Math.min(scale, 2.5f);
			sprite.setSize(sw * scale, sh * scale);
			sprite.setAlphaMult(alphaMult);
			sprite.renderAtCenter(pos.getCenterX(), pos.getCenterY());
		}

		@Override
		public void processInput(List<InputEventAPI> events) {
			if (pos == null) return;
			for (InputEventAPI e : events) {
				if (e.isConsumed()) continue;
				if (e.isMouseEvent()) {
					hover = pos.containsEvent(e);
				}
				if (e.isLMBDownEvent() && pos.containsEvent(e)) {
					pendingSelection = item;
					e.consume();
				}
			}
		}
	}
}
