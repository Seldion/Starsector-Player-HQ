package playerhq.shopping;

import com.fs.starfarer.api.Global;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SavedLists {

	public static final String FILE = "playerhq_shopping_lists.json";

	public static class SavedList {
		public String name;
		public List<ShopEntry> entries = new ArrayList<ShopEntry>();
	}

	public static List<SavedList> readAll() {
		List<SavedList> result = new ArrayList<SavedList>();
		try {
			if (!Global.getSettings().fileExistsInCommon(FILE)) return result;
			String text = Global.getSettings().readTextFileFromCommon(FILE);
			if (text == null || text.trim().isEmpty()) return result;
			JSONObject root = new JSONObject(text);
			JSONArray lists = root.optJSONArray("lists");
			if (lists == null) return result;
			for (int i = 0; i < lists.length(); i++) {
				JSONObject o = lists.getJSONObject(i);
				SavedList list = new SavedList();
				list.name = o.getString("name");
				JSONArray arr = o.optJSONArray("entries");
				if (arr != null) {
					for (int j = 0; j < arr.length(); j++) {
						JSONObject e = arr.getJSONObject(j);
						ShopEntry loaded = new ShopEntry(e.getString("category"), e.getString("itemId"), e.getString("name"),
								e.getString("mode"), Math.max(1, e.getInt("amount")));
						loaded.includeKnown = e.optBoolean("includeKnown", false);
						list.entries.add(loaded);
					}
				}
				result.add(list);
			}
		} catch (Throwable t) {
			Global.getLogger(SavedLists.class).warn("Could not read saved shopping lists", t);
		}
		return result;
	}

	public static boolean writeAll(List<SavedList> lists) {
		try {
			JSONArray arr = new JSONArray();
			for (SavedList list : lists) {
				JSONObject o = new JSONObject();
				o.put("name", list.name);
				JSONArray entries = new JSONArray();
				for (ShopEntry e : list.entries) {
					JSONObject eo = new JSONObject();
					eo.put("category", e.category);
					eo.put("itemId", e.itemId);
					eo.put("name", e.name);
					eo.put("mode", e.mode);
					eo.put("amount", e.amount);
					eo.put("includeKnown", e.includeKnown);
					entries.put(eo);
				}
				o.put("entries", entries);
				arr.put(o);
			}
			JSONObject root = new JSONObject();
			root.put("lists", arr);
			Global.getSettings().writeTextFileToCommon(FILE, root.toString(2));
			return true;
		} catch (Throwable t) {
			Global.getLogger(SavedLists.class).warn("Could not write saved shopping lists", t);
			return false;
		}
	}

	public static boolean save(String name, List<ShopEntry> entries) {
		List<SavedList> all = readAll();
		SavedList target = null;
		for (SavedList l : all) {
			if (l.name.equalsIgnoreCase(name)) {
				target = l;
				break;
			}
		}
		if (target == null) {
			target = new SavedList();
			all.add(target);
		}
		target.name = name;
		target.entries = new ArrayList<ShopEntry>();
		for (ShopEntry e : entries) {
			ShopEntry c = e.copy();
			c.bought = 0;
			target.entries.add(c);
		}
		return writeAll(all);
	}

	public static boolean delete(String name) {
		List<SavedList> all = readAll();
		for (int i = 0; i < all.size(); i++) {
			if (all.get(i).name.equalsIgnoreCase(name)) {
				all.remove(i);
				return writeAll(all);
			}
		}
		return true;
	}

	public static boolean exists(String name) {
		for (SavedList l : readAll()) {
			if (l.name.equalsIgnoreCase(name)) return true;
		}
		return false;
	}

	public static boolean isKnownItem(ShopEntry e) {
		for (CatalogItem item : ShopListCatalog.getAll()) {
			if (item.category.equals(e.category) && item.id.equals(e.itemId)) return true;
		}
		return false;
	}
}
