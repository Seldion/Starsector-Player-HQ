package playerhq;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.PlayerHQStationCMD;
import playerhq.modules.AssemblyBayModule;

import java.util.Map;

public class PlayerHQRemoteProductionDialogPlugin implements InteractionDialogPlugin {

	private static final String OPTION_DONE = "playerhq_remote_production_done";

	private final SectorEntityToken station;

	private InteractionDialogAPI dialog;
	private TextPanelAPI text;
	private OptionPanelAPI options;
	private CampaignFleetAPI playerFleet;

	// Set when the Strategic Assembly isn't available at all -- the dialog just shows a
	// message and a "Continue" button in that case, and never touches the picker below.
	private boolean unavailable = false;

	private boolean pickerRequested = false;

	private static volatile long lastPingMillis = 0L;
	private static volatile int pingCount = 0;
	private int pingsAtShow = 0;
	private int silentTicks = 0;

	public static void ping() {
		lastPingMillis = System.currentTimeMillis();
		pingCount++;
	}

	public PlayerHQRemoteProductionDialogPlugin(SectorEntityToken station) {
		this.station = station;
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		this.dialog = dialog;
		this.text = dialog.getTextPanel();
		this.options = dialog.getOptionPanel();

		if (station == null || !station.isAlive() || !AssemblyBayModule.isBuilt(station)) {
			text.addPara("The Strategic Assembly is not available.");
			options.addOption("Continue", OPTION_DONE);
			unavailable = true;
			return;
		}

		playerFleet = Global.getSector().getPlayerFleet();
		options.addOption("Done", OPTION_DONE);
	}

	@Override
	public void optionSelected(String optionText, Object optionData) {
		if (OPTION_DONE.equals(optionData)) {
			dialog.dismiss();
		}
	}

	@Override
	public void optionMousedOver(String optionText, Object optionData) { }

	@Override
	public void advance(float amount) {
		if (unavailable) return;

		if (!pickerRequested) {
			// First tick after init() -- the dialog has now settled in, so it's safe to hand
			// control over to the picker.
			pickerRequested = true;
			dialog.showCustomProductionPicker(
					new PlayerHQStationCMD.PlayerHQProductionPickerDelegate(station, playerFleet, text));
			pingsAtShow = pingCount;
			return;
		}

		if (pingCount - pingsAtShow < 30) return;

		if (System.currentTimeMillis() - lastPingMillis > 100L) {
			silentTicks++;
			if (silentTicks >= 3) {
				dialog.dismiss();
			}
		} else {
			silentTicks = 0;
		}
	}

	@Override
	public void backFromEngagement(EngagementResultAPI battleResult) { }

	@Override
	public Object getContext() {
		return null;
	}

	@Override
	public Map<String, MemoryAPI> getMemoryMap() {
		return null;
	}
}
