package playerhq.nex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.comm.IntelInfoPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.util.Misc;
import exerelin.campaign.intel.groundbattle.GroundBattleIntel;
import exerelin.campaign.intel.groundbattle.GroundBattleSide;
import exerelin.campaign.intel.groundbattle.GroundUnit;
import exerelin.campaign.intel.groundbattle.GroundUnitDef;
import exerelin.campaign.intel.groundbattle.IndustryForBattle;
import playerhq.modules.StationMarineDefense;

public class NexMarineDefense {

	private static final String KEY_ACTIVE = "$playerhq_nexBattleActive";
	private static final String KEY_UNITS = "$playerhq_nexUnitSizes";
	private static final String KEY_LOSS_TOTAL = "$playerhq_nexLossTotal";

	private static GroundBattleIntel cachedIntel = null;

	public static void advance(SectorEntityToken station, MarketAPI market, CargoAPI storage) {
		MemoryAPI mem = station.getMemoryWithoutUpdate();

		Object trackedObj = mem.get(KEY_UNITS);
		if (trackedObj instanceof Map && !((Map<?, ?>) trackedObj).isEmpty()) {
			reconcile(mem, market, storage, castMap(trackedObj));
		}

		GroundBattleIntel ongoing = GroundBattleIntel.getOngoing(market);
		if (ongoing == null) {
			mem.unset(KEY_ACTIVE);
			return;
		}
		if (mem.getBoolean(KEY_ACTIVE)) return;
		mem.set(KEY_ACTIVE, true);

		reinforce(mem, market, storage, ongoing);
	}

	@SuppressWarnings("unchecked")
	private static Map<String, Integer> castMap(Object o) {
		return (Map<String, Integer>) o;
	}

	private static void reinforce(MemoryAPI mem, MarketAPI market, CargoAPI storage, GroundBattleIntel intel) {
		if (storage == null) return;
		int marines = storage.getMarines();
		if (marines < 2) return;

		GroundBattleSide defender = intel.getSide(false);
		if (defender == null) return;

		Set<String> before = new HashSet<String>();
		for (GroundUnit unit : defender.getUnits()) before.add(unit.id);

		defender.createUnits(GroundUnitDef.MARINE, marines);

		List<GroundUnit> created = new ArrayList<GroundUnit>();
		for (GroundUnit unit : defender.getUnits()) {
			if (!before.contains(unit.id) && !unit.isPlayer()) created.add(unit);
		}
		if (created.isEmpty()) return;

		List<IndustryForBattle> priority = new ArrayList<IndustryForBattle>(intel.getIndustries());
		Collections.sort(priority, GroundBattleSide.PRIORITY_SORT);
		if (!priority.isEmpty()) {
			for (int i = 0; i < created.size(); i++) {
				created.get(i).setLocation(priority.get(i % priority.size()));
			}
		}

		Map<String, Integer> tracked = new HashMap<String, Integer>();
		int total = 0;
		for (GroundUnit unit : created) {
			tracked.put(unit.id, unit.getMarines());
			total += unit.getMarines();
		}
		mem.set(KEY_UNITS, tracked);
		mem.set(KEY_LOSS_TOTAL, 0);
		cachedIntel = intel;

		StationMarineDefense.sendMessage(total + " marines stationed at Player HQ joined the defense of "
				+ market.getName() + ".", Misc.getHighlightColor());
	}

	private static void reconcile(MemoryAPI mem, MarketAPI market, CargoAPI storage, Map<String, Integer> tracked) {
		GroundBattleIntel owner = null;
		if (cachedIntel != null && cachedIntel.getMarket() == market) owner = cachedIntel;

		Map<String, GroundUnit> found = new HashMap<String, GroundUnit>();
		if (owner == null) {
			for (IntelInfoPlugin p : Global.getSector().getIntelManager().getIntel(GroundBattleIntel.class)) {
				GroundBattleIntel gbi = (GroundBattleIntel) p;
				if (gbi.getMarket() != market) continue;
				for (GroundUnit unit : gbi.getSide(false).getUnits()) {
					if (tracked.containsKey(unit.id)) {
						found.put(unit.id, unit);
						owner = gbi;
					}
				}
				if (owner != null) break;
			}
		} else {
			for (GroundUnit unit : owner.getSide(false).getUnits()) {
				if (tracked.containsKey(unit.id)) found.put(unit.id, unit);
			}
		}

		if (owner == null) {
			clear(mem);
			return;
		}

		Map<String, Integer> updated = new HashMap<String, Integer>();
		int previousTotal = 0;
		int currentTotal = 0;
		for (Map.Entry<String, Integer> e : tracked.entrySet()) {
			previousTotal += e.getValue();
			GroundUnit unit = found.get(e.getKey());
			int now = unit == null ? 0 : unit.getMarines();
			if (now > 0) {
				updated.put(e.getKey(), now);
				currentTotal += now;
			}
		}

		int lost = previousTotal - currentTotal;
		if (lost > 0) {
			if (storage != null) storage.removeMarines(Math.min(lost, storage.getMarines()));
			mem.set(KEY_LOSS_TOTAL, mem.getInt(KEY_LOSS_TOTAL) + lost);
		}

		boolean ended = owner.isEnded() || owner.isEnding() || owner.getOutcome() != null;
		if (ended) {
			int totalLost = mem.getInt(KEY_LOSS_TOTAL);
			if (totalLost > 0) {
				StationMarineDefense.sendMessage(totalLost + (totalLost == 1 ? " marine" : " marines")
						+ " from Player HQ died defending " + market.getName() + ".", Misc.getNegativeHighlightColor());
			}
			clear(mem);
		} else {
			mem.set(KEY_UNITS, updated);
		}
	}

	private static void clear(MemoryAPI mem) {
		mem.unset(KEY_UNITS);
		mem.unset(KEY_LOSS_TOTAL);
		cachedIntel = null;
	}
}
